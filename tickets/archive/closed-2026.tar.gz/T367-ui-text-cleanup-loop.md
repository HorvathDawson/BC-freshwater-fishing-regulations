# T367 — UI text clean-up, owner back-and-forth (regs, conditions map, More)

Status: DONE (d3577f2e3) 2026-11-04, owner call (was: OPEN, batch 6b of RELEASE-PLAN-0.5.0.md). Leftovers → T377;
the SalmonCard caveat block → T372 part 2.

| id | title | status | commits | what's left |
|---|---|---|---|---|
| T367 | UI text clean-up as an owner back-and-forth (regs, conditions map, More): bad formatting, debloat top-level text; dev web app first, then the 0.5.0 APK | DONE 11-04 (owner call; leftovers → T377) | d3577f2e3 | owner 2026-11-03 (batch 6b) |

Why: the owner wants a clean-up pass mostly in the regs pane, the conditions map pane and More: badly formatted text,
and much less top-level text (debloat what shows before you tap in).

## How it runs (owner: "a back and forth item")
A loop, one round per owner note:
1. The owner says what bothers them (screen + what it should be).
2. Claude writes a short plan for that note (what changes, which file, any data-side cause).
3. Claude fixes it on the dev web app; the owner checks it there.
4. Repeat until the owner calls it done.

Only then does it go into the 0.5.0 APK (the one APK for the batch). No APK per round.

## Notes
- Text that comes from the data (rule wording, place names) is shown as sourced. A fix to its formatting is a display
  change; rewording or dropping content needs the owner's yes (ask-before-filtering rule).
- Keep a running list of the rounds here (note → fix → owner verdict).

## Rounds
- 0 (2026-11-03): regs loading spinner sat in the pane's top corner → centred, large size (0db30c2). Owner: OK.
- 1 (11-03): the gentle access note was raw grey text with a "See the map" link → its own block in the accent (not the
  amber), titled "Access may be restricted"; both map links dropped (they moved to the map without highlighting the
  area). Superseded by round 3.
- 2 (11-03): Runs tab: species chips → the spawning picture; the "made for another map" line → a visible bar on the map.
  Planned, not yet built. Cause of the stale run timing: the feed was built 10-29 for handles 10cbcb72…, the release's
  tiles are 822db448… (regs paint and conditions ship IN the release, so they always match) — owner sent it to the
  pipeline chat.
- 3 (11-03): (a) access → slim strips PINNED under the regs header, outside the scroll: amber "No public access ·
  <area>" and accent "Access may be restricted · <causes>", one line each, a tap opens the sentence. Both show at once
  (core `accessNotices` / `leadingAccessNotices`: the reserve is no longer hidden by the watershed). Banner wording
  shortened: "… is in X, closed to the public. The regulations below don't give you access." (b) forecast chips named
  by date ("Wed 4"), every day +1..+10 (T375's feed), the strip scrolls sideways (`CornerStrip scroll`); spoken labels
  unchanged. Verdict pending.
- 4 (11-04): the strip's dotted swatch read as "…" → removed. Round 2 built: Runs species chips show the spawning
  picture; a stale/failed run timing is an amber bar over the map (`PairBanner`, `col.runsProblem`, Runs tab only),
  no longer a grey line in the foot; words "Run timing is out of date for this map, so it isn't drawn." Verdict pending.
- 5 (11-04): ten dated chips pushed Change out of sight → `HorizonPicker` (map corner + panel header): Now · Forecast ▾
  (or the chosen day, filled) · Change; the middle opens the ten days under the strip, a pick closes it. The strip's
  scroll option is gone. Verdict pending.
- 5b (11-04): the day list stays open after a pick (6533a714c); then (owner: "big shift") ONE scrolling row under the
  strip, the tile's heading top-aligned beside it. Change in the panel is a plain segment with its word.
- 6 (11-04): Conditions as ONE gauge card: title = the gauge (▾ opens the gauges list, replacing the station-code chips),
  the reading, toggles on the title row, chart, legend (models are legend entries; the caption and model selector are
  gone), foot = when it was read.
- 7 (11-04): the estimate as a bordered tile (status dot + scale bar on the map's ramp, quiet sentence/range); toggles
  as joined segments; the figure in the display face, standing sentence case with a dot; one row over the plot (unit,
  readout/hint, zoom); chart 180–240 tall. Owner: OK apart from the strip (5b).
- 8 (11-04): map chrome: the day as ‹ · 📅 day · › (top-left); Trout & more | Salmon heads the Map tab's legend bar;
  the Runs species in the Runs bar (All, tap, long-press = only), the histogram stacked by species colour
  (`palette.runSpecies`, tokens `color.ui.run-species.*` from the other chat, which also passed `fishImages` to
  `RunsLegend` in Shell.tsx). The web Spots notice centred. The Conditions view shows the part's place row and both
  access notices, as the Regulations view does (`useWaterPlace`). Tests re-pinned (test files only).
- 9 (11-04): Change — the tile's colour bar back on the change ramp (`scale.ramp`); ONE Change chart in the gauge card
  (×today gridlines, 1× solid, the station's line bold with its peak marked, each model thin, T157's handover break and
  tick kept) in place of the sparkline AND the flow chart under it; the station's line opens on what happens ("Rises to
  about 4× … (52nd percentile, about normal for the time of year) …"), the models in one note ("Models: CLEVER rises
  to 4× (Tue) · COFFEE little change"); the end's percentile said whenever the station has a record. Verdict pending.

## State at the end of the first UI chat (2026-11-04)
Rounds 0–9 committed. Owner verdicts still to give on the dev web app: 3–9 (5b/7 noted OK in part).
Open, for the next UI chat (start from `handoff/PLAN/NEXT-SESSION-UI.md`):
- The forecast-day list by watershed (owner idea, round 3 A2): waits on the data chat's hook — the basin the browse map is
  centred on, a water's own basin, and basin names (the note was sent). Then: a list of days with each day's standing
  for that basin (`basinStandings`), tap a day to show it; browse uses the centre, a water its own basin, no fallback.
- From the map-UI research (unverified sources): a tappable legend (tap a class to isolate it), a collapsible legend
  bar, peak markers on the Runs histogram, a second cue besides colour for closed / open.
- The hydrograph draws one model at a time (its legend entries pick it); drawing several at once needs chart logic.
- Dead code left: `changeSpark` / `ChangeRunVM.spark` (always null now) and core `mapDayChips` are no longer drawn.
- Not this chat's: `packages/core/src/salmonFeed.test.ts` was re-pinned by the UI chat's test sweep to the data chat's
  uncommitted `salmonFeed.ts` (T372: an undrawn DFO place no longer paints "check"); the data chat commits it with that
  change, or reverts it if the change does not land.
- Open (not this chat's): `WaterScreen.regs-props.test.tsx` (fixture release, T35 Licence) ×2 and `WaterMode.test.tsx`
  (ONE MAP ENTRY) fail on HEAD without the round 3 edits too — the page shows the spinner after the keep tab appeared.

Start a UI chat from `handoff/PLAN/NEXT-SESSION-UI.md`.

## From T343 (2026-11-03, data chat → UI chat)
Two salmon-card items are yours (presentational files): (a) the COLLAPSED salmon section shows one image, the
ocean-phase chinook (`app/apps/mobile/assets/fish/chinook-salmon-ocean-phase.webp`); OPENED, each species row uses its
own `<species>-salmon-spawning-phase.webp`. (b) The DFO source info (page link, date modified, notice numbers) is one
collapsible line, collapsed by default; opened it shows the full source details. The view model is unchanged (core
`salmonCard`: `source`, `asOf`, `credit`, `dfoWords`).
(c) T343: draw the salmon card's new `hours` line (core `salmonCard(...).hours`, e.g. "Salmon fishing in daylight only:
one hour before sunrise to one hour after sunset"; null when all closed) near the gear line. Then tell the data chat (or
change core `salmon.ts` `asWords`: drop `n.fold === "hours" ||`) so the daylight note leaves the region block. Before 0.5.0.
(d) Forecast day chips: the every-day feed (+2, +4, +6–9) is the DATA chat's, T375. Build the chips on the days the feed
carries (by date); the rest fill in when T375 lands.
(e) T375 LANDED in the code (2026-11-03): `FORECAST_DAYS` is now [1..10] (core gauge-policy.generated.ts). Your ui tests
that pin the four days fail until updated with your chips: conditions.render (donorView ×2), MapScreen corner ×2, the
Change chip ×2 ("after +10" still holds: +10 is last). The live feed carries every day after the feeds worker redeploy.
(f) Forecast-day list: the centre basin, a water's own basin and the basin names are the data chat's, T376 (batch 4).
(g) Run timing (your 11-03 finding): FIXED 2026-11-04 (T373) — the local feed is bound to 822db448 again (reload the dev app); every release now binds its own.
(h) Your two asks (2026-11-04), DONE IN YOUR WORKING TREE, uncommitted — commit them with your files (they share them):
  `Shell.tsx` passes `fishImages={p.fishImages}` to `<RunsLegend>`; `shell/MapLegend.tsx` `RunsLegend` takes `fishImages`
  and hands it to `RunSpeciesChips`. The six species colours are tokens now — `color.ui.run-species.<steelhead|chinook|
  chum|coho|pink|sockeye>` (in `color.ui.*`, not `color.runs.*`: card colours, not map paint, so the map's ΔE guard does
  not compare them with the lake fill and the run-pass amber — it failed the style build as `color.runs.*`). `theme.ts`:
  `Palette.runSpecies[name]` from those tokens; `RUN_SPECIES_COLOUR` is gone; `RunsControls.tsx` + `MapLegend.tsx` read
  `palette.runSpecies[s.name]`. The tokens are committed (data chat); tsc + check-colours pass.
  Also yours, failing on your in-progress work: panel.silent (new `title`), the gauge reading's band words ("Below normal
  ·"), data-vs-ui's frozen list, back-layers, and the T375 horizon tests listed in (e).
(i) Full app suite 2026-11-04 (data chat fixed its own: T375 tests, run-species tokens, the release pins on r-ac5a4e4f734c,
  map-gestures). Failing on YOUR uncommitted work: check-platform (`regs/AccessNoticeBlock.tsx` uses `accessibilityState`),
  one-button (`HorizonPicker.tsx`), one-donor-state, back-layers, data-vs-ui (frozen list), adipose-shots / fish-looks-layout /
  fish-looks-shots, panel.silent (`title`), conditions.test (band words), and the (e) horizon tests.
