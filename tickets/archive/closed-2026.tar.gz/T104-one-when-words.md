# T104 — One "when" in words: titles and plain lines drop hours and weekdays

Status: DONE — 677158f80, 92cba91f0 (review: `DateRange.words` also calls `when_words`). Answers diff: 7 titles + 9
plains (Campbell, Nicomekl, Serpentine, Harrison, Pitt, Slocan, Fraser above Mission title only (no plain: a gate);
Lower West Arm r3 r4 r5 plains); card gate 0 problems. Rebuild: deliver. Left: owner questions below.

| id | title | status | commits | what's left |
|---|---|---|---|---|
| T104 | one "when" in words: titles/plain drop hours and weekdays | DONE | 677158f8, 92cba91f, 671eabad | live after the next deliver; Q64–Q65 |

Source: owner 2026-10-22 (unify checks that decide the same thing); unification audit 2026-10-22, finding 2
(CONFIRMED on `ui-rules-export.json` / `ui-rules-answers.json`).

## Decision being unified
"How is a rule's `when` (dates, weekdays, hours, unparsed seasons) said in words?"

## Where it is decided today
- `pipeline/deliver/answers/display.py:272` `_plain`: dates only.
- `pipeline/deliver/answers/display.py:382-387` `_title`: dates and weekdays, no hours.
- `pipeline/deliver/answers/labels.py:301` `_when_words`: everything.
- `pipeline/deliver/answers/rows.py:2204-2234`: four more weekday wordings.

How they differ:
- Campbell River's export has `when.hours` 21:00–05:00, but the shipped title and plain both say "No fishing, Aug 1–Dec
  31". Nicomekl and Serpentine are the same. A night closure reads as all-day.
- Kootenay Lake Lower West Arm: the title says "…, Sat–Sun" but plain says "Keep up to 5 kokanee a day". The other
  rule's title says "Release kokanee, Mon–Fri" but plain says "Release every kokanee".

## Work
- One `when_words(when, style)` in `pipeline/deliver/answers/common.py` that covers dates, weekdays, hours and
  unparsed seasons. `style` covers the title/plain/label variants. `_plain`, `_title`, `_when_words` and the four
  `rows.py` wordings call it.
- Gate: any rule with `hours` or `weekdays` names them in both `title` and `plain`.
- Pin: a grep test that no other module in `pipeline/deliver/answers/` formats weekday or hour names itself.

## Acceptance
Proof is a reviewed behaviour change. The answers diff lists every changed title and plain. Expected: the hours rules
(Harrison, Pitt, Campbell, Nicomekl, Serpentine, Slocan) plus every plain whose rule has weekdays, and nothing else.
The gate fails on a mutation that drops hours from `_title`.

Rebuild: deliver. Depends: none. Size: M. Owner: no.

## Owner questions

- **Slocan reads "12:00 to 00:00"**; the book prints "12 pm to midnight". `when_words` could say "noon"/"midnight"
  for 12:00/00:00 (changes the catalogue label too, so an export rebuild). Default: unchanged.
- **`dates.When.words()` is still a second wording of a `when`** ("Saturdays and Sundays" without "on", hours before
  weekdays, unparsed seasons without "as printed:"). Its only shipped surface is the licensing labels (2 live:
  Atnarko/Bella Coola and Burnt Bridge "…, from reopening to steelhead fishing; the period is not printed").
  Routing it through `when_words` would prefix those with "as printed:", which is wrong for a curated note.
  Default: leave it until the licensing labels are reworked; then route it through `when_words` and pin it.
