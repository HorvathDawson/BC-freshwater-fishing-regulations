# T224 — Name variants from local sources (municipal, ECCC, DFO, synopsis, OSM, BC GNIS), each with its real source

Status: DONE 2026-10-29 — in release r-62e2f3a8c81e (atlas c1029). Owner spot-check of 20 auto-accepted names is Commits: 009aeec0, 39cc91e2, 2ea061c4.
listed below (OWNER-TODO); a reject → `python -m pipeline.tools.mined_names` → next build. Earlier: 009aeec0, 39cc91e2,
2ea061c4.

| id | title | status | commits | what's left |
|---|---|---|---|---|
| T224 | name variants from local sources (municipal, ECCC, DFO, synopsis, OSM, BC GNIS), each with its real source | DONE | 009aeec0, 39cc91e2, 2ea061c4 | in r-62e2f3a8c81e (Kilgard Creek shown, Lonzo variant; 169 shown, 12 not in atlas); owner spot-check 20 in OWNER-TODO / Names tab |

Source: owner 2026-10-28: 08MH079's stream is FWA-unnamed but Abbotsford's municipal layer calls it "KILGARD CREEK", and
the app has no such variant — "we could find many more". Add-ons the same day: every variant carries its REAL source and
evidence wherever provenance shows, never a borrowed label (a municipal name is never "official"); give existing
sources human-readable labels and fix mislabelled ones.

## Today (how a variant reaches the app)
`data/curated/waters/name_variants.json` (3,695 entries, each name with a `source` code) + the added-streams
`name_variants` (`data/curated/waters/added_streams.json`, municipal names, all applied as source `alias`) →
`pipeline.atlas.graph.names.apply_name_variants` (name tuples with a source) → registry `variants` (BARE STRINGS: the
source is dropped here) → bundle `alias(item_id, alias, alias_key)` (no source column) → app search ranks an alias a
step behind the name and shows "also X". A water with no gazetted name DISPLAYS its highest-priority variant, so an
alias on an FWA-unnamed line becomes its name with no hint where it came from.

## Work
1. DONE (Claude): miner + candidates — `mine.py`, `fwa_index.py`, `osm_extract.py`; `candidates.json` (+ `tables.py` prints the tables); findings below.
2. ★ Owner: flow (search alias only vs display name) and the auto-accept rule (below, "Owner calls").
3. Carry provenance end to end: registry variants become `{name, source, source_ref, official, evidence}`; bundle
   `alias` gains `source` + `official` (schema + contract + `release` test), app search row says "also X · City of
   Abbotsford stream layer". Bundle re-cut, no promote without the owner.
4. Fix the mislabelled existing variants (below, "Existing variants"): Burnaby names stored as `alias`, the FWA
   gazetted "South Alouette River" stored as `alias`, 24 added-streams municipal variants whose city is not recorded.
5. Apply accepted candidates as name_variants entries (source per candidate), side atlas build, binding diff (a new
   name can make a rule bind), reach + deliver.

## Findings (2026-10-28; numbers from candidates.json)
Matching:
- LINES (municipal, OSM): matched to FWA within 25 m.
  - `blk_overlap` = the share of the FWA line along the source.
  - `source_overlap` = the share of the source along the FWA line.
- POINTS (ECCC stations, cached BC GNIS mouths): the station's bound or matched blk/wbk, else the nearest line within 150–200 m.
- RECORDS (DFO, synopsis): the name vs the item the record matches.
- Dropped: names already present (ignoring case or punctuation), and 54 rows on FWA lines the added-streams batch
  removed.

By source (high / medium / low):

| source | high | medium | low |
|---|---|---|---|
| ECCC station names | 4 | 14 | 197 |
| City of Abbotsford stream layer | 3 | 32 | 105 |
| Burnaby | 0 | 1 | 0 |
| Port Moody | 0 | 0 | 3 |
| Squamish | 0 | 0 | 4 |
| OSM (basemap, OSM 2026-03-05) | 206 | 604 | 7,832 |
| DFO salmon regulations | 0 | 11 | 4 |
| Synopsis | 0 | 5 | 0 |
| BC GNIS (cached WFS, ~440 features) | 0 | 3 | 2 |

Merged: 8,832 rows; 218 high (197 on FWA-unnamed lines), 553 medium, 8,061 low; 39 corroborated by two sources.

Confidence levels:
- High:
  - lines: both overlaps ≥ 80 %;
  - ECCC: a bound or reviewed station on an unnamed line;
  - any target: two sources agree.
  - A name with no water word is capped at medium.
- Low: mostly OSM or municipal names labelling a whole network by its main creek (flag `tributary_of_same_name`).

Notable rows:
- 08MH079 / blk 356314888 has two rival names: Kilgard Creek (Abbotsford, 69 % / 85 %, medium) and Lonzo Creek (North
  Fork) (the ECCC station, bound, high).
- Non-OSM highs: Gill Brook, Marshall, Shamrock, Smith Brook, Mckay, Jantz Stream, Corinne Brook (Abbotsford);
  Inkaneep Creek, Meadow Creek Diversion, Quinsam River Diversion Headpond, Noble Creek (ECCC).
- English names FWA gazettes under an Indigenous name: Chilanko River = Tsalhanqox, Pine Creek = Koosawu.áa Héen,
  Deserted River = ts'unay stulu.
- Likely an OSM error: Kicking Horse → "Otterhead River".

How a variant reaches the app: see "Today" above. No surface shows a variant's source. On an FWA-unnamed line any
alias becomes the DISPLAYED name: 11 municipal aliases do this now, e.g. "Tillicum Slough" on blk 356346715.

### Owner calls
1. Flow: (a) search alias only ("also X · <source>"), or (b) also the display name of an FWA-unnamed water. Today's
   code does (b) silently. Default: (a), with display only by a per-name yes.
2. Auto-accept rule: high, no rival name, not a tributary label, relation `unnamed`, and either ≥ 80 % line overlap or
   an ECCC station. 181 rows qualify (≈160 OSM-only). Proposed: as search alias only, never `different`.
   Default: no auto-accept.
3. 08MH079: Kilgard Creek and/or Lonzo Creek (North Fork).

### Variant record + labels (proposed)
Record: `{name, source, source_label, source_ref, official, evidence}`. `official` is true only for BC Geographical
Names.

Labels:

| code | label |
|---|---|
| gazette | BC Geographical Names (official, via FWA) |
| side-channel | Main channel's official name (inherited) |
| override | Project curation (owner decision) |
| gauge | ECCC hydrometric station name |
| regulation / synopsis | Freshwater Fishing Synopsis |
| stocking | Freshwater Fisheries Society stocking records |
| bathymetry / marker | BC lake bathymetry map (label) |
| vessel_restriction | Vessel Operation Restriction Regulations (SOR/2008-120) |
| lake_survey | BC lake survey table |
| dfo | DFO salmon regulations |
| alias | Alternate name (source not recorded); to be eliminated |
| municipal:\<city\> | City of Abbotsford stream layer, City of Burnaby waterways layer, City of Port Moody ESA streams layer, District of Squamish watercourses layer |
| osm | OpenStreetMap |

No display surface carries a source today, so there was nothing display-only to relabel. No bundle field changed,
so no re-cut was made. The labels need step 3.

### Existing variants: mislabelled or provenance lost (`existing_variants_audit` in candidates.json)
- "South Alouette River" (wbk 329292631): the FWA gazetted name, stored as `alias`. It should be gazette/official.
- 8 Burnaby names stored as `alias`, city lost. 7 of them (Third Beach, Second Beach, Ramsay, Eagle, Cranberry,
  Beecher, Chub) target FWA blks the added streams REMOVED, so those entries are dead; the names live on the minted
  added streams.
- added_streams.json: all 367 municipal variants are applied as `alias`.
  - For the 343 `added` names, the city can be recovered from the stream.
  - For the 21 `duplicate` and 3 `excluded_fwa` names, the city is not recorded.
  - Abbotsford was never run through this batch.
- `override` names with no recorded origin: Seven Mile Reservoir, Waneta Reservoir, Beaver Tree Lake, Lightning Lake.
  "Whiteswan Lake outlet stream" is a description shown as a name.
- Nothing non-gazetted is labelled gazette/official: `gazette` comes only from FWA GNIS.

## Acceptance
No variant in the bundle without a source; no non-gazetted name marked official; every accepted candidate traceable
to its source row; binding diff reviewed before promote.

Depends: owner calls (2). Size: M. Owner: yes (2). Default: search alias only, nothing auto-accepted.

## Close-out (2026-10-29, verified on r-62e2f3a8c81e)
- `mined_names.json` is current (`--check`), no name marks yet. 183 entries: 181 auto-accepted — 169 shown as
  the water's name (FWA-unnamed lines), **12 not applied** (their FWA line is not
  in the atlas: pruned or tidal piece — `registry.mined` reports, never applies): Cowichan River (354087697), Maraude,
  Port Augusta, Blue Heron, Celtic Slough, Quesnel River (Side Channel), South Ziggurat, Upper Titman, Rae, North,
  Ninebark, Hunlen Creek; + 08MH079's two (below).
- 08MH079's line: core item `blk:356314888` "Kilgard Creek" (name_source: City of Abbotsford stream layer) + alias
  "Lonzo Creek (North Fork)" (ECCC); tiles `stream` layer names it (same vintage 07f861e5422be466).
- core `name_source` 3,937 rows, none `alias`; the 38 aliases without a row are gazetted (official) second names, by
  design. "South Alouette River" gazette in the registry. App: search "also X · source", "Name from …" (uiWords).

### Owner spot-check (20; Names tab `#names/`, a reject takes one out)
Picked for risk: every non-OSM auto-accept + the OSM rows with the weakest overlap / shortest line / no water word.
| name | source | blk | why look |
|---|---|---|---|
| Cat Stream | OSM | 354128296 | two OSM ways: 95 % / 100 % over 3.0 km (qualifies) + a 285 m stub at 4 % — no water word but "stream" |
| The Cut Coulee | OSM | 354089612 | no water word |
| Cohen Creek | OSM | 356272352 | 160 m source line |
| Benes Creek | OSM | 354126239 | 309 m |
| College Creek | OSM | 359295223 | 80 % overlap (edge) |
| North McNaughton Creek | OSM | 354125014 | 81 % / 80 % |
| Brigade Bay Creek | OSM | 360357261 | 81 % / 80 % |
| Problem Creek | OSM | 356305031 | 81 % / 83 % |
| Coho Creek | OSM | 356356588 | 82 % |
| Corinne Brook | Abbotsford + OSM | 356056778 | OSM 100 % / 100 %; Abbotsford's two lines cover 39 % / 22 % |
| Jantz Stream | Abbotsford + OSM | 356062107 | OSM 83 % / 100 %; Abbotsford 74 % |
| Marshall Creek | Abbotsford | 356082830 | Marshall is also the main creek's name nearby |
| Gill Brook | Abbotsford | 356096337 | — |
| Mckay Creek | Abbotsford | 356128529 | spelling (McKay?) shown as sourced |
| Shamrock Creek | Abbotsford | 356196726 | — |
| Smith Brook | Abbotsford | 356304947 | 70 % of the source on the line |
| Inkaneep Creek | ECCC | 356370187 | FWA-unnamed line under a known gazetted name |
| Meadow Creek Diversion | ECCC | 356368998 | a diversion shown as a water |
| Quinsam River Diversion Headpond | ECCC | 354088905 | a headpond shown as a stream |
| Noble Creek | ECCC | 354151912 | — |

### Auto-accept audit (owner 2026-10-29: "we didnt add this variant right? only should have auto added certain ones")
Every one of the 181 applied auto-accepts meets the owner rule (decisions.md "T224": high confidence, relation
`unnamed`, one candidate, no rival, ≥ 80 % overlap or an ECCC station), rechecked source by source: 0 outside it. Cat
Stream (blk 354128296, near Nanaimo) is one of them — applied and shown — because a second OSM way named "Cat Stream"
covers 95 % of the FWA line (3,037 m, 100 % of the way on it); the 4 % row the spot-check list first quoted was its
other, 285 m way. Nothing removed or renamed (ask-first rule): a Names-tab reject takes it out.

### Owner 2026-10-29: close-out
- Coverage names (177): accepted by the owner (`names.COVERAGE_ACCEPTED`). Gauge names: Inkaneep Creek (08NM012), Noble
  Creek (08HA028), and — after a hold — Meadow Creek Diversion (08NH128) and Quinsam River Diversion Headpond (08HD034);
  each credited to its gauge ("Name from the Environment Canada gauge 08NM012 (Inkaneep Creek near Oliver)",
  `names.gauge_label`). 183 accepted names. The two re-accepted items were put back into the live atlas registry
  surgically (same items as before, gauge labels) rather than by an atlas rebuild.
