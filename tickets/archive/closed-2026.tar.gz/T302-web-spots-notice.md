# T302 — Spots on the web app: a notice instead (phone app only for now; accounts coming)

Status: DONE 8c0337a3e, 7e752a935 (web; owner 2026-10-30: "make it so spots in the webapp instead just say something about how they work locally on
the phone app but they don't sync to web yet. Coming soon will be accounts etc").

| id | title | status | commits | what's left |
|---|---|---|---|---|
| T302 | Web Spots tab → notice: spots live in the phone app, no web sync yet, accounts coming; web save entry points + walkthrough spot steps adjusted | DONE | 8c0337a3e, 7e752a935 | owner 2026-10-30; web Spots tab + add → notice (Get the app), walk skips spots on web; shots T302-shots/ |

## Work
1. On web, the Spots tab shows a short, friendly notice instead of the spot list/capture: spots are saved on your phone in the
   Can I Fish This? app; they don't sync to the website yet; accounts that sync phone and web are coming. A "Get the app"
   link (Play listing; the test link while internal) — no store badge art we don't have.
2. Web hides "Save a spot" entry points (map long-press / sheet button) or routes them to the same notice.
3. The T293 walkthrough's spot steps are skipped on web (or replaced by one step pointing at the notice); the Help text says
   spots are phone-only for now.
4. Existing web-saved spots (localStorage/IndexedDB from earlier testing): left untouched, just not shown — say so in the ticket.
Words in core tables; phone app unchanged.

## Acceptance
Web screenshots (phone + desktop) of the Spots tab and a save attempt; walkthrough on web skips spots; phone unchanged.

Depends: T293, T294. Size: S. Owner: no.

## Done
- Web only (`webSpotsNotice()`, WebSpotsNotice.tsx): the Spots tab is a notice — spots are saved in the phone app, they
  don't show on the website yet, accounts are coming — with "Get the app" (the Play listing). Words: core `WEB_SPOTS_WORDS`.
- Every web way of adding a spot (the map's right-click / long-press "New spot" → Continue, the route's add) lands on the
  same notice, with "Back to the map". The phone app is unchanged (the capture flow is `SpotCaptureFlow`).
- The T293 walkthrough has no spot steps on the web (20 steps); its last step and Help → Offline say spots are in the app.
- Spots saved in a browser before this stay in its storage, untouched and unshown.
- Shots: T302-shots/ (phone + desktop: the tab, the right-click "New spot", the notice after Continue). Test:
  WebSpotsNotice.test.tsx.
