# T364 — Real-iPhone run

Status: DROPPED — merged into T88 (2026-11-05 audit; the work continues there) — was: OPEN (owner 2026-11-03: Android 0.5.0 first, iOS next; from the ticket check's iOS gaps).

| id | title | status | commits | what's left |
|---|---|---|---|---|
| T364 | Real-iPhone run: location prompt, offline first download, edge-back gesture, gauge pill padding | DROPPED — merged into T88 (2026-11-05) | T313, T88 | owner: steps in OWNER-TODO iOS |

The Simulator is not a phone. On a real iPhone (free 7-day signing or TestFlight): the location prompt, the first
offline download (foreground URLSession, b8e33ca80), the edge-back gesture verdict (T313), the gauge pill padding
(OWNER-TODO "iPhone (T217)"), and the walkthrough. Owner holds the phone. Size: S.

Owner steps written to OWNER-TODO "iOS (T88, T364, T365)" (2026-11-05); nothing else to do until the TestFlight build exists.
