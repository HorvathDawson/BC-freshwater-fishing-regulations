# T214 — app polish: quota wording, desktop navigation, part highlight, steady stretch buttons

Status: DONE (555e7ee9 items 1, 2, 4; 33775c57 item 3)

| id | title | status | commits | what's left |
|---|---|---|---|---|
| T214 | app polish: quota sub-cap wording names its total, desktop no-swipe + Esc back, clearer part highlight, steady up/downstream buttons | DONE | 555e7ee9 33775c57 | items 1, 2, 4 (subcap lead + golden amendment, desktop no-swipe + Esc Back, reserved exit slot); item 3 part halo at full outline, others dim 0.25 (web light + dark) |

Source: owner 2026-10-27.

1. Quota sub-cap wording names its total: "Of these, only 1 may be over 50 cm (20 in) — 2 if one is a hatchery
   steelhead" → "Of your 2 trout and char, only 1 may be over 50 cm (20 in) — 2 if one is a hatchery steelhead" (the
   group and its number from the total it belongs to; every such line, all regions). Golden parity: a reasoned wording
   amendment, not a blind re-cut.
2. Desktop: no swiping between Regulations / Conditions / Map (swipe only on touch/mobile); Esc acts as Back.
3. Regs tab map-section navigation: make the highlighted part/stretch much more obvious (selected vs others), every
   water colour incl. amber + cvd.
4. Upstream/downstream navigation still flickers: the "Flows into X" line appears/disappears and moves the buttons —
   reserve its space (or place it where it cannot shift the controls); a test asserts the buttons keep their position.

## Outcome (2026-10-27)
- **1 (built)**: core `tree.ts` `subcapLead`/`tierWords`: a size tier whose store words start "Of these, " reads "Of your N <group>, " (N = the
  number of the tier it sits in, the group = the row title through `lc`); the cap's own numbers stay big. The pipeline still prints "Of these"
  (not touched). Golden parity is a reasoned amendment: `oracles.ts subcapRuled` rewrites page v36's 117 "Of these, " strings at load from the
  golden's own facts (group title; parent's first big number, a folded share's `leadN`, the head's `big` at the top), `SUBCAP_REWRITES` = 117
  pinned in `exclusions.test.ts`; the Kitimat store walk reads the lead the same way. No re-cut. VM fixtures re-cut (the lead only).
  Tests: `tree.test.ts` (lead, bold, no parent / no number / no title, proper noun), `exclusions.test.ts`, `tree.parity.test.ts`.
- **2 (built)**: `useViewSwipe(route, go, touch)` is off when `touch` is false; the Shell passes `isTouchDevice()` (`touchDevice.web.ts`:
  primary pointer coarse; native always true). `useEscapeBack` (`escapeBack.web.ts`, mounted in `Shell`): Escape is the one Back on the
  desktop web, not while a layer/search/dialog is open, not typed in a field, not when already handled. Tests: `gestures.test.tsx`,
  `escapeBack.web.test.tsx`; the swipe tests (`WaterMode.test.tsx`, `tools/water-frame-swipe.test.ts`) stub a phone.
- **3 (built, 33775c57)**: `paint.ts` `PART_HALO_PX` = `CASING_PX` (was 1.25): the part you are on is ringed at the browse map's full
  outline (2.5 px each side; `RING_PX` on a lake/wetland), and `opacity.water.others` 0.4 -> 0.25 (all three themes). The water line keeps
  its legend width (T151 no-bold holds). Tests: `parity.test.ts` (dim 0.25, casing +2*CASING_PX, halo = casing), `tools/water-status-cvd.test.ts`
  unchanged green. Web :39218 verified on the Chilliwack (amber part 1, closed part 3) light + dark: shots `handoff/PLAN/app-integration/T214-shots/`.
  Dark: the closed red sits near the highlight pink; the wider halo and the dimmed others still separate it. Phone check is the owner's.
- **4 (built)**: T203 moved the chip LAST, but the bar sits at the foot of the screen, so a line that appears grows the bar upward and lifts the
  steps and "Show regulations" anyway. Now the VM carries `exitHeld` (the water's mouth flows into another water, at any part) and the bar keeps a
  44 px slot (`water-map-exit-slot`) at every part, the chip filling it (one line, ellipsis); the part name keeps two lines (46 px) so a name that
  wraps in one part does not move the steps either. Test: `WaterMapView.test.tsx` (same children, order, slot and name heights at the mouth and one
  step up, and back). Layout is asserted structurally (jsdom lays nothing out); a phone check is the owner's.
