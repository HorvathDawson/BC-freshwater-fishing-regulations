# Rules spot-check: the 0.10.0 candidate against the printed synopsis (2026-11-25, night)

Read-only. No curated row changed, no owner mark written.

## What I read

- **Data:** release candidate **r-71d09ad82e81** (`data/release/CANDIDATE` says so; built 2026-11-25 13:47). I read its
  source bundle `data/generated/bundle/bundle.sqlite` (written 12:57). It is the same build: its `entries_digest`
  `96ee09da512eae1c` and `reach_digest` `9db14e7a9f81e253` equal the ones in
  `data/release/r-71d09ad82e81/manifest.json`. I did not decode the shipped `regs-*.sqlite` shards. Their frames are
  compressed blobs. I read the rules each water part carries: tables `item`, `part`, `ruleset`, `rule`, `entry`,
  `designation`. For a few waters I also read the stored open/closed answer in
  `data/generated/bundle/verdicts.sqlite` (`segment`/`reading.closed`).
- **There was no rebuild tonight** (checked 21:27). The bundle is older than the T1146 fix. So the T1146 side-channel
  gaps are still in this data (see below).
- **Book:** `data/source/fishing_synopsis.pdf`. I rendered the rows to images and read them by eye. Page numbers below
  are PRINTED pages. PDF page = printed + 2 for pages up to 40, and printed + 6 from page 41 on. I checked this
  against the page footers.
- **Important:** the two synopsis PDFs in the repo are **not the same edition state.** The copy the task named,
  `data/source/official/2025-2027_freshwater_fishing_regulations_synopsis.pdf`, has **no in-season corrections**.
  `data/source/fishing_synopsis.pdf` prints them in red, for example "No Fishing July 4-July 14" on the Cowichan, the
  Fraser and Region 3/5 steelhead closures, "No Fishing between Peace Canyon Dam and Hwy 29 Bridge", and "A person
  in a boat may angle with an unlimited number of rods" on Kootenay Lake. The data follows the corrected copy, so I
  used that copy. Checked against the `official/` copy, those rows would show as false differences. The PDF text layer
  has about 48 red lines, counted by text colour with `rules-spot-check/redlines.py`. That count includes some
  text hidden under other text, so it is not an exact count of visible corrections.
- **The PDFs have a hidden overlaid text layer.** For example, PDF p.17 carries page 18's Q-rows under page 15's
  C-rows. So plain text extraction mixes rows together. Reading the rendered page is reliable. (The pipeline's
  extractor handles this with an ink check, `pipeline/regs/extraction/extract_synopsis.py:120-150`.)
- Helper scripts are in `night/rules-spot-check/`: `read_water.py`, `compact.py`, `setlist.py`, `setdiff.py`,
  `row.py`, `render.py`, `redlines.py`. Every run was one process under `nice -n 15`, taking a few seconds and well
  under 1 GB.

## Region base rules (the zone rules): one row per region

Compared box by box against each region's "Regional Regulations" page: the daily quotas, size limits, region
closures, single barbless hook, bait bans, possession quotas and set lining.

| Region | Book page | What the book says (summary) | What the data holds | Verdict |
|---|---|---|---|---|
| 1 | 13 | Summer closure, streams of MU 1-1 to 1-6, Jul 15-Aug 31. Single barbless hook and bait ban on all streams all year. Haida Gwaii stream bait ban Nov 1-Apr 30. Trout 4 (1 over 50 cm; 2 hatchery steelhead over 50 cm allowed; 2 from streams, must be hatchery). Release wild steelhead, wild trout from streams and all char. Bass unlimited, crayfish 25, kokanee 5 (none from streams), white sturgeon catch and release, perch unlimited. Haida Gwaii: trout/char 5 (1 over 50 cm, 3 Dolly Varden, 2 from streams), release trout/char under 30 cm from streams, kokanee 10 | `z1:*` (9 entries), the same item by item, with Haida Gwaii carved out of the region box | MATCH |
| 2 | 21 | Trout/char 4 (1 over 50 cm, 2 hatchery steelhead allowed, 2 from streams must be hatchery, 1 char none under 60 cm). Release wild trout/char from streams, wild steelhead, and hatchery fish under 30 cm from streams. Bass 20, crappie 20, crayfish 25, kokanee 5, whitefish 15, white sturgeon catch and release. Single barbless hook on streams. Malcolm Knapp lakes closed. Protected species. Stop fishing after the hatchery steelhead quota | `z2:*`, the same | MATCH |
| 3 | 28 | Spring closure, all streams, Jan 1-Jun 30. Single barbless hook. Trout/char 5 (4 from streams, 1 over 50 cm, 1 bull trout or lake trout none under 60 cm). Release ALL steelhead, bull trout from streams Aug 1-Oct 31, and lake trout Oct 15-Jan 31. Bass and perch closed, burbot 2, crayfish 25, kokanee 5, whitefish 15. Shuswap annual quota | `z3:*`, the same | MATCH |
| 4 | 34 | No fishing in streams Apr 1-Jun 14. Trout/char released in streams Nov 1-Mar 31. Single barbless hook. Trout/char 5 (1 rainbow or cutthroat over 50 cm, 2 from streams, 1 bull trout). Bass, pike, walleye, perch and white sturgeon closed. Burbot 2, kokanee 15 (5 over 30 cm). Kootenay Lake main body annual quota of 20 rainbow over 50 cm | `z4:*`, the same. The annual quota of 20 is held on the Kootenay Lake main-body row (`kootenay_lake_main_body.r6`), not on `z4:kootenay_annual`, which has no rule. The effect is the same | MATCH |
| 5 | 42 | Spring closure Apr 1-Jun 30 in streams of the Fraser and Thompson watersheds, except the Fraser mainstem. Single barbless hook. Trout/char 5 (1 over 50 cm, 2 from streams, 1 bull trout, 2 lake trout). Release all steelhead, lake trout Oct 1-Nov 30, and bull trout from streams Aug 1-Oct 31. Bass closed, burbot 5, kokanee 5, whitefish 15. Three-part white sturgeon rule | `z5:*`, the same | MATCH |
| 6 | 49 | Skeena and Nass bait ban. Steelhead stream closure May 15-Jun 15 (main stems exempt). Skeena above Cedarvale and Nass above Kitsault closed Jan 1-Jun 15 (Skeena mainstem Jan 1-May 31; Nass mainstem exempt). Iskut and Fraser watershed closure Apr 1-Jun 30. Trout/char 5 (1 over 50 cm, 3 bull trout/lake trout, 1 trout from streams Jul 1-Oct 31). Release bull trout from streams, trout under 30 cm from streams, trout from streams Nov 1-Jun 30, lake trout in the Fraser and Skeena basins Sep 15-Nov 30, and wild steelhead. Set lining in lakes | `z6:*`, the same | MATCH |
| 7A | 58 | Spring closure Apr 1-Jun 30. Single barbless hook and bait ban on streams. Trout/char 5 (1 over 50 cm, 2 from streams, 3 lake trout, 1 bull trout 30-50 cm from lakes Oct 16-Aug 14). Release lake trout under 30 cm, and lake trout of any size Sep 15-Oct 31. Grayling catch and release. Burbot 5, kokanee 10, white sturgeon closed. Possession is 1 daily quota for lake trout and bull trout | `z7a:*`, the same | MATCH |
| 7B | 64 | Single barbless hook and bait ban on streams. No fin fish as bait. No set lining. Trout/char 5 (1 over 50 cm, 2 from streams, 2 lake trout). Bull trout kept only from the Liard basin or named waters, 30-50 cm, Oct 16-Aug 14. Grayling 2 (none under 30 cm, 1 over 45 cm; release May 1-Jun 15 and in the Williston watershed). Kokanee 10 (none from streams except the Peace). Pike 3, walleye 3, goldeye 10, perch 5 | `z7b:*`. Bull trout: "release all" across the whole zone (`trout_char_quota.r10`), with keeping allowed by the Liard River Watershed row (`r7:liard_river_watershed…` r1-r3). The outcome is the same | MATCH |
| 8 | 68 | Spring closure Apr 1-Jun 30. Single barbless hook. Trout/char 5 (1 over 50 cm, 4 from streams with only 2 over 30 cm). 20 brook trout from streams. Release bull trout from streams. Bass and perch closed, burbot 2, crappie 20, crayfish 25, kokanee 5, walleye 8, whitefish 15. Garnet Lake closed | `z8:*`, the same | MATCH |

**Every regional base box matches the book.** I found no difference in a zone rule's text or numbers. The only base-rule
problem is WHERE one rule lands: a region closure applied to a river on an MU boundary (Campbell River, below).

## The waters (37 rows; every region has at least 3)

Unless a row says otherwise, "the data" means the rules on that water's parts in the bundle. "Base" means the region's
rules from the table above, and it matched.

| # | Water (region, book page) | The book's row (quoted, abbreviated) | What the data holds | Verdict |
|---|---|---|---|---|
| 1 | Cowichan River (R1, p15) | "No Fishing July 4-July 14" (red correction). "No Fishing July 15-Aug 31*". "No Fishing from weir (dam) at Cowichan Lake's outlet to Greendale Trestle, Nov 15-Apr 15". "No Fishing in tributaries upstream of and including Holt Creek". "Fly fishing only upstream of CNR Trestle (Mile 66) Sept 1-Nov 15". "No Fishing downstream of the CNR Mile 66 Trestle between Sept 1-Nov 15". "Fly fishing only from signs at Greendale Trestle to CNR Bridge (mile 70.2)". Speed and engine limits on parts | 6 parts. Every row is present and placed on the right parts: the Jul 4-14 and Jul 15-Aug 31 closures on all parts; the Sep-Nov closure below Mile 66 (p0-1); fly only above it (p2-5); fly only Greendale to mile 70.2 (p4); the weir closure (p5). Stored answer on Jul 8: closed on all 6 parts | MATCH. The `official/` PDF lacks the Jul 4-14 line; the data is right for the current book |
| 2 | Stamp River (R1, p18) | "No Fishing between fishing boundary signs 200 m upstream of and 500 m downstream of Stamp Falls, June 15-Nov 15". "No Fishing from the confluence with Ash River upstream to the Great Central Lake dam*, Jan 1-Apr 30". Bait ban all year above Girl Guide Falls, and Jun 1-Aug 24 below them. Engine 7.5 kW on parts | 8 parts. r1 Stamp Falls closure (p2), r2 Ash to dam closure (p4-7), r3 bait ban above (p1-7), r4 bait ban Jun 1-Aug 24 below (p0) with the region's all-year bait ban lifted the rest of the year (r4x), r5 engine. MU 1-7, so no summer closure, which is correct | MATCH |
| 3 | **Campbell River (R1, p14)** | Row filed under **MU 1-10**. "No Fishing between Elk Falls and John Hart Dam Power Station". "No Fishing from Strathcona Dam downstream 100 m". "No Fishing from … Maple Street … to … cement block, Aug 1-Oct 31". "No Fishing in any tributaries (except Quinsam River), Dec 1-May 31". Fly only John Hart to the power line. Artificial fly only below the power line Dec 1-May 31. No vessels Elk Falls to John Hart. **No summer-closure line and no exemption line** | All the row's rules are present and placed. **But parts 1-5 and 7-10 also carry the Region 1 summer closure** ("No fishing in streams Jul 15-Aug 31 — MU 1-1 to 1-6"). Every Campbell section has MU set `1-10,1-6`: the river is the MU boundary, and membership by overlap pulls it in. Stored answer on Aug 1: **closed** on p1-5 and p7-10; **open** on p6 (a side channel). | **DIFFERENT.** The data closes the Campbell Jul 15-Aug 31; the book lists the river in MU 1-10, outside the closure. I think the book is right. The book exempts by name 1-6 rivers it means to keep open (the Quinsam row carries "Exempt from July 15-August 31 summer closure", and so does Nitinat), and the Campbell has no such line because it is not in the closure. Severity: **wrongly told not to fish**, on a well-known summer salmon river. It does not bite before this edition ends (next Jul 15 is after Mar 31, 2027). Scale: 15 sections province-wide sit in a mixed 1-6/1-10 or 1-3/1-7 MU set and carry the closure: Campbell 10, Quinsam 1 (exempt by its own row), Spencer Creek 1, 3 others |
| 4 | Koksilah River (R1, p16; T1146) | "No Fishing Dec 1-May 31 and July 1-Sept 30" | p0: the row, plus the Cowichan Jul 15-Aug 31 closure (as a Cowichan tributary). p1 (5 channel sections, 6.1 km, the T1146 case) has the row but not the Cowichan tributary rule. Stored answer: closed Aug 1 on both parts, open Jun 15 on both | MATCH in outcome. The T1146 gap is visible (p1 lacks one redundant rule) and changes no answer |
| 5 | Gordon River (R1, p16; several parts) | "No Fishing July 15-Aug 31". "No Fishing upstream of Bugaboo Creek, Nov 1-Apr 30; artificial fly only upstream of Bugaboo Creek when open" | 3 parts. The closure on all parts; the Bugaboo closure and fly only on p2; p0 sits in the national park (national park permit requirement) | MATCH |
| 6 | Strathcona Park waters: Thelwood Creek, Elk River R1 (R1, p18, p14-15) | "No powered boats on any water within Strathcona Park except Gold, Upper Campbell and Buttle lakes". Thelwood Creek "No Fishing". Buttle Lake's tributaries "Fly fishing only; except Thelwood Creek is closed all year". Elk River (R1) "Fly fishing only" | Thelwood: closed on both parts. The park boat rule is on p1 only; p0 lies in Strathcona-Westmin Park (a known T1146 open item). Elk River R1: fly only plus no powered boats | MATCH. The rule is closed either way; the boat-rule gap on Thelwood p0 is T1146 group D |
| 7 | Buttle Lake (R1; **no row of its own**) | Excluded from the park boat rule by name. Only the R1 base applies | Lake set: R1 lake quotas (4 trout, 1 over 50 cm, release all char), mercury advisory, possession. No park boat rule | MATCH |
| 8 | Fraser River (R2, p23) | Dead fin fish as bait only for sturgeon. Landstrom Bar to Croft Island closure May 1-Oct 31. No fishing in the non-tidal Fraser in Region 2 from one hour after sunset to one hour before sunrise. Jesperson's, Herrling and Seabird side channels closed May 15-Jul 31. "No Fishing for steelhead Fraser River Mainstem Aug 15-Dec 31" (red). Boats must not impede commercial vessels | All 6 rules on p1-4 (the Landstrom zone on p2). White sturgeon licence fishery present. Tidal part (p0) left to the federal rules | MATCH |
| 9 | Squamish River (R2, p26; Baynes Island Ecological Reserve) | "Bait ban". Tributaries closed except Ashlu, Cheakamus, Elaho, Mamquam and the Powerhouse Channel | 4 parts. Bait ban on p1-3. p1 (2 sections) also carries "No fishing in ecological reserves", which is Baynes Island. p0 is tidal | MATCH |
| 10 | Capilano River (R2, p22; several parts) | "No Fishing upstream of fishing boundary signs at footbridge situated approximately 100 m downstream of the fish fence". "Bait ban, Aug 1-Oct 31; steelhead catch and release" (includes tributaries) | p1 open, with the bait ban and steelhead release; p2-3 closed (p3 is the no-access watershed); p0 tidal | MATCH |
| 11 | Chilliwack / Vedder Rivers (R2, p22) | Closed above the line 100 m below Slesse Creek. Slesse to Tamihi closed Apr 1-Jun 30. Tamihi to Vedder Crossing closed May 1-Jun 30. Below Vedder Crossing: (a) fly only, bait ban, hatchery rainbow ≤50 cm and hatchery cutthroat released, May 1-31; (b) closed Jun 1-30; (c) hatchery rainbow ≤50 cm quota 4, Jul 1-Apr 30 | Chilliwack p3-4 closed; p2 Apr-Jun; p0-1 May-Jun. Vedder (both parts) carries r4-r9 for below Vedder Crossing; r9 lifts the region's "2 from streams" | MATCH |
| 12 | Fraser River (R3, p30) | Exempt from spring closure upstream of the Thompson. Trout closures below Hell's Gate Sep 1-Nov 15, Hell's Gate to the Thompson Oct 1-Nov 30, above the Thompson Oct 1-31. Boston Bar closure. Bridge River Rapids closed Mar 31-Jun 20. Lillooet closed Oct 1-May 31. Thompson confluence closed Oct 1-May 31, with a bait ban and 15 mm hook Oct 1-Dec 31. Steelhead closures Spuzzum to Hell's Gate Aug 15-Dec 31 and above Hell's Gate all year (red) | All 12 rules present and on the right parts. The spring closure stays below the Thompson, as the book's "upstream of Thompson River" exemption says. "Trout" is read as trout and char, which is the book's own definition (p80) | MATCH |
| 13 | Fraser River (R5, p45, and R7A, p59) | R5: no trout fishing below the Chilcotin Oct 1-31. Mainstem open all year; bait ban Sep 15-Jul 15. No sturgeon fishing Sep 15-Jul 15, and none above Williams Lake River. Steelhead closed below the Chilcotin all year (red). R7A: "Exempt from spring closure; also EXEMPT from bait ban upstream of Cottonwood River" | R5 rules on p18-22 and the R7A exemptions on p22-23, as printed | MATCH |
| 14 | Thompson River (R3, p32; classified) | Upstream of Kamloops Lake: exempt from spring closure; rainbow 2 (none over 50 cm). Downstream: closed Oct 1-May 31; trout/char 2 (none under 35 cm); May opening Deadman to Bonaparte (catch and release, fly only); bait ban above Martel; no angling from boats; Class II Oct 1-Dec 31 with Steelhead Stamp (when open) | 12 parts. Every line present. The May opening lifts both the Oct-May closure and the spring closure on p6-8. Class II designation on p0-10. Stored answer: open Aug 1, closed Oct 15 below the lake | MATCH |
| 15 | Hamilton Lake (R3, p30; **age limit**) | "Youth/Disabled Accompanied Water April 1-Sept 30 (see page 4)" | `hamilton_lake.r2`: angling closed to anglers 16 and over, except disabled B.C. residents and companions, Apr 1-Sep 30. R3 lake base | MATCH |
| 16 | Bonaparte Lake (R3; **no row**) | Only the R3 base applies (the Bonaparte River row is a different water) | Set 382: the R3 lake base exactly | MATCH |
| 17 | Kootenay Lake (R4, p37; **special limits**) | All parts: burbot catch and release; bass and perch unlimited. Main body: unlimited rods in a boat (red); kokanee 0; bull trout 1; rainbow 10 any size; Conservation Surcharge Stamp to keep rainbow over 50 cm, annual quota 20. Upper West Arm: rainbow catch and release Jan 1-May 31; trout/char 2 (1 bull trout); kokanee catch and release except Apr 1-3 and Jul 1-2 (5). Lower West Arm: trout/char 2 (1 bull trout); kokanee 5 Saturday and Sunday only | Three arm items, each with its own rows plus the all-parts rows. Bass and perch lift the region's closures | MATCH. The "combined kokanee from both arms ≤5" note has no rule; I could not see it shown (not checked in the app) |
| 18 | Elk River (R4, p36; classified) | Above Elko Dam: bait ban Jun 15-Oct 31; catch and release Jun 15-Oct 31 on four named stretches; elsewhere 1 (none under 30 cm) Jun 15-Oct 31; bull trout catch and release; electric motor only; Class II when open, with tributaries. Below the dam: 1 (no cutthroat under 30 cm, no bull trout under 75 cm) and bait ban Jun 15-Oct 31; electric only; Class II | Every line, split correctly across the stretches (p1,3,5,7 catch and release; p2,4,6 quota 1). Class II designation on all parts | MATCH |
| 19 | Forsyth Creek (R4, p36; T1146) | "No Fishing from Connor Lake downstream 3 km". "For remainder, see Elk River's tributaries" (closed Sep 1-Oct 31; trout/char 1 none under 30 cm and bait ban Jun 15-Aug 31; bull trout catch and release). Class II when or where open | p2 closed (3,000 m); p0 and p3 carry the Elk tributaries rules. **p1 (991 m channel) carries only the R4 base**: no Sep-Oct closure, no bull trout release, no bait ban. Stored answer on Sep 15: p1 **open**, every other part closed | **DIFFERENT** in this candidate. The book is right. Severity: an angler could break the law, on a 1 km channel. T1146 (already done, not yet built) fixes it. It does not bite before the edition ends (Sep 1, 2027 is after Mar 31, 2027) |
| 20 | Halfway River (R4, p37) | "No Fishing downstream of falls approximately 11 km from Arrow Lake" | p0 (10.05 km) closed; p1 above the falls open with the R4 base and the Upper Arrow tributary bull trout release | MATCH |
| 21 | Elk Lake (R5, p45; **ice rule, boat rule**) | "No Ice Fishing; trout daily quota = 1 (none under 50 cm); single barbless hook; electric motor only - max 7.5 kW" | r1 no ice fishing, r2 quota 1 (none under 50 cm), r3 single barbless hook, r4 electric only | MATCH |
| 22 | Forest Lake (R5, p45; **fly only**) | "No Ice Fishing; Trout daily quota = 1 (none under 50 cm); artificial fly only; bait ban; engine power restriction - 7.5 kW (10 hp)" | r1-r5, the same | MATCH |
| 23 | Horsefly River (R5, p45; classified) | "No Fishing Nov 1-May 31". Trout/char catch and release; artificial fly only, bait ban. No angling from powered boats from Woodjam Bridge to Quesnel Lake. Class II Jun 1-Oct 31; Steelhead Stamp not required | All present. Class II designation with no stamp. The data also lifts the R5 spring closure for June (r1x), read from the row's own dates | MATCH. One note: the book does not say "exempt from spring closure" in words. The reading is reasonable (the region text says streams listed in the tables are excepted, and the Class II season starts Jun 1) |
| 24 | Horsefly Lake (R5; **no row**) | Only the R5 base (Quesnel Lake's Horsefly Bay closure is a different water) | Set 1302: the R5 lake base, plus the white sturgeon closure above Williams Lake River | MATCH |
| 25 | Skeena River (R6, p53; classified, bait ban) | "Bait ban" (with tributaries). Mainstem: two Class II waters, Skeena River 2 (Exchamsiks to 1.5 km above Kitsumkalum, Jul 1-Sep 30, stamp only for steelhead) and Section 4 (from 1.5 km above the Zymoetz, Jul 1-Dec 31, stamp required). Non-guided non-resident aliens may not angle on weekends in two zones. No boats at the Kispiox confluence | 22 parts. Bait ban on all of them. Skeena River 2 designation (p4-7), Section 4 (p11-21); weekend non-resident alien closures (p11, p14-18); Kispiox boat rule (p17); region mainstem closure Jan 1-May 31 above Cedarvale (p13-21) | MATCH |
| 26 | Babine River (R6, p50; classified) | Weekend non-guided non-resident alien closure. Closed 100 m above to 80 m below the counting fence. Rainbow Alley open all year. Fly only (two stretches). Bait ban. No boats below the fence. Class I Sep 1-Oct 31 with stamp, from the juvenile weir to the Skeena | Every line placed. Class I on p0-5 and not on Rainbow Alley (p6-7), which matches "from the juvenile fish counting weir … downstream" | MATCH |
| 27 | Shelagyote River (R6; **no row**; Babine tributary; T1146) | The Babine row "includes tributaries" and is Class I water | p1 (44 sections) carries the Babine rules and the Class I designation by the tributary walk. **p0 (1 channel section) has neither the Class I designation nor the Babine and Skeena row rules.** The region-wide Skeena bait ban still applies there | **DIFFERENT** in this candidate (T1146 case). Severity: could break the law (fishing without a Classified Waters Licence Sep 1-Oct 31, on one channel piece). Fixed by T1146. Not in force before the edition ends |
| 28 | Stuart River (R7A, p61) | "Exempt from spring closure; rainbow trout catch and release, Apr 1-June 30" | r1 lifts the spring closure; r2 rainbow release Apr 1-Jun 30; 7A stream base | MATCH |
| 29 | Stuart Lake (R7A; **no row**) | Only the 7A base | Set 1297: the 7A lake base, with bull trout 30-50 cm Oct 16-Aug 14 from lakes | MATCH |
| 30 | Peace River (R7B, p66; several parts) | Hwy 29 to Site C: grayling and whitefish catch and release (with tributaries); lake trout 3; Halfway mouth ±5 km closed Mar 1-Jun 30; "No Fishing between Peace Canyon Dam and Hwy 29 Bridge" (red). Site C to 1,200 m below: No Fishing. Below that: grayling catch and release; kokanee 10 | All placed: p5-7 (Halfway closure on p6), p4 closed, p1-3 downstream, p8 Peace Canyon to Hwy 29 closed. Kokanee 10 lifts the zone's "none from streams" | MATCH |
| 31 | Halfway River (R7B, p65; T1146) | "No Fishing from confluence with Peace River to fishing boundary signs approximately 5 km upstream, Mar 1-June 30". "Arctic grayling catch and release, Mountain whitefish catch and release" | p0 (6.7 km) closed Mar-Jun; the grayling and whitefish release on all parts. p2 (T1146 channel) lacks only the Peace row's copies of the same two releases | MATCH in outcome |
| 32 | Kotcho Lake (R7B; **no row**) | Only the 7B base. It is not in the Peace or Liard basins, so no bull trout may be kept | Set 1634: the 7B base, with bull trout release and no Liard or Peace rows | MATCH |
| 33 | Okanagan Lake (R8, p70; **special limits**) | "Rainbow trout daily quota = 2 (only one over 50 cm), bass daily quota = 8, yellow perch daily quota = 20". Speed limits or no vessels at buoyed and signed spots | r1/r6 rainbow 2 with 1 over 50 cm; bass 8 and perch 20, each lifting the region's closure (in `exempts`); vessel rules shown as notes "in part" | MATCH |
| 34 | Okanagan River (R8, p70) | "No Fishing Oct 1-Nov 15; bass daily quota = 8, yellow perch daily quota = 20". Exempt from spring closure from the Okanagan Lake Dam to McIntyre Dam and below Drop Structure No. 1 (about 1 km above Osoyoos Lake). Rainbow trout catch and release; no powered boats | 3 parts. The spring closure is lifted on p2 (lat 49.26-49.50, 12.6 km: the dam to McIntyre) and p0 (lat 49.08, 1.4 km: below the drop structure); it holds on p1 (22.6 km between them) | MATCH |
| 35 | Oyama Lake (R8; **no row**) | Only the R8 base | Set 720: the R8 lake base | MATCH |

That makes 35 numbered rows covering 37 waters: row 6 holds three park waters, and row 13 holds the Fraser in two
regions. Every region has at least three waters: R1 9, R2 4, R3 4, R4 4, R5 5, R6 3, R7A 3, R7B 3, R8 3. The
no-row waters are Buttle, Bonaparte, Horsefly Lake, Shelagyote, Stuart Lake, Kotcho and Oyama. DFO salmon rules:
present on Cowichan, Campbell, Fraser, Skeena, Babine and Squamish. Not checked.

## Every DIFFERENT, with severity

1. **Campbell River (R1) summer closure.** The data closes it Jul 15-Aug 31; the book files it under MU 1-10, outside
   the closure. Severity: **wrongly told not to fish** (high visibility, but not in force before Mar 31, 2027). Cause:
   area membership by overlap. The river is the 1-6/1-10 line, so every section is in both MUs. The same cause is noted
   in `T1146-side-channels…md:103` ("Campbell River p6 … main straddles MU 1-6/1-10"), but there it is filed as the
   channel being wrong, when the main stem is the likely one at fault.
2. **Forsyth Creek p1 (991 m channel).** Missing the Elk River's tributaries rules. Severity: **could break the law**
   (shown open Sep 1-Oct 31; bull trout keepable). Small and in force only from Jun 15, 2027. T1146 fixes it.
3. **Shelagyote River p0 (1 channel section).** Missing the Babine Class I designation. Severity: **could break the
   law** (Classified Waters Licence not shown). Small. T1146 fixes it.

No wording-only difference was worth a ticket. Small label inconsistencies: Kootenay Lake's bass and perch labels
say "lifts …" and Okanagan Lake's identical lifts do not. The Lower West Arm repeats the kokanee 5 line (r3 = r5).

## Patterns

- **The zone (base) rules are right.** All nine regional boxes match the book line by line. The weak point is not the
  text but the **membership of a water in a region-wide area when the water is the area's border** (MU or park).
  Campbell is the one case I found that changes an answer on a main stem. T1146 lists the park version (Strathcona,
  365 sections carrying the park boat rule outside the park).
- **Water rows are parsed very faithfully.** 30 of 30 rows read had every line present, with dates, sizes,
  weekday rules, sunset hours and lifts right, including the red in-season corrections.
- **Placement inside multi-part waters is right** where I could check it with lengths and latitudes (Halfway 10.05 km
  for "~11 km", Okanagan River's three stretches, the Skeena licence sections, the Babine weir). I did not check most
  boundary points on a map.
- **The only rule gaps are on side-channel parts**, all already explained by T1146 and fixed in code but not yet built:
  Forsyth p1, Shelagyote p0, Koksilah p1, Halfway (7B) p2, Campbell p6.
- **Two synopsis copies disagree.** `data/source/official/…synopsis.pdf` lacks the red corrections the data
  follows. Anyone validating against it gets false differences (Cowichan, Fraser, Peace, Kootenay).

## Verdict for the release

**Go**, on the rules side, with the T1146 rebuild that is already planned. Nothing I found is in force between now
and the edition's end (Mar 31, 2027). The Campbell summer closure and the two channel gaps all fall in Jun-Oct
windows. The Campbell finding is the one real, visible misstatement on a main stem. It needs an owner decision, not a
release hold. Caveat: the app also shows whole-year calendars, so a planning angler would see the Campbell as closed
Jul 15-Aug 31 now.

## Picks for the owner

1. Campbell River (R1) and the MU 1-1 to 1-6 summer closure:
   (a) **Treat the Campbell as MU 1-10, as its book row says: no summer closure on the main stem (recommended).**
   (b) Keep the closure (the river is the MU line, so the closure reaches it).
   (c) Ask the Region 1 office first, and keep the closure until they answer.
2. Shipping 0.10.0:
   (a) **Ship after the T1146 rebuild, and re-check Forsyth p1 and Shelagyote p0 on that build (recommended).**
   (b) Ship r-71d09ad82e81 as it is (none of the gaps is in force before Mar 31, 2027).
3. The stale synopsis copy `data/source/official/2025-2027_freshwater_fishing_regulations_synopsis.pdf`:
   (a) **Replace it with the current gov.bc.ca copy, or label it "original print, without in-season corrections" (recommended).**
   (b) Leave it as it is.

## NEW TICKET

- NEW TICKET: Campbell River (R1) carries the MU 1-1 to 1-6 summer closure (Jul 15-Aug 31) because every section
  straddles MU 1-6/1-10; the book lists the river under MU 1-10 with no closure. Also check the other 5 mixed-MU
  sections that carry it (Spencer Creek and others).
- NEW TICKET: `data/source/official/2025-2027_freshwater_fishing_regulations_synopsis.pdf` lacks the in-season (red)
  corrections that `data/source/fishing_synopsis.pdf` and the data carry. Refresh or label it so validations use the
  current book.
- (No new ticket for Forsyth, Shelagyote, Koksilah or Halfway: T1146 covers them. Verify on the rebuilt candidate.)

## Not verified

- The shipped `regs-*.sqlite` answer shards. Their frames are compressed. I read the bundle's rules and, for Campbell,
  Forsyth, Koksilah, Cowichan and the Thompson, the stored open/closed answer in `verdicts.sqlite`. My day numbers
  assume a 366-day year, which is a guess; every check date sits well inside its window.
- What the app's screens print (labels, notes, calendar). Not run.
- Boundary points on the map (signs, bridges, falls). I checked only part counts, lengths and latitudes for a few.
- DFO salmon rules and in-season notices. I only noted that they exist.
- The live gov.bc.ca synopsis. Not fetched. I relied on the repo copy `data/source/fishing_synopsis.pdf`, which the
  memory notes say is not byte-identical to gov.bc.ca.
- Licence details beyond whether the designation or requirement exists. Possession quotas beyond the base box.
  Provincial (zp) rules, except the steelhead annual quota of 10.
- Whether the "UNCERTAIN" known-steelhead-water copies of the steelhead release rule (`z1`/`z3`/`z5`/`z6` `…r5b`/`r6b`/`r9b`)
  ever make a water show "unknown".
- The 48 red-line count includes some hidden overlaid text. It is approximate.
