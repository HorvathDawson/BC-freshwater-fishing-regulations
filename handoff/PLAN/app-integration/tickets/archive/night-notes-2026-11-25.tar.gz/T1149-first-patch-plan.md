# T1149 first patch: stop an area's rule reaching far outside the area (Creston first). Build-ready plan

Night agent, 2026-11-25, read-only. Code read at main (planning worktree, e14d494b3). Data: the main checkout's 0.10.0
candidate (bundle 12:57, tiles 12:35, atlas 03:18; one vintage, the same files the T1149 scoping used).
Scripts, outputs and pictures: `night/T1149-first-patch-plan/`:
- `measure_all_parks.py`: every stream section in all 708 provincial park and 33 WMA area items, cut against its polygon. 20 s, 1.5 GB.
- `measure_clean_areas.py`: the same for today's clean-cut areas (national parks, ecological reserves, Chilkoot). 3 s.
- `variants.py`: the no-cut variants, computed from the measured lengths.
- `pictures.py`: Goat River and Corn Creek, before and after.
- CSVs and JSONs of the results, and `pr265.diff`.

Lengths are measured on the tile layer's lines (`stream.geojsonl`) in BC Albers, against `atlas/full/area_catalog.gpkg`.
"Outside" is the section's length minus the part inside the polygon. A straddler has more than 5 m outside.

## Three findings first

1. **Majority binding is wrong for parks.** Under it, park water inside the boundary loses its rule. Bowron: 26.4 km
   inside the park would show the looser regional quota and allow bait. Strathcona: 102.5 km inside would lose its
   rule. Strathcona would still have 19 sections reaching more than 1 km outside, the worst 10.9 km (Salmon River).
   For Creston alone, majority still leaves 9.5 km outside: Kootenay River 3.4 km, an unnamed creek 3.3 km and
   David Creek 1.1 km still say "bass: no limit" where bass are closed. The only fix that is right on both sides is
   the clean cut that national parks already use.
2. **PR #265 has no length measure to reuse.** Its `part.inside_area` is a test on run end tokens: a side channel
   whose run goes from one area's cut to the same cut (`pr265.diff` lines 3155-3165). It does not measure length.
   The measure that does exist is `registry/regions.py:58-94` `region_shares`, the region home measure. The atlas
   build computes it once from `area_catalog.gpkg` and `geometries.pkl`.
3. **The cut costs less than it sounds.**
   - For Creston it is one curated edit: give the WMA its own def with `cut: "clean"`, as national parks have. No new
     cutter code.
   - It adds about 66 sections. Item ids do not change, so no entry resync. The owner has 0 marks on the Creston entry.
   - It needs one atlas side build (31.7 min, peak 20 GB). The release can reuse the proof's atlas, because the atlas
     build is deterministic.
   - It needs two small code changes. A lake-loop test treats every `area:wma:` id as membership-only
     (`lake_loops.py:94-99`). The new build check is about 200 lines.

## 1. How national parks are cut today, and what cutting more areas would take

**Today:**
- `data/curated/waters/area_closures.json`: national parks (lines 5-31), ecological reserves (33-63) and the
  Chilkoot Trail (64-80) have `cut: "clean"`, `rejoin_m: 1000`. Provincial parks (101-111), WMAs (113-124) and the
  Liard watershed (125-134) have `cut: false`, which means membership only.
- `cut_mode` checks the value (`pipeline/atlas/splits/area_splits.py:28-42`).
- `pipeline/atlas/build.py:1120` `cut_areas`: for a clean area, `resolve_clean_cuts` (`clean_cut.py:319`) applies
  `decide_rejoin` (`clean_cut.py:179-217`) to each blue-line chain:
  - outside runs of up to `rejoin_m` between inside stretches are joined to the inside;
  - cuts sit at the outer crossings;
  - dips under 5 m are ignored (`DIP_M`, `clean_cut.py:176`).
  The cutter's inside intervals go to `clean_inside` (`build.py:1169-1176`). Membership-only areas only load their
  polygons (`build.py:1209`).
- Membership: `pipeline/atlas/splits/border.py:327` `mark_inside_areas`.
  - For a clean area, a stream piece is a member exactly when it lies in a cutter interval (`border.py:397-406`).
    A piece that straddles an interval end goes to the build gate's `straddlers` list.
  - For every other area, a piece is a member when the polygon covers it, or when more than 1 m of it is inside
    (`_AREA_MIN_OVERLAP_M`, `border.py:275`, test at `border.py:438`).
- The registry turns membership into area items (`registry/build.py:501-514`). `within` is a set operation on that
  item (`reach/extent.py:1285-1318` via `area_sections`, `extent.py:49-67`).
- The area id comes from the def's `kind`: `area:{kind}:{slug(name)}` (`area_catalog.py:28-30`, `build.py:1176`).
  So a new def with `kind: "wma"` keeps `area:wma:creston_valley_wildlife_management_area`. All five Creston
  extents in `region-4.json` (lines 2638, 2670, 2708, 15381, 15400) still resolve.

**Ecological reserves are already cut clean.** "Cut provincial parks, reserves and WMAs" therefore means provincial
parks and WMAs. Measured with `measure_all_parks.py`; the clean-cut pieces come from my simulation of the 1,000 m
rejoin:

| scope | areas with straddlers | stream straddlers | km outside | new sections (clean, 1,000 m) |
|---|---|---|---|---|
| ALL provincial parks (708 items) | 669 | 16,495 | 34,632 | about 17,117 |
| ALL WMAs (33 items) | 31 | 1,083 | 2,399 | about 1,168 |
| **Creston Valley WMA** (rule: bass/perch no limit + permit) | 1 | 57 | 190.3 | **66** (km left outside: 0.24) |
| **Strathcona Park** (no powered boats) | 1 | 384 | 478.4 | **379** (5.5 left) |
| **Bowron Lake Park** (quota 1, bait ban, barbless, no powered boats) | 1 | 31 | 135.4 | **35** (0.5 left) |
| Garibaldi Park (Pitt River "No Fishing within Garibaldi Park") | 1 | 197, but **0 of the 413 Pitt-bound sections** | 344.9 (none bound by a rule) | 0 needed: the Pitt is already cut by the curated `garibaldi_park_boundary` split |
| Kikomun Creek Park (lake rules only) | 1 | 1 (not bound) | 1.9 | 0 needed |
| Hamber Park (Wood River) | 0 | 0 | 0 | 0 |

**Recommendation: cut only the areas whose rule binds streams.** Cutting all parks would add about 18,000 sections
(about 0.9% of the atlas) to fix nothing a rule reads. This is the same reasoning as the owner's 09-08 ruling in
memory `straddling-sections-mark-not-cut`. The build check (section 3) refuses the day a rule lands on an uncut area
that reaches too far, so nothing goes quiet.

**What a cut changes (Creston: 57 blue lines; hardening adds 381 for Strathcona and 30 for Bowron):**
- **Section ids.** New `{blk}:{measure}` ids for the pieces above each cut, and the handle digest changes. Section
  ids never leave the bundle (AGENTS.md:179-185), so links, feeds and pins are unaffected. Every derivative is
  rebuilt from the new handles: the tiles key includes the handles and `area_closures.json`
  (`pipeline/build.py:349-361`), and the reach and deliver keys include the handles. Tiles and bundle stay one
  vintage, enforced by the build's vintage check.
- **Item ids and entry ids do not change.** Items are keyed by gnis/wbk, and the area id comes from the kind. So the
  registry→entry resync in memory `registry-change-entry-resync` is NOT needed. Proof: the registry's item-id set
  before and after must be identical.
- **Owner marks.** A mark holds a rule's reach as metres per named water to 0.1 km, plus a COUNT of unnamed sections
  (`regs/review/fingerprint.py:177-188`). A cut moves no named water's metres. It does change the unnamed counts on
  the rules it touches. There are 0 marks on the Creston, Strathcona and Bowron entries and 0 on any `z4:` zone
  entry (grep of `marks.jsonl`). Strathcona's blue lines appear in 9 tidal marks, keyed by `split:tidal:<blk>`.
  Expected to hold; to be confirmed by the stale-marks listing in the proof.
- **Gauge matches.** Keyed by station, blk and coordinates (`gauges/matches.json`), not by section. Unaffected;
  `section_gauge` is rebuilt.
- **Golden fixtures.** `app/fixtures/golden/page-oracle.json` pins the Creston rule and the lower Kootenay River
  (line 17971). The release's golden re-cut step re-cuts it. Any T1135-type pin that reads the live release can
  still stop the follows.
- **Rebuild time.** Atlas 31m40s at a 20.0 GB peak (0.10.0 `atlas-next.log`). Then the build: reach 12.8 min
  alongside tiles 18.2, then deliver 15.1, 33.9 min in all (release-timeline.md).
- **Binding diff to expect, Creston.**
  - Records that change: `creston_valley_wma_waters.r1` and `.r2`, and the licensing records
    `creston_valley_wma_permit` (r4 entry) and `z4:creston_valley_permit`.
  - What they lose: about 190.1 km outside the WMA, on 57 blue lines. They gain 0 m.
  - Region 4's bass/perch closure binding does not change. It applies again on the outside pieces because the
    Creston rule's `exempts` (`region-4.json` 2647-2657) no longer reaches them.
  - At section level, every rule on those 57 lines shows old ids lost and new ids gained with the same metres. That
    is why a metres diff is needed (section 3).

## 2. The no-atlas-rebuild alternative, designed concretely

**Where it would go.** Two candidate places:
- **(R) The reach step.** A filter in `extent.area_sections` (`extent.py:49-67`), reading a share map attached to
  the graph as `regions.attach_from` does. No atlas run at all. **Rejected.** It makes two memberships: the
  registry and the review app say "member", the reach says not. The repo's own rule for area facts is the opposite:
  `outside_area_items` states them "ONCE … applied … to the one registry item every reader asks — never on a rule,
  never in a reader" (`registry/build.py:941-943`).
- **(G) A registry pass.** `trim_area_straddlers(registry, shares, policy)` placed right after `outside_area_items`
  in the atlas build (`build.py:1624`) and in `atlas/sidecars.py:170`.
  - Shares come from the same file the check writes (`area_overreach.json`, section 3), measured like
    `region_shares`.
  - The policy is a per-def key in `area_closures.json`, e.g. `"straddle": "majority"`. It is a curated proposal.
  - It creates no sections, so handles stay. The sidecar route (`python -m pipeline.atlas.sidecars --out`) can write
    the new registry without an atlas rebuild. However, writing into a promoted atlas is refused without `--force`
    (sidecars.py docstring), and I could not confirm that a sidecar-written atlas is promoted as a routine release
    step. So in practice it is also an atlas side build. Its saving is no new sections, not machine time.
  - Editing `area_closures.json` reruns the tiles anyway (the tiles key includes it).

**What each variant does** (`variants.py`; km wrongly outside before → left after; km inside wrongly stripped; pieces
still more than 1 km outside):

| area (direction of its rule) | today | majority (share in ≥ 50%) | share in ≥ 25% | inside ≥ 1,000 m | outside ≤ 1,000 m | majority OR outside ≤ 1,000 m |
|---|---|---|---|---|---|---|
| Creston WMA (LOOSER: lifts a closure; + permit) | 190.3 out, 38 over 1 km | **9.5 out / 16.3 in / 3 over** | 18.6 / 11.1 / 8 | 36.7 / 14.9 / 5 | 5.5 / **36.4** / 0 | 13.3 / 14.5 / 3 |
| Bowron (stricter) | 135.4, 18 | 3.4 / **26.4** / 1 | 28.2 / 9.5 / 6 | 67.0 / 4.8 / 10 | 4.1 / 28.5 / 0 | 6.2 / 25.1 / 1 |
| Strathcona (stricter, boats only) | 478.4, 118 | 99.0 / **102.5** / 19 | 222.6 / 31.4 / 56 | 212.5 / 100.0 / 49 | 97.5 / 180.9 / 0 | 157.7 / 78.8 / 19 |
| Garibaldi, Pitt r1 (closure) | 0 (already cut) | 0 | 0 | 0 | 0 | 0 |
| Liard watershed (outside parts outside B.C.) | 15.6, 4 | 12.5 / 1.4 / 3 | 14.0 / 0.4 / 3 | 12.0 / 4.0 / 3 | 6.5 / 26.8 / 0 | 14.4 / 0.3 / 3 |
| Hamber, Kikomun | 0 bound straddlers | — | — | — | — | — |

Only seven areas bind a rule by overlap and are not regions or MU groups. Those two are excluded by the owner's
line ruling (Campbell River). So the "top ten" are these seven.

**Collateral by direction.**
- For a stricter area (Bowron, Strathcona), stripped inside water is the unsafe side: anglers are told the looser
  regional rule inside the park.
- For Creston, stripped inside water shows the bass closure (the safe side), but it also loses the permit line on
  16.3 km inside the WMA (mildly unsafe).

**The variant with least collateral that helps Creston:** majority, scoped to the WMA def only. It changes nothing
in any other area. It still leaves 3 pieces more than 1 km outside, so it fails a 1,000 m acceptance cap. The Kootenay
River is one of them, a water the book names as included ("including … Kootenay River and Canal", p.36).

## 3. Recommendation and the proofs

**First patch (0.10.1, after the 0.10.0 merge-back): a clean cut for the Creston Valley WMA alone, plus the build
check as a ratchet.**
- It is right on both sides: 0.24 km left outside, about 0 km inside lost.
- It is one curated edit, with no new cutter code. National parks have run this cutter since 10-06.
- It adds 66 sections and changes no item id.
- Cost against majority: about +40 min of machine time and a metres-level proof. Majority needs the atlas side build
  too (section 2), so the real difference is the new sections.
- Four small new pieces of 10-14 m would appear at the WMA edge: Old Kootenay River Channel twice (317223, 317225)
  and two unnamed (433467, 391711). Each loses the WMA rule (the safe side for a lift). They will appear in the part
  list.

**Hardening release:** the same clean cut for Strathcona Park and Bowron Lake Park: one new
`provincial_parks_ruled` def with `kind: "park"`, `where PROTECTED_LANDS_NAME IN (…)`. That is about 414 new
sections. Then the ratchet's baseline goes empty and the check is strict. Side benefit: the T1146 cause D side
channels (Burman, Bedwell, Rees, Comox, Thelwood) merge into their main stems. Liard: leave it, because a watershed
boundary is a drainage divide. Garibaldi, Kikomun and Hamber: nothing to do.

**The build check (needed in both releases).**
- **What it measures.** For every stream piece bound through `within` (`area_id` or `area_kind`) or `within_area`
  to an area whose def is not `first_last`: the longest CONTINUOUS run outside the polygon, counting only length
  inside B.C.
- **Why a continuous run, not the total.** I measured today's clean areas. They pass by construction: of 137
  straddling pieces, the longest single outside run is 976 m (Beaverfoot River). Measured by total, they would fail:
  Beaverfoot is 7.5 km outside in total because it IS Yoho's boundary, the owner's line ruling. 15 pieces exceed
  1 km in total.
- **Why only inside B.C.** A B.C. rule never applies outside B.C., and every area is clipped to the outline
  (`_clip_policy`). This keeps Liard out. Not measured per run: the scoping found 0.1 km of Liard's outside lies
  inside B.C.
- **Cap: 1,000 m, the same as `rejoin_m`.**
- **What it refuses.** Any bound piece over the cap that is not in a curated, owner-approved baseline. It also
  refuses a baseline line that no longer overreaches, so the baseline can only shrink.
  - First patch baseline: Strathcona's 114 pieces and Bowron's 17 (measured, longest run > 1,000 m), keyed by area,
    blk and measure range (not section id).
  - After the Creston cut, Creston must have 0.
  - Garibaldi's 86 and Kikomun's 1 are bound by no rule, so they do not count.
- **Where it lives.**
  - The atlas writes `area_overreach.json` beside `region_home.json`: in `write_sidecars` (`build.py:1781`, next to
    `write_homes` at `:1804`) and in `atlas/sidecars.py` (add it to `SIDECARS`, `sidecars.py:50`; call it next to
    `:197`). `read_overreach` raises when the file is missing (no silent fallback).
  - The reach run then lists every offender with `!!` and stops, as it does for dead override ids
    (`reach/cli.py:86`). The baseline file's hash goes into the reach key (`pipeline/build.py`, beside `unplaced`).

**Proofs before any PR, from a side run (`pipeline build --atlas` then `--side`, after the 0.10.0 release frees the
Mac):**
1. **A metres-level binding diff, by place.** A read-only lane script built from both bundles' `section_measure` and
   `section_ruleset` (blk and measure intervals for each rule).
   - The four Creston records lose 190.1 km ±1%, only on the 57 lines, and gain 0 m.
   - Every other rule and licensing record changes by 0 m (±1 m per line).
   - The named creeks that must appear, with km outside: Goat River 23.8, Corn Creek 23.2, Summit Creek 21.8,
     Boulder 10.2, Newington 6.9, Dodds 6.2, Teetzel 6.0, Duck Creek 5.6, Midgeley 5.1, Cory 4.7, Jock 3.9,
     McLellan 3.9, Drywash 3.8, Kootenay River 3.4, Moores 3.2, Wilds 2.8, Littlejohn 2.8, Tito 2.5, Boundary Creek
     1.7, David Creek 1.1, East Branch Kootenay River 0.2, Old Kootenay River Channel (2 × about 0.01), and 30+
     unnamed.
2. **The existing section-level diff** (`python -m pipeline.atlas.reach.binding_diff`): its changes must be only
   those four records plus id churn on the 57 lines. Nothing gained in metres.
3. **An answer diff** on the outside pieces: bass and yellow perch "no limit" becomes Region 4's closure, and the
   permit row disappears. No change elsewhere.
4. The registry's item-id set is unchanged. The stale-marks listing shows 0 new stale marks.
5. **The check is proven by a mutation.** On the side atlas with the Creston def back at `cut: false`, the reach run
   refuses and names the 37 Creston pieces.

## 4. Lanes, files, tests, sizes, pictures, hours

**Lane A, Opus, size S-M: Creston clean cut.**
- `data/curated/waters/area_closures.json` (a PROPOSAL, owner approves):
  - a new def `creston_valley_wma`: `layer wma`, `kind wma`,
    `where WILDLIFE_MANAGEMENT_AREA_NAME = 'CRESTON VALLEY WILDLIFE MANAGEMENT AREA'`, `cut "clean"`,
    `rejoin_m 1000`, `tile_layer wma`, with `tile_names` moved onto it;
  - the general WMA def gets a `where … <>` in place of `which: all`.
  - No `outside_items` on the new def: `outside_of` and `outside_area_items` build the id from the def id, not the
    kind (`lake_loops.py:104-108`, `registry/build.py:962`).
- `pipeline/atlas/registry/lake_loops.py:94-99`: membership-only must be decided per area id, not by the
  `area:wma:` prefix. Otherwise the now-cut Creston still counts as membership-only.
- Check, and fix only if needed: the tile export with two defs on the `wma` layer. The pin
  `app/tools/tile-contract.test.ts:248` ("only Creston ships") must stay green.
- Tests (`pipeline/tests/test_t1149_creston_cut.py`):
  1. The Creston def's area id is unchanged and its cut mode is clean. Mutation: drop `kind` → the id becomes
     `area:creston_valley_wma:…` → the test fails.
  2. Synthetic: a line through a polygon. The outside piece is not a member of a clean area. Mutation: `cut: false`
     → the piece is flagged → the test fails.
  3. A lake loop across a clean WMA edge is refused. Mutation: restore the prefix test → the loop joins → the test
     fails.

**Lane B, Opus, size M: the overreach check.**
- A new `pipeline/atlas/registry/areas_overreach.py`: `write_overreach` and `read_overreach`, modelled on
  `regions.region_shares` / `write_homes` / `read_homes`.
- Hooks in `build.py:1781`, `sidecars.py:50/197` and `reach/cli.py` (after `:86`); the reach key in
  `pipeline/build.py`.
- A curated baseline `data/curated/waters/area_overreach_known.json` (a proposal).
- Tests (`test_t1149_area_overreach.py`):
  1. A piece with a 1,200 m outside run is refused. Mutation: cap = ∞ → the test fails.
  2. A baseline row lets it pass; a stale baseline row is refused. Mutation: drop the stale test → the test fails.
  3. Length outside B.C. is not counted. Mutation: no clip → refused → the test fails.
  4. `first_last` areas (regions, MU groups) are never checked. Mutation: include them → the Campbell River test
     fails.
  5. A missing `area_overreach.json` raises. Mutation: return `{}` → the test fails.

**Lane C, part of A's proof, not a ticket:** the metres-diff script, the answer diff, the pictures. Independent
second-agent review before merge (owner rule 11-17). Lanes A and B touch different files and can run in parallel.

**Pictures the owner must see:**
- Already made from the design (projected, not built): `night/T1149-first-patch-plan/goat-river-before-after.png`
  and `corn-creek-before-after.png`. Both show the WMA polygon. Goat River: the rule today on all 24.0 km, after on
  145 m. Corn Creek: 24.0 km today, 766 m after.
- From the side run: Goat River and Corn Creek in the web app at 390 px, map and page, before and after. The bass
  row goes from "No limit" to closed on the outside part; the permit line goes; the new part names read "… Creston
  Valley Wildlife Management Area boundary".
- Summit Creek: its 2.6 km inside must keep the rule.
- The list of the four 10-14 m edge pieces.

**Hours, start to production** (release-timeline.md §5 one-day patch; estimates):

| step | hours |
|---|---|
| Lanes A and B in parallel, with tests | 3 |
| Side proof: atlas 0.5 + build 0.6 + diffs and pictures 0.75 | 2 |
| Review and CI | 1 |
| Owner look before the cut: pictures, diff, the curated proposal, picks | 0.3 |
| Night release: atlas reuse (0.5 if not reused) + build 0.6 + follows 0.5 + staging 0.7 + smoke and device pass 1-2 | 3-4.5 |
| Owner's morning production sitting, phones | 1.5 |

About 11-12 h of work. On the clock: start in the morning after the 0.10.0 merge-back, production around noon the
next day, **about 26-28 h**. Risks:
- T1135-type pin stops (+45 min each);
- the edge slivers tripping T1140's `name_check`;
- the two-defs-per-tile-layer question.

## 5. Replacement text proposed for T1149

> **T1149 — An area's rule reaches far outside the area on sections that straddle its boundary.** Status: OPEN — HIGH.
> Split in two (2026-11-26 plan, `night/T1149-first-patch-plan.md`).
>
> **Part 1, first patch (0.10.1): Creston Valley WMA.** Its rule (bass and yellow perch no limit, which lifts Region
> 4's closure, plus the WMA permit) shows on 190 km of creeks outside the WMA (Goat River 23.8 km from 145 m inside;
> Corn Creek; Summit Creek): the app says "keep any number" where fishing for bass is illegal. Fix: the Creston WMA
> gets its own `cut: "clean"`, `rejoin_m: 1000` def (area id unchanged), as national parks have; lake_loops decides
> membership-only per area id. Plus the build check: no stream piece bound by an area rule (areas that are not
> first_last) has a continuous run longer than 1,000 m outside the area inside B.C. The reach run refuses, with a
> curated, owner-approved baseline that may only shrink (first patch: Strathcona 114, Bowron 17). Proofs before
> the PR:
> - the metres-level binding diff: the four Creston records lose about 190.1 km on 57 named and unnamed lines and gain
>   0 m; every other rule changes by 0 m;
> - the answer diff on the outside pieces only;
> - the registry item ids unchanged; 0 new stale marks;
> - the check refuses with the cut reverted;
> - pictures of Goat River and Corn Creek, before and after.
>
> Model: Opus. Size: M (two lanes).
>
> **Part 2, hardening release: Strathcona and Bowron.** The same clean cut for the provincial parks whose rule binds
> streams (about 414 new sections). The baseline goes empty, and the check is strict. Expected diff: Strathcona's
> boat rule loses about 473 km outside, Bowron's rules about 135 km, nothing gained. The T1146 cause D side channels
> merge. Not cut: the other provincial parks and WMAs (about 18,000 sections for no rule; the check refuses the day
> one gains a rule that reaches out), Liard (a drainage divide), Garibaldi (the Pitt is already cut by its curated
> split). Rivers that ARE a region or MU line keep both sides' rules (owner ruling, Campbell River). Model: Opus.
> Size: M.

## Picks for the owner

1. **The first-patch fix for Creston:**
   - (A) A clean cut at the WMA edge, the national-park cut: right on both sides, 66 new sections. **Recommended.**
   - (B) Majority binding for WMAs only: no new sections, but 9.5 km still shows "no limit" outside (Kootenay River
     3.4 km) and 16.3 km inside loses the permit line.
   - (C) Majority for every area: Bowron and Strathcona water INSIDE the parks would lose their rules.
2. **Strathcona and Bowron:**
   - (A) The same cut in the hardening release. **Recommended:** a small first-patch diff.
   - (B) In the first patch too: one atlas run instead of two, but about 8 times the diff and many more part names to
     check.
3. **The build check's limit:**
   - (A) The longest continuous outside run ≤ 1,000 m, counted only inside B.C. **Recommended:** today's national
     parks pass, and the longest run is 976 m.
   - (B) The total outside ≤ 1,000 m: this would refuse Yoho's Beaverfoot River and 14 other boundary rivers.
   - (C) 250 m.
3b. **The check's start:**
   - (A) A baseline of the known Strathcona and Bowron pieces that may only shrink. **Recommended.**
   - (B) Strict from day one, which means doing Part 2 first.
4. **The four 10-14 m edge pieces** (Old Kootenay River Channel ×2, two unnamed):
   - (A) Accept them outside: the safe side for a lift rule. **Recommended.**
   - (B) Look at the pictures first.

## NEW TICKET lines

- NEW TICKET: A binding diff by place (blk and measure metres per rule) beside the section-level `binding_diff`, so
  any cut, not only T1149's, can be proven with "only these metres moved". (T1149 Part 1 uses a lane script; this
  makes it a tool.)
- (Lane items inside T1149, no ticket: the lake_loops membership-only by area id; two defs on one tile layer.)

## Not verified

- Whether `load_area_split_defs` and the tile exporter accept two defs on the `wma` layer with `tile_names` on one of
  them (read, not run).
- How a sidecar-written atlas is promoted for a release (the reason section 2 assumes an atlas side build anyway).
- The clean-cut counts (66 / 379 / 35, km left) are my simulation per section, at a 1,000 m rejoin. The real cutter
  works per blue-line chain, snaps to boundaries already on the line, and runs the 5 m sliver gate. Real counts will
  differ a little.
- Lengths are from the tile layer's lines, not the atlas's own `geometries.pkl` (2 GB; not loaded tonight).
- Liard's continuous outside runs inside B.C. were not measured. The 0.1 km inside B.C. figure is the scoping's.
- The Region 4 bass/perch closure on the outside water rests on the scoping's reader check of two sections.
- The 9 tidal marks on Strathcona lines staying fresh is expected, not checked.
- The hours are estimates from the last two releases, not trials.
- The 0.10.0 chat's "majority inside reusing #265's measure" was checked against `gh pr diff 265`. The pipeline part
  of #265 is `builders.py`, `part.py` and a test only.
