# The data build: run only what its inputs need, every output a hashed artifact

Night agent, 2026-11-25 (written 23:00 MST), read-only. The code is read at main
(`c0daabd8a`, the planning worktree). The numbers come from the main checkout's `data/generated` (read only). Scripts are
in `night/data-build-caching/` (`runs.py`, `logtimes.py`, `wasted.py`). Each was one niced process and took a few seconds.

## Short answer

- **Most of what you asked for exists already.** Every stage after the atlas has a key. The key is a digest of what the
  stage reads, its own code included. A stage whose key has not moved is skipped (`pipeline/build.py:30-36,480-512`).
  Inside deliver, each step (bundle, answers, …) is skipped the same way (`pipeline/common/stepcache.py`). A build
  where nothing changed takes 2 seconds (15 such runs in the manifest). The release id is a hash of the output files'
  hashes (`pipeline/deliver/release/rebase.py:38-42`). The release command does not rebuild a candidate it already
  built (`pipeline/release.py:1681-1717`).
- **The atlas is not decided by a key.** It never builds itself. It records the curated files it was built from, and the
  release refuses an atlas that is behind them (`pipeline/atlas/inputs.py:7-12`, `release.py:1228-1240`). **Its record
  has no code stamp.** An edit to the atlas code is not noticed.
- **What is missing:**
  1. **Four holes where a stale result could pass.** A stage key holds only `.py` files, so the bundle's `schema.sql` is
     in no key. The tiles and clim keys leave out the installed packages and tippecanoe. The atlas has no code stamp.
     The release manifest also depends on which release came before it.
  2. **A one-slot cache.** Only the last result of each stage and step is kept, so going back to an earlier state means
     building it again. Side runs (`--side`) start with an empty cache.
  3. **Keys use file times, not content, for the big files.** This causes false reruns. Measured: 16 bundle reruns that
     made the same bytes, 115 min in 27 days. 13 of them came from the in-season loop, which is already fixed. File
     times also mean no other machine can reuse a result.
  4. **Deliver waits for all of the tiles stage (18.2 min), but needs only its first 7.4 min** (the layer files).
     Splitting the tiles stage saves about 6 min on every build that runs the tiles.
- **How much faster this makes a release:** on a release like 0.10.0, where the atlas changed so every stage had to
  run, the design saves about 6 min of the 33.9. The big savings are on small changes and in development:
  - a README edit: 10 min → 0;
  - a tile-drawing change: about 21 → 12 min;
  - going back to an earlier state: up to 28 → about 1 min;
  - side runs no longer start cold.

  The data build is under 5% of a release's hours (release-timeline.md §4), so **fix the correctness holes first**.

---

## 1. The stage graph as it really is

`python -m pipeline build` (`pipeline/build.py`). The stages and their order are one table, `STAGE_GRAPH`
(`build.py:103-119`). `--jobs 2` is the release's setting (`release.py:859-860`). clim and reach start together. The
tiles start when a slot frees. Deliver starts when reach and tiles are both done (`build.py:117`, `depends=("reach",
"tiles")`), and after clim (it reads clim by content).

### Measured times

The durations come from the log files of 59 builds, 2026-10-30 to 2026-11-25
(`data/generated/build-logs/<start>/<stage>.log`). Each stage's start is the run's start, or the end of what it waits
for. Its end is the log file's last write. Script: `logtimes.py`. The manifest keeps only the last 20 runs
(`build.py:440`), so the logs are the longer record. The 3 in-manifest full runs agree with the log times to the
minute.

| Stage | Sub-steps (time, 0.10.0 build) | Reads | Writes | Minutes: n, min / median / max | What decides that it runs |
|---|---|---|---|---|---|
| **atlas** | one process, `pipeline.atlas.build --full` | the FWA gpkg (10.2 GB), the coast gpkg, 13 curated waters files (`inputs.py:50-67`) | `atlas/full/` 3.5 GB: geometries.pkl 2.07 GB, waterbody_polys.pkl 728 MB, graph.pkl 629 MB, registry.json 122 MB, section handles | n=1 in the manifest: **31.7** (peak 20.0 GB) | **Only by hand**: `build --atlas [--promote]` (`build.py:700-723`). `build` warns, and `release` refuses, when a recorded curated input moved (`build.py:726-738`, `release.py:1228-1240`) |
| **clim** | `gauges.feed.climatology` | HYDAT (size + time), its release marker, the station roster (size + time), the accepted datum changes, **the year** (`build.py:284-293`) | `clim.json` | n=3: 0.5 / 0.5 / 30.9 (the 30.9 was a loaded Mac, 11-18) | its key |
| **reach** | one process (no timers inside) | the atlas handles and registry, the corpus, the steelhead list, DFO places, the tidal record, 3 curated files, **the code it imported** + the installed packages (`build.py:319-333`) | `reaches/full/` 745 MB: rule_section.jsonl.gz 485 MB, licensing_section.jsonl 131 MB, steelhead_presence.jsonl 118 MB | n=34: **10.2 / 11.7 / 46.0** (the over-14 runs were loaded Macs) | its key |
| **tiles** | layer export **441 s** (`tiles.log:59`), then 30 tippecanoe passes, about **647 s** (total 1,088 s, `tiles.log:99`) | the atlas handles, the gpkg (size + time), the tidal record, `areas.json`, the obstacles file, **the .py files under 4 hand-picked folders** (`build.py:349-362`) | `tiles/` 3.9 GB: `layers/*.geojsonl` 3.6 GB (stream 2.5 GB), atlas.pmtiles 189 MB; then `data/release/tiles/<handles16>.<sha12>/` about 200 MB | n=27: **8.5 / 15.0 / 44.1**; 0.10.0: 18.2 | its key |
| **deliver** | bundle 518 s · verdicts 53 · status_index 5 · export 20 · answers 88 · card_check 97 · store 54 · release 72 · runtiming 0 (`deliver.log:149-547`) | atlas, corpus, every declared curated file by content, the source stamps, clim.json, the DFO typed feed and the in-season end tokens by content, **the code it imported** (`build.py:240-260,334-336`); the bundle also reads the tile layers (`bundle/build.py:624,738-782`) | `bundle/` 213 MB (bundle.sqlite 160 MB, verdicts 46 MB), the export pair, the answers, `data/release/r-<id>/` 31 MB, the run-timing base | full chain n=36: **6.0 / 12.1 / 15.3**; deliver alone n=19: 0.7 / 9.3 / 13.3 | its key, **and any run of reach or tiles** (`build.py:492`), even one that wrote the same bytes. Inside it, each of 7 steps is skipped or run on its own (`deliver/__main__.py:78,98-139`) |
| (vintage) | `vintage.report_all`, seconds | tiles + bundle + every artifact | — | — | every run (`build.py:869-877`) |

Whole builds that ran reach, tiles and deliver: n=20, **21.0 / 27.6 / 59.1 min**. The two release builds were 28.7
(0.9.0) and 33.9 (0.10.0). In total, 59 runs took 1,217 machine-minutes (20.3 h) in 27 days.

### The deliver steps across 27 deliver runs (seconds, from each `deliver.log`)

| Step | Typical when it runs | Cached? |
|---|---|---|
| bundle | 345–518 (grew from about 350 on 11-07 to 518 on 11-25) | yes |
| verdicts | 46–78 | yes |
| status_index | 5 | yes |
| export | 17–30 | yes |
| answers | 63–94 | yes |
| card_check | 74–131 | yes |
| store | 50–71 | yes |
| release | 17–72 | **always runs** |
| runtiming | 0–65 | **always runs** |

### How does the atlas decide that its inputs changed? Is the code part of it?

- **It does not decide.** `pipeline build` never rebuilds the atlas to check it (`build.py:33-36`). A person runs
  `build --atlas`.
- **What exists is a record of what it was built from.** `graph.pkl.meta.json` holds `input_hashes`: 14 entries. 12 are
  curated files by sha256. The cuts are hashed by their anchors only. The two gpkg files are hashed by size and time
  (`inputs.py:17-23`). The record is taken when the build starts. `behind()` compares the record with the tree now.
- **No code and no package versions are in it.** I checked the live atlas's meta file: `input_hashes` and `build_ts`
  only. So an edit to `pipeline/atlas/build.py` leaves the atlas "current".
- **The mechanism to copy is the other stages' key**, not the atlas's. A stage is up to date when
  `sha(inputs + code + environment)` equals the last successful key and its outputs exist (`build.py:30-33,492`).
  - reach and deliver have the full **code stamp** (T522). The key holds the bytes of every module the stage really
    imported, and the interpreter and every installed package (`build.py:296-303,667-678`,
    `stepcache.py:77-84`).
  - tiles and clim have a weaker one: every `.py` file under hand-picked folders, and no packages (`build.py:104-116,141-152`).
  - the atlas has none.

## 2. Can each stage be skipped, and is it deterministic?

### What each key should be

The general rule: `sha256(stage name, its arguments with paths taken out, the content hash of each input file, the output
hashes of the stages it reads, its code, the environment)`.
- **Its code** means every repo file it read, not only `.py` files.
- **The environment** means Python, the installed packages, and the version of each outside tool.

| Stage | Skippable today? | Key today | What the key lacks | Deterministic? (evidence) |
|---|---|---|---|---|
| atlas | by hand only | none (a record of 14 inputs) | code, packages, tool versions; the gpkg by time, not content | **Yes**: two builds byte-identical (T65, memory `atlas-build-not-deterministic`, "two builds identical"); `build.py:33-34` says so |
| clim | yes | HYDAT and roster by size + time, datum, year, `.py` under 3 files | packages; content in place of times | Probably. It reads the clock for the **year** only (`climatology.py:299`), and the year is in the key. Not proven byte for byte |
| reach | yes | full (traced modules + packages) | **non-`.py` files it reads**; content in place of times for the gpkg | **Yes for what the bundle reads.** 11-11T03:15: reach ran again and the bundle ran again, then the verdicts step was REUSED on the bundle's unchanged sha256 (`deliver.log`) |
| tiles | yes | `.py` under 4 folders, gpkg by time, areas, obstacles by time, handles, tidal | **packages (shapely, pyogrio), tippecanoe / tile-join / pmtiles versions**, `pipeline/common`, any non-`.py` file | **Yes since T305.** The tile id is the archive's own sha256 (`tiles/version.py:1-12`). The random temp path tippecanoe writes into the metadata is masked before hashing (`version.py:52-60`). The same id came out of 4 builds (`822db448….f98ea27b8e5f`: 10-31, 11-02 three times) and of 2 builds (`105218b3….feb6d896ff03`, 11-11) |
| deliver | yes | full (traced) + curated by content + source stamps | **`schema.sql` / `indexes.sql` and every other non-`.py` file**; the SQLite library version; the previous release (below) | **Yes.** 15 pairs of runs rebuilt the bundle and the answers from scratch and minted the **same release id**, for example `r-c7c6b2422c65` at 11-18 06:56 and 08:53, and `r-f749475d0962` at 11-13 21:24 and 22:01 (`wasted.py`; ids grepped from each `deliver.log`). The card gate's sampling is seeded (`answers/card_check.py:698`, `answers/trout/check.py:739`). The clock is kept out: `published` and `minAppVersion` are stamped after the build and are outside the id (`release/stamp.py:1-15`). gzip is written with mtime 0 (`water_digests.py` docstring) |

### The holes where a stale result could pass (a wrong cache hit)

1. **Non-`.py` code is in no stage key.**
   - The traced code key is built from `M` (module) lines only (`build.py:667-678`). The fallback hashes `*.py` only
     (`build.py:147`).
   - The live manifest's deliver record lists 285 code files, every one a `.py` file (and the reach record 105, the same).
   - Yet the bundle reads `pipeline/deliver/bundle/schema.sql` and `indexes.sql` (`bundle/build.py:39-40`), and the store
     reads `pipeline/deliver/store/schema.sql`. `schema.sql` is edited in real commits (61829dbbf T1053, 6d34b7580
     T985).
   - A commit that changes **only** a schema file leaves `build` saying "deliver up to date". The bundle on disk would
     not have the new column.
   - The step cache would catch it, because it keys every file read by content (`stepcache.py:140-150`). But the step
     cache only runs when the stage runs. **Fix:** the stage key also holds every file the trace read under the
     repo's code folders (`pipeline/**`, tracked, not generated). It is one more part of the trace already recorded.
2. **The tiles and clim keys are hand-picked folders with no packages.**
   - A shapely, pyogrio or GDAL upgrade changes how geometry is simplified, but leaves the tiles "up to date". So does a
     `brew upgrade tippecanoe`.
   - `tippe.check()` only checks that the tools are on the PATH (`tiles/tippe.py:191-196`).
   - **Fix:** trace tiles and clim like reach and deliver. Keep P18 (tiles are geometry only) as a short **exclude list**
     (the registry names), not as hand-picked include folders. Add `tippecanoe --version`, `tile-join --version`,
     `pmtiles version` and `sqlite3.sqlite_version` to the environment fingerprint. Python's own version string does not
     name the SQLite library, and the bundle's bytes depend on it.
3. **The atlas has no code stamp.** **Fix:** run the atlas build under the same recorder. Add `code` (the modules it
   imported) and `env` to its `input_hashes`. `behind()` then names "atlas code changed" the same way it names a curated
   file.
4. **The release folder depends on the release before it.**
   - `changed_waters` counts against the release LATEST names (`deliver/__main__.py:290-294,317-324`). It is outside
     the id, but it is inside `manifest.json`.
   - A cache that is keyed on inputs and restores a whole release folder could restore the wrong count.
   - **Fix:** move the count into the stamp step with `published` (it is a publish-time fact), or put the previous id
     into the release step's key.

Also: **file times in keys.** These are not wrong hits; they cause false misses, and they block sharing:
- the gpkg, HYDAT, stations, places and obstacles are keyed by size + time (`build.py:226-229`);
- every file under `data/source` (24 GB) and the atlas folder is keyed by size + time in nanoseconds
  (`deliver/__main__.py:142-159`, `stepcache.py:169-182`);
- every curated file **including READMEs** is too, for the bundle step.

The measured cost is `wasted.py`'s count of bundle runs whose next step was REUSED (same bytes out):

| Why the bundle ran | Runs | Minutes | Still happens? |
|---|---|---|---|
| the in-season step rewrote `notice_waters.json` | 13 | about 95 | **No.** Last seen 11-19; fixed by T679 #11 (the resolution is generated now) and T788 #10 |
| the reach run's report.json got a new time (the bundle picks the newest run by time, `bundle/build.py:156`) | 1 | 6.6 | yes |
| a cut's label edit (`cuts.json`) | 1 | 7.4 | yes |
| a module the bundle imports changed, with no effect | 1 | 7.4 | yes (normal: you cannot know the output until you run it) |

READMEs are named among the "declared inputs changed" in 7 runs (11-11, 11-12 ×2, 11-13, 11-20, 11-21, 11-25). Each
time other files changed too, so a README-only rerun was not isolated. It would cost about 10 min (the bundle, then the
release step).

**Fix:**
- keep a content-hash index: (device, inode, size, mtime_ns) → sha256 in one small file, the way git's index works;
- key by content;
- hash a file again only when its time moves;
- leave `*.md` out of the curated digest.

The first run hashes the 24 GB of sources once (**guess**: under a minute on this SSD). After that it costs almost
nothing.

## 3. Finer than stages

### 3a. Split the tiles stage: `tiles.layers`, then `tiles.pack`

- The bundle reads only `tiles/layers/*.geojsonl` and `atlas.meta.json`'s handles (`bundle/build.py:624,738-782`,
  `bundle/access.py:298-307`). Those are written in the first 441 s.
- The 647 s of tippecanoe make the `.pmtiles` that only the release step and the vintage check need.
- **Design:**
  - `tiles.layers` writes the layers and a manifest of their sha256s;
  - `tiles.pack` runs tippecanoe on them;
  - deliver keys the layers **by content** (the way it keys `clim.json` today, `build.py:38-43`), not "tiles ran";
  - only the release step waits for `pack`.
- **0.10.0 with this:** deliver starts at max(reach 12.8, layers 7.4) = 12.8 min, not 18.2. The build ends at about
  12.8 + 15.1 = **27.9 min, against 33.9**. It would be about 23.6 against 28.7 for 0.9.0.
- **Memory (a guess):** pack (≤ 9.9 GB) and deliver (13.2 GB) at the same time is about 23 GB of this Mac's 48 GB
  (`sysctl hw.memsize`). This is inside heavy.sh's 50%-free start gate only if nothing else runs.

### 3b. Edges by content, not by "it ran"

- Today a reach or tiles run always reruns deliver (`build.py:492,544`), even when it wrote the same bytes.
- The steps inside then skip on the bytes, but the stage still costs the release and run-timing steps, plus restoring
  every cached output (about 1–2 min).
- **Design:** every edge is by content. A stage's output gets a manifest (file → sha256), and downstream keys hold that
  digest. This is "early cutoff": a rerun that changed nothing stops there.

### 3c. Inside the bundle (measure first)

- The bundle is one process of 8.6 min writing 80 tables. Its log prints no per-part times. The families of tables come
  from different inputs:
  - **gauges** (HYDAT, matches, clim, stations; about 15 tables);
  - **rules** (the reach run; ruleset, section_ruleset);
  - **licensing**;
  - **salmon** (the DFO feed; salmon_section);
  - **places / access** (the atlas and the tile layers);
  - **parts** (part, part_section, water_exit).
- **Design:** add a timer per part (T295 style), then cache each family as its own step keyed by its own reads. The
  SQLite file is then put together from the parts. A DFO refresh would redo the salmon part only.
- **The size of the gain is a guess** until the timers exist. If salmon is about 1–2 min of the 8.6, a DFO refresh
  saves about 6 min.

### 3d. Per water and per region: only for development, not the release

- The answers (88 s) and the card gate (97 s) could reuse a water whose inputs are unchanged.
  `release/water_digests.py` already gives each water a digest of its decoded answers.
- But the card gate is a safety gate. The release should keep running it in full. A per-water mode is worth it only for
  a lane iterating on wording, saving about 2.5 min per try.
- A per-region or per-entry reach is the only way to make a rule edit much faster than 12 min. Today the reach run has
  no timers either, so how much is loading the 2.7 GB atlas against binding 1,516 entries is **not known**. Measure
  that first.

### 3e. Five realistic changes, minutes of build

"Today" uses the measured medians, with 0.10.0's numbers in brackets. "Design" assumes 3a + 3b + content keys + the
cache. Rows marked *guess* need 3c's or the reach's timers.

| Change | Stages that must run | Today | With the design |
|---|---|---|---|
| **A curated rule edit** (one `synopsis/region-N.json` rule) | reach, deliver (no tiles, no atlas) | reach 11.7 + deliver 12.1 ≈ **24** (28) | the same 24 with 3a–3b. With bundle parts, rules only: about 20 (*guess*). With a per-entry reach: about 10–12 (*guess*) |
| **A DFO notice refresh** (the typed feed) | deliver only (`build.py:255-256`) | the bundle and everything after it: **about 13–15** | the salmon part + verdicts → store + release: about 7–8 (*guess*) |
| **An app-only change** (`app/` only) | **none.** No key reads `app/` | **2 s** (all up to date), already | 2 s; the release says "data unchanged" plainly (§6) |
| **A tile drawing change** (tippecanoe flags in `tippe.py`, not the layers) | tiles (pack only) | tiles 15–18 + deliver forced (steps reuse, about 2–3) ≈ **18–21** | pack 10.8 + release step 1.2 ≈ **12** |
| **A HYDAT refresh** (quarterly) | clim, deliver | 0.5 + about 13–15 ≈ **14–16** | clim + the gauge part + downstream: about 8 (*guess*) |
| (also) a README or label-only curated edit | none should | **about 10** (bundle + release) | **0** |
| (also) going back to an earlier state (a revert, the release branch against main, a side run) | none should | everything that differs from the last run: **up to 28** | restore from the store: **about 1** (copying about 1 GB; clones cost no disk) |

A **tiles style change in the app** (the MapLibre style) is an app change: no data build, today or after.

## 4. Where the artifacts live

### On the Mac: a content-addressed store

```
data/cache/
  hash-index.sqlite                 (dev, inode, size, mtime_ns) -> sha256, so content keys stay cheap
  stages/<stage>/<key>/             one finished stage run: its outputs + out.json (file -> sha256, bytes) + provenance.json
  steps/<step>/<fingerprint>/       the deliver steps, K per step instead of one (stepcache.py:202-204 keeps one)
  index.json                        last used, size, and which pointers name it
```

- **Live homes are filled from the store by an APFS clone** (`cp -c`, copy-on-write). The live file and the cached file
  share disk blocks until one is written, so the current version costs no extra space.
  - The step cache copies on purpose today, so that a write through a shared hard link cannot corrupt the cache
    (`stepcache.py:330-335`). A clone keeps that safety: a write to a clone does not touch the original.
  - **Not verified:** whether Python's `shutil.copyfile` clones on APFS. Use `cp -c` or `clonefile(2)`.
- **Never pruned:** whatever LATEST, CANDIDATE, PUBLISHED, the staging pointer or the baseline names.
- **Pruned:** the rest, least recently used first, down to a cap. The proposed cap is 20 GB (82 GB free today; heavy.sh
  stops under 20 GB).
- **Older large outputs are kept zstd-compressed** (sampled with `gzip -1`, 100 MB of each):

| Stage output | Raw | Compressed (sampled) | Copies under a 20 GB cap |
|---|---|---|---|
| atlas | 3.5 GB | about 1.8 GB (geometries.pkl to 55%, graph.pkl to 25%) | current + 1 (replaces today's hand-kept `atlas/full.prev`, 3.5 GB) |
| reach run | 745 MB | about 0.5 GB (485 MB is already gzip) | 4 |
| tile layers | 3.6 GB | about 1.0 GB (lake.geojsonl to 28%) | current + 2 |
| tile pack (pmtiles) | 189 MB | the same (already compressed) | as many as releases name |
| deliver outputs (bundle, verdicts, export, answers, store) | about 260 MB (`deliver-cache` is 256 MB) | about 100 MB (**guess**) | 10 |
| release folder | 31 MB | (already gzip) | as today |
| clim.json | small | — | 10 |

**Disk you get back today, without the store:**
- `data/release/tiles/` holds **18 tile versions, 3.6 GB**. `prune.py` never touches it (`release/prune.py:5-8`).
  Keeping the versions that kept releases name frees about 3 GB. That belongs in T1142.
- The hand-kept `atlas/full.prev` (3.5 GB) becomes the store's previous atlas.

### In R2: a private build cache, later

- **Where:** a new **private** bucket, never the public data buckets. Objects are `stages/<stage>/<key>.tar.zst` with
  `<key>.json` (out.json + provenance) beside them.
- **When to push:** after a release build, only the stages that release used: about 1.8 + 0.5 + 1.0 + 0.2 + 0.1 = 3.6 GB
  per full release.
- **When to pull:** on a miss, behind a flag (`--remote-cache`).
- **Who gains:**
  - **A fresh Mac** (T1120): it pulls the atlas, the reach run and the tiles instead of building them, about 62 min of
    machine time saved. It still needs the 10 GB gpkg, because the bundle reads it (`build.py:240-246`).
  - **CI:** it cannot build the atlas (20 GB peak; a standard runner has 16 GB, **not checked tonight**). So CI uses the
    cache to **check** a release (§5), not to build one.
- **Cost:** R2 charges about $0.015 per GB-month, with no egress fees. That is from memory and **not checked tonight**.
  Keeping 3 releases is about 11 GB, so cents a month.
- **The key must hold no machine path and no file times.** That is why content hashing (§2) comes first: today's keys
  could never match on another machine.

### "Tiles and bundle share a vintage", by hashes

- **Today:** `vintage.report_all` checks at the end of every build that the tiles, the bundle and every artifact carry
  one `section_handles` digest. Strict mode refuses (`build.py:869-877`, `vintage.py:217`). The release id covers the
  tiles block (`rebase.py:24-35`), and the tile id starts with the handles digest (`version.py:1-12`).
- **With the design:**
  - the deliver key holds the atlas id and the **tile layers' output digest**, and the release step holds the pack's
    tile id;
  - so a cached deliver can only be served with the same layers it was cut from;
  - the release step cannot be served with another pack, because its key would differ.
- The strict vintage check stays as the loud last line. It should never fire, and if it does, a key is missing something.

## 5. Making a wrong cache hit impossible, or loud

1. **The key covers all the code.** That means every module imported, **every repo file read** (hole 1), the installed
   packages and the tool versions (hole 2). The atlas gets the same (hole 3).
2. **Outputs are checked on the way out.** The step cache already hashes a restored file again in place, and refuses a
   kept output whose bytes changed (`stepcache.py:223-240,264-267`). The stage store does the same against `out.json`.
3. **`--no-cache`.** It exists today as `build --force <stage>` and `deliver all --no-step-cache` (`build.py:765-766,784`).
   Rename it to one flag, `--no-cache`, that skips every lookup and still records what it built.
4. **`build --verify [stage…]`.**
   - It runs the stages into a side folder with no cache, then compares each output's sha256 with the stored one.
     Equal: the entry is proven. Different: the run stops, naming the stage, and the entry is marked "bad" so it is
     never served again.
   - The side-run mechanism exists (`--side`, `build.py:55-58`).
   - Running it needs the machine for a full build (about 34 min). The release-night run, while the Mac is idle, is the
     place for it.
5. **Provenance in every release folder, outside the id.** A `provenance.json` holds:
   - the commit, and the git tree hash of `COMMITTED` (`release.py:175`: pipeline, data/curated, scripts, deploy,
     project_config.py, config.yaml);
   - each stage's key and output digest;
   - the environment fingerprint and the tool versions;
   - the atlas's input record and its code stamp.

   This is the T251 pattern, like `published`, so stamping it changes no id.
6. **How the release gate proves the data was built from the tagged code.**
   - At `release --final` (and in the ship workflow's verify job, ship-workflow-design.md), check out the tag cleanly.
   - Check that the tree hash of `COMMITTED` equals the provenance's.
   - Then **compute the stage keys again** from that checkout. That is hashing only, a minute or two, no build. They must
     equal the provenance's keys.
   - Today the proof is the Mac's ledger `commit` plus "nothing in `COMMITTED` was committed or left dirty since"
     (`release.py:1681-1693`) plus the preflight's clean-tree check. That is good on this Mac, but nothing outside the
     Mac can check it.
   - With provenance, a key mismatch at the tag means the data was built from other code, and it is a stop.
   - Step 4 proves that building again gives the same bytes. Together they prove "this data comes from this commit".

## 6. Does a release need a data build when only the app changed?

**No, and today it mostly does not build one.** What `release --staging` does after an app-only change, read from
the code:
- **build:** `pipeline build --hold-latest` finds every stage up to date and takes 2 s, like the 15 no-op runs in the
  manifest. No CANDIDATE is written, so the release is LATEST, "(already LATEST)" (`release.py:1707,1717`).
- **checks and follows:** they are recorded per release id and skipped when done for that id
  (`release.py:2026-2036,1841-1917`). The app's own checks still run, because fast-fail is keyed on the tree's content,
  and with the follows skipped it runs the app gates itself (`release.py:1514-1525,1534-1548`).
- **staging:** "already on staging" skips the upload and goes straight to the tags (`release.py:2159-2162`). The rc tag
  then names the same data release.

**What it should do instead:**
- **(a)** Say it in one line at the start: "data unchanged: r-… was built at <commit>; its keys match HEAD; no data
  build, no data checks, no upload".
- **(b)** Prove that line by recomputing the keys (§5.6), not by finding nothing to do. Today a stale key (holes 1–3)
  would also find nothing to do.
- **(c)** Leave out the pipeline data tier on the candidate. It already passed for that id.
- **(d)** Every release so far has carried a new data release: 25 ids in the ledger, none app-only. So this path has
  never been run for real. Rehearse it once (`release --staging --dry-run`) before relying on it.

## 7. A staged plan

"Saves" means build minutes, from the measured medians. *Guess* marks the ones that need timers first.

| Step | What | Size | Saves per release | Saves per dev iteration | Risk |
|---|---|---|---|---|---|
| **S1. Correctness first** | holes 1–4: non-`.py` reads in stage keys; tiles + clim traced, tool versions in the environment; the atlas code stamp; `changed_waters` moved to the stamp | S–M | 0 (it can add a rerun the first time) | 0 | low; closes silent-stale paths |
| **S2. Content keys** | the hash index; content in place of size + time; `*.md` out of the curated digest; the bundle picks its reach run by digest, not by time | M | 0–10 (README / label / promote churn) | 0–10 | low |
| **S3. Split the tiles; content edges** | `tiles.layers` / `tiles.pack`; every edge by output digest | M | about **5–6** on a build that runs the tiles (0.9.0, 0.10.0) | same | medium (memory overlap: one heavy job at a time) |
| **S4. The store** | `data/cache` with K slots, clones, a 20 GB cap, pruning; side runs share it; tile-folder pruning (into T1142) | M | 0–28 (a re-cut, going back) | **up to 28** for a side run or a branch switch; about 3 GB of disk back now | medium (disk) |
| **S5. Provenance + verify** | `provenance.json`; the key recompute at `--final` and in the ship workflow; `build --verify` on release night; one `--no-cache` flag | M | 0 (it adds trust; verify is about 34 min of an idle night) | 0 | low |
| **S6. Timers, then parts** | per-part bundle timers and reach phase timers; then bundle parts as steps | M–L | about 6 on a DFO / HYDAT refresh (*guess*) | same | medium |
| **S7. R2 cache** | private bucket, push after a release, pull on a miss | M | 0 on this Mac | about 62 min for a fresh machine (T1120) | low; one new secret |

**Order: S1, S2, S5, S3, S4, then S6 and S7 only if wanted.**

Total for a typical release:
- **about 6 min** when the tiles run;
- **0–10 min** on a rules-only patch, rising to about 12 (*guess*) with a per-entry reach;
- the big win is development: a side run or a branch switch drops from 24–34 min to about 1–5.

### Replacement text for existing tickets

- **T606 item 3** (held: "it needs deliver's real read set first"). Replace with: "3. Atlas-only files leave the deliver
  stage's key, using the read set the stage trace already records (`build.TRACED`, `_traced_key`: every file deliver's
  steps read, by content). Do it with the data-build-caching design's content keys (S2), not by a hand list. A file
  the trace does not show deliver reading is out of the key; one it does show is in. `build --verify deliver` once
  proves it."
- **T1142**, add to Work: "(5) `data/release/tiles/` keeps only the tile versions that a kept release names
  (`prune.py` skips `tiles/` today, `prune.py:5-8`; 18 versions, 3.6 GB on 2026-11-25). (6) `atlas/full.prev` moves into
  the build store's cap once that exists (the data-build-caching design, S4)."
- **T1133**, add one line: "The data build stays on the Mac. The workflow does not build it; it checks it: from a clean
  checkout of the tag, it computes the stage keys again and compares them with the release's `provenance.json`
  (data-build-caching design S5)."
- **T1120**, add one line: "Optional, after S7: a fresh machine pulls the atlas, reach and tiles by key from the private
  build cache instead of building them (about 62 min of machine time); the FWA gpkg is still fetched."

---

## Picks for the owner

1. **Who starts an atlas build?**
   - (A) `pipeline build` says "atlas behind: inputs or **code**" and the release refuses it. A person still starts the
     32 min build, as today plus the code stamp. **(recommended)**
   - (B) `pipeline build` builds a side atlas itself when the atlas key moved, then stops for the parity check before
     promoting.
   - (C) As today.
2. **What to fix first?**
   - (A) The four correctness holes, then content keys, then provenance, then speed. **(recommended)**
   - (B) Speed first (the tiles split, the store).
   - (C) Only the holes; leave speed.
3. **Proving the cache (`build --verify`, about 34 min with no cache)?**
   - (A) Once per release, on the release-night run while the Mac is idle. **(recommended)**
   - (B) Once a week by hand.
   - (C) Only when something looks wrong.
4. **Build store size cap on this Mac?**
   - (A) 20 GB. **(recommended)**
   - (B) 40 GB.
   - (C) 10 GB (the current atlas, reach and tiles plus one previous of each, roughly).
5. **A remote build cache in R2?**
   - (A) Not yet: the local store first, R2 after the fresh-clone proof (T1120). **(recommended)**
   - (B) Now, pushed after every release.
   - (C) Never.
6. **An app-only release:**
   - (A) It says "data unchanged" and proves it by recomputing the keys; no data checks, no upload. **(recommended)**
   - (B) As today (finds nothing to do and goes on).

## NEW TICKET lines

- NEW TICKET: Stage keys hold every repo file the stage reads, not only `.py` modules (`schema.sql` and `indexes.sql`
  today: a schema-only commit leaves `build` saying "deliver up to date"); a test edits a tracked non-`.py` input
  and expects the stage to run. (S1, high, size S)
- NEW TICKET: The tiles and clim stages are keyed on what they really import (traced, like reach and deliver), with
  P18's "geometry only" as a short exclude list. The environment fingerprint adds the tippecanoe / tile-join / pmtiles
  versions and the SQLite library version. (S1, medium, size S)
- NEW TICKET: The atlas records its code (the modules it imported) and the environment beside its curated inputs.
  `atlas.inputs.behind` and the release name "atlas code changed". (S1, medium, size S)
- NEW TICKET: `changed_waters` (and its `from`) is stamped at publish time with `published`, so a release folder is a
  pure function of the build's inputs. (S1, low, size S)
- NEW TICKET: Content keys everywhere: a content-hash index (device, inode, size, time → sha256), file times out of
  every stage and step key, `*.md` out of the curated digest, and the bundle names its reach run by digest, not by
  newest time. (S2, size M)
- NEW TICKET: Split the tiles stage into layers and pack. Deliver keys the layers by content and starts after them;
  only the release step waits for the pack. Every stage edge is by output digest (early cutoff). About 6 min per build
  that runs the tiles. (S3, size M)
- NEW TICKET: A content-addressed build store `data/cache/` (K slots per stage and per deliver step, APFS clones into
  the live homes, a size cap, least-recently-used pruning that never touches what a pointer names), shared by side
  runs. (S4, size M)
- NEW TICKET: `provenance.json` in every release folder (commit, `COMMITTED` tree hash, stage keys and output digests,
  environment, atlas record). `release --final` and the ship workflow recompute the keys from a clean checkout of the
  tag. `build --verify` rebuilds with no cache and compares; one `--no-cache` flag. (S5, size M)
- NEW TICKET: Timers per part inside the bundle and per phase inside the reach run, written to the build manifest, so
  the next caching step is measured, not guessed. (S6 prerequisite, size S)
- NEW TICKET (later, after the two above): The bundle's table families (gauges, rules, licensing, salmon,
  places/access, parts) become cached steps of their own. (S6, size L)
- NEW TICKET (later): A private R2 build cache pushed after each release and pulled on a miss (`--remote-cache`).
  (S7, size M; one new secret)

## Not verified

- **The bundle's inner split and the reach's inner split.** Neither prints per-part times, so every number for the
  bundle parts or a per-entry reach is a guess.
- **Cross-machine determinism.** All the evidence (15 same-id deliver pairs, 6 same-id tile builds, T65 for the atlas)
  is from this one Mac with one set of libraries. A Linux runner or another Mac may give other bytes (GEOS, SQLite
  page layout, tippecanoe build).
- **clim byte determinism.** Not shown by any rerun pair in the logs.
- **The memory of the overlap in 3a** (pack and deliver at once, about 23 GB). Estimated from the stage peaks; not run.
- **Whether `shutil.copyfile` clones on APFS.** I did not test it. `cp -c` does.
- **Compressed sizes.** Sampled with `gzip -1` on the first 100 MB of four files; zstd would do a bit better.
- **R2 prices and the runner memory size.** From memory, no web check tonight.
- **Tonight's release build** (it was running: a `.trace-reach-*` folder exists). Its times are not in these tables.
  The manifest's last full run is 12:30.
- **How often side runs and lane builds happen.** Their logs live in their own side folders, not in
  `data/generated/build-logs`. The dev savings for side runs are per run, and how many runs a week is not known.
- **The release-timeline's claim that "a no-op rerun takes 2 s".** Confirmed (15 runs of 2 s in the manifest).
- **The app-only release path** (§6). It comes from reading the code; it has never been run, because every release in
  the ledger carried new data.
