# CI and release speed: build-ready changes (night of 2026-11-25)

Read-only night agent. Repo read at main `e14d494b3` (the planning worktree). Nothing was changed, run or pushed.
Times are MST. "Guess" marks an estimate. Helper files are in `night/ci-speed-build-plan/`:
`job-139648424848.log` (the pipeline `check` job log of 02:21 UTC, read with `gh api …/actions/jobs/<id>/logs`) and
`recut-readers.txt` (the 80 test files that read a release or a fixture re-cut from one).

Inputs: `night/ci-merge-queue.md` (CI timings), `night/release-timeline.md`, `night/ship-workflow-design.md`,
`night/fewer-questions.md`, tickets T1144, T1133, T1135, T1063, T1062 (open) and T1058, T1059 (closed, from the
archive), the workflows, `scripts/ci_paths.py`, `scripts/ci_status.py`, `scripts/before_push.py`,
`scripts/before_pr.sh`, `.githooks/`, `pytest.ini`, `conftest.py`, `pipeline/tests/conftest.py`,
`pipeline/tests/machine_state.py`, `pipeline/tests/test_workflow_pins.py`, `pipeline/release.py`,
`pipeline/release_follows.py`, `scripts/heavy.sh`.

## The short answer

- **Biggest CI win: run the pipeline tests on all 4 cores.** The `Tests` step is one process today
  (`.github/workflows/pipeline-ci.yml:126-127`). The suite already gives every process its own temp folder and its
  own curated copy (`pipeline/tests/machine_state.py:157-166, 293-300`), so it is mostly ready for `pytest-xdist`.
  Guess: a code PR goes from about 40 min to about 20 min, PR CI and queue together.
- **Stop the third run on push to main.** Every main commit already has a green `merge_group` run at the same sha.
  Checked live: `gh run list --commit 23dfa7aa8` (origin/main) lists `merge_group` runs of all four workflows, all
  success. `scripts/ci_status.py:96-98` looks runs up by commit, any event, so it reads those runs.
- **Release: the six test-pin stops and the 8.3 h of sleep are the big hours.** Neither needs CI. Both can be fixed
  with small code: one pins file re-cut with the fixtures, and `caffeinate` inside `heavy.sh` and the release command.

---

## 1. Pipeline tests in parallel (pytest-xdist)

### What is measured

- Job 139648424848 (log saved): `8450 passed, 7 skipped, 1673 deselected … in 1118.41s` (18.6 min). Another run
  took 643 s (ci-merge-queue.md, table "Inside the slow jobs"). The workflow's own comment gives 10-17 min
  (`pipeline-ci.yml:61-62`).
- Collection took about 27 s (Tests step start 02:23:13, first progress line 02:23:40 in the log).
- The slowest test is 67.5 s (`test_dfo_vectors.py::test_the_committed_vectors_are_what_the_python_reads_today`).
  The slowest files, adding only their tests in the top 25: `test_dfo_live.py` ≥ 110 s, `test_dfo_vectors.py`
  ≥ 84 s, `test_before_push.py` ≥ 62 s. Per-file totals were not measured: the log shows only the top 25.
- Runner image: ubuntu-26.04, 20261116.202.1 (from the log). It has 4 cores (ci-merge-queue.md; core count not
  re-checked).
- `pytest-xdist` is in neither `requirements.txt` nor `constraints.txt`. Nothing in the repo names xdist (searched).

### Is the suite safe to run in parallel? What I found by reading

Safe already:
- **Temp folders.** Each pytest process points `TMPDIR` and `tempfile.tempdir` at `<temp>/pyt-<pid>`
  (`machine_state.py:157-166, 293-298`). An xdist worker is its own process, so it gets its own folder, nested
  inside the controller's. `tmp_path` is per worker under xdist anyway.
- **The curated sandbox.** Each process copies the tracked curated tree into its own run folder
  (`machine_state.py:130-141, 299`). The copy is 17.7 MB and 82 files (`git ls-files data/curated | xargs du`), so
  four copies cost nothing.
- **Ports.** The only socket binds port 0, which the system picks (`test_curation_review_browser.py:44-45`). The
  review-app tests use FastAPI's in-process `TestClient` (for example `test_curation_review_api.py:52-53`).
- **Fixed `/tmp` paths.** None in code. The two `/tmp/…` strings are test values that are never opened
  (`test_before_push.py:371`, `test_curation_review_inputs_sync.py:88`).
- **Writes into the checkout.** The only `shutil.copy` calls with ROOT copy *from* the repo *into* a temp tree
  (`test_deploy_gates.py:44`, `test_stepcache.py:440`, `test_staging_scripts_fail_safe.py:704`). Git commands that
  write (`commit`, `checkout`, `update-ref`) run in temp repos (`test_staging_scripts_fail_safe.py:742, 804`).
- **The heavy lock.** Tests that run `heavy.sh` point it at a scratch folder (`test_release_command.py:1354-1361`).
- **The environment.** Tests that set `os.environ` by hand put it back (`test_review_queue.py:487-499, 521-533`).
- **Session fixtures.** The only one is `live_store_of` (`pipeline/tests/conftest.py:143`). Only data tests use it,
  and CI deselects them.
- **The release-backed tests.** CI's no-data tier deselects every `needs_*` test. The tests found by rule
  (`under_test.release`) read the committed mini release and only read it. The release follows run on the Mac
  through `pipeline/release.py:751-761`, one command at a time. xdist does not touch them.

Watch list. These are the tests that could break, in order of likelihood:
1. **Time limits under load.** `test_answers_28_card_solver.py:153` (< 2.0 s), `test_export_codec.py:472` (< 5 s),
   `test_gradle_watch.py:49` (< 30 s). With 4 workers on 4 cores they should keep a core each, but tests that start
   child processes share. If one turns flaky, give it more time or mark it
   `@pytest.mark.xdist_group("serial")` and use `--dist loadgroup`.
2. **Memory.** On the Mac, one process for the whole suite grew to about 111 GB with the data tiers
   (`scripts/pytest-chunked.sh:3-5`). On CI the no-data tier passes in one process on the runner. Four workers each
   carry their own imports (geopandas, pyproj, shapely) and a quarter of the tests. Peak memory is not measured.
   The proof run below measures it.
3. **Lazy partial-clone fetch.** CI clones with `filter: blob:none` (`pipeline-ci.yml:72-73`).
   `test_review_proposals.py:96` (`MARKED_AT = "2bd29a26"`) reads old blobs with `git show`, so git fetches them into
   the shared `.git`. Two workers fetching at once is probably safe (git writes objects atomically), but I have not
   confirmed it. With `--dist loadfile` only one worker runs that file.
4. **Order inside a file.** 112 test files have module-scoped fixtures (`grep -l 'scope="module"'`). Some may rely
   on an earlier test in the same file. `--dist loadfile` keeps each file in one worker, in order, so this is safe.
   Plain `--dist load` would not be safe until it is checked.
5. **Nested pytest runs** (`test_test_env.py:79`, `test_smoke_coverage.py:79`, `test_machine_state.py:157`) inherit
   `PYTEST_XDIST_WORKER`. Each runs its own collection in a child process. I expect no effect; I have not checked.
6. **The Mac.** Never use `-n` there. `scripts/pytest-chunked.sh:15-18` explains why: a child process forked after
   pyproj loaded crashes (T792 B). Locally, `before_pr.sh` keeps the chunked runner. xdist is for the Linux CI only.

### The change (sketch, not in the repo)

`requirements.txt` (after `pytest`, line 64) and `constraints.txt` (beside `pytest==9.1.1`, line 66):
```
# requirements.txt
pytest-xdist
# constraints.txt — the newest release that supports pytest 9.1 (check PyPI; not checked tonight)
pytest-xdist==<x.y.z>
execnet==<a.b.c>
```
`.github/workflows/pipeline-ci.yml:121-127`:
```yaml
      # (NEW) The no-data tier on every core of the runner: one test FILE per worker at a time (--dist loadfile keeps a
      # file's tests in order in one process and makes its module fixtures once). The Mac keeps the chunked runner
      # (scripts/pytest-chunked.sh, T792 B: -n would share a process between pyproj and a fork there).
      - name: Tests
        run: python -m pytest -q --durations=25 -n auto --dist loadfile -m "not slow and not needs_bundle and not needs_atlas and not needs_reach_run and not needs_tiles and not needs_source and not needs_cache"
```
The `-m "…"` stays as the step's only quoted `-m`, so `scripts/test-env.sh:31-39` (`no_data_markers`) still reads
it. `--durations=` stays, so the pin at `test_workflow_pins.py:65` still holds. Add one pin to
`test_ci_jobs_have_timeouts_and_the_ci_workflows_cancel_superseded_runs`: the Tests step has `-n auto` and
`--dist loadfile`, so a later switch to `--dist load` has to be a deliberate change to the test too.

For the first PR only, a temporary step measures memory:
```yaml
      - name: (temporary) peak memory of one worker
        run: /usr/bin/time -v python -m pytest -q -n auto --dist loadfile -m "<same>" 2>&1 | grep -E "Maximum resident|passed"
```

### How it is proven safe (what must still be caught)

- **The same tests run.** The PR's summary line must read `8450 passed, 7 skipped, 1673 deselected` (or whatever
  main's last serial run printed at the PR's base). Same numbers, same skips.
- **A failure still fails the job.** Push one temporary commit with `assert False` in one no-data test. `pipeline ok`
  must go red, naming the test. Then drop the commit.
- **The machine-state guard still fires in a worker.** `test_machine_state.py` plants a read of `data/curated`, a
  write, and a swallowed read. It must still pass, since it runs inside a worker.
- **Two green runs in a row** on the same PR (re-run the job). This catches order or timing flakiness.

### Saving, risk, rollback

- Saving (guess, about 3x on 4 cores): Tests from 11-19 min to about 4-7 min. The `check` job goes from about 20 min
  to about 8-10 min. That happens twice per code PR (PR and queue), so about 14-24 min saved per code PR. After this,
  the app tier (vitest shards 5.6-7.8 min, ci-merge-queue.md table A) becomes the longest path.
- Risk: low to medium (the watch list above). It changes CI only; nothing in the app or the data changes.
- Rollback: delete `-n auto --dist loadfile` from the one step. The package can stay installed.
- Optional 1b: `python -m pipeline.tools.emit --check` takes 68 s inside the same job (log 02:22:05 → 02:23:13).
  Moving it to its own job would save about 1 more minute of the longest path. It costs one more job per run.

---

## 2. The merge queue reuses a green run of the same files

### How it decides today

- The `changes` action runs `python3 scripts/ci_paths.py github <area>`
  (`.github/actions/changes/action.yml:21-31`).
- For `merge_group` it diffs `base_sha...head_sha` (`ci_paths.py:191-209`). If any changed path is in the area,
  every heavy job runs again.
- The area lists are kept complete by `test_workflow_pins.py:326-338`. They are wide: the pipeline area includes
  `app/**`, `scripts/**`, `.github/**` and `deploy/**` (`ci_paths.py:84-95`). So almost any code PR touches it.
- Tonight, 3 of 7 code PRs (#256, #257, #264) had nothing in their area land between their PR run and their queue
  run. Each re-ran a 15-21 min tier for nothing (ci-merge-queue.md §2).

### The design: a content fingerprint

The idea: "these exact files already passed this workflow", decided by content, not by guessing which commits landed.

1. **Fingerprint.** A new `ci_paths.py fingerprint <area>` hashes every *tracked* path in the area, together with
   git's blob id and file mode (`git ls-tree -r HEAD`). It needs trees only, so it works in the `blob:none` clone the
   `changes` job already makes. The workflow file is inside its own area, so a changed workflow changes the
   fingerprint.
2. **Mark.** When an area's jobs ran and all passed, the `ok` job uploads a tiny artifact named
   `green-<area>-<fingerprint>` (kept 3 days). It does this on any event: pull_request, merge_group or push. A red
   run uploads nothing, because the step comes after the verdict step and has no `always()`.
3. **Look up.** In `github()`, when the area *was* hit, compute the fingerprint of the commit being tested and ask
   `GET /repos/{repo}/actions/artifacts?name=green-<area>-<fp>`. An unexpired artifact from a run of this repo (not
   a fork) means `run=false`, said with that run's id. Any API error means `run=true`, said in the log: the safe
   side, never silent. A PR's mark is for its test merge commit, so equal fingerprints mean the queue group has the
   same area files.
4. This also covers a PR's own fix-up push that changes nothing in an area (for example a docs-only second push on a
   code PR).

Sketch, `scripts/ci_paths.py` (stdlib only, as now):
```python
import hashlib, urllib.request, urllib.parse
FP_SCHEME = "1"                      # bump to forget every recorded green run
MARK = "green-{area}-{fp}"

def fingerprint(area: str, rev: str = "HEAD") -> str:
    pats = [_glob(p) for p in AREAS[area]]
    h = hashlib.sha256(f"scheme {FP_SCHEME} area {area}\n".encode())
    for rec in _git("ls-tree", "-r", "-z", "--full-tree", rev).split("\0"):
        if rec:
            meta, path = rec.split("\t", 1)            # "<mode> blob <sha>", path
            if any(p.match(path) for p in pats):
                h.update(f"{meta} {path}\n".encode())
    return h.hexdigest()[:32]

def green_elsewhere(area: str, fp: str, env=os.environ, get=None) -> tuple[bool, str]:
    name = MARK.format(area=area, fp=fp)
    try:
        got = (get or _api_get)(f"repos/{env['GITHUB_REPOSITORY']}/actions/artifacts?name={name}&per_page=10",
                                env["GH_TOKEN"])
    except Exception as e:                              # said, and the jobs run: never a silent pass
        return False, f"could not ask GitHub for {name} ({type(e).__name__}: {e}); the jobs run"
    for a in got.get("artifacts", []):
        wr = a.get("workflow_run") or {}
        if not a.get("expired") and wr.get("head_repository_id") == wr.get("repository_id") == int(env["REPO_ID"]):
            return True, f"these {area} files passed in run {wr.get('id')} on {str(wr.get('head_sha'))[:12]}: skipped"
    return False, f"no green run of these exact {area} files ({name})"

# in github(), after `hit` is non-empty (ci_paths.py:205-208):
#     if env.get("GH_TOKEN"):
#         seen, why = green_elsewhere(area, fingerprint(area), env)
#         if seen:
#             return False, why
```
`.github/actions/changes/action.yml` env: add `GH_TOKEN: ${{ github.token }}` and
`REPO_ID: ${{ github.repository_id }}`. Each workflow's `changes` job gets
`permissions: { contents: read, actions: read }` at job level. I am fairly sure the artifacts API needs
`actions: read` (not verified). The workflow-level `permissions` pin at `test_workflow_pins.py:139` stays as it is.
Add a pin that only the `changes` job adds `actions: read`.

Each workflow's `ok` job (pipeline `pipeline-ci.yml:190-201`, app `app-ci.yml:150`, feeds `feeds-worker-ci.yml:69`,
docs `docs-ci.yml:108-119`):
```yaml
    steps:
      - uses: actions/checkout@v5
        with: { fetch-depth: 1, filter: "blob:none" }        # trees for the fingerprint (was: sparse ci_paths.py)
      - name: Every job passed or was skipped
        env: { NEEDS: "${{ toJSON(needs) }}" }
        run: python3 scripts/ci_paths.py verdict
      - id: fp
        if: needs.changes.outputs.run == 'true'
        run: echo "fp=$(python3 scripts/ci_paths.py fingerprint pipeline)" >> "$GITHUB_OUTPUT"
      - if: needs.changes.outputs.run == 'true'
        uses: actions/upload-artifact@v6
        with: { name: "green-pipeline-${{ steps.fp.outputs.fp }}", path: scripts/ci_paths.py,
                retention-days: 3, overwrite: true }
```
The pin at `test_workflow_pins.py:235-236` says the verdict is the last step. It changes to "the verdict step by
name, then the two mark steps, which have no `always()` / `!cancelled()`".

### How it is proven safe

- **The #262 + #263 clash still fails.** #263, ahead in the queue, changed ledger and app files. The group commit's
  app fingerprint then differs from #262's PR fingerprint, so the app tier runs and fails, as it did tonight.
- **The T978 mini-release clash still fails.** The first PR changed `pipeline/**`, so the second PR's group
  fingerprint differs and the tier runs.
- **Unit tests in `test_ci_paths.py`**, each written so that a mutation of the code fails it:
  - a change in the area changes the fingerprint;
  - a change outside the area keeps it;
  - a chmod or a rename inside the area changes it;
  - an API error, an expired artifact or an artifact from a fork means "run";
  - a match means "skip" with the run id in the reason.
- **The pin:** no mark is uploaded after a red verdict.
- What it still cannot catch: a test whose result depends on the date or on the runner image, between the PR run and
  the queue run (minutes to hours apart). The re-run today would catch it only by luck. The release follows run
  every test anyway.

### Saving, risk, rollback

- Saving: 15-21 min on about 3 of 7 code PRs today. After change 1, about 8-10 min on those PRs, about 4 min
  averaged over all code PRs (guess). Docs PRs queued behind them wait less.
- Risk: **medium**. A bug here is a false green on a required check. The fingerprint is exact content, and every
  error path means "run". Build it with Opus and an independent review (AGENTS rule).
- Rollback: remove the `green_elsewhere` call in `github()` (one line). Marks left behind do nothing.
- Fit with T1144 item 2 (one gate workflow): the logic sits in `ci_paths.py`, so a single gate job can call it for
  all four areas. Build 2 together with, or after, T1144 item 2.

---

## 3. No third run on push to main

### What the push run does today

- All four CI workflows have `push: branches: [main, "release/**"]` (`pipeline-ci.yml:20-21`, `app-ci.yml:21-22`,
  `feeds-worker-ci.yml:14-15`, `docs-ci.yml:17-18`).
- After queue-on, 31 of 31 push runs on main were at a sha that a `merge_group` run had already tested green:
  157 jobs, 421 run-minutes, about 21% of all jobs (ci-merge-queue.md §2).

### What reads it, and what must stay

- **`ci_status.py`** (release preflight, `build-apk.sh`, `upload.sh`). It asks by commit first, any event
  (`ci_status.py:96-98, 157, 220`). Main's sha has the `merge_group` runs (checked live, above). The strict
  ancestor search pages through every run of the workflow, every event (`:178-208`). So it keeps working. The branch
  fallback `--branch main` (`:220`) is used only when the sha has no run at all. That happens only when a commit
  reaches main around the queue (an admin merge). Then the strict check STOPs ("its area changed since its last
  run", `:169-172`). That is the right answer, and a manual run fixes it.
- **Release branches.** Picks are pushed straight to `release/**`, with no queue, so keep `release/**`. Production
  builds read those runs (strict judge).
- **Caches.** PR runs restore caches saved on main. Caches saved in PR or queue runs are scoped to that ref. Only
  `setup-node` (pnpm) and `setup-python` (pip) cache (`.github/actions/app-setup/action.yml:15-30`,
  `pipeline-ci.yml:74-75`). Their keys change only when `app/pnpm-lock.yaml`, `requirements.txt` or
  `constraints.txt` change. So a small warm job on main, run only on those paths, keeps the caches.
- Nothing else reads push runs: searched `run list|actions/runs|--event|badge.svg` in `scripts deploy pipeline app/tools
  .github README.md`. `start-workflow.sh:48` reads `workflow_dispatch` runs only.

### The change (sketch)

In all four workflows:
```yaml
on:
  push:
    branches: ["release/**"]     # (NEW) main's commits are the merge queue's, tested at the same sha (merge_group)
    paths: [...]                 # unchanged: the area, word for word
  pull_request:
  merge_group:
  workflow_dispatch:             # (NEW in app, docs, feeds worker; pipeline has it) a commit that reached main around
                                 # the queue: `gh workflow run <file> --ref main`, then ci_status reads that run
```
New `.github/workflows/cache-warm.yml`:
```yaml
name: cache warm
# (NEW) the pnpm store and pip wheels every PR restores are main's (a PR's own caches are scoped to it); since main has no
# CI push run, this job makes them when their inputs change
on:
  push:
    branches: [main]
    paths: ["requirements.txt", "constraints.txt", "app/pnpm-lock.yaml", "app/package.json", "app/.nvmrc",
            ".github/actions/app-setup/**", ".github/workflows/cache-warm.yml"]
  workflow_dispatch:
permissions: { contents: read }
concurrency: { group: cache-warm, cancel-in-progress: true }
jobs:
  warm:
    runs-on: ubuntu-latest
    timeout-minutes: 15
    steps:
      - uses: actions/checkout@v5
      - uses: ./.github/actions/app-setup     # the same setup-node + setup-python keys as the CI jobs
```
Pins to change:
- `test_workflow_pins.py:210`: `on["push"]["branches"] == ["release/**"]`.
- New pin: cache-warm's paths cover app-setup's inputs.
- New pin: pipeline-ci's `setup-python` `with:` equals app-setup's, so the keys match.

Docs to change:
- the docstrings at `ci_paths.py:16-21` and `ci_status.py:5-15`;
- `docs-ci.yml:8-9` ("a red run on a ledger edit stays the newest").

### Proof, saving, risk, rollback

- Proof: `test_ci_status.py` gains cases with `"event": "merge_group"` runs at the sha (green means ok, red means
  STOP), and a strict ancestor case where the ancestor's only run is a `merge_group` run. The fixtures today are all
  `"event": "push"` (`test_ci_status.py:23`). After landing, run `ci_status.py --strict --sha <new main sha>` by hand
  once and read the `ok` lines.
- What it still catches: a red queue run at the sha (STOP); a commit that reached main around the queue (STOP,
  naming the changed area paths).
- Saving: no PR waits less when runner slots are free. It frees about 21% of jobs, which matters at busy times and
  in the first hour after a jam. It also leaves fewer runs for `ci_status` to page through.
- Risk: low. Rollback: put `main` back in the four `branches:` lists and in the pin.

---

## 4. The title-length rule

Facts:
- CI checks `"<title> (#N)"` against `headerMax: 100` (`app/tools/versioning.json:23`,
  `app/tools/check-commits.mjs:33-36`, `docs-ci.yml:98-104`).
- AGENTS W48 already says "at most 93 characters" (`AGENTS.md:89`) and that commitlint checks it "in the hook,
  before push". That is not true: the hooks check commits only (`.githooks/commit-msg`,
  `.githooks/pre-push:39`), never the title.
- Tonight #266 failed 5 pushes on a 96-character title (+ " (#266)" = 103), and it took 77 min to land a docs PR.
  #261 failed at 101 and was closed (ci-merge-queue.md §3.3).

**Pick (recommended): check it locally, keep CI as it is.**
- `before_pr.sh` takes `--title "<title>"` (required) and first runs
  `node app/tools/check-commits.mjs --title "$title" --number 9999`. Four digits is the strictest number until
  #9999, so it needs no `gh` and has no race with other PRs.
- AGENTS W48 changes "93" to "92".
- `before_push.py --pre-push`: when the branch has an open PR (`gh pr view --json number,title,mergeable`), it
  checks that title with the real number and stops with `gh pr edit --title`. If `mergeable` is `CONFLICTING`, it
  warns. Offline, it warns and goes on.

Sketch, `scripts/before_pr.sh` after line 24:
```bash
title=""
while (( $# )); do case $1 in --title) title=${2:-}; shift 2 ;; *) echo "before-pr: unknown argument $1" >&2; exit 2 ;; esac; done
[[ -n $title ]] || { echo 'before-pr: --title "<the PR title>" is required: its merge commit "<title> (#N)" is checked first' >&2; exit 2; }
node app/tools/check-commits.mjs --title "$title" --number 9999 \
  || { echo "before-pr: FAIL (the title: Conventional Commits, at most 92 characters so that ' (#NNNN)' fits in 100)" >&2; exit 1; }
```
The PASS line adds `title <n>/92 ok`.

Why not "measure the title alone": the merge commit would then reach 107 characters. Merge commits are picked onto
release branches, and the merge-back PR's `--range` check would then refuse them. It also changes CI and the history
rule.

Proof: `test_before_pr.py` (already drives the script with `BEFORE_PR_SELFTEST`) gains a 92-character title (pass) and a
93-character one (fail). Mutation: drop the suffix in the check, and the 93 case passes, so the test fails.
Saving: up to 77 min on the PR it hits (2 of about 83 PRs tonight). Risk: none in CI. Rollback: drop the flag.
CI-only? Tooling and docs only.

---

## 5. Release-backed pins that move in one command (T1135)

### The pins today

- The follows stage already runs every check on the candidate and lists every failure together
  (`pipeline/release.py:763-784`, `:1909-1928`).
- What made six stops of about 45 min each (T1135) is that each fix needs a commit and a full re-run, and a literal
  copied from a release can only be fixed by hand.
- Tests that read the release under test, found by rule (`python -m pipeline.release_follows` functions, run
  tonight): **12 pipeline files and 39 app files**.
- Tests that read the release or a fixture re-cut from it (taps.json, page-oracle, regs-release, section-lines,
  golden pages): **80 files** (`ci-speed-build-plan/recut-readers.txt`, by grep).
- The six that stopped 0.10.0 (lines on main, which still has the old values; the release branch has the new ones in
  5c5a0b60a, d7370c772, 2cc614bb2):

| Pin | Where (main) | Moved to on 0.10.0 |
|---|---|---|
| version slice `ln[:10]` | `pipeline/tests/test_release_command.py:1982` (fixed on main: by length) | not release data: a branch test |
| Vedder display frame literal 109 | `app/conformance/src/regs/harness.parity.test.ts:75` (fixed: read from taps.json) | 112 |
| glossary term count | `app/conformance/src/regs/reads.release.test.ts:175` | 67 → 68 |
| Glenn Creek row pages | `app/conformance/src/regs/sourceLine.fixture.test.ts:100-101` `ROW_PAGES` | sheet numbers and p.38 |
| unnamed closed banner page | `app/packages/ui-native/src/WaterScreen.unnamed.test.tsx:136` | p.26 → p.16 |
| Williston "applies" sentence | `pipeline/tests/test_answers_26.py:366` | + "Covers Williston Lake and its tributary streams." |

- The existing vintage guard (`app/tools/vintage-pins.test.ts:1-12`) catches only integers above 366. Four of the six
  were small numbers or strings, so it could not see them.

### The one-go design

1. **One pins file per suite**, holding the values copied from a release: `app/fixtures/golden/pins.json` and
   `pipeline/tests/fixtures/release-pins.json`. Tests call one helper:
   ```ts
   // app/conformance/src/pins.ts (NEW)
   export function pin(name: string, actual: unknown): void {
     if (process.env.PIN_RECORD) return record(process.env.PIN_RECORD, name, actual);  // the re-cut's record mode
     expect(actual, `pin ${name} (app/fixtures/golden/pins.json; a re-cut moves it)`).toEqual(PINS[name]);
   }
   // reads.release.test.ts:175 becomes: pin("reads.glossary", { v: s.glossary.version, n: s.glossary.terms.length });
   ```
   ```python
   # pipeline/tests/pins.py (NEW)
   def pin(name, actual):
       if os.environ.get("PIN_RECORD"):
           return _record(os.environ["PIN_RECORD"], name, actual)
       assert actual == PINS[name], f"pin {name}: the release says {actual!r}, release-pins.json {PINS[name]!r}"
   ```
2. **A new FOLLOWS row** in `pipeline/release_follows.py:56-81`:
   `Follow("pins", "values the release-backed tests compare with, recorded from the candidate", ("app/fixtures/golden/pins.json", "pipeline/tests/fixtures/release-pins.json"), RECUT, answers=True)`.
   After `sync.mjs` (`refresh_cmd`, `:101-111`), the re-cut also runs the pin-bearing tests with
   `PIN_RECORD=<tmp>` and writes both files.
3. **One stop, one accept.** `answers=True` means a moved pin stops the release at `stage_recut`
   (`release.py:1862-1907`) with the existing `--accept-fixtures <token>`. The token now covers the golden pages and
   the pins. Reading `git diff -- app/fixtures/golden/pins.json pipeline/tests/fixtures/release-pins.json` shows every
   pin's old and new value at once. 6 stops become 1 accept.
4. **Quick re-runs.** After a fix, `candidate_failures` re-runs only the checks that failed (their files or node
   ids), then the full set once at the end. Today each fix re-runs everything, about 45 min (T1135).
5. **A guard.** `vintage-pins.test.ts` gains: in a file matching `LIVE` or reading a re-cut path, an assertion whose
   expected value is a `Synopsis p.N` string or a sentence over 40 characters goes through `pin()`, or has a comment
   saying why it is fixed. A sketch: the false-positive rate is not measured.

Start with the six above and the T991 pins, then convert as each pin moves. That is not a sweep of all 80 files.

### Proof, saving, risk, rollback

- Proof (T1135's own acceptance): replay the 0.10.0 changes on a branch. `release --staging --dry-run
  --rehearse-follows` must list all moved pins in one block, and the real run must pass after one accept.
- What it still catches: a pin moved by a bug still stops the release, and the diff names it. CI on main still
  compares the committed pins.json with the committed fixtures, so a hand-edited pins.json fails CI.
- The danger: values recorded from the release itself can look tautological. The guard is the stop and the accept,
  exactly as for the golden pages today. Record mode runs only in the release command, never in CI.
- Saving: about 2-3 h per release that changes answers (0.10.0 lost about 4 h, T1135; this leaves one follows run
  and one accept).
- Risk: low to medium (test-only, plus release tooling). Rollback: put the literals back in the tests and drop the
  row.
- T1135 item 1 (a side release built on a lane before it merges) stays as written. It is heavy (reach + deliver,
  about 30 min on the Mac) and is not needed for this.

---

## 6. Keep the Mac awake; a fair heavy-job queue (T1063)

### Facts

- No `caffeinate` or `pmset` anywhere in `scripts/`, `deploy/`, `pipeline/`, `app/tools/`, AGENTS.md or the
  runbooks (searched tonight).
- 0.10.0: the Mac slept from about 03:50 to 12:06, 8.3 h, with the lid closed (release-timeline.md §2).
- `heavy.sh` waiters retry `mkdir` every 20 s (`scripts/heavy.sh:46, 229-254`). The queue file feeds only `--status`
  (`:132-135, 226`). In 0.9.0 the iOS build waited 70 min and lost the lock to later arrivals (T1063).

### Sketch: awake

`scripts/heavy.sh` after line 276 (`job=$!` / `set +m`):
```bash
# (NEW) the Mac stays awake while the job runs (idle and, on power, system sleep); caffeinate ends with the job
if command -v caffeinate >/dev/null 2>&1; then caffeinate -i -s -w "$job" & fi
```
`pipeline/release.py` `main()` (`:2969`), for `--staging`, `--dry-run` with `--build` or `--rehearse-follows`, and
`--prod`:
```python
def stay_awake() -> str:
    """(NEW) macOS: no idle sleep (and no system sleep on power) while this release runs; on battery an unattended run
    is refused (--on-battery REASON goes on, printed)."""
    if sys.platform != "darwin":
        return "not macOS: nothing to keep awake"
    batt = subprocess.run(["pmset", "-g", "batt"], capture_output=True, text=True).stdout
    if "AC Power" not in batt.splitlines()[0] and not is_tty() and not ON_BATTERY_REASON:
        raise SystemExit("release: refused on battery for an unattended run: plug the Mac in (or --on-battery REASON)")
    subprocess.Popen(["caffeinate", "-i", "-s", "-w", str(os.getpid())])
    return "kept awake while this runs (caffeinate); keep the lid open unless an external display is attached"
```
Tests:
- `scripts/tests/heavy.test.sh` already puts fake tools on PATH (`:57`). Add a fake `caffeinate` that records its
  arguments, and assert `-i -s -w <the job's pid>`.
- `test_release_command.py`: Popen is replaced with a recorder; on battery with no TTY the run is refused; with
  `--on-battery` it goes on, printed.

**Important limit (not verified tonight; no web research was allowed for this task):** as far as I know,
`caffeinate` does not stop a MacBook from sleeping when its lid is closed without an external display. 0.10.0's sleep
was a closed lid. So the release runbook must also say "lid open, on power". `sudo pmset -a disablesleep 1` would cover
a closed lid but needs the owner's password, so it is his pick (Picks, 4).

### Sketch: a fair queue (T1063)

Write the queue file as `epoch`, `cmd`, `priority` (`heavy.sh:226`: today date and cmd). Replace the bare `mkdir`
loop at `:229` with "try only when I am first":
```bash
mkdir -p "$LOCK.queue" && printf '%s\n%s\n%s\n' "$(date +%s)" "$cmd" "${HEAVY_PRIORITY:-0}" > "$QUEUE"
first() {   # am I the live waiter with the highest priority, then the longest wait (then the lowest pid)?
  local best="" q
  for q in "$LOCK.queue"/*; do
    [[ -f $q ]] && alive "${q##*/}" || { rm -f "$q"; continue; }
    best+="$(sed -n 3p "$q") $(sed -n 1p "$q") ${q##*/}"$'\n'
  done
  [[ $(sort -k1,1nr -k2,2n -k3,3n <<<"$best" | head -1 | cut -d' ' -f3) == "$$" ]]
}
while ! { first && mkdir "$LOCK" 2>/dev/null; }; do ...stale takeover as today...; nap "$(first && echo 5 || echo "$WAIT_POLL")"; done
```
- `HEAVY_PRIORITY=1` is set only by the release command's own heavy calls (`release.py:752`, `build_cmd`
  `:859-864`, the store builds). An AGENTS rule 18 line says only a release run may set it.
- `--status` shows the order.
- Test (`heavy.test.sh`): three waiters A, B, C queued in that order, with C at priority 1. When the lock frees, C
  takes it, then A, then B. A waiter that died is skipped.
- T1063 item 0 (test runs from hooks inside a lane) stays in T1063.

### Saving, risk, rollback

- Saving: awake, 0 to 8.3 h per release (8.3 on 0.10.0). Fair queue, 1 to 1.7 h (0.9.0: the fast-fail 30 min behind
  other lanes plus the iOS 70 min wait; release-timeline.md §3).
- Risk: low. It is macOS tooling and touches no app or data. Rollback: delete the lines.

---

## 7. A pre-cut gate enforced by `release --cut`

What code can check:
- **(a) No open owner line on a ticket in the release's scope.** Scope means tickets whose Status starts with
  `OPEN — <version>` or `IN PROGRESS — <version>` (for example T1135 "OPEN — 0.10.1, …"; 8 tickets match `0.10.1`
  today). Open owner lines are `- [ ] YYYY-MM-DD — …` in a `## Owner` block (`app/tools/ledger.mjs:5-9, 310-345`).
  99 such lines exist across all open tickets today (grep).
- **(b) Scope tickets not DONE** are listed. The release chat retargets them or names them.
- **(c) The owner pack exists**, only if the owner picks the pack (fewer-questions.md §3a): a committed
  `handoff/PLAN/release/packs/<version>.md` with a `Sent:` line.
- **(d) What's-new cleared:** `release --final` refuses while the version's changelog entry is `draft: true` (the cut
  writes it, `release.py:508-517`). `scripts/check-changelog.mjs:25` only prints this today. Clearing it after the rc
  means a new rc, so the runbook says to clear it before the staging ship.

What code cannot judge: whether a picture was really looked at, or whether a default is acceptable. Those stay in the
pack.

Sketch:
- `ledger.mjs` gains `--owner-open --release <v> --rev origin/main`. It reads the tickets at that rev (`git show`;
  the cut has just fetched main, `release.py:2662`) and prints JSON `[{id, status, open: [asks]}]`. One parser, the
  one that exists.
- `release.py` `cut()`, after the version is decided and before the prompt (`:2696-2698`, also on `--dry-run`):
  ```python
  open_ = owner_open(version)            # node app/tools/ledger.mjs --owner-open --release <v> --rev origin/main
  if open_ and not owner_open_reason:
      print("release --cut: refused: tickets in this release still wait on the owner:\n" + "\n".join(
            f"  {t['id']}: {a}" for t in open_ for a in t["open"]) +
            "\n  answer them (or move the ticket to the next release), or --owner-open \"<why>\"", file=sys.stderr)
      return 1
  ```
  The reason is printed and kept in the release ledger.
- Tests: a fixture ticket tree with one open line in scope (refused), one out of scope (passes), one answered line
  (passes), and the escape with and without a reason. Mutation: a parser that ignores the `## Owner` heading flags
  ask-like lines elsewhere in a ticket, so the test fails.

Saving: 1 to 3 h and no idle night (release-timeline.md §4 item 4). Risk: low; false positives are named and the
escape exists. Rollback: delete the call.

---

## Order to land (biggest saving, least risk first)

| # | Change | Size | Kind | Saves |
|---|---|---|---|---|
| 1 | 4. title check in `before_pr.sh` + pre-push, AGENTS 93 → 92 | S (½ h) | tooling/docs, CI unchanged | up to 77 min on a hit PR |
| 2 | 6a. `caffeinate` in heavy.sh + release command, battery refusal, runbook "lid open" | S (1 h) | macOS tooling | 0-8.3 h per release |
| 3 | 1. pytest-xdist on the pipeline tier, with the proof run | S-M (2 h + 2 CI runs) | **CI-only** | ~14-24 min per code PR (guess) |
| 4 | 3. drop `main` from `on: push`, cache-warm, workflow_dispatch, ci_status tests | S (1-2 h) | **CI-only** | ~21% of jobs; slots |
| 5 | 7. pre-cut owner gate + `--final` draft refusal | S-M (2-3 h) | release tooling | 1-3 h per release |
| 6 | 5. pins file + one accept + quick re-runs (T1135 item 3/4) | M (½ day) | tests + release tooling | 2-3 h per answers-changing release |
| 7 | 6b. fair heavy queue + release priority (T1063) | S (2 h) | Mac tooling | 1-1.7 h per release |
| 8 | 2. merge-queue reuse by fingerprint (with T1144 item 2) | M (½ day, Opus + review) | **CI-only** (required checks) | ~4 min per code PR after #3 row; more before |

None of these changes what the app shows or what the pipeline builds. CI-only: 1, 2, 3 (rows 3, 4, 8). Tooling and
docs only: 4, 6, 7. Rows 1-4 fit one build chat in a day.

---

## Proposed text to add to T1144

> **Added 2026-11-26 (night CI audit, `night/ci-merge-queue.md`, `night/ci-speed-build-plan.md`).**
> Facts correction: the runner shortage was the first hour after the move only (2-10 jobs at once, up to 35 waiting);
> from 00:00 UTC on 11-26 the org reaches the Free plan's 20. #217's 32 queue minutes were about 24 waiting and about 8
> working on the app path, beside a 20-minute pipeline path. The real cost is the pipeline `Tests` step (11-19 min,
> one core, `pipeline-ci.yml:126-127`) run on the PR, again in the queue, and a third time on push to main.
> 7. Drop `main` from the four CI workflows' `on: push` (keep `release/**`); add `workflow_dispatch` to app, docs and
>    feeds worker; add `cache-warm.yml` (push to main on the dependency files only). `ci_status.py` reads the
>    `merge_group` run at the sha; prove it with `merge_group` fixtures in `test_ci_status.py`. Pin:
>    `test_workflow_pins.py:210`.
> 8. Item 2's gate reports ONE required check (the ruleset names one context; `ci_paths.py` REQUIRED and
>    `ci_status.py` WORKFLOWS follow), and reuses a green run of the same area files by fingerprint
>    (`ci-speed-build-plan.md` §2): a `green-<area>-<fp>` artifact per green area, looked up in the `changes` job;
>    any API error runs the jobs.
> 9. `handoff/PLAN/ios/APP-STORE-SUBMISSION.md` (app area, `ci_paths.py:67`) runs the whole app tier for a docs
>    edit (8 PRs on 11-25); move its check to docs-ci. `handoff/PLAN/runbooks/**` runs the pipeline tier
>    (`ci_paths.py:93`); say so in AGENTS.
> Item 5 (docs PRs at once): no limit is needed with 20 slots; if a rule is wanted, at most two code PRs in CI at
> once. Settle it after items 7-8 land.
> Acceptance add: a code PR's last push to merge, measured before and after with the commands in
> `ci-merge-queue.md`.

## NEW TICKET lines

- NEW TICKET: The pipeline no-data tier runs on every core of the CI runner (`pytest -n auto --dist loadfile`,
  pytest-xdist pinned), proven by equal test counts, a planted failure and two green runs; peak memory measured; the
  Mac keeps the chunked runner.
- NEW TICKET: The PR title is checked as its merge commit before the PR opens (`before_pr.sh --title`, at most 92
  characters) and on every push to an open PR (pre-push, with a conflicted-PR warning); AGENTS W48 says 92.
- NEW TICKET: The release command and heavy.sh keep the Mac awake for a run (`caffeinate -i -s -w`); an unattended
  release on battery is refused (`--on-battery REASON`); the runbook says lid open and on power.
- NEW TICKET: `release --cut` refuses while a ticket in the release's scope has an open owner line or is not DONE
  (`ledger.mjs --owner-open`; `--owner-open REASON`), and `release --final` refuses a draft What's-new entry.
- NEW TICKET: Release-backed pins live in two pins files, re-cut with the fixtures and accepted with one token;
  after a fix the follows re-run only what failed, then everything once (the build half of T1135 items 3-4; add it to
  T1135 instead if the planning chat prefers).
- Line items, not new: T1063 (the fair-queue and priority sketch, §6); T1144 (the text above); T1133 (nothing new:
  phone builds on CI remove release-day lock waits, ship-workflow-design.md).

## Picks for the owner

1. Pipeline tests in parallel: (a) **pytest-xdist on the same 4-core runner (no extra jobs)** (recommended);
   (b) 3-4 shards like the app suite (+3 jobs per run); (c) a larger runner (billed).
2. The PR title check: (a) **checked locally with the suffix, CI unchanged, limit 92** (recommended); (b) CI measures
   the title alone (the merge commit may then reach 107 characters and fail a pick's commit check).
3. The push-to-main run: (a) **drop it, keep `release/**`, add a cache-warm job** (recommended); (b) keep it.
4. Keeping the Mac awake: (a) **`caffeinate` in the scripts, plus a runbook line "lid open, on power"** (recommended);
   (b) also `sudo pmset -a disablesleep 1` while a release runs (needs your password each time); (c) as today.
5. Release pins: (a) **one pins file, one accept for all moved pins** (recommended); (b) keep the literals and only
   make the follows list them all at once.
6. The merge-queue reuse (fingerprint): (a) **build it with the single gate workflow (T1144 item 2), after
   xdist** (recommended); (b) build it now, alone; (c) not at all (keep the re-run, about 8-10 min per code PR after
   xdist).
7. The pre-cut gate: (a) **refuse the cut while an in-scope ticket has an open owner line, with a reason flag**
   (recommended); (b) only print the list; (c) no gate.

## Not verified

- The xdist speed-up (about 3x is a guess), peak memory with 4 workers, and whether the three time-limit tests stay
  green. Nothing was run: the rules forbid test suites tonight.
- That concurrent lazy blob fetches into one partial clone are safe. That nested pytest runs ignore the inherited
  `PYTEST_XDIST_WORKER`.
- That the artifacts API's `name` filter matches exactly, and that `GITHUB_TOKEN` needs `actions: read` for it.
  Whether `merge_group.base_sha` is main's tip or the entry ahead: the fingerprint design does not depend on it.
- That `caffeinate -i -s` cannot stop lid-close sleep on a MacBook without an external display. That is my
  understanding, not checked (no web research in this task).
- The pytest-xdist and execnet versions that support pytest 9.1.1 (PyPI not checked).
- Why the 0.10.0 rehearsal found 3 pin stops and the real run 3 more (T1135's figure; I did not read that chat).
- Per-file test durations (only the top 25 are in the CI log). The core count and RAM of tonight's runner (taken from
  the audit, not re-read).
- That `release.py` has no other reader of push runs on main. I searched `scripts deploy pipeline/*.py app/tools
  .github README.md` for run lookups and found only `ci_status.py` and `start-workflow.sh` (dispatch runs).
