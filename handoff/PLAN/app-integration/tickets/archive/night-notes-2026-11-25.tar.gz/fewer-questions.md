# Fewer, earlier, better-batched owner questions per release

Read-only notes, 2026-11-25 night. Sources: every `## Owner` block in `handoff/PLAN/app-integration/tickets/*.md`
(read with an awk filter, all 260 files), `OWNER-UNFILED.md`, tickets T1140, T1146, T1145, T1149, T1150, T1151, T1108,
T1119, T1132, T1062, T1071, T1072, T1128, the roadmap `handoff/PLAN/ROADMAP-after-0.9.0.md`, `handoff/PLAN/STATUS.md`,
AGENTS.md, tickets README, and 836 closed tickets unpacked from `archive/closed-2026.tar.gz` (searched for
2026-11-22..24 owner answers). How I counted: I only list a question when a file shows it with a date. The 0.9.0
cycle is thinly recorded (closed tickets keep the answer, rarely the hour), so that part of the table is a sample,
not a complete count. Times of day come only where a file states them.

## 1. The questions

Cycle codes: PRE = before the cut (staging run started about 15:15 on 11-25 for 0.10.0; the 0.9.0 cut was 11-24).
POST = after the cut, release held or running. NIGHT = on release night / evening hours.
Kinds: LOOK = a picture, WORD = a wording, CALL = a data or rule call, SCOPE = scope or timing, CLICK = a store/console click.
"Knowable" = could have been known and asked before the cut (Y / partly / N).

### 0.10.0 (11-24 and 11-25)

| # | Question (his answer in short) | When | Kind | Blocked release? | Knowable before the cut? |
|---|---|---|---|---|---|
| 1 | Part label words "Part N of M" from pictures (T1140). He rejected it: "no part x of n anywhere in the app. that is a fault", "Hold 0.10.0 for the reserve name" (about 16:55, 11-25) | POST/NIGHT | WORD (+LOOK) | YES, it held the release | Yes. The label was Claude's own proposal, and "every part has a real name" is an old rule of his (T780, 11-20: part names say the place alone). Ask would have been answered "no" |
| 2 | Where a multi-part water's link lands: "A: Map with the parts" (T1140, 15:14) | POST | SCOPE | Partly (moved the repo-move earlier) | Partly |
| 3 | Move the repo now, re-cut 0.10.0 after: "Yes, move now" (T1140/T1041, 15:14) | POST | SCOPE/timing | YES (staging was in flight; kept release/0.10.0) | Partly. 11-23 he had said "repo move after 0.9.0"; 11-24 "0.9.1 before repo change"; it flipped on 11-25 |
| 4 | The Map bar without the count: "The part's real name"; parts outside B.C.: "<water> outside B.C." (T1140) | NIGHT | WORD | Yes (part of the hold) | Yes, same family as #1 |
| 5 | A name for nameless parts: "outside strathcona park sounds bad maybe a different name?" (T1140, open) | NIGHT | WORD | Yes (hold waits on pictures) | Partly. The nameless parts only surfaced in the 11-25 investigation (26 parts) |
| 6 | The 15 rule-gap side channels: "Fix the binding in 0.10.0" (T1146) | NIGHT | CALL | Yes | No. Found by that evening's read-only pass |
| 7 | Fix diff wider than predicted (34 feeder creeks, Manson, Old Kootenay): "Accept: they are tributaries" (T1146) | NIGHT | CALL | Yes | No (needed the fix to be built) |
| 8 | Strathcona Park cut at its boundary or keep (T1146 group D / T1149): "what is the issue... with hardening release" | NIGHT | CALL | No (deferred) | No. Found in the same pass; a good example of a question correctly pushed to the next release |
| 9 | Is Strathcona-Westmin Park part of "Strathcona Park waters"? MacMillan Creek bait ban? (OWNER-UNFILED) | NIGHT | CALL | No (defaults stand) | No |
| 10 | Game-fish bar open colour: "calendar bar colors still do not match for open" (T1145, about 16:55) | NIGHT | LOOK | YES (he added it to the hold) | Yes. He had said it for trout on 11-23 (T1028: "same open color as salmon"); the game-fish bar was a leftover of that |
| 11 | Look at Capilano before/after open colour (T1145, open) | NIGHT | LOOK | No | After a build only |
| 12 | Look at the naming pictures (Squamish, Gordon, two nameless parts, Capilano) "before the naming merges" (T1140) | NIGHT | LOOK | YES (his gate: "nothing merges before you have seen them") | After a build only |
| 13 | Noons p4 / Seymour p3 misfiled streams: "take the fwa version for now, add a gotcha" (T1150) | NIGHT | CALL | Not by itself | No |
| 14 | FWA has no line for Turner, Tunnel, Capitol: "fix the cause... compare with osm?" (T1150) | NIGHT | CALL | No | No |
| 15 | T1150 scope: "just add all to hardening release"; the two "leave out" rows: "do whatever makes our current state decent" | NIGHT | SCOPE | No | No |
| 16 | T1150 variant: 83 rows or 31 (open, hardening) | later | CALL | No | No |
| 17 | Park rule outside the park: when to fix (T1149): hardening | NIGHT | SCOPE | No | No |
| 18 | T1151 braid simplification pick and the "channel joins where it touches its river's water body" rule (open, default stands) | after | CALL/LOOK | No | No |
| 19 | iOS: EU trader status, content rights (Esri), App Privacy linked, countries, Performance Data (T1071; 11-24 23:12 to 11-25 14:25, seven answers, several multiple choice, and "keep ticked but next release will add to privacy page") | PRE/POST | CALL (legal) + CLICK | Gated the submission, not the data release | Yes. The App Store checklist is a fixed list; asking it in one sitting was possible on 11-24 |
| 20 | App Store wait for the new picture set: "Wait for the new set" (11-24 23:04) | PRE | SCOPE | Gated the iOS submit | Yes |
| 21 | Production push proof: "Soon, on build 45", then 11-25 00:12 "move this to after iphone release" | NIGHT | SCOPE | Gate removed by him | Partly (the proof was always at risk) |
| 22 | Store pictures: direction A, first two frames, "drop tablet set", "hold play pictures until before prods release" (T1072; 11-24 to 11-25 13:43) | PRE/POST | LOOK + SCOPE | Not 0.10.0 | Yes |
| 23 | "One word: 'before prods release' means the Play production release? Correct?" (T1072, open) | POST | SCOPE | No | Yes (an agent could record that reading) |
| 24 | Repo move: org settings, rename, second account, merge-queue ruleset OK (T1041/T1062 area; 11-25 13 to 15:24) | PRE/POST | SCOPE + CLICK | Gated the new tooling | Yes (a checklist since 11-23) |
| 25 | Release candidates plan: six picks ("Plain 0.10.1", "At the staging ship", "Claude on your word", ...) (T1062, 11-25 ~13:58) | POST | SCOPE/CALL | No (the patch was built but not blocking) | Yes (asked 11-24 already, plan stage) |
| 26 | Performance monitor design picks (scope, retention, device detail, label) (T1132, 11-25) | POST | CALL | No (moved to hardening) | Yes, forced by the 14:06 label answer |
| 27 | Mapbox: spend, keyed provider, cache, web keeps Esri, engine, offline imagery (T1108, 11-25) | POST | SCOPE | No (0.11) | Yes. Out of scope for 0.10.0 by his own rule |
| 28 | Boat launches and docks: four picks (T1119, 11-25) | POST | CALL | No (0.11) | Yes |
| 29 | Satellite tile cache: "Keep cache, reword the page" (T1148) | POST | WORD | No | Partly |
| 30 | Dependabot and CodeQL "I turned them on, keep" (T1141), workflow clean-up (T1144) | POST | CALL | No | Yes |
| 31 | Bucket over R2 free tier: "yes compress it" (T1089, 11-24) | PRE | CALL | No | Partly |
| 32 | Version: "0.10.0, follow the rule" (roadmap, 11-25) | POST | SCOPE | No | Yes (T998 already computed it) |
| 33 | Play closed testing feedback? "no ... all was through the app pathway" (T1046, 11-24) | PRE | CALL | No | Yes |
| 34 | Last-minute open lines still waiting: T1109, T1110, T1115, T1124, T1125, T1126 word/picture picks, T1153 look, T1152 words, T1128 frame 3 look, PR #238 frame 3 look | POST | WORD/LOOK | No (all proposed for 0.10.1) | Yes: each is a "pick from pictures" that could be one sitting |
| 35 | Production commands for 0.10.0, App Store submit, What's-new words (OWNER-UNFILED) | NIGHT | CLICK + WORD | These ARE the release | Yes, except the hold moved the day |

That is 35 rows from 11-24 and 11-25; about 20 are the "more than 20 multiple choice" he mentions. About eleven of them
(1, 3, 4, 5, 6, 7, 10, 12 plus 2 and the T1146 follow-ups) touched the release itself; the rest were piled onto the same
day because the chats were all asking at once.

### 0.9.0 (11-22 to 11-24), sample from closed and open tickets

| # | Question (answer) | When | Kind | Blocked? | Knowable earlier? |
|---|---|---|---|---|---|
| a | Class II line under the water name: A now / B beside (T1004, 11-22, still open) | PRE | LOOK | No | After a build |
| b | Region page map link look A/B/C (T1010, 11-22, still open) | PRE | LOOK | No | After a build |
| c | Gravel Slough highlight look (T1024, 11-23, still open) | PRE | LOOK | No | After a build |
| d | Gauge page chart "App's chart, ~260 KB"; ELF "fix in 0.9.0" (T1039, 11-23) | PRE | LOOK + CALL | No | After a build |
| e | One block both calendars; second line A; merge the 130 waters (T1052, 11-24) | PRE/POST | WORD/LOOK | No | After a build |
| f | Head-lakes list: "All 22, but a stream's own row wins"; "tributary rules dont apply to the lake either" (T1053, 11-24) | POST | CALL | Rule pinned later; the 0.10.0 pins re-cut | Partly |
| g | Dated closures win unless exempt; all-year "No Fishing" yields; "add all of this logic to gotchas" (11-24) | POST | CALL | No | No |
| h | Salmon size gate "Raise to 110,000" (11-24); "Rules only, hide 0" (11-24) | POST | CALL | Stopped a gate | Partly (gate failing was a late finding) |
| i | Version: "let it be 0.9 but we wont release yet until we have more stuff" (T998, 11-22) | PRE | SCOPE | No | Yes |
| j | MapLibre for 0.8.6 (11-22 dialog); T866 proposal | PRE | CALL | No | Yes |
| k | Boundaries only for highlighted section (T997, round 2, 11-22) | PRE | LOOK | No | After a build |
| l | PR #84 gauge-search answers (T1045, 11-23) | PRE | WORD | No | Partly |
| m | Request Google indexing, Play 404 file copy, Search Console checks (T1002 area, 11-22) | PRE | CLICK | The Play 404 was a live bug | Yes |
| n | Play testers count, questionnaire TODOs, rollout (T1046, 11-23/24) | PRE | CLICK | No (launch) | Yes |

The 0.9.0 cycle shows the same shape: most of its questions are looks tied to a build, and its late data-rule calls (f, g, h)
came from checks running at the end.

## 2. Patterns

Counting the 35 rows of 0.10.0 (my classification, a count of rows above, not a measurement of effort):
- LOOK or WORD from pictures: 13 (1, 4, 5, 10, 11, 12, 18, 22, 29, 34 and more). These are "show him what it looks like". Almost all of
  them sit after a build exists.
- CALL (data/rule): 10 (6, 7, 8, 9, 13, 14, 16, 26, 28, 31).
- SCOPE / timing: 9 (2, 3, 15, 17, 20, 21, 23, 25, 27, 32).
- CLICK: 3, plus legal answers (19, 24, 35).

Which come late and why:
1. A look that only exists after a build. The part-name pictures, the open colour, the head-lake and gauge looks. The
   cure is not asking earlier (there is no picture), it is to build the picture early (a mock-up or a data-only preview
   before the cut) and to show all of them once. Row 1 is the worst case: the picture came after the label was built.
2. A finding from a late investigation. T1146 (15 channels, then 34 feeders), T1149 (park rule 478 km out), T1150 (misfiled
   city streams), the MacMillan channel. These were found by read-only passes the same evening. They cannot be asked
   earlier; the right handling is a rule for them: they go to the next release unless they would put wrong
   information on the screen in the release itself. He did this himself for T1149 and T1150 (hardening) and for the
   Strathcona cut, which shows it works when it is offered as a choice.
3. A default that was not allowed to stand. "Part N of M" shipped as a recommended default and he called it "a fault".
   README says owner calls never block, build the default. That is correct for neutral calls but not for ones that
   contradict something he has already said. His "Couldn't we just assume most of these are done already?"
   (T711/T780, 11-20) shows he prefers defaults. The failure is not asking too little; it is a default that went
   against a standing ruling nobody had written as a rule.
4. A promise that changed with the day. Repo move order flipped 3 times (11-23, 11-24, 11-25 15:14). Plain scope changes
   cost a re-cut. A scope rule exists in the roadmap ("Scope is frozen when the chat starts") but a decision in the
   middle of a release overrode it.
5. Store and legal answers came as a stream (11-24 23:04 to 11-25 14:48) because the App Store screens were walked
   one at a time and a question appeared with each screen. The list of App Store answers is fixed (T1071's checklist
   existed); one sitting would have covered it.
6. Many chats asked at the same time. At least five chats (0.10.0, repo move, iOS, store content, planning) each sent
   multiple-choice questions on 11-25. He answered in the order they arrived, not by importance, and several answers
   were to chats that did not know about each other (Mapbox for content rights came up in the iOS dialog and had to be
   relayed to the planning chat).

What was NOT late: the data rules and scope calls for features (T1108, T1119, T1132) were asked on the release day but were never
needed by it. They cost him time at the worst hour and could have waited for the owner pack of the next release.

## 3. Proposals

### 3a. A pre-cut owner pack (one sitting)

A single page, built by the planning chat the day before the cut and updated until the cut. Ask once, all at the same
sitting, with defaults. Contents, in this order:
1. Every picture of the release, as images in the chat (or an artifact page) the owner opens on his phone. One image per
   screen state, before and after, light and dark when it matters. Not paths.
2. Every wording that anglers will read (labels, What's-new, privacy sentences, store text), each with the proposed text.
3. Every data or rule call raised so far, each as one multiple-choice question with a recommended default and the cost of the
   other options (how many waters, how many minutes of rebuild).
4. Every scope or timing call (what is in, what moves to the next release).
5. A list of his clicks (App Store, Play, console) with the exact order, so he does them in one go.
Each item has: ticket, question, default, and what happens if he does not answer ("default ships").
Rule of use: the pack is closed at the cut. Items he does not answer ship with their default; answers that change a default
go into the next release. Exception only for the stop-ship test below.

How to build it without much extra cost: the ledger already lists open owner lines (`node app/tools/ledger.mjs` writes
`views/OWNER.md`); a "pack" mode could list only the open lines of tickets in the release's scope, with the default
(tickets already carry "Default:" lines) and a link to the pictures. The 0.10.0 files show these defaults mostly exist
(T1150, T1151, T1152, T1153 all say "Default: ..."), so the pack would be assembling, not inventing.

### 3b. Standing answers he has effectively given (write them as rules)

Each with his words and where. These are the rules whose breach turned into a question on 11-25. Proposed as
written rules, to be confirmed once by him (everything added is a proposal, so these too).

| Standing answer | His words (source) | What it would have saved |
|---|---|---|
| Every part has a real name or a distance, never a counter | "there should be no part x of n names anywhere in the app. that is a fault. ... all types will have a name" (T1140, 11-25); T780 (11-20): part names say the place alone | Questions 1, 4, 5 and the 16:55 hold |
| Same open colour everywhere | "the schedule bar for trout should have same open color as salmon" (T1028, 11-23); "the calendar bar colors still do not match for open" (T1145, 11-25) | Question 10. One token for "open", with a test, would never need a ask |
| Everything added is a proposal | memory `everything-added-is-a-proposal` (10-29) | Ask the same item once, not as a surprise |
| No silent fallbacks | memory `no-silent-fallbacks` (11-03) | Would settle nameless parts: show a real fallback label, never a bare water name |
| Tributary rules do not apply to the lake | "tributary rules dont apply to the lake either only streams that is important too" (T1053, 11-24) | Head-lake questions |
| Dated closures win unless exempt; all-year "No Fishing" yields | his words 11-24, "add all of this logic to gotchas" | Closure rule calls |
| Anything not in the release scope goes to the next release | "just add all to hardening release" (T1150), "with hardening release" (T1149), "do whatever makes our current state decent until this is fixed in hardening" | Questions 8, 13 to 17 would be recorded defaults, not questions |
| Defaults are fine | "Couldn't we just assume most of these are done already?" (T711/T780, 11-20) | Answers to neutral picks |
| Pictures, not paths | memory `send-images-to-owner`, `images-with-image-questions` | Waiting on pictures |
| Questions in batches; by push notification | memory `questions-in-chat-batches`, `questions-by-push-notification`; roadmap "Questions are batched with pictures" | The stream of one-at-a-time asks |
| Scope frozen at chat start | roadmap rule (owner 11-23) | The 11-25 additions |
| Wording for stores: one set for both stores | "we want the android and iphone images to use the same set ideally" (T1071, 11-24) | A future "do the stores share" question |
| Satellite imagery will go to Mapbox on mobile later | "we will be changing it to mapbox soon" (T1108) | The content-rights question recurring each submission |
| Play pictures held until the Play production release | "hold play pictures until before prods release" (T1072) | Row 23 (just record the reading) |
| Privacy: the label may run ahead of the app for one release | "keep ticked but next release will add to privacy page" (T1071/T1132) | Future label questions |

Where these should live: `pipeline/docs/RULINGS.md` for data readings (already the home of rulings), a new short
"standing rulings" section in AGENTS.md for app/UX ones (naming, colour), and the decisions page by subject (AGENTS
W49 already says "a decision goes in the decisions page by subject"; the problem on 11-25 is that no chat had it in view
when it chose the label).

### 3c. What agents may decide with a recorded default

Agents decide and record (ticket line "Decided by the agent, default: ..., owner may change in the next release"):
- Anything a standing answer above already settles.
- A wording variant where all options say the same fact (not a new claim about regulations).
- A look inside the existing design system (spacing, an existing colour token, platform pairs) with no new rule.
- Data calls where the default is "keep as is" or "carry it, do not widen" (rules in AGENTS already say this for the
  straddling, unplaced and ambiguous cases).
- Anything with fewer than a handful of waters affected and a one-line revert (T1146's MacMillan channel).
- Scope: a new find that does not put a wrong answer on screen goes to the next release (already his own habit).
Ask him only when: (1) a rule changes what an angler is told about open, closed or allowed (the regulations meaning); (2)
a legal or store statement is his to make (EU trader, privacy words, content rights); (3) a spend or an account; (4)
something contradicts a standing answer; (5) he has said "ask me".
Related existing rule: README "Owner calls never block work". Add the corollary: a default must be checked against the
standing answers first; if it contradicts one, the default is the standing answer.

### 3d. A release-night rule

After the cut, only stop-ship questions go to him. A stop-ship question is one where the build on staging would
tell an angler something false about a rule, crash, or break a store requirement, and where no default is safe. Everything
else becomes a ticket line with a default and waits for the next release's pack. Concretely on 11-25: question 1 (the label)
and 10 (colour) were wishes on top of a correct release; that is exactly the grey area. Two ways to deal with it:
(a) he is told in the pack, before the cut, that "a late look that changes what ships" will cost a re-cut and is his
call each time, with the cost in hours (T1140's costs: reach, tiles and deliver about 33 minutes, follows about 45;
plus the golden pages re-cut once); (b) a look that is not a stop-ship goes into the next patch (the T1140 landing A already
works this way). His own order on 11-25 (hold for names) is legitimate; the point is that the cost was visible only after
he had asked.
Also: no new multi-choice questions from agents between 20:00 and the morning unless stop-ship; they are queued and sent
together in the next morning's push.

### 3e. How pictures reach him

He cannot open repo paths. Rules already exist in memory (send images, same message as the question). Make it a path to take:
1. The 0.10.0 chat (or planning chat) renders the pictures into one image per question (before/after side by side) and sends
   them as images in the same chat message as the question, or publishes one artifact page per pack where each question
   has its picture inline and the answer buttons. Several T-tickets point to `T1145-shots/` style folders: an owner line
   saying "look at `handoff/.../T1145-shots/`" cannot be acted on by him (T1145, T1004, T1010, T1024, T1039 all do this).
2. The owner pack artifact is the single place; the ticket gets the link and the answer.
3. Mark each picture as "built" (real screen) or "mock-up" so he knows what he is judging.
4. A picture is not required for questions with a default and no look (data calls).

## 4. Checklist drafts

### Before the cut (for the planning chat to turn into a runbook page)

1. Open the release's scope list (ticket numbers) and freeze it. Anything new after this goes to the next release unless it is
   a wrong answer on screen.
2. List every ticket in scope whose `## Owner` block has an open `- [ ]` line. For each: question, kind (look, wording, data,
   scope, click), default, cost of the other options.
3. Check each default against the standing answers (page of 3b). Any default that contradicts one is replaced by the standing answer.
4. Mark each item "no picture needed" or "needs a picture". Build the pictures from the candidate data (a read-only preview
   is fine) before asking. Ask `where does a nameless / unusual case exist?` using the audit list (e.g. parts with no name,
   waters with no rule), so the late finds come before the cut.
5. Run the known "late finder" checks early: unnamed parts, rule-gap channels, straddlers, colour tokens, the store checklist
   (EU trader, privacy label, content rights, age rating), pins and golden pages. Anything found goes into the pack now.
6. Assemble the owner pack: pictures inline, defaults, his clicks in order (store answers, production commands).
7. Send the pack as one push; one sitting. Record each answer in the ticket the same turn (W49).
8. Items left unanswered at the cut: default ships. List them in the release notes of the cut for him.
9. Cut. Version computed by the rule (T998).

### Release night

1. No new questions to him except stop-ship (a false rule shown, a crash, a store requirement that blocks, a secret).
2. A stop-ship question goes alone, with: what is wrong, a picture, the default, and the cost in hours of each option.
3. Everything else: write a ticket line with its default; it goes to the next release's pack.
4. A change he asks for after the cut is answered with its cost first ("this re-runs reach, tiles and deliver: about 33 + 45
   minutes, plus golden pages"), then his pick.
5. Chats do not send their own questions at the same hour; the planning chat owns the queue (roadmap row P already does intake).
6. The production commands and store clicks come as one ordered list, with the dry runs.
7. After the ship, the planning chat sends one "what is left for next time" summary of the defaults that shipped.

### Proposed AGENTS.md lines (text for notes only, not applied)

- A9. **Ask the owner once per release, before the cut.** Questions, pictures and wordings for the release go into one owner
  pack, with a default and the cost of the other options. After the cut only a stop-ship question (a rule shown wrong,
  a crash, a store block, a spend) goes to him; everything else becomes a ticket line with its default for the next
  release.
- A10. **A default never contradicts a standing answer.** Before offering or building a default, read the standing answers
  (the standing rulings list) and use them. A new owner answer that sets a pattern (a naming rule, a colour rule,
  "to the hardening release") is added to that list in the same turn (W49).
- A11. **Pictures go to the owner as images in the question's own message (or in the pack's artifact page), never as repo
  paths.** A ticket's owner line that points at a `-shots/` folder also says where the picture was sent.
- A12. **A late find that does not put a wrong answer on the screen of the running release goes to the next release**
  (ticket + default); the chat that found it says so and does not ask him on the night.
- A13. **One queue for owner questions:** only the planning chat sends them, in batches, by push; a build chat hands its
  questions to it (already roadmap rule for owner items; make it an AGENTS rule).

## Picks for the owner

1. Release-night rule: after the cut, only stop-ship questions reach you; the rest wait for the next pack.
   (a) Yes, default (recommended). (b) Yes, but a look you ask for yourself still re-cuts with the cost shown first.
   (c) No, keep asking as now.
2. Standing rulings page: write down the answers in 3b as rules.
   (a) Yes, one page, you confirm the list once (recommended). (b) Only the naming and colour ones. (c) No.
3. Owner pack: one sitting before each cut, pictures inline in an artifact page.
   (a) Yes, artifact page with answer buttons (recommended). (b) A chat message with images. (c) Keep as now.
4. Agent-decided defaults: the list in 3c.
   (a) Yes (recommended). (b) Only for wording and looks, not data. (c) No.
5. Quiet hours: no multi-choice from chats between 20:00 and morning except stop-ship.
   (a) Yes (recommended). (b) 22:00. (c) No.

## NEW TICKET lines

- NEW TICKET: Owner pack for each release (page built from the open owner lines of the release's tickets, with
  defaults and inline pictures), plus a check that a ticket's owner line naming a `-shots/` folder also records where the
  picture was sent.
- NEW TICKET: Standing rulings page (owner answers that set a pattern), read before any default is offered; add the first
  entries from section 3b.
- NEW TICKET: Runbook page "Before the cut / Release night" from section 4 (the release-by-hand runbook; adds the
  stop-ship definition).
- NEW TICKET: Early late-finder audit before each cut (unnamed parts, rule-gap channels, straddlers, colour tokens,
  store checklist), so that finds like T1146, T1149, T1150 appear before the cut.

## Not verified

- The 0.9.0 list is a sample: closed tickets keep answers, rarely the time of day. I did not read the chat logs, only files.
- Times of day for 11-25 come from ticket text (13:20, 14:06, 15:14, about 16:55, etc.); I did not check commit times.
- I did not check whether memory notes (standing answers like "everything added is a proposal", "no silent fallbacks",
  "pictures, not paths") say exactly what I quote; I used their titles from the memory index, not their full text.
- I did not count how many separate questions the owner saw in the chat that day (the "more than 20" is his figure); my 35 rows
  are from the files and may split or merge a few of his dialogs.
- "Real name or a distance" as a rule: the owner's exact words are the T1140 quote above; I did not find that phrase written as a rule in the repo.
- Whether T1081 / T1128 / T1151 hold more owner lines than I read (I read the Owner blocks I list, T1081's block gave nothing new).
- The roadmap's claim that notifications go out by push could not be checked; I used it as written.
