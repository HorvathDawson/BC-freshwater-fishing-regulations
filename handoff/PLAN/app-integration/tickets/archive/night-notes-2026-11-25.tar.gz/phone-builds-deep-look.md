# Phone builds (Android and iPhone): why they are slow and unreliable in a release

Night agent, 2026-11-25, read-only. Local times are the Mac's clock (-07:00). Gradle's own logs stamp -08:00 (its Java
thinks Vancouver is on standard time), so I added an hour to every Gradle timestamp below. Code is read at main
(planning worktree, c0daabd8a). Past builds are read from the main checkout's output files and the tool logs in the
home folder. I ran no build.

## The short answer

**The builds are fast. The waits around them are slow.** Every measured phone build took minutes:

- **Gradle:** 56 s to 6 m 3 s (45 builds, 11-19 to 11-24, from `~/.gradle/daemon/*/daemon-*.out.log`; most were 1 to 2 min).
- **iPhone:** `xcodebuild archive` took 81 to 131 s (7 builds, 11-17 to 11-24), and the export plus upload took 82 s
  (0.9.0). Both are measured from the DerivedData folder's birth time to its activity log, and then to
  `app/dist/ios/build.log`.

The hours went to four things, each with its own cause:

1. **A Gradle client that hung for over an hour** after BUILD SUCCESSFUL. T1058's fix stops this one form. A hang in
   any other step (Metro, xcodebuild, pod install, prebuild) is still not watched.
2. **A "fast-fail" that is not fast on release day.** For a store build, "changed" means everything since the last
   store build. Any pipeline file in that set makes it run **the whole no-data pipeline test tier**, outside the heavy
   lock, on a Mac loaded by other chats. CI (strict) and the release's follows have already tested that same tree.
3. **An unfair lock.** Waiters retry every 20 s and whoever is first wins. The iPhone build waited 70 min and lost the
   lock twice to later arrivals (T1063).
4. **Holding the lock while doing nothing.** The iPhone build keeps the heavy lane for up to 45 min while it polls
   Apple's processing (`build-ios-testflight.sh:65`, `testflight-distribute.mjs:156`).

The task's premise needs one correction: **MapLibre is not built from source on every build.** It is built once per pin
into `cache/maplibre/<MLN_VERSION>/` and checked by its commit (`deploy/lib/build-links.sh:54-64`). The only build on
this Mac was 2026-11-22: 703 s (`app/tools/maplibre-android/build.sh:13`), and the daemon log shows 11 m 41 s with 56
tasks. Its real cost is that the file exists **only on this Mac**.

**A trap in the "build overnight, upload in the morning" plan.** `build-apk.sh --no-upload` builds the bundle and
commits the versionCode. But the documented morning command, `--publish-only`, does **not** upload the bundle to Play
(`deploy/staging/build-apk.sh:170-196`). It only rewrites the version files and sends the email. On iPhone,
`--no-upload` exports an `.ipa`, and the upload is "Transporter or `xcrun altool` by hand" (`build-ios-testflight.sh:17`).
Today, neither phone has a one-command "upload what was built last night".

---

## 1. Each build end to end, as it runs today

### Android production (`CONFIRM_PROD=canifishthis.ca deploy/prod/build-apk.sh`)

`deploy/prod/build-apk.sh:10` runs `deploy/staging/build-apk.sh --play --production`.

| # | Step (file:line) | Waits on | Time (how measured) | Failure history |
|---|---|---|---|---|
| A1 | Fast-fail base = the last Play build's commit (`build-apk.sh:202-213`, `app/dist/apk/last-play-sha`) | — | seconds | — |
| A2 | Precheck, before the lock: links, JDK and SDK, changelog, **rc check (T1062)**, keystore and certificate, app.json committed, **one Play API call**, wrangler login, run token, R8 flags, the pinned AAR and its build id, uncommitted app paths (`:216-288`) | the Play API, wrangler | not measured (a guess: under 1 min) | 0.8.4: a missing `cache/` exited with no message (fixed in T978, `build-links.sh:7-9`) |
| A3 | **CI gate**: `ci_status.py --strict` (`:293`, `build-links.sh:184-190`) | GitHub API pages, up to 10 pages × 4 workflows, 60 s timeout each (`ci_status.py:57, 66`) | not measured | 0.9.0: "no finished run", because the green ancestor was more than 30 runs back, so `CI_CHECK_SKIP` was used (T1059). **Fixed only in part, see F3** |
| A4 | **Fast-fail** (`build-links.sh:191-194`), **outside the heavy lock** | the CPU it shares with every other lane | 0.9.0: **30 min** behind the 0.9.1 lanes' tiers (T1063 source line). The script's own target is ≤ 2 min (`fast-fail.sh:3`) | see F2 |
| A5 | **Heavy lock**: `exec scripts/heavy.sh build-apk 20` (`:300`); retries every 20 s (`heavy.sh:46, 229-254`); then waits for 20 % free memory (`:264-270`) | other heavy jobs | 10-29: 12 min behind an atlas build (`app/dist/build-apk.log` lines 1-37, 36 waits × 20 s). 0.9.0: the Android wait was not recorded | see F4 |
| A6 | Same-HEAD check (`:340`, `build-links.sh:171-175`) | — | seconds | new with T1062 |
| A7 | Fresh git worktree in `$TMPDIR` (`:342-346`); versionCode bump in the worktree (`:348-351`) | — | seconds | — |
| A8 | `pnpm install --offline --frozen-lockfile` (`:415`) | the pnpm store | not measured | — |
| A9 | `expo prebuild --platform android --no-install` (`:417`): config plugins (R8, Gradle memory, upload signing, pinned MapLibre) | — | not measured (a guess: 20-60 s) | — |
| A10 | **Gradle `bundleRelease`** (`:421`) through `gradle_watched`: `--no-daemon`, stops 120 s after the BUILD line, or after 1 h (`deploy/lib/gradle-watch.sh:26-27`). Includes Metro and Hermes, R8 and signing | — | 56 s to 6 m 3 s. 0.9.0 first try: 3 m 27 s, 695 tasks, all executed, then a **hang of over an hour**. Retry 12:13 → 12:19 (6 m 3 s, a loaded Mac; AAB at 12:19:07) | **The T1058 hang, see F1** |
| A11 | Keep the Hermes and R8 maps (`:423`); R8 check (`:425`); upload-key signature (`:427-430`); MapLibre build id (`:433`) | — | seconds | T512 (stock MapLibre shipped in builds 20 and 21) is now caught here |
| A12 | **Commit the versionCode** into the main checkout (`:434`, `:331-337`); copy the AAB | — | seconds | — |
| A13 | `--no-upload` ends here (`:439`). **It writes no `play.json`, no notes file and no `last-play-sha`** | — | — | see F6 |
| A14 | Play upload with the mapping file (`:446`) | the Play API | not measured | — |
| A15 | R2 `play/<code>.json` and `play.json`; email (`:450-468`) | wrangler | seconds | an expired wrangler login is fixed by `--publish-only` |

Inside the lock, the measured whole staging build is 2 m 30 s and 2 m 05 s (T1058's two proof runs). A production build
adds the Play upload, which was not measured.

### iPhone production (`CONFIRM_PROD=canifishthis.ca deploy/staging/build-ios-testflight.sh --production`)

| # | Step (file:line) | Waits on | Time (how measured) | Failure history |
|---|---|---|---|---|
| I1 | Fast-fail base = the last upload (`:84`, `app/dist/ios/last-sha`) | — | seconds | — |
| I2 | Precheck: xcodebuild, pod, node, links, changelog, rc check, team id, the ASC key `.p8`, wrangler (`:89-123`) | — | not measured | T993 (11-21): the iPhone build ran no gates at all before this |
| I3 | CI `--strict`, then fast-fail (`:125`) | as A3 and A4 | not measured | as A3 and A4 |
| I4 | **Heavy lock** (`:129`) | other heavy jobs | **0.9.0: about 70 min** (T1063: queued at 13:58, lost the lock at 14:23 and 14:47; DerivedData shows the archive starting at 15:15:17) | see F4 |
| I5 | Worktree, `pnpm install`, buildNumber in the worktree only (`:192-198`) | — | not measured | — |
| I6 | `expo prebuild -p ios` (`:200`) | — | not measured | — |
| I7 | `pod install` (`:202`; only the last 5 lines are shown, the rest goes to the log) | CocoaPods cache (`~/Library/Caches/CocoaPods`, 2.0 GB) | not measured. 118 Podfile dependencies, 117 pods (`build.log:302`) | none recorded |
| I8 | **`xcodebuild archive`**, automatic signing with the API key (`:206-208`) | Apple's signing service | **81-131 s** over 7 builds (DerivedData birth → `Logs/Build/*.xcactivitylog`). 0.9.0: 15:15:17 → 15:16:43 | none recorded. **No watchdog** |
| I9 | `-exportArchive` with destination `upload` (`:227-229`) | App Store Connect | 0.9.0: 82 s (15:16:43 → `build.log` 15:18:05). It warns "Upload Symbols Failed" for 6 frameworks (`build.log` tail) | **No watchdog** |
| I10 | dSYMs kept; `testflight-last-build`, `last-sha`; R2 version files (`:231-248`) | wrangler | seconds | — |
| I11 | **`testflight-distribute.mjs`**: polls Apple's processing every 30 s for up to 45 min, then export compliance, What to Test, External group, Beta review (`:253`) — **still inside the heavy lock** | Apple | Apple's processing time (header: "~5–30 min", `:9`). Not recorded for 0.9.0 | 0.9.0: the external submit was refused by Claude's permission check and went to the owner, about 8 h on the calendar (release-timeline.md row 62) |

Inside the lock, iPhone is about 3 min of work plus install, prebuild and pods (not measured). Then 5-45 min of polling
keeps the lane held.

### The failures, one by one

**F1. Gradle hang after BUILD SUCCESSFUL (T1058).**
- *Evidence:* `~/.gradle/daemon/9.4.1/daemon-53034.out.log`.
  - Build started 10:10:52.
  - "Daemon will be stopped at the end of the build after running out of JVM Metaspace" (line 275).
  - BUILD SUCCESSFUL in 3m 27s (line 285).
  - `stop()` at 10:14:18.931 (line 300), then "dispatching the build result" 1 ms later (lines 304-305).
  - "Timed out waiting for finished message from client" 60 s later (line 312).
- *Root cause, as far as the evidence goes:* the daemon did send the result, then shut the connection while stopping
  itself, and the client never finished reading. This is a race in Gradle's client/daemon handoff, triggered by the
  Metaspace expiry. It is not a crash.
  - Of 45 daemon logs, 2 others also show "Timed out waiting" (11-22 18:18 and 11-24 02:39), but those clients exited
    (both builds have a later build). So the race is common and the hang is rare.
- *The fix:*
  - Metaspace raised to 1024m (`plugins/with-gradle-memory.js:24`). Peak is 416 MiB, 41 % (T1058). This removes the
    **trigger** while the app's class count stays about where it is.
  - `--no-daemon` keeps the handoff: a single-use daemon still talks to the client over a socket (`gradle-watch.sh:17`).
  - The watcher stops a client 120 s after its BUILD line (`gradle-watch.sh:82`). This bounds the **symptom** at about
    2 min.
  - **Removed or symptom?** Mostly removed (trigger gone), with a bounded symptom kept.
- *Two gaps left:*
  - (a) After a stop, the build counts as **failed** (exit 124, `:95`), so the whole build and the lock wait run again,
    even though A11's checks (signature, MapLibre id, R8) would prove the AAB sound.
  - (b) A hang *before* the BUILD line (Metro stalling inside `createBundleReleaseJsAndAssets`, a stuck download) is
    caught only by the 1 h cap (`GRADLE_MAX_S=3600`, `:27`), against a normal build of 1-7 min.
- *Fast detection:* see the "watchdog" sketch below.

**F2. The 30-minute fast-fail (T1063 source).**
- *Root cause:*
  - Store builds set `FAST_FAIL_BASE` = the last store build's commit (`build-apk.sh:202-213`,
    `build-ios-testflight.sh:84`). For a release, that is the whole release's diff.
  - Any changed pipeline source file then runs "the whole no-data tier, as CI", in chunks
    (`scripts/fast-fail.sh:399-409`): "minutes, once per ship".
  - It runs **outside the heavy lock** (`build-links.sh:184-194`), so it competes with every lane's tests (load average
    85-145, T1063).
- *What the fix on record does:* none exists yet. T1063 item 0 would put hook test runs inside a lock. That reduces the
  competition, not the redundant work.
- *What removes it:* on a release branch at the newest rc, the tree was already tested.
  - The release follows ran the app suite, 25 gates and the pipeline data tier (release-timeline.md row 50).
  - CI `--strict` is green at that commit.
  - The store build should then run only its **app-side** fast checks (the changelog, `pnpm check:fast` about 21 s,
    `fast-fail.sh:381`), not the pipeline tier.
  - Rule: when `release --rc-check` passes, the ledger has a follows pass for that rc's commit, and the diff since then
    touches only build numbers, skip the pipeline tier and say so.
- *Detection:* fast-fail prints its total (`fast-fail.sh` `finish`). Add a store-build line: "fast-fail took N min; over
  5 min is a sign the base is wrong".

**F3. The CI lookback (T1059).**
- *Fix on record:* page through up to 10 × 100 runs (`ci_status.py:57, 186-207`).
- *Today's counts* (`gh api …/workflows/<wf>/runs`, total_count, read 2026-11-25 night):

  | Workflow | Runs |
  |---|---|
  | app-ci | 1330 |
  | pipeline-ci | 941 |
  | docs-ci | 729 |
  | feeds-worker-ci | 541 |

- *Why that matters:*
  - app-ci is already past the 1000 the search can read.
  - The search stops at the first finished run whose commit is an ancestor, usually near the top. So it works today.
  - But a path-filtered workflow whose area has not changed for a few busy days (feeds-worker-ci, docs-ci) can drop
    beyond 1000 runs back. Then it says CANNOT TELL (exit 2, `:206`), and the build stops before the lock.
  - The 0.9.0 night showed 1000 runs in about 21 h (release-timeline.md "Where the numbers come from").
  - **This is a symptom fix with a ceiling.**
- *What removes it:* walk the ancestors instead of the runs.
  - For each workflow, take the last commit that changed its area (`git log -1 --format=%H <sha> -- <area paths>`;
    `ci_paths.py` already holds the areas).
  - Ask GitHub for runs **at that commit**: `GET /repos/{o}/{r}/actions/runs?head_sha=<c>`, one call.
  - The number of calls no longer grows with the number of runs.
- *Detection:* the CANNOT TELL line already says itself. Have the precheck print "pages read: N of 10" so a creep toward
  the cap shows before it bites.

**F4. The 70-minute lock wait (T1063).**
- *Root cause:* `heavy.sh` waiters retry `mkdir` every 20 s, and the queue file is read only by `--status`
  (`heavy.sh:226-254`). The lock goes to the first retry after the holder leaves, not the longest waiter. There is no
  priority. A queued 0.9.0 iPhone build lost twice.
- *Fix on record:* none yet. T1063 is OPEN, and a sketch is in ci-speed-build-plan.md §6.
- *What would detect it:* `heavy.sh --status` already lists the waiters. Add each waiter's waited time, and a warning
  line from the waiter itself every 10 min.

**F5. The iPhone build holds the lock while it polls Apple** (`build-ios-testflight.sh:65`, `:253`). There is no
failure on record, but it blocks the lane for up to 45 min with no CPU in use. *Fix:* end the heavy job after the R2
version files, then run `testflight-distribute.mjs` outside the lock. Its own header calls it light work, and every step
is a no-op when it is already done (`:64`).

**F6. "Build overnight, upload in the morning" is not a command** (see "A trap" above).
- With `--no-upload`, the versionCode is computed **without asking Play** (`ONPLAY=0`, `build-apk.sh:317-320`). Only
  app.json and `~/.canifishthis/play-last-version-code` decide it.
- It also commits the bump (`:434`) before anything is uploaded.
- That is safe while this Mac is the only uploader. It needs care once CI uploads too.

**F7. No Xcode, CocoaPods or signing stop is on record** in the tickets I read (T88, T918, T1071). One problem is on
record: an "App Manager" key cannot sign for the store; the key needs the Admin role (`build-ios-testflight.sh:36`, seen
2026-11-14). The 6 "Upload Symbols Failed" warnings (0.9.0 `build.log`) mean Apple's crash reports for those frameworks
(MapLibre, React, Hermes) arrive without symbols. That is not a stop.

### A watchdog for every build step (fast detection of any hang)

One rule for all store builds: **a step with no new output for N minutes is stopped, said and reported.** Today only
Gradle has a watcher, and it looks for the BUILD line, not for silence.

| Step | Output goes to | Quiet limit (a guess, from the measured lengths) | Hard cap |
|---|---|---|---|
| pnpm install, prebuild | stdout | 5 min | 10 min |
| Gradle (R8 can be quiet 1-3 min) | gradle-watch log | 8 min | 20 min (now 60) |
| pod install | `app/dist/ios/build.log` | 8 min | 15 min |
| xcodebuild archive / export | `build.log` | 8 min | 20 min |
| testflight-distribute | stdout, a line every 30 s | 5 min | 45 min (as now) |

How:
- Generalise `gradle_watched` into `watched <log> <quiet_s> <max_s> -- cmd`, reusing `_gw_stop` (`gradle-watch.sh:43-57`).
- Have `heavy.sh` stop a job whose `log:` file has not grown for `HEAVY_QUIET_MAX` seconds, when set (`heavy.sh:196-200`
  already records the log path).
- A stop sends the existing feeds-worker email ("build-apk: stopped, no output for 8 min in step X; log at …"), so the
  owner learns of it in minutes, not hours.
- The MapLibre build writes only to its own log (`build.sh:68`), so it needs its own limit (an 11-12 min build).

---

## 2. What is rebuilt every time that need not be

| Thing | Today | Cache key if cached | Minutes saved (how sure) | Do it? |
|---|---|---|---|---|
| **MapLibre Android AAR** | Already cached: `cache/maplibre/<MLN_VERSION>/`, checked by file name and `SOURCE.txt`'s commit (`build-links.sh:54-64, 78-88`). Built once, 703 s | `MLN_COMMIT` + NDK `28.2.13676358` + CMake `3.31.6` + ABIs (`build.sh:20-27`) | 0 on the Mac (it is not rebuilt). About 12+ min per runner build if CI had no cached file | **Yes for CI:** a GitHub Release asset per pin, with its sha256 and SOURCE.txt (ship-workflow-design.md NEW TICKET). Also a second copy off the Mac: today one disk failure means rebuilding plus installing the NDK |
| `expo prebuild` output | Regenerated in every fresh worktree | hash of the native inputs (section 4) | about 0.5-1 min (a guess, not measured) | **No.** Prebuild is where the R8, signing and pinned-MapLibre plugins act and refuse. A stale copy would bypass those refusals |
| Gradle task outputs | "695 actionable tasks: 695 executed" in every build-apk worktree (daemon logs). Dependencies and transforms do persist in `~/.gradle/caches` (9.4 GB) | Gradle's own input hashes (`org.gradle.caching=true`; not set anywhere in `plugins/`) | about 0.5-1 min of a 1-2 min build (a guess) | Low value. Possible later, with a test that a cache hit never changes the AAB's R8 scores or MapLibre id |
| CocoaPods | `pod install` every time; pod downloads are cached (`~/Library/Caches/CocoaPods`, 2.0 GB) | `Podfile.lock` | small (not measured) | No |
| **Xcode DerivedData** | A **new folder per build**, because the worktree path changes (`build-ios-tf-$$`, `:189`). 7 folders × about 986 MB = **6.9 GB left behind** in `~/Library/Developer/Xcode/DerivedData` (du, tonight) | — | 0 (the archive is only 81-131 s anyway) | **Yes, for disk, not time:** `-derivedDataPath "$WT/DerivedData"` so it goes away with the worktree. It also keeps each release archive clean on purpose. Disk filled twice before (`heavy.sh:33-35`) |
| JS bundle (Hermes) | Built inside Gradle and inside Xcode, once per platform | — | — | **No.** The bundles differ by platform and by `EXPO_PUBLIC_*` (production and staging differ, `build-apk.sh:302-313`) |

**Never cache or reuse:** the signing keystore and certificates, provisioning profiles, the versionCode and
buildNumber, the `EXPO_PUBLIC_*` environment (production against staging), the changelog notes, the git-sha stamp
(`EXPO_PUBLIC_GIT_SHA`), and the R8 mapping and dSYMs (they belong to one binary).

**Honest total:** caching saves at most 1-2 min per phone build on the Mac. Caching is not where the hours are.

---

## 3. The queue problem: options

Release-morning minutes below are machine time for both phones. The owner's minutes are separate.

| Option | Minutes per release | $ per month (4 releases) | Signing-key safety | What the owner sets up | Risk |
|---|---|---|---|---|---|
| **A. Priority lane for release builds (T1063)** + store builds release the lock before Apple polling (F5) + no pipeline tier in the store fast-fail (F2) | Lock wait → about 0-5 min (the current holder finishes). Today: 30 + 70 min seen | $0 | unchanged (keys stay on the Mac) | nothing | low. Rule: only a release run may set priority |
| **B. Build both phones overnight on the rc with `--no-upload`, upload only in the morning** | Morning: about 2-5 min of uploads + Apple processing (5-30 min) | $0 | unchanged | needs two small tools first (F6): an "upload the built AAB" and an "upload the built .ipa". Then he runs the night builds before bed, or Claude does on his word (production is his, `confirm-prod-owner-only`) | low. A replaced rc only uses up build numbers. The night build must be refused when HEAD ≠ the newest rc (already true, T1062) |
| **C. Android on a GitHub Linux runner** (T1133 stage A) | Build about 10-20 min (a guess: a cold runner, a cached pnpm store and Gradle dependencies, the MapLibre asset downloaded). The Mac lock is out of it | **$0**: standard runners are free in public repos ([GitHub docs](https://docs.github.com/en/billing/concepts/product-billing/github-actions), read 2026-11-25). A private repo would pay $0.006/min, about $0.50 a month | Keystore in an **environment** secret (`play`) with the owner as required reviewer. Better still: build unsigned in a job with no secrets, then sign and upload in a second job behind the approval. The approval gap (agents use his `gh` login) must close first (T1160) | env `play`; `ANDROID_UPLOAD_KEYSTORE_B64`, its properties file, `PLAY_SERVICE_ACCOUNT_JSON`; the MapLibre asset per pin; a versionCode rule (Play's highest + 1, recorded on the tag, not a commit pushed to the branch) | medium. MapLibre on CI (NDK version matching); a public repo's workflows must never run on fork PRs with secrets |
| **D. iPhone on a GitHub macOS runner** (T1133 stage C) | about 15-25 min (a guess) | **$0** in a public repo (same page). A private repo would pay $0.062/min, about $6 a month | ASC API key `.p8` (Admin role) as an environment secret. Cloud signing with `-allowProvisioningUpdates`, so no certificate to export | env `app-store`; `ASC_KEY_ID`, `ASC_ISSUER_ID`, `ASC_KEY_P8`, team id | medium. **Not verified:** whether the runner image's Xcode matches the Mac's (the Mac builds with the iPhoneOS 27.2 SDK, `build.log:1572`). The build-number state (`~/.canifishthis/testflight-last-build`) must move to App Store Connect's highest + 1 |
| **E. Xcode Cloud** | similar to D (a guess) | $0 within **25 compute hours a month**, included with the developer program ([Apple news](https://developer.apple.com/news?id=ik9z4ll6), checked 2026-11-25 by search; unused hours do not roll over) | keys stay with Apple | connect the repo in App Store Connect | **higher. My understanding, not verified:** Xcode Cloud wants the Xcode project in the repo. Here `ios/` is generated and gitignored (`app/apps/mobile/.gitignore:4-5`), so every build needs a `ci_post_clone.sh` that installs Node and pnpm, runs prebuild and pods. Android stays elsewhere. The source would be read by Apple's service |
| **F. EAS Build** (Expo's servers) | about 15-30 min, queue included (a guess; free-tier limits not checked) | not checked | the keys (keystore, ASC key) would be **held by Expo** | an Expo account and credentials uploaded | It breaks the self-host rule: the build, the keys and the pinned MapLibre fetch all leave our hands. `with-pinned-maplibre.js` already refuses an EAS production profile without the pin (README "How a build uses it"). **Not recommended** |
| **G. Stay on the Mac, as today** | measured: 1.5 to 3 h of waits in 0.9.0 | $0 | as now | — | the single-Mac risk (sleep, disk, other chats) |

**Recommendation: A now, B next, then C. Leave D until iOS is unbenched and C has shipped once.** A and B are both
small, and together they turn release morning into uploads only. Moving to CI (C, D) removes the single-Mac risk, but it
is weeks of work, and the build itself is only minutes either way.

---

## 4. Is a phone build needed at all?

There is no over-the-air JS update here (`expo-updates` is not in `app/apps/mobile/package.json`; count 0). So **any
change to code the app bundles needs a store build.** Only "data / web / worker only" can skip.

| What changed since the last shipped phone build | Phone build? |
|---|---|
| Only data (a data release, no app version): no rc either, owner pick "data-only releases get rcs: No" (T1062) | **No** |
| Only the web site, SEO, the feeds or data worker, docs, the pipeline | **No** |
| App JS or TS (`app/apps/mobile/**` outside native, `app/packages/{core,data,map,ui,ui-native}/**`) | **Yes**, but no native risk: the build is routine, and a prebuild or MapLibre change is not expected |
| Native: `app/apps/mobile/package.json` native deps, `app/pnpm-lock.yaml`, `app/patches/**`, `app/apps/mobile/app.json` (except version and build numbers), `app.config.js`, `plugins/**`, `modules/**`, `app/tools/maplibre-android/pin.env` | **Yes**, plus the full device pass (R8 keep rules, MapLibre) |

0.10.0 for example: since v0.9.0, the native inputs changed are `package.json`, `r8-keep-rules.pro`,
`with-gradle-memory.js` and `with-r8.js` (`git diff --name-only v0.9.0 origin/release/0.10.0 -- …`). So 0.10.0 needs
both builds with the full device pass.

**How the release command should decide and say so:** `release --phones-needed` prints one of three words with its
reason:
- **none**: no app path changed since the last store build's commit (`app/dist/apk/last-play-sha`,
  `app/dist/ios/last-sha`, or better the last `v*` tag);
- **js**: app paths changed, no native path;
- **native**: lists the native paths and the **native-input hash** (sha256 over the sorted list above, minus the
  version and build-number fields).

Two more rules:
- The hash goes on the rc tag's annotation, so a CI build (C) can reuse a prebuild image keyed by it later, and so
  "native" is a fact, not a guess.
- The cut and the runbook's Step 6 read that word: "none" skips Step 6, said.

---

## 5. Store steps after the build, and their waits

From `handoff/PLAN/play-production-access/releases.md` and T1071:

| Step | Typical wait (the project's record) | Can be prepared ahead? |
|---|---|---|
| Play **Internal** | available within minutes of upload (no review recorded as a wait) | — |
| Play **Closed** (promotion, `play-upload.py --promote`) | Google reviews it. 0.9.0 promoted 2026-11-24, **still pending** on 11-25. Earlier rows do not record the review time | Promote as soon as Internal installs; nothing else |
| Play **Production** | the owner's staged rollout in Play Console; production access is still gated by the closed test (T1046) | — |
| TestFlight **processing** | "~5–30 min" (`build-ios-testflight.sh:9`). Not recorded for 0.9.0 | the night build (B) moves it off the morning |
| TestFlight **Beta App Review** (the first build of a version) | 0.8.5: submitted 11-21, approved 11-22 (about 1 day). 0.9.0: submitted about 22:58 on 11-24, still waiting | the What to Test text comes from the changelog. A night upload starts the clock about 10 h sooner |
| **App Store review** | not yet recorded (the first submission is T1071, 0.10.0) | every screen except "select the build" is done (T1071, 2026-11-25 14:48) |

Also: Claude's permission check refused the external TestFlight submit in 0.9.0, and it waited about 8 h for the owner
(release-timeline.md row 62). Decide ahead whether the distribute step is Claude's on the owner's word, or always his.

---

## 6. A staged plan

| Stage | What | Size | Saves |
|---|---|---|---|
| **S1** | T1063 as rewritten below: a fair queue, release priority, and store builds release the lock before Apple polling | S (about 2-3 h with tests) | 30-70 min of waits per release |
| **S2** | Store fast-fail on a tested rc skips the pipeline tier (F2) | S | up to 30 min |
| **S3** | A watchdog for every build step, plus an email on a stop. Gradle's hard cap 60 → 20 min | S-M | turns a 1 h+ hang into about 10 min, reported |
| **S4** | Upload-what-was-built for both phones (`--upload-built`): checks the file's sha against the build record and HEAD = rc, then Play upload with mapping, notes and version files (Android), or `altool`/`xcrun` upload, build number, version files and distribute (iPhone) | M | enables B: morning = uploads only |
| **S5** | `release --phones-needed` and the native-input hash on the rc tag | S | a whole phone round skipped on data/web-only releases |
| **S6** | CI ancestor lookup by commit (F3); DerivedData inside the worktree | S | removes a coming CANNOT TELL; 1 GB of disk per iPhone build |
| **S7** | T1133 stage A: Android on CI (needs the MapLibre asset first) | L | the single-Mac risk for Android |

**Expected time for both phone builds on release morning:**

| | Today (0.9.0 as recorded) | After S1-S3 | After S1-S5 (built overnight) |
|---|---|---|---|
| Waits (fast-fail, lock) | 30 + 70 min, and more | 0-5 min | 0 in the morning |
| Build work | about 5 min Android + about 5 min iPhone (measured parts plus guesses for install, prebuild and pods) | the same, 10 min | 0 in the morning |
| Hang risk | 1 h+ (0.9.0) | at most about 10 min, reported | at night, reported by email |
| Uploads + Apple processing | in the lock | outside the lock | about 5 min of uploads, then Apple's 5-30 min, nobody waiting |
| **Total on the morning clock** | **about 2.5-3 h** (recorded: Android 10:10 → 12:19; iPhone queued 13:58 → archived 15:16) | **about 20-30 min** | **about 5-10 min of owner time** |

### Replacement text for T1063

> **T1063 — `scripts/heavy.sh`: a fair queue, a release priority, and no idle holding**
>
> Source: 0.9.0 (2026-11-24): the production fast-fail took 30 min behind the 0.9.1 lanes' tiers; the iPhone build
> waited about 70 min and lost the lock twice (13:58 queued; lost at 14:23 and 14:47) because waiters retry `mkdir`
> every 20 s and the queue file only feeds `--status` (`heavy.sh:226-254`); the iPhone build then held the lane while it
> polled Apple (`build-ios-testflight.sh:65, 253`, up to 45 min).
>
> Work:
> 1. Fair queue: the queue file holds `epoch`, `cmd`, `priority`; a waiter tries the lock only when it is the live
>    waiter with the highest priority, then the longest wait (ci-speed-build-plan.md §6 sketch).
> 2. `HEAVY_PRIORITY=1` is set only by the release command's own heavy calls and the two store-build scripts on a
>    `release/x.y.z` branch at the newest rc; AGENTS says only a release run may set it.
> 3. Test runs from hooks (vitest, pytest tiers) take a light lane or the lock, so they cannot pile up outside it
>    (was item 0).
> 4. `build-ios-testflight.sh`: the heavy job ends after the R2 version files; `testflight-distribute.mjs` runs after
>    the lock is released.
> 5. `--status` shows each waiter's priority and how long it has waited; a waiter prints a line every 10 min.
>
> Acceptance: `heavy.test.sh`: waiters A, B, C queued in order, C at priority 1 → C, A, B; a dead waiter is skipped; a
> fake distribute step runs with the lock free. The runbook's Step 6 names the flag.
> Severity: medium. Size: S. Model: Sonnet. Owner: no.

### Additions for T1133

- Before stage A: the MapLibre AAR as a GitHub Release asset per pin. Key: `MLN_COMMIT` + NDK + CMake + ABIs; sha256
  and `SOURCE.txt` beside it. The Mac's `cache/maplibre` can be filled from the asset too.
- The versionCode and buildNumber move from local files and a branch commit (`build-apk.sh:316-336`,
  `~/.canifishthis/testflight-last-build`) to "the store's highest + 1, written on the rc tag's annotation". Decide it
  before two uploaders exist.
- Split build and sign: the build job holds no secrets; a signing and upload job holds them behind the approval.
- The rc tag carries the native-input hash (section 4). A CI run on a tag whose phone answer is "none" builds no phone.
- iPhone (stage C): check the runner image's Xcode against the Mac's SDK first. Measure one trial run before the plan
  promises minutes.

## Picks for the owner

1. **Release-day queue:** (A) priority lane plus no idle holding plus the light store fast-fail (S1+S2), recommended;
   (B) only a "quiet Mac" rule for other chats; (C) as today.
2. **Phone builds overnight:** (A) yes, once the upload-built tools exist (S4): built on the rc before bed, uploaded in
   the morning, recommended; (B) build in the morning after S1-S3 (about 20-30 min); (C) as today.
3. **Where phones build next:** (A) the Mac, with S1-S6, and Android to CI after the MapLibre asset; iPhone stays on
   the Mac while iOS is benched (recommended); (B) both to GitHub runners soon; (C) Xcode Cloud for iPhone; (D) EAS
   (breaks self-host).
4. **A Gradle client stopped after BUILD SUCCESSFUL:** (A) keep the AAB if the signature, MapLibre and R8 checks all
   pass, and say so (recommended); (B) fail and rebuild, as today.
5. **External TestFlight submit:** (A) Claude runs it on your word, as part of the build (recommended); (B) always yours.

## NEW TICKET

- NEW TICKET: Store builds' fast-fail on a tested release candidate runs the app checks only: the pipeline tier is
  skipped when the newest rc's follows passed and only build numbers changed since, said (F2).
- NEW TICKET: A no-output watchdog for every store-build step (install, prebuild, Gradle, pods, xcodebuild, export,
  distribute) with an email on a stop; Gradle's hard cap from 60 to 20 min (S3).
- NEW TICKET: `build-apk.sh --play --upload-built` and `build-ios-testflight.sh --upload-built`: upload the file built
  by `--no-upload` (sha checked, HEAD = rc), with notes, mapping, version files and the TestFlight group (S4, F6).
- NEW TICKET: `release --phones-needed` (none / js / native, with reasons) and the native-input hash on the rc tag;
  Step 6 skipped on "none" (S5).
- NEW TICKET: `ci_status.py --strict` finds an ancestor's run by commit (the last commit that changed the area, then
  `head_sha`), so the answer does not depend on the run count; app-ci already has 1330 runs against a 1000-run reach
  (F3).
- NEW TICKET: The iPhone build's DerivedData goes inside its worktree (`-derivedDataPath`), and the 7 left-over
  `CanIFish-*` folders (about 6.9 GB) are removed with the owner's OK.
- NEW TICKET: The MapLibre AAR kept somewhere besides this Mac (GitHub Release asset per pin, sha256), the prerequisite
  for CI and the fix for a disk loss. Already a line in ship-workflow-design.md; one ticket for both.
- NEW TICKET: The phone build scripts record the start and end of each step in one file per build (the release-timeline
  ticket already asks this for the ledger; this is its phone half).

## Not verified

- No build was run. The times for pnpm install, prebuild, pod install, the Play upload and Apple's processing are **not
  measured**: no log records them. The iPhone times come from file birth and modification times, not from a timer.
- Whether the race in F1 can still happen under `--no-daemon` with a single-use daemon. I read Gradle's logs, not its
  source.
- The Gradle build cache's real saving, and whether the Hermes bundle and R8 tasks hit the cache across worktrees.
- Whether GitHub's macOS runner images carry the Xcode this Mac uses (iPhoneOS 27.2 SDK). Whether Xcode Cloud can work
  with a generated `ios/`. EAS free-tier limits. Times for builds on CI runners (all guesses).
- What held the lock from 13:58 to 15:15 on 11-24, beyond T1063's words. heavy.sh keeps no history of holders.
- Play Closed review times before 0.9.0, and Apple's 0.9.0 processing time: not recorded.
- Outside facts: GitHub's runner pricing page (fetched 2026-11-25); Apple's 25 Xcode Cloud hours (news page found by
  search 2026-11-25; I did not open the page itself).
