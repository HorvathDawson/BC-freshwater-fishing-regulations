# The checks after the data build ("follows"): a deep look

Night agent, 2026-11-25, read-only. Times are MST unless marked UTC. Nothing was run but small read-only scripts
(each one process, `nice -n 15`, seconds). Code is read at main (the planning worktree, `c0daabd8a`). The release
code on `origin/release/0.10.0` is the same in the files below (`git diff --stat` empty).

Helper files in `night/follows-deep-look/`:
- `stops.py`, `stages.py`, `cmds.py`: read the chats' own session logs for every release stage line, every stop
  block and every command, with timestamps. Outputs: `stops.txt`, `stages.txt`, `rel0100.txt`, `rel090-lane.txt`.
- `datatier-run1.txt`: the 0.10.0 data tier, chunk by chunk, cut from that chat's `release-3.log`.

## The short answer

1. **The owner's "25 minutes clean" is from before the data tier joined.** 0.8.5's clean follows (16:31 to 16:56 on
   11-21) ran before commit `d0f0d6ab1` (11-21 22:13) added the pipeline data tier. A clean follows today, measured on
   0.10.0's first run on a quiet Mac, is **about 48 minutes**. The data tier alone is 36 of them (2172 s).
2. **The follows already collect every failure in one pass.** They do not stop at the first failure
   (`pipeline/release.py:763-784`). Both releases stopped **once** in the follows tests: 4 failures listed together
   each time. The time went on three other things:
   - the whole 48-minute set runs again after a one-line fix;
   - the preflight before it can add up to 17 minutes (the fresh-copy test run);
   - two blind spots hid failures until the real run. The rehearsal gives up when the re-cut fails, and the data
     tier names no test.
3. **None of the 12 follows failures in 0.9.0 and 0.10.0 was a real data defect.** 9 were literals copied from an
   older release, 1 was a test assumption (the version's length), 1 was a stray untracked file in the main checkout,
   and none was flaky. Earlier releases show the same checks catching real defects (section 5), so the fix is to make
   them cheaper. They should not be cut.

---

## 1. What the follows run, in order

Code: `pipeline/release.py:2026-2036` (`stage_follows`) runs three steps, then the push gate. The test step's list is
`follow_tests_cmds` (`release.py:751-760`), run one after another by `candidate_failures` (`release.py:763-784`).
Times come from the 0.10.0 first run (`release-3.log`, quiet Mac: 13:52-14:40, heavy.sh "free 70%"). Vitest prints
Pacific time, so 12:59 in the log is 13:59 MST.

| # | Step | Protects against | Quiet time | Order | Repeat of PR CI, or needs the new data? |
|---|---|---|---|---|---|
| a | In-season resolve (`stage_inseason`, `release.py:1841-1854`) | a notice that no longer resolves on the new data | under 1 min (13:50:08 in the ledger) | alone | **New data** |
| b | Fixture re-cut, `sync.mjs` (`stage_recut`, `release.py:1862-1907`; steps in `app/tools/regs-recut/sync.mjs:48-55`) | goldens, page oracle, regs fixture and golden pages out of step with the release; a changed golden page stops for an accept | about 1.5 min (13:52:08 to about 13:54) | alone, and it stops everything after it on rc≠0 (`release.py:1868-1872`) | **New data**. It also runs two vitest files itself in update mode (`sync.mjs:52-53`) |
| c | Pipeline tests found by rule: 12 files (`release_follows.py:288-292`; list from `python -m pipeline.release_follows`) | answers and slices compared on the candidate, not on LATEST | 4.4 min (`275 passed … in 263.98s`, log line 691) | through heavy.sh, one by one | **New data**. CI runs them on the committed mini release |
| d | Whole app vitest suite, 846 files (`release_follows.py:348-351`) | the 39 files that read the release (found by rule), plus about 80 that read re-cut fixtures (`ci-speed-build-plan/recut-readers.txt`) | 3.7 min (`Duration 221.79s`, log 3046) | heavy.sh | **Mixed.** About 39-80 files need the candidate. The other ~770 are a **pure repeat** of app-ci's 4 vitest shards on the same code (`.github/workflows/app-ci.yml:115-116`). In CI, `liveRelease()` returns null without `data/release`, so the release files skip there (`app/conformance/src/fixtureRelease.ts:79-107`) |
| e | Feeds worker suite, 45 files (`release_follows.py:354-357`) | worker code | 6 s | heavy.sh | **Pure repeat** of `feeds-worker-ci.yml` |
| f | 25 `check:fast` gates, one by one (`release_follows.py:329-345`; list from `app/package.json` `check:fast`) | tickets, anchors, changelog, typecheck ×3, knip, `--check` emitters (gauge-policy, calendar, pack, app-reads, feed-formats, answers), inventories… | about 0.8 min for all 25 (13:03:00-13:03:47 Pacific) | one by one, no heavy.sh | **Mostly a repeat** of app-ci's `gates` job (`app-ci.yml:88-89`). Only the gates whose inputs the re-cut commit touches (anchors, the emitters' `--check`) see anything new. I did not verify which emitters read the generated data |
| g | Pipeline data tier: every `needs_*` test, not `slow`, in 93 chunks (`release_follows.py:84-97`; `scripts/pytest-chunked.sh:68-83`) | stale pins and invariant breaks in the live generated data (bundle, atlas, reach run, tiles, source, cache) | **36.2 min** (`93 chunks in 2172 s`) | one chunk after another; 56 chunks run alone (child processes, T792 B) | **New data, and not run anywhere else**: CI deselects every `needs_*` test (`pipeline-ci.yml` Tests step). This is the one step that is both irreplaceable and slow |
| h | Push gate (`release.py:1991-2023`) | the release's commits not on GitHub before the upload | seconds | alone | — |

Total clean, quiet: a + b + c + d + e + f + g ≈ 1 + 1.5 + 4.4 + 3.7 + 0.1 + 0.8 + 36.2 ≈ **48 min**. 0.10.0's run 1
measured 13:52:08 → 14:40:04, which is 48 min.

Before the follows, every run (including every rerun) passes preflight. Two parts of it are slow:
- **fast-fail**, keyed by the tree's content: 76-90 s when nothing changed.
- **the fresh-copy run** (`release.py:1568-1594`, `scripts/fresh-copy-tests.sh`): the whole no-data tier in a clone,
  612 s on 0.10.0 (rehearsal log). It runs again after any commit outside the follows' own paths, and a pin fix is
  such a commit. It is a **pure repeat** of pipeline-ci's `Tests` step on the same commit.

### The biggest chunks of the data tier (0.10.0 run 1)

The top 8 chunks are 1680 s of the 2172 s.

| Chunk | Time | Peak memory | What |
|---|---|---|---|
| 1 | 553 s | 6.7 GB | 40 files `test_answers_*` (the failed one: `test_answers_26.py`) |
| 84 | 256 s | 0.8 GB | 40 files |
| 65 | 197 s | 1.3 GB | 40 files |
| 75 | 196 s | **29.5 GB** | 40 files from `test_review_audit.py` |
| 53 | 133 s | 6.3 GB | 40 files |
| 14 | 124 s | 12.4 GB | `test_curation_review_api.py` alone |
| 45 | 120 s | 6.3 GB | 40 files |
| 56 | 101 s | 7.5 GB | 40 files |

---

## 2. Every stop in 0.9.0 and 0.10.0, with evidence

Sources:
- the release lanes' session logs (0.9.0: the release lane under the 0.9.0 chat; 0.10.0: the 0.10.0 chat);
- the 0.10.0 run logs `rehearse-1.log` and `release-1..4.log` in that chat's scratchpad;
- the ledger (`data/generated/release/ledger.json`, read only);
- the mtimes of `checks/<rid>/tests/*`;
- `git log`.

### 0.9.0 (candidate r-0aec88ed3edb)

| When | Stop | Cause | Cost | Resolved |
|---|---|---|---|---|
| 23:03-23:47 (rehearsal with `--build`) | re-cut declaration: Kootenay upper part 56 → 53 sections | **stale literal** in the re-cut's declarations (an intended atlas change) | found in the rehearsal, before the real run | `102ebc654` 23:48 (T1012) |
| 00:03 | binding diff | planned review | about 1.5 min to read and accept | `--accept-diff` |
| 00:05 | 10 golden pages changed (T991 highlight boxes) | planned review | about 1 min | `--accept-fixtures f6b2a347e1fb` |
| 00:07 → 00:47 (run 1, 40 min) | **4 failures, listed together**: `speciesSheet.parity.test.ts` ×2 (a `p.21 ↗` string without the new `[hl]`), `SheetHost.test.tsx` (`onBook(10)` without the box), gate `knip` | 3 × **stale literal** (T991 changed the page links); knip = **environment**: an untracked leftover `app/tools/testbed/out/runs/t978-m0002-scripts/colours.mjs` in the main checkout | fix 3 min (`a98dd68f9` 00:48) | rerun |
| 00:51 → 02:18:34 (run 2) | passed | — | preflight **17 min** (00:51 → 01:08:11, `checks/` mtime) + tests **70 min** under load: the 12 pipeline files took 16 min (4.4 quiet), because the 0.9.1 chat's lanes started at 01:10 | — |

What the one stop cost: about 90 minutes (the 3-minute fix, the 17-minute preflight and the 70-minute rerun). On a
quiet Mac the rerun would have been about 50 minutes, so the load added about 25-40 minutes. The follows took 2.2 h
in all, against about 48 minutes clean.

### 0.10.0 (candidate r-71d09ad82e81)

| When | Stop | Cause | Cost | Resolved |
|---|---|---|---|---|
| 07:20 (CI on the cut) and 12:20-13:07 (rehearsal, fresh-copy) | `test_release_command.py` sliced the version to 10 characters | **stale assumption** (not data): "0.10.0" is longer than "0.9.0" | found by CI and the rehearsal; fix PR #212, `2cc614bb2` 13:03 | by length |
| rehearsal, 13:07 | the re-cut fails: `harness.parity.test.ts:75` Vedder display frame 109 (now 112) | **stale literal**. It runs inside the re-cut (`sync.mjs:52-53`), so **the rehearsal returned early and never ran the follows tests** (`release.py:1974-1975`, "fixtures: WOULD STOP: the re-cut fails", rehearse-1.log 2479) | about 25 min to fix, review and push (`d7370c772` 13:30, PR #218) | now read from taps.json: a property, not a pin |
| 13:48 | binding diff | planned review | under 1 min | accepted |
| 13:50 | 12 golden pages | planned review | 2 min | `--accept-fixtures 6ecb5d4f2993` |
| 13:52 → 14:40 (run 1, 48 min) | **4 failures, listed together**: `reads.release.test.ts` statics (glossary 67 → 68), `sourceLine.fixture.test.ts` `ROW_PAGES` (Glenn Creek), `WaterScreen.unnamed.test.tsx` (page 26 → 16), and "pipeline data tier: rc=1" with no test named (it was `test_answers_26.py:366`, the Williston "applies" sentence) | 4 × **stale literal** (intended T1051 / T1053 changes) | fix 1 min (`5c5a0b60a` 14:41). The chat had to dig the data-tier test out of the log | rerun |
| 14:43:53 → killed 15:28 (run 2) | no failure: stopped by hand for the repo move and the release-candidate (rc) build (T1062) | — | preflight **12 min** (fresh copy 14:45 → 14:55:32), then tests from 14:56. At 15:25 it was on data chunk 65/93; it would have ended about 15:41 | — |

The follows proper ran from 13:52 to 15:28, which is 1.6 h. T1135's "six stops × 45 min ≈ 4 h" counts the rehearsal
with its 34-minute build (12:20-13:07), the CI-red fix and the two review accepts. The six pins were found in **three
batches**, not six: CI and the fresh copy found 1, the rehearsal's re-cut found 1, and follows run 1 found 4.

### Counted by cause (0.9.0 + 0.10.0, follows-related failures only, review stops left out)

| Cause | Count | Which |
|---|---|---|
| A literal copied from an older release (or a declared count) | **9** | Kootenay 56→53; speciesSheet ×2; SheetHost; Vedder frame 109; glossary 67; ROW_PAGES; unnamed p.26; Williston sentence |
| A stale test assumption, not data | 1 | version `ln[:10]` |
| Environment (machine state) | 1 | knip on an untracked file in the main checkout |
| A real defect in the data | **0** | — |
| Flaky / load-sensitive (failed) | **0** | load made 0.9.0's rerun about 25-40 min slower, but nothing failed from it |

Releases before them, for balance:
- 0.8.4 (r-fec3fab4c5aa, 11-20): 3 failures, skipped with `--no-follow-tests` to ship. Two were **real regressions**:
  T286 page-read budgets, Norrish 31/30 and Cultus 34/30, from T973's extra reads (T980). One was sample drift.
- 0.8.5 (r-741815c6090d, 11-21): 7 water-map tests pinned to the mouth mark. That was test fragility, fixed in
  `2ccf1ea45` (T985 #2).
- r-46e4355a7277 (11-16): 12 app tests pinned to the old part shapes, all intended changes (`39918037e`).

---

## 3. The structural problems, checked one by one

| Claim | True today? | Evidence |
|---|---|---|
| Fail-fast: one failure stops the run | **No, inside the tests.** Every check runs and every failure is listed (`release.py:772-784`). **Yes at the re-cut**: a re-cut failure stops before any test (`release.py:1868-1872`), and in the rehearsal it skips them all (`release.py:1974-1975`). That is how 0.10.0's rehearsal missed 4 failures | logs above |
| After a fix, everything reruns from the start | **Yes.** The pass is recorded only when all checks pass, keyed by release id only (`release.py:1916-1917, 1925-1926`). The reports are deleted first (`release.py:768`). There is no resume per check or per file | ledger `follows.tests` has only `release`, `at` and counts |
| Literals pinned to a release are spread over many files | **Yes.** 80 test files read the release or re-cut fixtures (`recut-readers.txt`). A rough grep of those 80 found 83 `p.N` page references, 43 asserts on strings over 40 characters and 32 asserts on numbers of 2+ digits. This is a lower bound: one-line patterns only, not reviewed by hand. The data tier's 108 `needs_bundle` files hold more (T931 found about 55 stale pins there) | rough grep, labelled |
| Tests read the live candidate | **Yes, by design.** `RELEASE_DIR` = the candidate (`release_follows.py:308-311`). The data tier reads `data/generated`, the build's live working outputs, with no override (`pipeline/common/curated.py:625`: `CURATED_ROOT` exists at :448, nothing for generated) | — |
| No "collect all failures" mode | **Partly false** (see the first row). What is missing: (1) the data tier names no test, only "rc=1" (`release.py:760` passes no report; `pytest-chunked.sh:73` writes no junit); (2) the re-cut's own tests hide everything after them | `release-3.log` stop block |
| No resume from the failed step | **True** (see the second row). Stages resume (inseason and re-cut are skipped when done); the test step does not | `release.py:1845, 1866, 1916` |
| Steps that could run at the same time | **True.** c, d, e and f do not depend on g, and g is 75% of the time. The chunks run one by one (`pytest-chunked.sh:68`). On a quiet Mac heavy.sh reported 70% free with a 48 GB footprint limit, and only one chunk passed 13 GB | log |
| Checks that repeat PR CI | **True, but small**, except the fresh copy. Repeats: fresh copy (10 min on each rerun that follows a commit), about 770 non-release app files (about 3 min), the worker suite (6 s), most gates (under 1 min). The data tier is **not** a repeat | section 1 |

---

## 4. The redesign

### (a) One pass that reports everything

1. **The re-cut never hides the tests.**
   - `sync.mjs:52-55`: run the two vitest steps in update mode so they write the fixtures. Their assertions then run
     as ordinary checks in the follows list, so the re-cut fails only on a real re-cut error (a python step's rc).
   - `release.py:1974-1975` (rehearsal): on a re-cut rc, put `"re-cut: rc=N"` on the failure list and still run
     `candidate_failures`, so the rehearsal lists every would-stop.
   - `release.py:1868-1872` (real run): the same, unless the fixtures could not be written at all.
2. **The data tier names its failures.**
   - `scripts/pytest-chunked.sh:73, 78`: a `--junit-dir DIR` option adds `--junitxml=DIR/chunk-$n.xml`.
   - `release_follows.py:92-97`: `data_tier_cmd` passes `--junit-dir <out>/data-tier`.
   - `release.py:760, 776-783`: the data-tier row gets a report *directory*, and `RF.report_failures` reads every xml
     in it. Result: `pipeline data tier: pipeline/tests/test_answers_26.py::test_every_rule_carries…`, not `rc=1`.
3. **Environment failures are named as such.** Run the gates in a clean `git worktree` at HEAD, or first refuse
   untracked files that knip or anchors would read (`git status --porcelain --untracked-files=all app/`). Either way
   0.9.0's knip stop becomes a plain "untracked file X in the checkout", seen before 40 minutes of tests.

### (b) Resume: a check that passed on this exact data and code is not run again

New ledger record `follows.passed: {<check id>: <key>}`, written after **each** check, not at the end:
- check ids: `pipeline:<file>`, `app:<file>` (from the vitest JSON per file), `gate:<name>`,
  `data:<chunk files hash>`;
- key = sha256(the candidate's `fingerprint`, already in the ledger) + the inputs' hash;
- inputs' hash = the digest of every tracked non-test file in that suite's roots, plus the check's own test file(s),
  plus uncommitted changes. Roots: `pipeline/` + `data/curated/` + `pytest.ini` + `conftest.py` for pipeline and data
  checks; `app/` minus `*.test.*` + the re-cut paths for app checks.

`candidate_failures` (`release.py:763`) skips a check whose key matches. On a rerun after a pin fix that touches only
4 test files, only those 4 files run: seconds for the app files, and one data file. Chunk 1 took 553 s for 40 files;
`test_answers_26.py` alone is a guess of 1-3 min.

Safety:
- a change to any non-test file in a suite's roots reruns that whole suite;
- `--follows-full` forces everything;
- the promote still requires every check passed on its **current** key, which equals a full pass on this code and
  data.

Code: `release.py:1909-1928` (record per check), `:763-784` (skip by key), and `:768`, which keeps the reports of
passed checks.

### (c) The pins in one file per suite, re-cut by one command

Take `ci-speed-build-plan.md` §5 as written:
- `app/fixtures/golden/pins.json` and `pipeline/tests/fixtures/release-pins.json`;
- a `pin(name, actual)` helper in each suite, with `PIN_RECORD` record mode;
- a new FOLLOWS row in `release_follows.py:62-81`, re-cut with `RECUT`, recorded right after `sync.mjs`;
- one accept token covering the golden pages and the pins.

Two additions:
- **Budgets are never pins.** `openCost.release.test.ts` (T286), `release-budget.test.ts` and `release-perf.test.ts`
  keep typed limits and are never recorded. T980 shows why: a budget caught a real +5 reads regression.
- **Split the record into `answers: true` pins** (sentences and pages an angler reads, which stop for a look) and
  `answers: false` pins (counts and ids, committed with the release id like a renumber, `release.py:1899`).

Which of the 12 failures should be **properties, not pins**:

| Failure | Make it |
|---|---|
| Vedder frame 109 | done: read from taps.json (`d7370c772`) |
| version `ln[:10]` | done: by length |
| glossary count 67 → 68 | a property: every glossary term has its definition and appears on a page. The count goes in `pins.json` (`answers: false`) |
| `WaterScreen.unnamed` p.26 → p.16 | a property: the cited page equals the store's own page for the tapped section (read from the store). The sample moved (sample drift, like T980 #2) |
| speciesSheet `p.21 ↗` ×2, SheetHost `onBook(10)` | a property: the sheet shows exactly the frozen golden page's links and boxes (read from `ui-native/src/regs/fixtures`, re-cut already) |
| `ROW_PAGES` Glenn Creek | a pin, `answers: true` |
| Williston "applies" sentence | a pin, `answers: true` (wording) |
| Kootenay 56 → 53 (re-cut declaration) | keep it as a declaration (it is the guard), but listed with the others, not as a re-cut stop |
| knip untracked file | not a test problem: (a)3 |

Guard: extend `app/tools/vintage-pins.test.ts`. Today it sees only integers above 366. It should also flag a
`Synopsis p.N` or a 40+ character sentence in a release-reading file that does not go through `pin()` and has no
"why fixed" comment. The false-positive rate was not measured.

### (d) Release-backed tests before merge (T1135)

A side release exists already: `python -m pipeline build --side DIR` writes every stage under DIR and touches nothing
live (`pipeline/build.py:10, 55-58`). Measured stage costs: reach 12.8 min, deliver 15.1 min, tiles skipped when the
tile code is unchanged (`build.py:113-120`: deliver depends on all of `pipeline/`). So a side release is about
15-28 min.

The lane command (NEW): `scripts/side-follows.sh` (through heavy.sh):
1. build `--side $T` from the lane's worktree, with the main checkout's data read-only;
2. `RELEASE_DIR=$T/deliver/release/<rid> REGS_STORE_REQUIRED=1` and `PIN_RECORD=$T/pins`: run the 12 pipeline files
   and the 39 + 80 app files;
3. print the pins diff and the golden-page diff;
4. **optional, step 2 of the work:** the data tier on the side build needs a generated-root override (a
   `GENERATED_ROOT` like `CURATED_ROOT`, `curated.py:448-490`). That is the real new work (M). Without it, a lane sees
   the app and pipeline release-backed pins but not the data-tier pins like Williston.

`scripts/before_pr.sh`: when the diff touches `pipeline/regs`, `pipeline/deliver`, `pipeline/atlas/reach` or
`data/curated` and no side-follows record exists for HEAD, it says so (T1135 item 2). The PR then carries its pins
diff, and the reviewer accepts it there. At the release, the re-cut records the same values, so the release shows no
diff.

### (e) Parallel steps and the expected clean time

New order inside `stage_follow_tests`:
1. a + b, as today (about 2.5 min);
2. **lane A**: the data tier, in 2 parallel chunk workers (3 if the Mac is quiet). Each worker takes the next chunk
   only while the expected footprint fits the 48 GB limit, so chunk 75's 29.5 GB runs beside small ones only. Split
   chunk 1 (553 s) to 10 files a chunk;
3. **lane B** at the same time: the 12 pipeline files → app files → worker → gates (about 9 min);
4. the perf and budget tests last, alone (load-sensitive by design), with one retry that prints both numbers.

Expected clean, quiet, 2 workers: about 2.5 + max(2172/2 s ≈ 18 min, 9 min) ≈ **21 min**. With 3 workers, about 15
min. This is a guess from measured chunk times: perfect packing is not reached, and memory may force 2.

Keep pytest-chunked's per-process rule: these are separate processes, not xdist forks, so T792 B does not apply.

### (f) What can leave the follows because PR CI already proved it on the commit

- **Fresh-copy run (10-17 min per rerun):** drop it from preflight.
  - Instead, right after the re-cut commit, push the release's own commits to `release/<x.y.z>`. That starts CI on
    exactly the commit that will ship, while the follows run.
  - Before tagging the rc (stage 7), require `scripts/ci_status.py --strict --sha <HEAD>`. It finds runs by commit
    (`ci_status.py:5-6, 96`). It accepts only a finished green run at that sha, or at an ancestor when nothing outside
    the allowed paths changed since (`strict_judge`, `ci_status.py:154-172`).
  - pipeline-ci takes about 22 min on the branch (release-timeline.md), so it finishes about when the parallel follows
    do.
- **The app suite's ~770 non-release files and the worker suite:** proved by app-ci and feeds-worker-ci on the same
  pushed commit, under the same `--strict` check. Run only the 39 rule-found files plus the re-cut readers (a
  `release_follows.app_fixture_readers()` rule, by grep of the re-cut paths). This saves about 2-3 min, so it is
  optional.
- **Gates:** keep them (50 s) but in a clean tree. Too cheap to be worth dropping.
- **Never drop:** in-season resolve, re-cut, the 12 pipeline files, the release-backed app files, the data tier.

### (g) Flaky and load-sensitive tests

None failed in the follows of 0.9.0 or 0.10.0. The named risks:

| Test | Risk | Do |
|---|---|---|
| `app/packages/ui/src/chart.render.test.tsx` | fixed 30 ms wait (T1070) | condition wait (T1070 item 1) |
| `app/packages/ui-native/src/WaterScreen.sources.test.tsx` | 40 s timeout under load (T1070 addendum) | find the slow await; then `testTimeout` per file |
| vitest "Timeout calling onTaskUpdate" | worker count under load (`app/vitest.config.ts:108-116`) | in the follows, set `maxWorkers` from heavy.sh's free memory |
| `app/tools/release-perf.test.ts:152-157` (p95 budgets) | timing under load | run last, alone, one retry (e) |
| `test_answers_28_card_solver.py:153` (< 2 s), `test_export_codec.py:472` (< 5 s), `test_gradle_watch.py:49` (< 30 s) | time limits (ci-speed-build-plan §1) | serial group if they flake |
| `test_review_dfo` segfault | load flake (T931) | watch; it runs in its own chunk |
| `test_review_screen.py::test_the_render_lock_is_pinned_by_mutation` (600 s child) | slow under load (T1041) | keep it alone in its chunk |
| `palette.render.test.tsx` 5 s timeout | named in T1041 | not checked tonight |

---

## 5. What must NOT be cut: what each check has caught before

| Check | Real catch | Evidence |
|---|---|---|
| Data tier | **T931**: the first full live run in days found an invariant break (T753 lake loop) and two real data refusals, T942 (Kitimat steelhead enforced, not told) and T944 (one section carrying both Bulkley and Morice). That is why it joined the release | T931 ticket; `d0f0d6ab1` (11-21) "(T931: ~55 stale pins accumulated where nothing ran the data tier)" at `release_follows.py:75-76` |
| Release-backed app tests | **T1140** (`ea82b60d0`): a tidal part's head threw on tap; "the release test fails 210 times on the old code" (province-wide on the release). **T980**: the T286 page-read budgets caught +5 SQLite reads from T973 | commit, T980 |
| Re-cut guards (`taps.py` declarations, `PART_GROWN`, the `trib_closed` pool) | T1012 (a part's count moved with the atlas, and the release declared it); T980 #2 (a sample pool with none stops the re-cut) | commits `102ebc654`, `4f2b87a43` |
| Golden pages stop | every answer change gets a human look (0.9.0 10 pages, 0.10.0 12 pages) | stage logs |
| In-season resolve | a notice that no longer resolves stops before the promote (T537) | `release.py:1841-1854` |
| 12 pipeline release-backed files | **no catch found in my search** of commit messages. Keep them (4 min) | — |
| Gates | caught nothing new in the follows (0.9.0's knip stop was environment). They are PR CI's job; keep them in the follows only because they cost under a minute | — |
| Fresh copy | it found the version slice on 0.10.0, but CI on the same commit found it first (07:20). **Covered by `--strict` CI** | rehearse-1.log 1667 |

---

## 6. Expected numbers

| Case | Today (measured / derived) | After stages 1-5 (estimate) |
|---|---|---|
| Clean follows, quiet Mac | **48 min** (0.10.0 run 1) | **about 21 min** (2 workers); 15 with 3 (guess) |
| Rerun preflight after a test-only fix | 12-17 min (fresh copy) | about 1.5 min (fast-fail keyed); CI checked at the rc tag instead |
| One real failure (fix 10 min) | 48 + 10 + 15 + 48 ≈ **2 h**; under load 2.2 h (0.9.0) | 21 + 10 + 1.5 + 2-5 (the failed files only) ≈ **35-40 min** |
| A failure hidden behind a re-cut failure (0.10.0) | + one more full round (about 1 h) | 0: listed in the same pass |
| A PR that changes answers, with T1135 | its pins move at release time, a stop each time | the pins diff is in the PR, and the release shows no diff |

### Staged plan

| Stage | What | Files | Size |
|---|---|---|---|
| 1 | One pass truly lists everything: the data tier names its tests (junit per chunk); the re-cut's assertions never hide the tests; the rehearsal runs the tests after a re-cut failure; gates in a clean tree | `pytest-chunked.sh:73,78`; `release_follows.py:92-97`; `release.py:760,776-783,1868-1872,1974-1975`; `sync.mjs:52-55` | S |
| 2 | Resume per check, keyed by candidate fingerprint + input hash | `release.py:763-784,1909-1928`; ledger | M |
| 3 | Parallel: lane A data tier with 2-3 memory-aware workers; lane B the rest; perf last, alone | `pytest-chunked.sh` (`--workers N`, footprint-aware); `release.py:751-784` | M |
| 4 | The pins files + record mode + the 6 property conversions + the vintage guard | `release_follows.py:62-81`; new `pins.ts` / `pins.py`; the test files above | M |
| 5 | Fresh copy out of preflight; push the release's commits early; `ci_status --strict` before the rc tag | `release.py:1568-1605, stage 7`; `ci_status.py` | S |
| 6 | T1135 side release before merge (app + pipeline release-backed first; the data tier needs a generated-root override) | new `scripts/side-follows.sh`; `before_pr.sh`; `curated.py` | M (without the data tier) to L (with) |

### Replacement text for T1135

> **T1135 — A lane that changes answers sees its release-backed pins move in its own PR, and the release follows stop
> at most once**
>
> Measured on 0.10.0 (night/follows-deep-look.md): the follows ran twice, not six times. The six pins came in three
> batches:
> - CI and the fresh copy found 1 (the version slice);
> - the rehearsal's re-cut found 1 (the Vedder frame). Because the re-cut failed, the rehearsal never ran the tests
>   (`release.py:1974-1975`);
> - follows run 1 found 4, and named the data-tier one only as "rc=1".
>
> Each rerun cost about 60 min: 12 min of preflight (fresh copy) and 48 min of follows, of which the data tier is 36.
> None of the 12 failures in 0.9.0 and 0.10.0 was a data defect.
>
> Work:
> 1. **(lane, before merge)** `scripts/side-follows.sh`: `pipeline build --side` from the branch (15-28 min, through
>    heavy.sh). Then run the 12 pipeline release-backed files and the release-backed and re-cut-reading app files
>    against it, with `PIN_RECORD`. Print every pin and golden page that would move. `before_pr.sh` says when a diff
>    touches answers and this was not run on HEAD. The data tier on a side build comes later: it needs a
>    generated-root override.
> 2. **(pins)** one pins file per suite, re-cut and recorded in the follows' re-cut step. Pins are `answers: true`
>    (stop for an accept) or `false` (committed with the release id). Budgets are never pins. Convert the 0.9.0 and
>    0.10.0 literals to properties where the table in follows-deep-look.md §4c says so.
> 3. **(one pass)** the rehearsal and the real run list the re-cut's failures with every test failure, and the data
>    tier names each failed test.
>
> Acceptance: replay the 0.10.0 changes on a branch. The side run prints all six with file and new value; the
> rehearsal lists them in one block; the release passes its follows on the first run after one accept.
> Size: M (without the side data tier). Model: Opus. Owner: no.

---

## Picks for the owner

1. **The slow data tier (36 of 48 min):** (A) run it in 2-3 parallel workers beside the other checks, keep every
   test (recommended); (B) keep it one after another and only add resume; (C) run only its `needs_bundle` part on
   each release and the rest weekly.
2. **The fresh-copy run before each rerun (10-17 min):** (A) drop it from preflight and require green CI on the
   shipped commit before the rc tag (recommended); (B) keep it, but only on the first run of a release; (C) keep as
   today.
3. **Release literals in tests:** (A) one pins file per suite, re-cut with the fixtures, and the six known ones made
   into properties (recommended); (B) properties only, no pins file; (C) as today, fixed by hand.
4. **T1135's side release before merge:** (A) app and pipeline release-backed tests first, the data tier later
   (recommended); (B) all of it, including the data tier, in one ticket; (C) not before merge: the faster follows are
   enough.
5. **Repeats of PR CI inside the follows (app non-release files, worker, gates, about 4 min):** (A) keep them: cheap
   insurance (recommended); (B) drop them, since `--strict` CI covers them.

## NEW TICKET lines

- NEW TICKET: The follows name every failure in one pass. The data tier writes junit per chunk and the stop names each
  test; the re-cut's own vitest assertions run as ordinary follows checks; the rehearsal runs every test after a
  re-cut failure; gates run in a clean tree, so an untracked file is named as such. (Stage 1, S)
- NEW TICKET: The follows resume. Each check (file, gate, chunk) is recorded as passed on the candidate's fingerprint
  plus its inputs' hash; a rerun runs only the failed and the changed; `--follows-full` forces all. (Stage 2, M)
- NEW TICKET: The follows run in two lanes. The data tier gets 2-3 memory-aware chunk workers (footprint limit 48 GB;
  chunk 1 split), beside the pipeline release-backed, app, worker and gate checks; perf and budget tests last, alone,
  one retry. Target: clean follows about 21 min on a quiet Mac. (Stage 3, M)
- NEW TICKET: The fresh-copy run leaves the release preflight. The release pushes its own commits right after the
  re-cut, and `ci_status.py --strict --sha HEAD` must pass before the rc tag. (Stage 5, S)
- NEW TICKET: A generated-data root override (`GENERATED_ROOT`, like `CURATED_ROOT`), so the data tier can run against
  a side build (T1135 step 2). (M)
- Line items for existing tickets, not new: T1070 (the chart and WaterScreen.sources timing tests), T1135 (replace its
  text with the block above), T1063 (a quiet Mac during the follows: 0.9.0's rerun lost about 25-40 min to another
  chat's lanes).

## Not verified

- The 0.9.0 rehearsal log was gone (its scratchpad folder was cleaned), so its Kootenay find is from the commit and
  the lane's commands only.
- The per-step times for 0.9.0 are inferred from report mtimes (`pipeline.xml` 01:24:05, `app.json` 01:28:17) and
  the stage line "follows ok (4260s)". The data-tier time inside it was not measured.
- The parallel savings (21 / 15 min) are estimates from chunk times, not trials. Memory with 2-3 workers was not
  measured.
- Which `check:fast` emitters (`pack`, `app-reads`, `gauge-policy`, `calendar`, `answers`) read `data/generated`, and
  so need the candidate: not checked.
- Whether a side build can skip tiles for a typical answers PR: read from the stage graph, not tried.
- The rough pin counts (83 / 43 / 32) are single-line greps over the 80 files, not a hand review.
- Run 2 of 0.10.0 was stopped by hand, so its end time (about 15:41) is an estimate from its chunk progress.
- No test, build or release command was run.
