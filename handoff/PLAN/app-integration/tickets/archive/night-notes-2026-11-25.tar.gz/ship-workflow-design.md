# Shipping from GitHub Actions: a design ready to build (T1133, with T1062 and T1144)

Night of 2026-11-25. Read-only: nothing was changed, run or uploaded. Code claims cite file:line in the repo at main
(the planning worktree). Times come from the release ledger and from `gh run list`, and each one says how it was
measured. A guess is marked **guess**. Outside facts carry their URL. All pages were read 2026-11-25.

## The short answer to the owner's question

Yes, it is a good idea, with two conditions:

1. **One workflow per environment, not a separate worker deploy.** You were right that a separate worker deploy is the
   weaker shape. A release is one set of things (data, worker, site) at one commit. One ship workflow per environment
   reads the tag, works out which of the three changed, ships them in a safe order and checks each one. That replaces
   five commands typed in your terminal today.
2. **The Mac keeps the data build and the big upload. The workflow only moves pointers and deploys code.** The Mac
   already uploads every data file under a name made from its content, before anything points at it. The workflow
   checks those files and then flips the one pointer. Nothing large is rebuilt in CI.

What it gives you: production becomes one approval click (it works from your phone) instead of about four commands
at the Mac. The 15-minute site build leaves the Mac's heavy-job lane. And a fresh clone no longer needs Cloudflare
logins to ship.

What it costs: deploy keys stored in GitHub on a public repo. There is also one real gap to close first. **Your own
GitHub login, which Claude sessions use today, can approve a production run through GitHub's API.** Section 3.4 says
how to close it.

---

## 1. Inventory: every step of a release today

### 1a. Staging (Claude may run all of it)

| # | Step | Command (file) | Runs on | Credential | Time | What it writes |
|---|---|---|---|---|---|---|
| S0 | Cut the branch | `python -m pipeline release --cut` | Mac | `gh` login (push) | seconds | `release/<x.y.z>` branch, one version commit |
| S1 | What's-new bullets | edit + commit `changelog.ts` | Mac | `gh` (push) | minutes, by hand | release branch |
| S2 | Rehearse | `release --staging --dry-run --build --rehearse-follows` | Mac (heavy lane) | `gh` (read), `r2:` (read) | build about 35 min (owner's figure) + tests | local only: `data/release/<r-id>/`, `CANDIDATE` |
| S3a | Preflight → build → checks → follows → promote | `release --staging --push` stages 1–6 (`pipeline/release.py`) | Mac | `gh` (push of its own commits) | build skipped after S2; the follows tests take minutes | git: in-season matches and re-cut fixtures pushed; local `LATEST` moves |
| S3b | Staging upload | `deploy/staging/upload.sh <r-id>` (stage 7) | Mac | rclone `r2:` key (R2 write), `gh` (starts a workflow), staging run token | **1m47s–5m22s** (ledger `promoted_at`→`uploaded_at` for r-fc137c4040fa, r-f749475d0962, r-adc4e248a163, r-fec3fab4c5aa) | R2 `bc-fishing-regulations-staging`: `private/runtiming/base/<handles>.json.gz` (upload.sh:77); `release/tiles/<tiles-id>/**` (:96-99); `map-assets/v1/**` (:101-104, **a fixed key, overwritten**); `release/basemap/…` (:105); `release/<r-id>/*.gz` (:106); the synopsis PDF (:108); feed seeds `feeds/live`, `feeds/hydat`, `feeds/dfo` (:109-124); `*.wasm` at the bucket root (:125-127); worker inputs via `sync-inputs.sh` (:141); the manifest stamped (:144); **the pointer `release/manifest.json` (:145)**; then **the clear deletes everything this release does not name** (:151-153); `test/` reset (:157) |
| S3c | Run timing | `feeds-runtiming.yml`, started by upload.sh (:87) and waited for (:133) | GitHub runner | repo secrets `R2_ACCESS_KEY_ID`/`R2_SECRET_ACCESS_KEY`, `CLOUDFLARE_ACCOUNT_ID` (feeds-runtiming.yml:96-102) | **2m13s–7m43s** (the last 3 successful runs in `gh run list`) | R2 staging `runtiming/**` |
| S3d | Smoke | `app/tools/smoke-staging.mjs` (upload.sh:160) | Mac | none | **52–58 s** (ledger `uploaded_at`→`smoked_at`, three releases) | local screenshots |
| S3e | Tags | `tag_release` (release.py:2067, called at :2216, **after** the upload and smoke) | Mac | `gh` (push) | seconds | git tags `data/<r-id>` and `v<x.y.z>-rc.N` |
| S4a | Staging site | `deploy/staging/site-all.sh` → web export (:50), SEO pages (:56), `site.sh` → `wrangler deploy` (site.sh:91), smoke (:94) | Mac (heavy lane) | `wrangler login` (OAuth on the Mac) | "the 15 minutes" (site-all.sh:7, a comment, not measured) | Cloudflare Worker `bc-fishing-regulations-staging` with static assets (60,233 files, 1.1 GB on disk: counted in `app/dist/staging-site`) at staging.canifishthis.ca |
| S4b | Staging feeds worker (when changed) | `deploy/staging/feeds.sh`: tests (:13), secret check (:16), backup-bucket lifecycle check (:34), pieces gate (:49), deploy (:52), 3 job runs (:58-63) | Mac | `wrangler login`, rclone `r2:` (read), `.run-token` | not measured (**guess**: 2–4 min) | Worker `bc-fishing-feeds-staging`; the jobs write `feeds/**` in R2 |
| S4c | Staging data worker (rare) | `wrangler deploy -c deploy/staging/data.wrangler.toml` | Mac | `wrangler login` | under 1 min (**guess**) | Worker `bc-fishing-r2-staging` (data-staging.canifishthis.ca) |
| S5 | Sideload APK | `deploy/staging/build-apk.sh` | Mac | debug keystore, `wrangler`, run token | not measured | R2 staging `app/android/**`, an email |

### 1b. Production (the owner runs every write)

| # | Step | Command | Runs on | Credential | Time | What it writes |
|---|---|---|---|---|---|---|
| P0 | Rehearse | `release --prod <r-id> --dry-run`, `prod/upload.sh --bucket …-staging --dry-run`, `prod/feeds.sh --dry-run`, `prod/site.sh --dry-run` | Mac | read only | minutes | nothing |
| P1 | Final tag | `release --final <x.y.z>` (Claude, on your word) | Mac | `gh` (push) | seconds | git tag `v<x.y.z>` on the newest rc |
| P2 | Android production build | `CONFIRM_PROD=canifishthis.ca deploy/prod/build-apk.sh` | Mac (heavy lane) | upload keystore, Play service account (`~/.canifishthis/`), `wrangler`, prod run token | not measured | git: versionCode commit (build-apk.sh:30); Play **Internal**; R2 prod `app/android/play/<code>.json`, `play.json`; an email |
| P3 | Promote to Closed | `play-upload.py --promote <code> --track alpha` | Mac | Play service account | seconds | Play **Closed (alpha)** |
| P4 | iPhone production build | `CONFIRM_PROD=canifishthis.ca deploy/staging/build-ios-testflight.sh --production` | Mac (Xcode) | App Store Connect API key (`.p8`, Admin role) | not measured | TestFlight build, What to Test, External group, Beta review |
| P5 | Production data | `CONFIRM_PROD=<r-id> release --prod <r-id>`; types the id again (release.py:2918-2972) → `deploy/prod/upload.sh` | Mac, interactive terminal; refuses agents (release.py:2746-2748) | rclone `r2:` key; reads the Mac's ledger and release folder | **≤ 2m05s** (r-fec3fab4c5aa: `staged_at` 19:00:07 → `prod_at` 19:02:12, typing included; an upper bound) | R2 `bc-fishing-regulations`: staging's manifest bytes compared first (prod/upload.sh:44-46); run timing copied from staging (:74-75); tiles, assets, basemap, data, synopsis **re-uploaded from the Mac's disk** (:79-88); seeds, clim, HYDAT, DFO (:92-104); inputs (:105); wasm (:106-108); old pointer → `release/manifest.previous.json` (:113-124); **pointer (:126)**; local `data/release/PUBLISHED` (:128); **prune** of releases neither pointer names (:138) |
| P6 | Smoke | `smoke-staging.mjs --production` | Mac | none | about 1 min (**guess**, as staging) | nothing |
| P7 | Production site | Claude builds `web-prod` + `seo-prod` (release-by-hand.md:366-371); you run `CONFIRM_PROD=canifishthis.ca deploy/prod/site.sh` | Mac | `wrangler login` | build about 15 min (**guess**, as staging) + deploy | Worker `bc-fishing-regulations` at canifishthis.ca; optional `canifishthis-host-redirect` (prod/site.sh:49) |
| P8 | Production feeds worker (when changed) | `CONFIRM_PROD=bc-fishing-feeds deploy/prod/feeds.sh` | Mac | `wrangler login`, `.run-token.prod`, rclone (read) | not measured | Worker `bc-fishing-feeds` (feeds.canifishthis.ca); its jobs write prod `feeds/**` |
| P9 | Production data worker (rare) | `wrangler deploy -c deploy/prod/data.wrangler.toml` | Mac | `wrangler login` | under 1 min (**guess**) | Worker `bc-fishing-r2` (data.canifishthis.ca) |
| P10 | Play Production, App Store | Play Console, App Store Connect | browser | your accounts | minutes | store tracks |
| P11 | Merge back, records | `gh pr create … release/<x.y.z>` | Mac | `gh` | minutes | PR into `main` |
| — | Rollback | `deploy/prod/rollback.sh` (data, :36-43); `wrangler rollback <version>` (each worker) | Mac | as above | seconds | R2 pointer; Worker version |

**Counted:** a production app release has you type **5 to 7 production commands** at the Mac (P2, P4, P5, P7, plus
P8/P9 when they changed). Each needs the Mac, its logins and a clean tree.

### 1c. Credentials that exist today

Read with `gh api` on 2026-11-25. Values were never read.

- GitHub **repo-level** secrets: `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_API_TOKEN`, `R2_ACCESS_KEY_ID`,
  `R2_SECRET_ACCESS_KEY`. **No environments exist** (`GET /repos/…/environments` returned none).
  `CLOUDFLARE_API_TOKEN` is read by no workflow (secrets.md:47). It dates from 2026-03 and its permissions are unknown.
- Repo settings: public, forking allowed. Fork-PR approval is `first_time_contributors`. The default `GITHUB_TOKEN` is
  `read`. Allowed actions: `all`, and `sha_pinning_required: false` at both the repo and the org. Every workflow pins
  actions by tag (`actions/checkout@v5`, `setup-python@v6`, `upload-artifact@v6`), not by commit.
- Rulesets: three branch rulesets. **No tag ruleset**: T1062 planned one "after the first rc release".
- The Mac: `wrangler login` (OAuth), rclone `r2:`, `gh` (keychain, your account), `~/.canifishthis/` (Play, keystore,
  App Store Connect key), and the two `.run-token` files.

---

## 2. The design

### 2.1 What runs where

| Piece | Built where | Shipped by | Why |
|---|---|---|---|
| Data release (atlas, reach, deliver, tiles) | **Mac** (unchanged) | Mac **puts** the files; the workflow **flips** the pointer | Many GB and about 35 min; it stays |
| Feeds worker | CI (`wrangler deploy` bundles it) | ship workflow, only when its bundle changed | Small, reproducible |
| Data worker, host redirect | CI | ship workflow, only when changed | Same |
| Web app + water pages | CI (export + SEO on the release, downloaded from R2) | ship workflow | Takes the 15-minute job off the Mac |
| Phones | Mac for now (section 4) | Mac | Signing, MapLibre build, Xcode |

### 2.2 Is the Mac's upload already addressed by content? Mostly yes, and the gaps are small

- **Yes:** every data file is named `<name>-<sha12>` (build.py:921-923). The release id is `r-` plus 12 hex of the
  sha256 of every file's sha256 and everything else the manifest says (rebase.py:38-42, build.py:946-949). Tiles live
  in `tiles/<handles16>.<sha12>/` and the basemap in `basemap-<sha12>`. `rebase.release_id(m)` (rebase.py:45-47)
  recomputes the id from a manifest, so CI can prove an id matches its contents.
- **Not covered by the id:** the manifest's own bytes. `published` and `minAppVersion` are stamped at upload, outside
  every hash (stamp.py:5-14), and so are `water_digests` / `changed_waters` (manifest.py docstring). **So the rc tag
  must carry the sha256 of the stamped manifest** (2.4).
- **Fixed keys, overwritten by every upload:** `map-assets/v1/**` (upload.sh:101-104), the root `*.wasm` (:125-127),
  the feed seeds (`--ignore-existing`, harmless) and the worker inputs (`sync-inputs.sh`). The inputs are
  "pointer-coupled" (upload.sh:138-141). They must go up in the flip, not in the put. So the Mac stages them under the
  release id (`ship/<r-id>/inputs/<key>`, plus the `<key>\t<cache>` list `pipeline.deliver.sync_inputs` prints today),
  and the workflow copies them to their live keys just before the pointer.

### 2.3 The Mac's new last step ("put", no pointer)

Split `deploy/staging/upload.sh` at line 128 into **put** (Mac) and **flip** (workflow):

1. The Mac runs every pre-gate it runs today (app gate, CI status) and the run-timing base put (:77).
2. It puts tiles, assets, basemap, data files and synopsis exactly as today (:96-108). These keys are new and named
   by content, so nobody sees them yet.
3. It stamps the manifest (:144) and puts it at **`release/<r-id>/manifest.json`**, never at `release/manifest.json`.
   The clear already spares `release/<r-id>/**` (:152).
4. It stages the worker inputs to `ship/<r-id>/inputs/` and the input list to `ship/<r-id>/inputs.tsv`. `ship/` joins
   the clear's spared list.
5. It puts the previous SEO snapshot the site build needs to `ship/seo-snapshots/` (`/changes` reads it:
   tools/seo/build.ts:57, :297; today it exists only in the Mac's `app/dist/seo-snapshots`).
6. **Then it tags** (tag_release moves from after the smoke, release.py:2216, to here). The rc tag is annotated with
   trailers the workflow reads:

   ```
   v0.10.1-rc.2
   Data-Release: r-71d09ad82e81
   Manifest-SHA256: <64 hex of release/<r-id>/manifest.json as put>
   Min-App-Version: 0.8.4
   Checks: passed 2026-11-25T13:47 (binding diff accepted: auto)
   Fingerprint: <ledger fingerprint>
   ```

   A data-only release has no rc (owner pick, T1062). Its `data/<r-id>` tag carries the same trailers.

Pushing the tags starts the staging workflow. This also fixes an order quirk: the rc then names what staging is about
to serve, not what it served a moment ago.

### 2.4 The staging workflow, `ship-staging.yml`

**Started by:** a push of tag `v*-rc.*` or `data/r-*`, or `workflow_dispatch` with a tag (to rerun). **Never** a
schedule. GitHub sends no tag event when more than three tags are pushed at once
(https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows). `tag_release`
pushes at most two, so the docs must say so. Concurrency group `ship-staging`, never cancelled. A second run for the
same push finds everything done and does nothing.

| Job | Secrets | What it does | The check after it | Stop and roll back |
|---|---|---|---|---|
| **plan** | none | Checks the tag name against a strict regex (passed as an env variable, never pasted into a script). Reads the trailers. Builds the feeds-worker bundle with `wrangler deploy --dry-run --outdir`, hashes it with its config, and compares that hash with the live version's tag (`wrangler versions list --json`, which shows Tag and Message: https://developers.cloudflare.com/workers/wrangler/commands/workers/). Does the same for the data worker. Decides the order: **worker first** if the release binds pieces the live worker lacks; **web first** if `Min-App-Version` is above the live site's version; else data → web (PRODUCTION.md "order rules"). Writes the plan to the job summary. | — | Any mismatch: stop, nothing sent |
| **verify** | R2 staging read | Downloads `release/<r-id>/manifest.json`, then checks: (1) its sha256 = `Manifest-SHA256`; (2) `release_id(m) == m.data_release == Data-Release`; (3) every file in `files`, plus synopsis, basemap, `tiles.current`, `tiles.mask` and `tiles.assets.pack`, is in the bucket with its byte size, and **each is downloaded and hashed** (gunzipped for `.gz`; the manifest's sha256 is of the raw bytes, build.py:920-925). That is about 30 MB of data, 198 MB of tiles and 225 MB of basemap for r-0aec88ed3edb (`du`; manifest `bytes`): about 1–2 min on a runner (**guess**). (4) **One vintage**: every file's `section_handles` equals `tiles.compatible[0]` without the `.*`, and that equals the first part of `tiles.current.id`. (5) `minAppVersion` = the trailer, and `pipeline.deliver.release.app_gate` passes. (6) `ship/<r-id>/inputs.tsv` names files that are all present. (7) The run-timing base for these tiles is present. | all pass | Stop. Nothing has changed for anyone |
| **runtiming** | R2 staging write | `feeds-runtiming.yml` becomes a reusable workflow (`workflow_call`), called in the same run. That ends the dispatch-and-poll (upload.sh:87-135). It is skipped when nothing would change (the T485 test, upload.sh:62-66). | `runtiming/index.json` names these tiles (:136-137) | Stop before the pointer |
| **worker** (if changed) | CF staging token, staging run token | Worker tests. `pieces_gate --worker-deploy` (feeds.sh:49). Saves the live version id. `wrangler deploy --tag <bundle hash> --message "<tag>"`. Runs the 3 jobs. | `/status.json` names the new version, the 3 jobs answer 200, `dfo.pieces` is there when bound | `wrangler rollback <saved id> --message "ship: <tag> failed"` (the docs say `--message` skips the prompts) |
| **data** | R2 staging write | Site gate and pieces gate. Format gate, then copies the inputs from `ship/<r-id>/inputs/` to their live keys. **New on staging:** copies the live pointer to `release/manifest.previous.json`. Writes the pointer as a copy of `release/<r-id>/manifest.json`. | `https://data-staging.canifishthis.ca/release/manifest.json` sha256 = trailer; 3 sampled files fetched through the data host match their sha256; `smoke-staging.mjs` data checks | Put `manifest.previous.json` back as the pointer (rollback.sh's logic). The inputs are re-copied from the previous release's `ship/` folder |
| **web** | CF staging token | Checks out the tag. Gets `release/<r-id>/` from R2 into a temp folder and the previous snapshot from `ship/seo-snapshots/`. Runs `export:web:staging` and `build-seo.mjs --release-dir`, then the `site.sh` merge (unchanged), then deploys with `--tag <commit>`. | `/site-release.json` names the release and the tag's commit; `smoke-staging.mjs` passes | `wrangler rollback <saved site version>`. Static assets belong to the Worker version, so they roll back with it (**not verified**, see Not verified) |
| **clear** | R2 staging write | The T433 clear (upload.sh:151-153), moved here so a failed smoke can still roll back. `test/` reset. | `rclone size` printed | — (it runs last, after everything is green) |
| **record** | `contents: write` (GITHUB_TOKEN) | Makes a draft GitHub Release for the rc: the plan, every check's result, the version ids deployed, the r-id. | — | — |

### 2.5 The production workflow, `ship-production.yml`

**Started by:** a push of tag `v*.*.*` other than `v*-rc.*`, i.e. `release --final`. A data-only release starts it
with `workflow_dispatch` (input `data_release`) from its `release/data-*` branch. Nothing ships until **you approve**.

- **plan** (no secrets, before the approval, so you read it first): `v<x.y.z>` is on the newest rc's commit, and that
  commit holds the ship commit (the `tag_problems` rule, done with git). The newest rc's trailers name the r-id. The
  bytes of staging's live `release/manifest.json` = `Manifest-SHA256`: production promotes only what staging serves,
  as prod/upload.sh:44-46 does today. The production site's and worker's live versions are read. A **prune dry run**
  lists every key the clean-up would delete (`prod_prune --dry-run --pending`, prod/upload.sh:137-138). The summary
  says: "Approving ships r-…, the worker (bundle …, changed / unchanged), the site at <commit>, and deletes N old
  objects (M MB)".
- **ship** (ONE job, `environment: production`). One job means one click. GitHub asks for a separate approval for
  each job that names a protected environment, so the steps live in one job:
  1. the same verify list as staging, now **while copying**. Staging → production goes through the runner with two
     least-privilege keys (read-only on staging, read and write on production), and the hashes are taken on the way
     (about 450 MB). This replaces re-uploading from the Mac's disk (prod/upload.sh:79-88). Copies the run timing as
     today (:74-75);
  2. the worker, if changed (as staging, with the production names and token);
  3. the data: inputs, then `manifest.previous.json`, then the pointer (:113-126);
  4. the web: the production export and SEO pages built here, then deployed;
  5. after each step its check (as staging, with `--production`). A failure rolls back **that step and the ones before
     it**, then stops;
  6. the prune, last, only when everything is green. It deletes exactly what the plan listed: anything else is a stop.
     **This is the one deletion. It is covered by your approval click, and the plan showed it to you first** (a pick
     below offers a second click).
- **record**: the GitHub Release for `v<x.y.z>` is published (the draft from the rc becomes final), with the record.
- **Afterwards on the Mac:** `data/release/PUBLISHED` is written by the Mac today (prod/upload.sh:128). It becomes a
  read of production's pointer (`release --sync-published`, a new small command) so the local prune keeps the right
  release.

Wall time after your click: about 25–35 min (**guess**: mostly the site build, about 15 min on the Mac, unknown on a
4-core runner).

### 2.6 What replaces `CONFIRM_PROD`

| Today (code) | In the workflow |
|---|---|
| `CONFIRM_PROD=<r-id>` + typing the id (release.py:2950-2961) | A GitHub Environment `production` with **you as the required reviewer**. The plan job's summary names the r-id; you approve after reading it |
| Refuses agent env vars (release.py:2746-2748) | Production secrets exist **only** in the `production` environment. A job gets them only after a required reviewer approves (https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments) |
| `--prod` reads the Mac's ledger (checks passed, fingerprint) | The rc tag's trailers (written by the Mac's staging ship), checked against staging's live bytes |
| `deploy/prod/*.sh` stay | They remain the **break-glass path** from the Mac (GitHub down), unchanged |

Environment settings: **"Allow administrators to bypass" off** (possible on a public repo on the Free plan, same
page). Deployment refs: only tags `v*.*.*` and the branch pattern `release/data-*`. Wait timer 0. "Prevent
self-review" is decided in 3.4.

### 2.7 Workflow YAML sketch (notes only; not in the repo)

Action SHAs are shown as `<sha>`. The build fills them with the commits of the named versions.

```yaml
# .github/workflows/ship-staging.yml  (SKETCH)
name: ship — staging
on:
  push:
    tags: ['v*-rc.*', 'data/r-*']
  workflow_dispatch:
    inputs:
      tag: { description: "the rc or data tag to (re)ship", required: true, type: string }
permissions: { contents: read }
concurrency: { group: ship-staging, cancel-in-progress: false }
env:
  TAG: ${{ inputs.tag || github.ref_name }}     # used only through $TAG, never pasted into a script
jobs:
  plan:
    runs-on: ubuntu-latest
    timeout-minutes: 15
    outputs:
      rid: ${{ steps.t.outputs.rid }}
      manifest_sha: ${{ steps.t.outputs.manifest_sha }}
      worker: ${{ steps.w.outputs.changed }}
      order: ${{ steps.o.outputs.order }}        # "worker,data,web" | "worker,web,data" | ...
    steps:
      - uses: actions/checkout@<sha>             # v5, pinned
        with: { ref: "refs/tags/${{ env.TAG }}", fetch-depth: 0, persist-credentials: false }
      - id: t
        run: |
          [[ "$TAG" =~ ^(v[0-9]+\.[0-9]+\.[0-9]+-rc\.[0-9]+|data/r-[0-9a-f]{12})$ ]] || { echo "::error::bad tag"; exit 1; }
          python3 scripts/ship/trailers.py "$TAG" >> "$GITHUB_OUTPUT"   # Data-Release, Manifest-SHA256, Min-App-Version
      - uses: ./.github/actions/app-setup        # pnpm install --frozen-lockfile; no cache restore in ship jobs
      - id: w
        run: node scripts/ship/worker-changed.mjs --config app/workers/feeds/wrangler.toml >> "$GITHUB_OUTPUT"
        # bundle via `wrangler deploy --dry-run --outdir`, sha256(bundle + config) vs the live version's tag.
        # Reading the live versions needs a token: give this step a READ-only CF token (Workers metadata read) or move it to `worker`.
      - id: o
        run: python3 -m pipeline.ship plan --env staging --rid "${{ steps.t.outputs.rid }}" >> "$GITHUB_OUTPUT"

  verify:
    needs: plan
    runs-on: ubuntu-latest
    environment: staging-read          # holds only the R2 staging READ key; refs: the same tag patterns
    timeout-minutes: 20
    env:
      AWS_ACCESS_KEY_ID: ${{ secrets.R2_STAGING_READ_KEY_ID }}
      AWS_SECRET_ACCESS_KEY: ${{ secrets.R2_STAGING_READ_SECRET }}
      R2_ENDPOINT: https://${{ vars.CLOUDFLARE_ACCOUNT_ID }}.r2.cloudflarestorage.com
      RID: ${{ needs.plan.outputs.rid }}
      MSHA: ${{ needs.plan.outputs.manifest_sha }}
    steps:
      - uses: actions/checkout@<sha>
        with: { ref: "refs/tags/${{ env.TAG }}", persist-credentials: false }
      - uses: actions/setup-python@<sha>
      - run: python3 -m pipeline.ship verify --bucket bc-fishing-regulations-staging --rid "$RID" --manifest-sha "$MSHA"
        # manifest sha, release_id recompute, every file present + sha256, one vintage, minAppVersion + app_gate,
        # inputs staged, run-timing base present

  runtiming:
    needs: [plan, verify]
    uses: ./.github/workflows/feeds-runtiming.yml     # becomes workflow_call
    with: { target: staging, upload: true, tiles_from_rid: "${{ needs.plan.outputs.rid }}" }
    secrets: inherit                                  # its own job names environment: staging-data

  ship:
    needs: [plan, verify, runtiming]
    runs-on: ubuntu-latest
    environment: staging               # CF staging token, R2 staging write, staging run token
    timeout-minutes: 60
    env:
      CLOUDFLARE_API_TOKEN: ${{ secrets.CF_STAGING_TOKEN }}
      CLOUDFLARE_ACCOUNT_ID: ${{ vars.CLOUDFLARE_ACCOUNT_ID }}
      AWS_ACCESS_KEY_ID: ${{ secrets.R2_STAGING_RW_KEY_ID }}
      AWS_SECRET_ACCESS_KEY: ${{ secrets.R2_STAGING_RW_SECRET }}
      RUN_TOKEN: ${{ secrets.STAGING_RUN_TOKEN }}
      RID: ${{ needs.plan.outputs.rid }}
      ORDER: ${{ needs.plan.outputs.order }}
      WORKER_CHANGED: ${{ needs.plan.outputs.worker }}
    steps:
      - uses: actions/checkout@<sha>
        with: { ref: "refs/tags/${{ env.TAG }}", fetch-depth: 0, persist-credentials: false }
      - uses: ./.github/actions/app-setup
      - run: npx --prefix app playwright install --with-deps chromium     # for the smoke (version from the lockfile)
      # one script runs the steps in $ORDER; each step: save the live version -> act -> check -> on failure roll back
      # every step done so far (in reverse) and exit 1. Every step is idempotent, so a rerun of the run is safe.
      - run: bash deploy/ship/run.sh staging "$ORDER"
      - run: bash deploy/ship/clear-staging.sh "$RID"     # T433's clear, now after every check is green
      - if: always()
        run: python3 -m pipeline.ship summary >> "$GITHUB_STEP_SUMMARY"

  record:
    needs: [plan, ship]
    runs-on: ubuntu-latest
    permissions: { contents: write }
    steps:
      - run: gh release create "$TAG" --draft --prerelease --notes-file ship-record.md -R "$GITHUB_REPOSITORY"
        env: { GH_TOKEN: "${{ github.token }}" }
```

```yaml
# .github/workflows/ship-production.yml  (SKETCH)
name: ship — production
on:
  push:
    tags: ['v*.*.*', '!v*-rc.*']
  workflow_dispatch:
    inputs:
      data_release: { description: "data-only release id (from its release/data-* branch)", required: true, type: string }
permissions: { contents: read }
concurrency: { group: ship-production, cancel-in-progress: false }
jobs:
  plan:                                   # no secrets: you read this summary before you approve
    runs-on: ubuntu-latest
    environment: production-plan          # R2 READ-only keys for staging + production, no reviewer; refs as production
    steps:
      - uses: actions/checkout@<sha>
        with: { fetch-depth: 0, persist-credentials: false }
      - run: python3 -m pipeline.ship plan --env production >> "$GITHUB_STEP_SUMMARY"
        # final tag == newest rc commit; trailers -> rid; staging live manifest sha == trailer; live site/worker versions;
        # prune dry run (what will be deleted)
  ship:
    needs: plan
    runs-on: ubuntu-latest
    environment: production               # required reviewer = the owner; admin bypass OFF; refs v*.*.* + release/data-*
    timeout-minutes: 90
    env:
      CLOUDFLARE_API_TOKEN: ${{ secrets.CF_PROD_TOKEN }}
      CLOUDFLARE_ACCOUNT_ID: ${{ vars.CLOUDFLARE_ACCOUNT_ID }}
      SRC_KEY_ID: ${{ secrets.R2_STAGING_READ_KEY_ID }}       # copy source, read-only
      SRC_SECRET: ${{ secrets.R2_STAGING_READ_SECRET }}
      AWS_ACCESS_KEY_ID: ${{ secrets.R2_PROD_RW_KEY_ID }}
      AWS_SECRET_ACCESS_KEY: ${{ secrets.R2_PROD_RW_SECRET }}
      RUN_TOKEN: ${{ secrets.PROD_RUN_TOKEN }}
    steps:
      - uses: actions/checkout@<sha>
        with: { fetch-depth: 0, persist-credentials: false }
      - run: '[[ "${GITHUB_REF_NAME:-}" != *-rc.* ]]'          # belt and braces: the env pattern also matches rc tags
      - uses: ./.github/actions/app-setup
      - run: python3 -m pipeline.ship plan --env production --recheck   # nothing moved since the plan job
      - run: bash deploy/ship/run.sh production "$(cat order.txt)"      # worker? -> data -> web, check + rollback each
      - run: python3 -m pipeline.deliver.release.prod_prune releases --remote "r2:bc-fishing-regulations" --expect plan-prune.json
  record:
    needs: ship
    runs-on: ubuntu-latest
    permissions: { contents: write }
    steps:
      - run: gh release edit "$GITHUB_REF_NAME" --draft=false --latest -R "$GITHUB_REPOSITORY"
        env: { GH_TOKEN: "${{ github.token }}" }
```

---

## 3. Secrets

### 3.1 The full list (names only), by environment

Cloudflare account id: a **variable** (`vars.CLOUDFLARE_ACCOUNT_ID`), not a secret (secrets.md:44 says it is not a
credential).

| GitHub environment | Deployment refs allowed | Reviewer | Secrets |
|---|---|---|---|
| `staging-feeds` (HYDAT, run timing) | branches `main`, `release/*`; tags `v*-rc.*`, `data/r-*` | none | `R2_STAGING_RW_KEY_ID`, `R2_STAGING_RW_SECRET` (the repo-level `R2_ACCESS_KEY_ID`/`R2_SECRET_ACCESS_KEY`, **moved off the repo level**) |
| `staging-read` | tags `v*-rc.*`, `data/r-*` | none | `R2_STAGING_READ_KEY_ID`, `R2_STAGING_READ_SECRET` |
| `staging` | tags `v*-rc.*`, `data/r-*` | none (staging is Claude's) | `CF_STAGING_TOKEN`, `R2_STAGING_RW_KEY_ID`, `R2_STAGING_RW_SECRET`, `STAGING_RUN_TOKEN` |
| `production-plan` | tags `v*.*.*`; branches `release/data-*` | none | `R2_STAGING_READ_*`, `R2_PROD_READ_KEY_ID`, `R2_PROD_READ_SECRET` |
| `production` | tags `v*.*.*`; branches `release/data-*` | **the owner**; admin bypass off | `CF_PROD_TOKEN`, `R2_PROD_RW_KEY_ID`, `R2_PROD_RW_SECRET`, `R2_STAGING_READ_*`, `PROD_RUN_TOKEN` |
| later: `play` | tags `v*.*.*`, `v*-rc.*` | owner for production tracks | `PLAY_SERVICE_ACCOUNT_JSON` (or none, with Google workload identity), `ANDROID_UPLOAD_KEYSTORE_B64`, `ANDROID_UPLOAD_KEYSTORE_PROPERTIES` |
| later: `app-store` | same | owner | `ASC_KEY_ID`, `ASC_ISSUER_ID`, `ASC_KEY_P8`; `IOS_TEAM_ID` as a variable |

**Delete:** the repo-level `CLOUDFLARE_API_TOKEN` (nothing reads it, its permissions are unknown), and revoke it in
Cloudflare. **Stay in Cloudflare and never go into GitHub:** the workers' own secrets (`REPORT_SALT`, `RUN_TOKEN`,
`NOTIFY_EMAIL_TO`, `GITHUB_DISPATCH_TOKEN`, `APNS_*`). `wrangler deploy` keeps them (prod/feeds.sh:8, "its secrets
stay").

**Environment patterns are loose.** `v*.*.*` also matches `v0.10.1-rc.1`: GitHub patterns have no "not". The
workflow's own trigger excludes rc tags (`!v*-rc.*`), and the ship job checks again. The reviewer is the real gate.

### 3.2 Least-privilege Cloudflare tokens

Cloudflare now has **account-owned tokens scoped to specified Workers**, with the roles Metadata Read-Only, Content
Read-Only, Editor and Admin. Editor can deploy but not delete
(https://developers.cloudflare.com/changelog/post/2026-09-15-granular-worker-permissions/,
https://developers.cloudflare.com/workers/authorization/). Updating an existing Worker needs Editor on it. **Changing**
routes or custom domains also needs Workers Routes Write on the zone (same page). Our deploys keep their custom domains
unchanged.

| Token | Kind | Scope | Used for |
|---|---|---|---|
| `CF_STAGING_TOKEN` | Account-owned API token | **Editor** on the Workers `bc-fishing-feeds-staging`, `bc-fishing-regulations-staging`, `bc-fishing-r2-staging`. Add zone `canifishthis.ca` **Workers Routes Write** only if a dry deploy shows it is needed (not verified). Read for R2 bucket lifecycle (feeds.sh:34), or move that check to a weekly look | `wrangler deploy`, `versions list`, `rollback`, `secret list` |
| `CF_PROD_TOKEN` | Account-owned | **Editor** on `bc-fishing-feeds`, `bc-fishing-regulations`, `bc-fishing-r2`, `canifishthis-host-redirect`; the same zone note | the same, production |
| R2 `…STAGING_RW…` | R2 API token, **Object Read & Write**, bucket `bc-fishing-regulations-staging` only | the staging bucket | the flip, the clear, run timing, HYDAT |
| R2 `…STAGING_READ…` | R2, **Object Read only**, staging bucket only | | verify, the production copy's source |
| R2 `…PROD_READ…` | R2, Object Read only, `bc-fishing-regulations` | | the production plan |
| R2 `…PROD_RW…` | R2, Object Read & Write, `bc-fishing-regulations` only | | the production copy, pointer and prune |

R2 Object tokens can be limited to a set of buckets, even one
(https://developers.cloudflare.com/r2/api/tokens/). Prefix-level limits exist only for **temporary credentials** made
from a parent token (https://developers.cloudflare.com/r2/api/s3/temporary-credentials/). The parent would still have
to live in GitHub, so it adds little here.

The **Mac** then needs only its rclone key for the put. It never needs a production key again, except for the
break-glass path.

### 3.3 Rotation

- Every Cloudflare token gets a **Token expiration** date (offered at creation:
  https://developers.cloudflare.com/fundamentals/api/get-started/create-token/). Proposed: 12 months, with an
  OWNER-TODO row a month before. Replacing one: create the new token, `gh secret set -e <env> <NAME>`, run the
  staging ship, revoke the old one.
- R2 keys: same steps. Revoking the parent kills every temporary credential made from it (temporary-credentials page).
- If a key leaks: revoke it in Cloudflare first (it stops at once). Then compare `wrangler versions list` for every
  worker against the ship records, and the bucket's pointer against the last record. Then make new keys.
- **GitHub is not a backup.** Secrets cannot be read back. The keystore and `.p8` files still need the password
  manager (secrets.md:8-10). That answers "we could add the secrets into github?": yes for deploy keys, scoped per
  environment; no as the only copy of anything.

### 3.4 What an attacker gets, and what stops them (public repo)

| Route | What GitHub does | What remains |
|---|---|---|
| A fork pull request | Secrets are not passed to runs from forks. `GITHUB_TOKEN` is read-only (https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows). Fork runs need approval for first-time contributors (repo setting today) | Set the approval to **all outside contributors** (a pick). No ship workflow has a `pull_request` trigger |
| `pull_request_target` / `workflow_run` | These are privileged and "must not explicitly check out untrusted code" (https://docs.github.com/en/actions/reference/security/secure-use) | **None exist today** (grep of `.github/workflows`). Add a CI rule (e.g. zizmor or actionlint) that fails on them |
| A changed workflow file | A tag push runs the workflow **as it is at the tagged commit**. Anyone who can push a tag gets that environment's secrets | Only accounts with write can push tags: you, and agents using your login. Add a **tag ruleset**: `v*` and `data/*` can be created by you only, never updated or deleted (T1062's planned ruleset). The `production` reviewer is the last gate |
| A hijacked action (e.g. a moved `v5` tag) | GitHub advises pinning to a full commit SHA (secure-use page). An org policy can now **require** SHA pins (https://github.blog/changelog/2025-08-15-github-actions-policy-now-supports-blocking-and-sha-pinning-actions/); the API shows `sha_pinning_required: false` here today | Pin every action by SHA and turn the policy on. Use only GitHub's own actions (checkout, setup-node, setup-python). **No third-party deploy action:** wrangler runs from the repo's lockfile |
| Script injection | A tag name or input pasted into `run:` can run code (secure-use page) | Pass values through `env:` and check the tag against a regex first (sketch above) |
| A poisoned cache | Privileged runs share main's caches (secure-use page) | Ship jobs restore no cache: a fresh `pnpm install --frozen-lockfile` |
| Repo-level secrets | Any workflow on any branch a writer pushes can read them | Move the two R2 keys into `staging-feeds`; delete the unused Cloudflare token |
| **Your own GitHub login, used by Claude sessions** | "Review pending deployments" accepts a classic token with `repo` scope, from a required reviewer (https://docs.github.com/en/rest/actions/workflow-runs#review-pending-deployments-for-a-workflow-run). `gh` holds such a token for your account | **The gap.** Any process holding your `gh` token can approve production through the API. Today's code refusal (agent env vars) has no counterpart in GitHub. The fix: agents push with **their own identity** (a GitHub App or a machine account with write, never a reviewer), and you turn on **"Prevent self-review"** so the identity that started a run cannot approve it (environments page). Until then the approval is your rule plus a written ban, the same strength as `CONFIRM_PROD` against a determined process, but not stronger |

**What each leaked key would give:**

- `CF_STAGING_TOKEN`: deploy any code to the three staging workers. The staging feeds worker holds
  `GITHUB_DISPATCH_TOKEN` (Actions read/write on this repo) and the staging backup bucket. So it leads to starting
  workflows, which the environments then gate.
- `CF_PROD_TOKEN`: **the most sensitive key.** Code deployed to `bc-fishing-feeds` can read its bindings: the
  production bucket, **the backup bucket with anglers' reports and crash records**, `REPORT_SALT` and the dispatch
  token. So this token sits only behind the reviewer, scoped to Editor on four Workers, and never in a job before
  approval.
- R2 production write: change the regulations the public reads (say "open" where a water is closed) or delete them.
  The pointer and its previous copy limit the damage window to the time until a rollback. The prune rules never touch
  `feeds/`, `private/` or `app/`.
- R2 staging: the same on staging (testers only).

**OIDC:** Cloudflare's GitHub Actions page names only an API token and account id
(https://developers.cloudflare.com/workers/ci-cd/external-cicd/github-actions/), and two searches found no Cloudflare
OIDC federation. **Not confirmed either way:** keys it is, with expiry dates. Google Play could use Google's workload
identity federation (OIDC, no JSON key) later. That is not checked for the Play API.

---

## 4. Phone builds

| | Android AAB | iPhone |
|---|---|---|
| Runner | Linux, standard. **Free on a public repo** ("Standard GitHub-hosted runners in public repositories are free": https://docs.github.com/en/billing/concepts/product-billing/github-actions) | macOS, standard. **Also free on a public repo** (same rule; the page does not single out macOS). A private repo would pay $0.062/min, so a 30-min build is about $1.86 (**guess** on the length). Free plan limit: 5 macOS jobs at once (https://docs.github.com/en/actions/reference/limits) |
| Secrets | upload keystore (base64) + its properties file, Play service account | App Store Connect API key (Admin role; secrets.md:55), team id |
| The hard part | **MapLibre is built from upstream main, not a release** (app/tools/maplibre-android/pin.env:5-17). CI must build it with the NDK once per pin and keep the file as a GitHub Release asset with its sha256 (self-hosted, as the rule asks). Then Expo prebuild, Gradle, R8, mapping upload. The versionCode commit (build-apk.sh:30) needs a decision: CI computes it from Play's highest + 1 and records it, instead of pushing to the release branch | Matching Xcode on the runner image; signing with the API key (`-allowProvisioningUpdates`); the build-number state kept today in `~/.canifishthis/testflight-last-build` |
| Effort | M | M–L |

**Recommendation for now: keep both phones on the Mac.** Move the Cloudflare items first: they are the owner's ask,
smaller, and they free the Mac's heavy lane. Then Android as T1133 stage A, with the MapLibre file built once per pin.
iOS last (stage C), and **iOS is benched** anyway (memory: no iOS device work until DFO extents are labelled and Play
closed testing is done).

---

## 5. Migration in small steps (each one shippable alone)

| Step | What it does | What you click once | What it saves |
|---|---|---|---|
| **M0** | Clean-up, no new deploys: pin every action by SHA, then turn on "require SHA pinning"; move the R2 repo secrets into env `staging-feeds`; delete `CLOUDFLARE_API_TOKEN`; tag ruleset for `v*` and `data/*` | 10 min: environment `staging-feeds`, the ruleset, the SHA policy box, revoke the old token in Cloudflare | Closes today's exposure |
| **M1** | Staging feeds worker from CI. Started by the rc tag; deploys only when the bundle changed; `--tag` on every version. `deploy/staging/feeds.sh` stays as a fallback | 10 min: env `staging`, create `CF_STAGING_TOKEN` (Editor on 3 Workers), set it and `STAGING_RUN_TOKEN` | Claude no longer needs `wrangler login` for staging |
| **M2** | Put / flip split on staging (2.3, 2.4): the Mac puts and tags, CI verifies, runs run timing, flips, keeps `manifest.previous.json`, clears | 5 min: R2 staging read key + env `staging-read` | Staging gets a rollback; the flip is checked by hash; run timing stops polling |
| **M3** | Staging website from CI | none | About 15 min of the Mac's heavy lane per site deploy (site-all.sh:7) |
| **M4** | Production workflow (2.5), one approval, `deploy/prod/*` kept as break-glass. First run in **rehearsal mode**: the job runs `--dry-run` everywhere; you approve it to try the click | 15 min: env `production` (you as reviewer, bypass off, refs), `CF_PROD_TOKEN` (Editor on 4 Workers), the two production R2 keys, `PROD_RUN_TOKEN` (from `.run-token.prod`) | Your production work drops from 5–7 terminal commands (P5, P7, P8, P9, plus P2/P4) to **1 click plus the phone builds**. Wall time about 25–35 min after the click (**guess**), with nobody waiting at the Mac |
| **M5** | Agents get their own GitHub identity; turn on "Prevent self-review" | 15 min: create the App or account, give it write, hand its token to the Mac's agent setup | Closes the gap in 3.4 |
| **M6** | Docs: release-by-hand.md Steps 4 and 7 rewritten; secrets.md; PRODUCTION.md | none | — |
| later | T1133 stage A (Android in CI), stage C (iPhone) | `play` / `app-store` environments | The single-Mac risk for phones |

Runner contention (T1144): the ship workflows use about 3–5 jobs per release. **Build them after T1144's gate
workflow**, or a release day waits in the same queue as docs PRs.

**Time per release, honestly:**

- The owner's attention: today, production means about 5–7 commands at the Mac, each with its prompt and a clean
  tree, plus waiting on Claude's prod site build in between. **Guess:** 30–45 min with the Mac in front of you. With
  M4 it is one approval read and click, from anywhere.
- Machine time does not shrink much. It moves: about 15 min of site build per environment leaves the Mac. Production
  data no longer re-uploads about 450 MB from the Mac.
- Unchanged: the data build (about 35 min), the follows tests, the phone builds, your look at staging.

---

## 6. Proposed update text for T1133 (for the planning chat to paste)

```markdown
## Plan (night agent 2026-11-25; notes: scratchpad night/ship-workflow-design.md)
Owner 2026-11-25, verbatim: "could we make the feeds workers prod and staging get deployed from gha? would that be a
good idea?"; "ideally we have all the cloudflare items pushed from gha I think? like when a release needs new worker
code pushed then it gets pushed and similar push other stuff it needs like data or webapp etc? maybe a seperate work
deploy is bad."; "we could add the secrets into github?"

Shape: ONE ship workflow per environment. ship-staging.yml starts on the rc tag (or data/r-* for a data-only release);
ship-production.yml starts on the final tag and waits for the owner's approval in the `production` environment (the
CONFIRM_PROD of GitHub: owner as required reviewer, admin bypass off, refs v*.*.* + release/data-*). Each run: plan
(no secrets; says what will change and what the prune deletes) -> verify (manifest sha256 from the rc tag's trailers,
release_id recomputed, every file present and hashed, one vintage: section_handles = tiles.compatible = tiles.current
prefix, minAppVersion + app_gate, inputs staged) -> the worker only when its bundle hash differs from the live
version's tag -> the data pointer (previous kept) -> the web app built in CI on the release -> a check after each, a
rollback of that step and the ones before on a failure; the prune and the staging clear last, after all is green.
The data build stays on the Mac; the Mac PUTS the release's content-named files and the staged worker inputs under
the release id, stamps the manifest to release/<r-id>/manifest.json, then tags (tag_release moves before the flip).
Phones stay on the Mac for now (stage A Android after this; iOS benched).

## Work (stages, each shippable alone)
M0. Pin actions by SHA + turn on the SHA-pinning policy; R2 repo secrets into env `staging-feeds`; delete the unused
    repo secret CLOUDFLARE_API_TOKEN (and revoke it); tag ruleset for v* and data/* (create: owner only; no update,
    no delete).
M1. Staging feeds worker from ship-staging.yml (bundle-hash change test, `wrangler deploy --tag`, /status + the 3
    jobs, `wrangler rollback` on failure). feeds.sh stays as the fallback.
M2. upload.sh split into put (Mac) and flip (workflow); rc trailers Data-Release / Manifest-SHA256 / Min-App-Version /
    Checks / Fingerprint; feeds-runtiming.yml becomes workflow_call; staging keeps release/manifest.previous.json; the
    T433 clear runs after the checks; `ship/` spared by the clear.
M3. Staging site built and deployed by the workflow (release folder and the previous SEO snapshot from R2).
M4. ship-production.yml (one job behind the approval: copy staging -> production through the runner with hashes,
    worker if changed, inputs, pointer, site, prune exactly as planned). First run in rehearsal mode. deploy/prod/*
    stay as break-glass. `release --sync-published` replaces the Mac's PUBLISHED write.
M5. Agents push with their own GitHub identity; "Prevent self-review" on (see NEW TICKET).
M6. release-by-hand.md Steps 4 and 7, secrets.md, PRODUCTION.md rewritten.
Then stage A (Android AAB in CI, MapLibre AAR built once per pin and kept as a Release asset) and stage C (iPhone).

## Acceptance
Staging (M1-M3): one rc tag ships worker (when changed), data and site with no command on the Mac after the put; a
deliberately broken check (a wrong Manifest-SHA256 on a test tag) stops before the pointer and changes nothing.
Production (M4): one release reaches production from one approval click; the run's record names the r-id, the
versions deployed and the keys pruned, and the rehearsal-mode run before it wrote nothing. The owner's production
steps for a data + site + worker release: 1 click (phones excepted).
Owner: creates the environments and tokens (about 40 min in all, spread over M0-M4), approves production.
Model: Opus for M2/M4 and the secrets set-up; Sonnet for M0, M1, M3, M6. Size: L in stages (M0 S, M1 S, M2 M, M3 M,
M4 M, M5 S). Release: after T1144's gate workflow (runner queue) and after 0.10.0.
```

---

## Picks for the owner

1. **Where the production prune runs:**
   (a) in the same approved run, last, exactly the keys the plan listed (recommended);
   (b) a second approval just for the deletion;
   (c) never in CI: the Mac runs `prod_prune` by hand.
2. **The web build for production:**
   (a) built in the approved job after your click (recommended; about 15 min more wall time, no artifacts);
   (b) built in the staging run and kept as a Release asset (1.1 GB, over the Free plan's 500 MB artifact storage; not
   checked for public repos);
   (c) still built on the Mac and handed over.
3. **Closing the "your login can approve" gap:**
   (a) agents get their own GitHub identity, then "Prevent self-review" on (recommended);
   (b) keep one login, with a written rule that agents never call the deployments API;
   (c) also require a typed approval comment naming the r-id (checked by the job; an API caller could still type it).
4. **Fork-PR runs:**
   (a) need approval for all outside contributors (recommended);
   (b) keep "first-time contributors" (today).
5. **Token expiry:**
   (a) 12 months with an OWNER-TODO reminder (recommended);
   (b) 6 months;
   (c) none.
6. **Order of the work:**
   (a) M0 now, the rest after T1144's gate workflow and 0.10.0 (recommended);
   (b) M0 to M2 straight after 0.10.0, before T1144;
   (c) only M0 and M1 (workers), and keep the data and site on the Mac.

## NEW TICKET lines

- NEW TICKET: Agents push with their own GitHub identity (a GitHub App or machine account, never a required reviewer),
  then "Prevent self-review" on the production environment. Today the owner's `gh` token in agent sessions can approve
  deployments through the REST API.
- NEW TICKET: Delete the unused repo secret CLOUDFLARE_API_TOKEN, revoke it in Cloudflare, and move R2_ACCESS_KEY_ID /
  R2_SECRET_ACCESS_KEY from the repo level into an environment (`staging-feeds`).
- NEW TICKET: Pin every GitHub action by commit SHA (and Dependabot for `github-actions` to bump the pins), then turn on
  the "require SHA pinning" policy; add a workflow lint (zizmor/actionlint) that refuses `pull_request_target`.
- NEW TICKET: The MapLibre Android library built from the pinned commit in CI once per pin, kept as a GitHub Release
  asset with its sha256 (the prerequisite for any Android build off the Mac).
- NEW TICKET: The SEO "previous snapshot" (`app/dist/seo-snapshots`, Mac only) kept in R2 so `/changes` can be built
  off the Mac.

## Not verified

- Whether `wrangler deploy` of an unchanged custom-domain Worker needs **Workers Routes Write** on the zone. The docs
  say "if a deployment changes Routes or Custom Domains". Test with a staging token without it.
- Whether a per-Worker Editor token can run `wrangler secret list` and `wrangler r2 bucket lifecycle list`
  (feeds.sh:16, :34). The second likely needs an R2 account permission.
- That `wrangler rollback` restores a Worker's static assets with its code (I believe assets belong to the version;
  the docs page I read did not say).
- The length and character limits of `wrangler deploy --tag` (a sha256 prefix should fit).
- Cloudflare OIDC: not found in two searches and the GitHub Actions page; not proven absent.
- macOS standard runners free on public repos: the billing page states the rule for standard runners in general and
  does not single out macOS.
- Artifact storage limits for public repos (the page lists 500 MB to 50 GB by plan, not by visibility).
- Runner times for the web export + SEO build, the verify download (about 450 MB), the Android and iPhone builds: none
  were run (read-only night). The Mac's figures above come from the ledger and `gh run list`; the site's 15 min is a
  script comment.
- That `rclone` copies between two different R2 keys stream through the runner as designed (two remotes). Not tried.
- Whether GitHub's environment tag patterns treat `v*.*.*` as also matching `-rc.` tags (assumed yes; the workflow
  guards it either way).
