# T1150 scoping: added city creeks that took an FWA river's watershed code (read-only, 2026-11-25 night)

This pass changed nothing. I did not commit or regenerate anything, did not build the atlas, wrote no marks, and uploaded nothing.

Data sources:
- the owner's main checkout: `data/curated/waters/added_streams.json`, the promoted atlas from 2026-11-25 03:20, and `bundle.sqlite` from 12:57;
- the FWA streams gpkg;
- the earlier lane's regenerated variant files, `l30/regen-fix` (plain bump) and `l30/regen-on` (no cascade). I checked that `regen-off` is byte-identical to today's file.

Code is quoted from the planning worktree (main at 8d2637f94).

Helper scripts and their outputs are in `night/T1150-scoping/`:
- `a1`–`a8` are the scripts; `a1_out.json` … `a5_out.json` are their outputs.
- `osm_download/overpass.json` is the OpenStreetMap download.
- `l30-copy/` holds the earlier lane's notes, row diffs and work-in-progress diff, copied so they survive.

Each script was one `nice -n 15` process and ran in under 25 s. The exception is `a8`: it was stopped at about 5 min and gave no result.

## 1. The finding, checked again

**Counts.**
- `added_streams.json` has 324 rows: 310 new city lines and 14 rows that extend an FWA line past its end.
- 37 rows drain straight to the sea: Burnaby 21, Port Moody 13, Squamish 2, and the hand-drawn Sheldens line. The ticket's "36" leaves out Sheldens.

**How I tested.** I compared every row's trimmed code with every FWA line in two ways:
- every FWA line within 5 km of each city layer (`a1_collisions.py`);
- every FWA stream code in BC, from the graph node dump (`a2_graph.py`).

**Result.** Twelve rows (eleven lines; Village Creek is two rows) carry the exact code of a different FWA line. The 3 extension rows that also share a code do so by design. There are no others anywhere in BC.

- **Coastal lines:** the other 25 coastal lines collide with nothing.
- **Lines that drain into a river or another city line (the other 273 rows):** none has an FWA code. Their codes are minted under their receiver, so nothing is filed under a river they do not touch.
- **The 8 rows that sit more than 80 m from their FWA receiver:** all join the city extension of that receiver: Guichon Trib.3, Glen-Lyon Trib.1, the Logger's Lane chain and one Schoolhouse piece. That is fine.
- **Not judged:** Gray Creek's line crosses its receiver, but its mouth end is 288 m away.

**The cause has two holes, not one.**
1. `coastal.estimate_coastal_wsc` (coastal.py:32-50) bumps a code only past other city codes (`used`). It never checks FWA codes.
2. The later uniqueness pass `_bump_wsc` (build_dataset.py:823-842, called at :1241) also checks only city codes.

**Why the result differs by water.** The atlas folds a city line into the river item in one of two ways:
- *Seymour and Noons:* the river is bigger, so the city line takes the river's name as a side channel (graph/names.py:181-190). The registry then files it under the river's gnis (registry/build.py:58-67).
- *The `wsc:` items:* everything on one code is grouped, whatever its name. The split-by-name rule at registry/build.py:149-152 applies only to `gnis:` items. That rule is why Kyle Creek and Wilkes Creek did split out.

**When it started.** I checked the git history of the curated file:
- Tunnel Creek and Capitol Creek have collided since the first commit, 2026-09-03.
- Turner, Village and Aliceville moved onto FWA codes on 2026-10-29 (8efa98468, "every FWA line stays"). That day 38 rows left and the codes cascaded. Example: Turner Creek went from 900-057240 to 900-057239, Noons Creek's code.

### The table (rules: every row below shows rule set 0 today, the Zone 2 + province base, 92 rules; Sheldens shows set 8)

| # | City name (source, src id) | Length | Code it got | FWA line owning that code | Distance | Item today | Should be |
|---|---|---|---|---|---|---|---|
| A1 | Tunnel Creek (Burnaby 247) | 216 m | 900-078372 | Seymour River 360886339 (+8 Seymour side lines) | 1,068 m (across Burrard Inlet) | gnis:6105 Seymour River, its part p3; Seymour answers to "Tunnel Creek" | own water "Tunnel Creek", set 0 |
| A2 | Turner Creek (Port Moody 112), with Turner Creek Trib.1 (115, 583 m) | 2,198 m | 900-057239 | Noons Creek 360880849 and unnamed 360244416 | 678 m / 1,082 m | gnis:23366 Noons Creek, p4; Noons answers to "Turner Creek" | own water "Turner Creek" (+ its Trib.1), set 0 |
| A3 | Capitol Creek (Burnaby 297), with Capitol Trib.1 | 722 m | 900-053687 | unnamed 360570081 (city name "Squatters Creek") | 144 m | wsc:900-053687 "Squatters Creek" holds both; alias "Capitol Creek" | own water "Capitol Creek", set 0 |
| B1 | Kask's Camp Creek (Burnaby 161) | 346 m | 900-053873 | unnamed 360788071 (city name "Heron Creek", 903 m) | 1,715 m | wsc:900-053873 is named "Kask's Camp Creek" and holds the Heron line too | two waters: Kask's Camp Creek; Heron Creek keeps the id |
| B2 | Village Creek (Port Moody 321 + 341) | 1,575 + 789 m | 900-058384 | unnamed 360827018 (city name "Schoolhouse Creek North", 1,958 m) | 253 m / 600–726 m | wsc:900-058384 is named "Village Creek" and holds the Schoolhouse line too | two waters. Village Creek. Schoolhouse Creek North gathers the FWA line, its extension and its 10 city pieces |
| B3 | Mamquam Blind Channel Wetland (Squamish 662) | 89 m | 900-103611 | unnamed 360767895 (city name "Logger's Lane Creek", 1,478 m) | 348 m | wsc:900-103611 is named "Mamquam Blind Channel Wetland" and holds the Logger's Lane line | two waters: the wetland; Logger's Lane Creek gathers the FWA line + extension + the city "Loggers Lane Creek" line |
| C1 | Kyle Creek (Port Moody 204.0) | 416 m | 900-056279 | School House Brook 360728050 | 651 m | separate, blk:-2200000296 | same water, new id |
| C2 | Wilkes Creek (Port Moody 134) | 1,461 m | 900-057925 | Hett Creek 360724731 | 610 m | separate, blk:-2200000420 | same, new id |
| C3 | Aliceville Creek (Burnaby 244) + 3 tribs | 1,053 m | 900-059187 | unnamed 360731231 (in no item) | 860 m | wsc:900-059187 | same, new id |
| C4 | Rainbow Creek (Burnaby 338) + 1 trib | 846 m | 900-076392 | unnamed 360455980 (in no item) | 1,519 m | wsc:900-076392 | same, new id |
| D | Sheldens Creek (hand-drawn) | 1,041 m | 950-016367 | 360846083 (Sheldens) | 0 m: its head is the FWA mouth (T806) | wsc:950-016367, set 8 | keep shared, exempt it |

How each column was measured:
- **Distance:** shortest distance between the two lines in EPSG:3005.
- **Item and rules:** from `bundle.sqlite` (`section_measure`, `item_section`, `section_ruleset`).

**Rules do not change.** Every city line already shows only the base set. At Noons and Seymour, the owner's two "leave out" rows keep the river rule off the city line.

**What does go wrong.**
- **The wrong water:**
  - Seymour and Noons each get an extra part.
  - A search for "Tunnel Creek", "Turner Creek", "Capitol Creek", "Heron Creek", "Schoolhouse Creek North" or "Logger's Lane Creek" opens another water.
  - "Schoolhouse Creek North" exists as **10 separate items**, wsc:900-058379 … 058389 (`a3`, bundle `item` table).
- **A risk for later rules:** Turner Creek Trib.1's code (900-057239-436900) sits under Noons Creek's code. Any "Noons Creek and its tributaries" rule would walk into it. No such rule exists today.

## 2. Name variants: is the city name a local name for an FWA stream?

Two sources:
- FWA names within 2 km (`a4_names.py`);
- OpenStreetMap: one Overpass query, base time 2026-11-26T04:15Z, all waterways within 1.2 km of 29 points (`a5_osm.py`, `a6_osm_detail.py`).

"Share" is how much of the city line lies within 80 m of the OSM line of that name.

| Line | FWA names nearby | OpenStreetMap | Verdict |
|---|---|---|---|
| Tunnel Creek | Seymour 1,068 m (north shore), Lynn 1,716 m | no line; nearest named waterway 1.1 km | **Own creek.** It is on Burnaby's side of Burrard Inlet; the Seymour is across the water. A 2012 Burnaby council report proposes the name "Tunnel Creek" for an unnamed stream that runs north from Montrose Park into Burrard Inlet. The name refers to the 1911 water tunnel to the Seymour supply. ([Burnaby council report, 17 Sep 2012](https://search.heritageburnaby.ca/media/hpo/_Data/_CouncilMinutesAndReports/Unrestricted/2012/17-Sep-2012/90898.pdf), seen through a web search on 2026-11-25. I did not confirm that the name was adopted.) |
| Turner Creek | West Noons 261 m, Noons 678 m | **"Turner Creek"**, 14 ways, 87 % of the city line within 80 m; West Noons Creek 254 m away, 0 % | **Own creek** with the same name in OSM. The Port Moody Ecological Society lists Turner Creek among the north-shore streams of Port Moody Arm ([vcn.bc.ca/pmes](https://vcn.bc.ca/pmes/Port%20Moody%20Arm.htm), 2026-11-25; undated page). It is not West Noons Creek. |
| Capitol Creek | none within 2 km | no line; OSM "Squatters Creek" runs on the FWA line 139 m away (0 % overlap) | **Own creek, probably.** The city layer itself draws Capitol and Squatters as two lines 144 m apart. No outside source names Capitol Creek; a web search found nothing. |
| Kask's Camp Creek | none within 2 km | no line; "Simon's Creek" 581 m away | Own creek. The FWA line it shares a code with is 1.7 km away. |
| Village Creek | Mossom 609 m, Windermere 687 m | **"Village Creek"** on it (95 %). OSM calls the FWA line 360827018 "School House Creek North". | Own creek. OSM agrees with the city's names for both lines. |
| Mamquam Blind Channel Wetland | Stawamus 926 m | no line; OSM "Mamquam Blind Channel" 322 m away. **OSM puts "Mamquam Blind Channel" on 30 % of FWA 360767895**, which the city calls Logger's Lane Creek. | The 89 m piece is its own feature. **The name of FWA 360767895 is disputed** (city: Logger's Lane Creek; OSM: partly Mamquam Blind Channel). This is for the owner to look at. |
| Kyle Creek | School House Brook 651 m | an unnamed OSM stream lies along it (100 % within 40 m) | Own creek |
| Wilkes Creek | Hett 610 m | **"Wilkes Creek"** on it (100 %); Hett Creek 298 m away | Own creek |
| Aliceville Creek | Stoney 1,023 m | no line; Cougar and Crab creeks 229–588 m away | Own creek (city-only) |
| Rainbow Creek | McCartney 1,940 m | **"Rainbow Creek"** on part of it (47 %) | Own creek |

**Conclusion: none of the 11 is a local name for the FWA line whose code it took.** In every case the FWA line is a different stream, 144 m to 1.7 km away. So the owner's default, "they stay waters of their own", holds.

Two leftover name questions, neither caused by this bug:
- **(i) FWA 360767895:** is it Logger's Lane Creek, or the Mamquam Blind Channel?
- **(ii) The side find from earlier:** the city puts the name "West Noons Creek" on the unnamed FWA line 360244416 (346 m). OSM leaves that line unnamed and puts West Noons Creek 7 m away. It is probably the lowest bit of West Noons Creek. Today it sits in the Noons Creek item because it has Noons Creek's code, which is FWA's own code. This fix does not touch it.

## 3. The fix variants

I re-measured both of the earlier lane's files (`a1`, `a3`). Only `wsc` / `receiver_wsc` change. Lines, blks, names and name_variants are identical.

An item id for a city water is `wsc:<its code>` (registry/build.py:65-67). So **moving a code moves the item id**, and if a neighbour takes the old code, the id now points at a different creek.

The three cases where the FWA line keeps its own code are unavoidable:
- wsc:900-053873 goes from Kask's Camp to Heron Creek;
- wsc:900-058384 goes from Village to Schoolhouse Creek North;
- wsc:900-103611 goes from Mamquam Wetland to Logger's Lane Creek.

In each case the city line was squatting on FWA's code.

| | V1 plain bump | V2 no cascade (`l30/t1150-wip.diff`) | **V3 recommended:** V2 + continuation exempt + keep earlier codes + no reuse of an old code |
|---|---|---|---|
| Rows that change | 83 of 324 | 31 | **about 29** (estimated: V2 minus Sheldens and Logger's Lane Trib 4) |
| Item ids touched today | 81 | 30 | about 28 |
| …of which now point at a DIFFERENT creek | **33** (wsc:900-078374 Mill Creek becomes Starfish Creek, and so on along the coast) | 6 (the 3 unavoidable + 058385, 103610, 950-016367) | **3** (the unavoidable ones) |
| …gone | 48 | 21 | about 21 |
| Ids in the public slug map (`app/seo/slug-map.json`) | 80 | 29 | about 28 |
| FWA codes still shared afterwards | 11 rows, all deliberate: the 10 Schoolhouse pieces + Loggers Lane Creek, joined to the FWA line they extend | the same 11, deliberate | the same 11 + Sheldens, deliberate |
| Sheldens Creek | moved: **wrong** (DFO places name wsc:950-016367, `dfo_salmon/places/region-6.json` lines 498 and 3523; T806) | moved: **wrong** | kept |
| Will a future regeneration cascade? | yes | yes: the codes are still assigned in minting order | no: a stream keeps its code unless it hits an FWA code |

How the V2 and V3 columns were reached:
- **V2 ids:** from `a3_ids.py`.
- **V3:** not regenerated. It is a design, with the numbers estimated from V2.

**V3 in words.**
1. Mint tidal codes as today.
2. A code that equals an FWA code moves to the nearest free Level-2 slot. "Free" means:
   - not an FWA code anywhere in BC;
   - not another city code;
   - not a code any water held in the previous file. This stops a freed id being handed to a neighbour.
3. A line whose head is an FWA line's mouth keeps the FWA code. That is the T806 continuation, tested in `_carry_continued_order` (build_dataset.py:1583-1605).
4. A tidal stream that had a code in the previous file keeps it unless that code collides. This is the same idea as `_keep_previous_blks` (build_dataset.py:1636-1682), which keeps blks stable.

The tributaries re-mint under their new parent, so they stay "in the graph all the way down". The rowdiffs show this, for example Turner Creek Trib.1 900-057239-436900 → 900-057246-436900. The new Level-2 numbers are only estimates of position along the coast, as they are today.

**The "reserved code range" idea.** Example: give every city coastal creek a Level-2 in a band that FWA never uses.
- It would also stop the cascade.
- But FWA does not reserve any band, so a later FWA release could still land on one. The check in section 4 would still be needed.
- A deeper code, under the river's own code, would make the creek a *tributary* of that river for rules like "X and tributaries", which is exactly this bug.

V3 gives the same protection without moving all 37 codes. Not recommended.

**Resync, recommended variant (V3):**
- **Owner marks** (`data/curated/review/marks.jsonl`): none name an affected id or blk (grep). No resync needed.
- **Matches:** no synopsis entry is matched to an affected item, except Noons and Seymour (`entry` table). Their ids do not change.
- **His two "leave out" rows** (`unplaced_piece_calls.json`, noons_creek.r1 / -2200000392:0 and seymour_river.r1 / -2000000390:0) **go stale in every variant.** The pieces leave those rivers, so the rules no longer meet them. A stale row stops the reach run (reach/build.py:1626-1641, `unplaced_gate`). They have to be removed in the same change, with his OK.
- **`continuations.json` has a reviewed owner row that is ALREADY stale.** It reads "Aliceville Trib.1-1 → Aliceville Trib.1" and is keyed wsc:900-059194-…. Since 10-29 those ids have been wsc:900-059187-…, so the bundle holds the link instead of shipping it (`continuations_held.json`, status "label"). V2 and V3 move the ids again. The fix should re-key this row to the new ids. It is his row, so he says yes.
- **`name_variants.json` line 73221:** the Sheldens note cites wsc:900-053687 and wsc:900-053873 as examples of a shared code. Text only, but it will be wrong afterwards; reword it.
- **Public site** (`app/seo/slug-map.json`): ~28 ids change. The slug map is already out of step today: **11 city creek ids in it now name a neighbouring creek.** Example: wsc:900-057240 is "turner-creek-r2-near-port-moody" in the map but Suter Brook Creek in today's bundle. Cause: the 10-29 cascade, after the map was made. Regenerate the map in the same release.
- **Tests and fixtures naming affected ids:**
  - app/tools/item-id-links.test.ts:28 (blk:-2200000296 Kyle Creek);
  - app/fixtures/golden/taps.json:5608 (blk:-2200000420 Wilkes);
  - app/seo/legacy-crosswalk.json:33598.
  - The pipeline tests that mention the Noons piece (test_reach_drops_nothing.py:116-124, 264-283; test_shore_cuts.py:76) use made-up data and should not need changes. Not run.

**Expected atlas parity (V3, predicted, not built):**
- Seymour River: −1 section (-2000000390:0, 215 m), parts 4 → 3, alias "Tunnel Creek" gone.
- Noons Creek: −1 section (-2200000392:0, 2,198 m), parts 5 → 4, alias "Turner Creek" gone. It keeps its "West Noons Creek" alias.
- Squatters Creek: −Capitol Creek.
- wsc:900-053873 becomes "Heron Creek" (FWA only).
- wsc:900-058384 becomes "Schoolhouse Creek North": the FWA line + extension + 10 city pieces. Its 9 other item ids go.
- wsc:900-103611 becomes "Logger's Lane Creek": the FWA line + extension + city line -2100000129. Its old id wsc:900-103610 goes.
- New waters: Tunnel Creek, Turner Creek, Capitol Creek, Kask's Camp Creek, Village Creek, Mamquam Blind Channel Wetland.
- Kyle, Wilkes, Aliceville (+3), Rainbow (+1), Capitol Trib.1, Turner Trib.1, Finch Creek: new ids only.
- Net item count: about −5. That is +1 each for Seymour/Tunnel, Noons/Turner, Squatters/Capitol and Kask's/Heron, and −9 for Schoolhouse.
- Nothing outside these waters.
- **Possible extra change:** Turner and Tunnel are skipped by the coast cut today. They sit in rivers whose owner limit governs them (splits/shore.py:91-110, T685), and `shore_cuts.json` has no row for either. Once they are their own waters the coast cut will look at them. If their lines run inside the sea polygon, as Suter Brook's does (cut at 130 m), they gain a cut and new piece ids. I could not measure this: the polygon read ran past the 5-minute limit. The side atlas will show it.

**Expected rule-binding diff (V3):**
- No rule gains or loses a section: every affected city line is in base set 0 before and after.
- The only diagnostic change: the two "unclassified" rows in `rule_diagnostic.jsonl` (lines 291 and 319) go away, together with his two accepted rows.
- If the coast cut does add a cut on Turner or Tunnel, their tidal part moves to the tidal rules. That would be the only real binding change, and it is attributable.

## 4. The build-time check

**Rule.** A city line (not an extension) whose code equals an FWA line's code must lie within 80 m (`_CONNECT_TOL`, build_dataset.py:44) of that FWA line or of that line's city extension. Otherwise it is refused by name: "blk … (Tunnel Creek) has the Seymour River's code 900-078372 but lies 1,068 m from it". A T806 continuation passes, because its distance is 0 m.

**Where it goes:**
1. **The atlas build** (the one that matters, because the curated file is stored and the atlas never recomputes it): pipeline/atlas/build.py, right after `fids += add_fids` at line 559. Every FWA fid in BC is in hand there. Raise `SystemExit` listing each refused line, like `_apply_fwa_exclude` at build.py:283-295.
2. **The generator** (so a bad file is never written): build_dataset.py `resolve_and_mint`, after the uniqueness pass (~line 1243), using `fwa_chains`. Raise `ValueError` like the propagation check at :1294-1296. `validate.validate_propagation` cannot do it, because it sees only the city rows (validate.py:29).

**What it would have caught** (simulated in `a7_check_sim.py`):
- On today's file it refuses **exactly the 11 lines (12 rows)** by name. Their distances are 144 m to 1,715 m, all over 80 m. Sheldens passes at 0 m.
- On both variant files it refuses nothing. The 11 deliberate shares are all 0 m from the FWA line or its extension.
- It would have stopped the 2026-10-29 regeneration that moved Turner, Village and Aliceville onto FWA codes, and the 2026-09-03 file that already had Tunnel and Capitol.

## 5. Recommended plan (hardening release)

1. **Code** (S):
   - `coastal.py`: an "off FWA codes" step, a "keep earlier codes" step, the continuation exemption, and never reusing a code from the previous file.
   - `_bump_wsc` also skips FWA codes.
   - The two checks from section 4.
   - Unit tests: a Tunnel-like case refused; the Sheldens-like case passes; a regeneration keeps an existing code; no code from the previous file is reused by another stream; a mutation pin.
2. **Regenerate into a side folder.** Proof: the row diff is about 29 rows with only `wsc` / `receiver_wsc` changed, the new codes collide with no FWA code anywhere in BC, Sheldens is unchanged, and running it again gives the same bytes. Show the owner the row list as a proposal.
3. **Curated changes in one proposal, each with his OK:**
   - the new `added_streams.json`;
   - remove his two `unplaced_piece_calls.json` rows;
   - re-key the Aliceville row in `continuations.json`;
   - reword the Sheldens note;
   - a `pipeline/docs/GOTCHAS.md` entry: "a city coastal line must never take an FWA code; which line is the real stream".
4. **Side atlas** (~32 min) and parity against section 3's list, stated before the run. Anything else stops the lane and goes to the planning chat. Check the coast-cut result for Turner and Tunnel.
5. **Side reach** (~33 min with tiles + deliver) and a line-by-line binding diff. Expected: zero rule-section changes, plus any coast-cut change on Turner or Tunnel; nothing else.
6. **Resync:** slug map regenerated (about 28 + the 11 already-stale ids), the two app fixtures, `legacy-crosswalk.json`.
7. **The owner's look:** before/after pictures of the six named waters (Seymour, Noons, Squatters, Kask's/Heron, Village/Schoolhouse North, Mamquam/Logger's Lane), plus the name question on FWA 360767895.

Size: M. About one day of lane work: code S, data proposal S–M, one side atlas + reach about 65 min of machine time, resync S.

## Picks for the owner

1. **Which fix?**
   - (a) **V3: own codes, nothing cascades, no old id reused (recommended);**
   - (b) V2 no-cascade as drafted, with Sheldens exempted;
   - (c) V1 plain bump: 83 rows, 33 ids re-pointed.
2. **Your two "leave out" rows** (Noons, Seymour):
   - (a) **remove them in the same change; the pieces stop being part of those rivers (recommended);**
   - (b) keep them until you have looked at the pictures. The reach run stops until then.
3. **Group C** (Kyle, Wilkes, Aliceville, Rainbow: already separate waters, only the code is shared):
   - (a) **fix them too, which changes their ids (recommended; your "all 11");**
   - (b) leave their codes as they are.
4. **FWA 360767895 near Squamish:** the city calls it Logger's Lane Creek; OpenStreetMap puts "Mamquam Blind Channel" on part of it.
   - (a) **Logger's Lane Creek, the city's name (recommended);**
   - (b) Mamquam Blind Channel;
   - (c) look at the picture first.
5. **The reviewed Aliceville continuation** (keyed on old ids, held since 10-29):
   - (a) **re-key it to the new ids in the same change (recommended);**
   - (b) leave it held.

## NEW TICKET lines

- NEW TICKET: Public slug map is out of step with item ids. 11 city creek URLs in `app/seo/slug-map.json` name a neighbouring creek since the 2026-10-29 code cascade (for example turner-creek-r2-near-port-moody → today Suter Brook Creek). Regenerate the map and decide redirects.
- NEW TICKET: City "West Noons Creek" name sits on the unnamed FWA line 360244416, inside the Noons Creek item. It is probably West Noons Creek's lowest reach. Owner look.
- NEW TICKET (later, optional): A water made only of city lines takes its id from its code (`wsc:`), so any code change moves its URL and its links. Consider keying such waters by their stable blk. This would be a one-time large id change; only if the owner wants it.

## Not verified

- **V3 is a design and was not run.** Its numbers are estimates from V2.
- **Whether the coast cut will add a cut on Turner or Tunnel.** The tidal-polygon read took over 5 minutes and was stopped.
- **How the live website resolves the slug map.** I did not check whether the 11 stale ids show the wrong creek on the site today.
- **Whether anything reads the Level-2 position order of the coastal codes.** I believe nothing does; not checked.
- **Pipeline and app tests:** none were run.
- **Gray Creek's mouth 288 m from its receiver:** not judged.
- **Outside sources:**
  - the Burnaby report shows the name Tunnel Creek was proposed in 2012, but I did not confirm it was adopted;
  - the Port Moody Ecological Society page is undated;
  - no outside source names Capitol Creek or Kask's Camp Creek.
- **Freshness of the data I read:** the graph node dump is the earlier lane's (made 17:12 from the 03:20 atlas). The bundle and atlas are the files present tonight. A release build was running and may replace them.
