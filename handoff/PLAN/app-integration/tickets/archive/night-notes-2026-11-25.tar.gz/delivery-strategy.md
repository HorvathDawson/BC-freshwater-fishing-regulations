# Shipping small and often: trains, over-the-air updates, flags, web deploys, the data contract (night of 2026-11-25)

Read-only night agent. The repo was read at main `41d87c507` (the planning worktree) and at `origin/release/0.10.0`.
Nothing was changed, run, pushed or uploaded. Every outside page was read on **2026-11-25**; its URL sits beside the fact.
"Guess" marks an estimate. Helper scripts and their output are in `night/delivery-strategy/`:
`native_share.py` + `.txt`, `native_detail.py` + `.txt`, `section_versions.py` + `.txt`, `merge_to_users.py` + `.txt`.

Built on tonight's notes, not redone: `release-timeline.md` (machine work is about 4 h of a 17 h release),
`ci-merge-queue.md` (a code PR takes 40 min), `ci-speed-build-plan.md` (xdist, no push run on main, title check, pins,
caffeinate, pre-cut gate), `ship-workflow-design.md` (one ship workflow per environment, T1133), `fewer-questions.md`.

## The short answer

You asked for two things at once: two trains (data and web small and often, store builds batched and rare), and
small releases that are faster. They fit together. Here is the shape I recommend:

1. **Three trains now, and maybe a fourth later.**
   - **Data:** on demand, same day. The data-only path already exists.
   - **Web:** from main, one approval click, same day.
   - **Native store build:** every 2–3 weeks, in batches.
   - **Phone JavaScript over the air (OTA):** a fourth train, decided after two weeks of measuring (see 3).
2. **Today, the web cannot ship without the phones.** A web-only change bumps the app version, and the release
   runbook then builds both phones (`release-by-hand.md:80-81`). The first step is a web-only release path. It is
   small, and it is the step that lets you do "stuff in web first".
3. **OTA fits this app less well than it seems.** I checked every app version since 0.4.0. **20 of 32 version steps
   changed native code or native build config** (MapLibre patch, our three native modules, plugins). That leaves 12
   that were JavaScript only (`native_share.txt`). Since 0.8.3 every version has touched native code. An OTA built
   from main only reaches phones whose native build matches, so most weeks OTA would have to come from a release
   branch. It is still worth doing for fixes, but after the cheaper steps, and only if native churn falls.
4. **The data contract is mostly built. It has two blind spots.** The answers-section versions and the list of
   required files are checked by the app, but not by the release gate (section 4). There is also no rule that
   stops a data release from cutting off the phones in use. Close those two gaps, and a web-first or data-first
   release cannot force an app release by accident.
5. **Merge to users today.** For the 37 code PRs in 0.9.0, the median time from merge to production data was
   **24.7 h** (13.6–40.4 h; `merge_to_users.txt`). The target is the same day for data and web.

---

## 0. What is there today (facts read tonight)

| Fact | Where |
|---|---|
| **No OTA.** `expo-updates` is not a dependency, not in the lockfile (0 matches) and imported nowhere. No `updates` or `runtimeVersion` key in `app.json`. `eas.json` has build profiles only, with no channels. | `app/apps/mobile/package.json:15-46`; `app/pnpm-lock.yaml` (grep); `app/apps/mobile/eas.json:1-19` |
| The only "app update" is the store's own: `expo-in-app-updates` (Play in-app updates). | `package.json:33`; `app/apps/mobile/src/appUpdater.native.ts` |
| **No feature-flag system** (grep for flag/toggle/remote-config: nothing). Build-time switches do exist and work as flags: `EXPO_PUBLIC_MAP_LAB` (refused in a production build), `EXPO_PUBLIC_REGS_ONE_BY_ONE`, `EXPO_PUBLIC_RELEASE_GATE`, `EXPO_PUBLIC_TROUT_TABLE`. | `app.config.js:25-28`; `apps/mobile/index.js:53-54`; `App.tsx:267, 399-400` |
| `EXPO_PUBLIC_UPDATE_CHANNEL` is the **data** channel (live / test), not code. | `apps/mobile/src/env.ts:127-138` |
| **The app version is put into the JavaScript bundle when it is built.** `APP_VERSION` comes from `app.json` through Metro. So an OTA bundle would carry its own version. | `apps/mobile/version-stamp.js:25-32`; `src/config.ts:48` |
| **The data gate on a phone:** a manifest whose `minAppVersion` is above this app's version is never installed, and the data in use is kept. | `packages/core/src/appVersion.ts:99-105`; `packages/data/src/release/boot.ts:400` |
| **The web is never gated by version.** Its safety is the site gate before an upload: the live site must be at least the release's `minAppVersion`. | `App.tsx:350-352, 399-400`; `pipeline/deliver/release/site_gate.py:1-13` |
| **The table that drives the release gate:** `app_reads.json`, one row per app version saying what each release file's reader accepts. `app_gate` works out the oldest app that reads everything. Kept by `app_reads --check` in `pnpm check`; the cut writes the row (T1048). | `pipeline/deliver/release/app_gate.py:10-15, 36-78`; `pipeline/tools/emit/app_reads.py:1-30` |
| Feeds are gated the same way. Every feed index carries `minAppVersion`; today all are `0.0.0`. | `packages/core/src/feedFormats.generated.ts:28-37` |
| Tiles pair with data through `tiles.compatible`; there is no format number. | `packages/data/src/release/boot.ts:477-478`; `manifest.ts:159-161` |
| **"Additive" is a habit, not a check.** The contract marks additions "ADDITIVE, last, nullable — still core/1" in comments. Nothing compares the contract with the one a shipped app was built against. | `pipeline/deliver/release/contract.py:108-152, 204-247` |
| CI already rebuilds the committed **mini release** (an invented release built by the real pipeline) and fails if it moved. | `.github/workflows/pipeline-ci.yml:134-137`; `pipeline/tools/mini_release.py:1-15` |
| **One version line for web and phones.** Only `app/` commits bump the version, and an app release builds both phones. A data-only release exists; a web-only one does not. | `handoff/PLAN/runbooks/release-by-hand.md:80-81, 99-100, 436-452` |
| The site is the web export plus about 60,000 SEO water pages built from a release. `--relink` re-points stored pages at a new export without rebuilding them. | `deploy/staging/site-all.sh:6-12, 42-57` |
| Production data stamps: `minAppVersion` 0.8.0 for releases of 11-18 to 11-20, **0.8.4** from 11-21 (the production release r-0aec88ed3edb). | the main checkout's `data/release/r-*/manifest.json`, read-only |

---

## 1. Over-the-air JavaScript updates (expo-updates, self-hosted)

### 1a. What the store rules say (quoted)

- **Apple, Developer Program License Agreement §3.3.1(B) "Executable Code":** "Interpreted code may be downloaded to
  an Application but only so long as such code: (a) does not change the primary purpose of the Application by
  providing features or functionality that are inconsistent with the intended and advertised purpose of the
  Application (b) does not bypass signing, sandbox, or other security features of the OS; and (c) for Applications
  distributed on the App Store, does not create a store or storefront for other Applications."
  https://developer.apple.com/support/terms/apple-developer-program-license-agreement/ (no version date on the page).
- **Apple, App Review Guideline 2.5.2:** apps may not "download, install, or execute code which introduces or changes
  features or functionality of the app". **2.5.19:** "Don't include any hidden, dormant, or undocumented features in
  your app". **2.3.1(a):** "All new features, functionality, and product changes must be described with specificity in
  the Notes for Review". https://developer.apple.com/app-store/review/guidelines/
- **Google Play, Device and Network Abuse:** "an app may not download executable code (such as dex, JAR, .so files)
  from a source other than Google Play. This restriction does not apply to code that runs in a virtual machine or an
  interpreter where either provides indirect access to Android APIs (such as JavaScript in a webview or browser)."
  https://support.google.com/googleplay/android-developer/answer/9888379
- **Expo:** "you need to follow the rules of the platforms and app stores … This usually means changes to your app's
  behavior need to be reviewed." Expo lists JavaScript bug fixes, copy, styling and layouts as fit for an update.
  Native code, permissions and SDK upgrades need a new build. https://docs.expo.dev/eas-update/introduction/

**What this means here:**
- Google's rule clearly allows JavaScript run by the Hermes engine.
- Apple allows downloaded interpreted code within the app's purpose, but 2.5.2 forbids code that "introduces or
  changes features".
- The honest line: **OTA for fixes, copy and small UI; new features ride a store build** (or are declared in review
  notes).
- Whether Hermes bytecode counts as "interpreted code" is not stated by Apple. Expo's hosted update service ships
  exactly this to App Store apps at scale, but that is precedent, not a ruling. **Not verified.**

### 1b. How it would work (the Expo Updates protocol, our own server)

The protocol is open, and any server that follows it may serve updates:
- The phone sends `expo-platform` and `expo-runtime-version`.
- The server returns a manifest (`id`, `createdAt`, `runtimeVersion`, `launchAsset`, `assets[]`, each asset with
  its SHA-256 in base64url) as JSON or `multipart/mixed`.
- A `rollBackToEmbedded` directive is defined.
- Code signing: the phone sends `expo-expect-signature` and checks the `expo-signature` header (`rsa-v1_5-sha256`)
  against a certificate built into the app.
- "An asset located at a particular URL MUST NOT be changed or removed." Manifests should be served with
  `private, max-age=0`; assets with `immutable`.

https://docs.expo.dev/technical-specs/expo-updates-1/

Expo's example server says it is "not guaranteed to be complete, stable, or performant enough".
https://github.com/expo/custom-expo-updates-server

Signing through Expo's own hosted service needs a paid plan (https://docs.expo.dev/eas-update/code-signing/). We would
sign our own updates, which the protocol allows. The SDK 58 reference documents a custom server, the `updates` keys
(`url`, `checkAutomatically` default `ON_LOAD`, `fallbackToCacheTimeout` default `0`, `codeSigningCertificate`,
`requestHeaders`) and the runtime policies (`appVersion`, `nativeVersion`, `fingerprint`, a custom string).
https://docs.expo.dev/versions/latest/sdk/updates/ (v58, recommended `~58.0.22`)

**Design, fitted to this repo:**

| Piece | What | Where | Size |
|---|---|---|---|
| O1 bootstrap build | Add `expo-updates`. `app.json`: `runtimeVersion: {policy: "fingerprint"}`, `updates.url = https://updates.canifishthis.ca/manifest`, `checkAutomatically: "ON_LOAD"`, `fallbackToCacheTimeout: 0` (never wait on the network at launch), `codeSigningCertificate` + metadata, `requestHeaders: {"expo-channel-name": <staging/production from EXPO_PUBLIC_APP_ENV>}`. One store build per platform carries it; until then nothing changes. | `app/apps/mobile/app.json`, `package.json`, a `fingerprint.config.js` that adds `app/patches/**` and `apps/mobile/modules/**` | S–M |
| O2 update server | A small Worker route (on the data worker or its own `updates.` host). It reads `ota/<channel>/<runtime>/<platform>/current.json` from R2 and returns that manifest with its **pre-computed** signature. It holds no key and signs nothing. Assets are served from R2 at `ota/assets/<sha256>` with `immutable`. A 204 or an empty response when there is no update. | `app/workers/` (new route) + tests | M (about 200 lines + tests, guess) |
| O3 publish tool | `expo export --platform android,ios`. Every asset is hashed and put by content (never overwritten). The manifest is written and signed with the private key, then the pointer is flipped. The old pointer is kept as `previous.json`, exactly the data release's put/flip shape (ship-workflow-design 2.3). | `app/tools/ota-publish.mjs` | M |
| O4 workflows | `ship-ota-staging` on a tag or dispatch. `ship-ota-production` behind the `production` environment (your click), with the signing key **only** in that environment. | `.github/workflows/` | M, after T1133 M0 and T1160 |
| O5 app wiring | The update id goes into crash reports and the crash context. Source maps are kept per update id (`tools/sourcemaps.mjs keep`). The "app update" notice says "restart to finish updating" when an OTA is downloaded. That joins T1073: never promise what the store will not give. | `App.tsx`, `packages/core/src/appUpdate.ts` | S–M |
| O6 the cut decides the train | `release --cut` compares the fingerprint with the last store build's. Same → "OTA train". Different → "store train". Printed, never guessed. | `pipeline/release.py` | S |

**When a store build is still needed.** The runtime version comes from the fingerprint, which hashes "anything that
may impact the native runtime" (https://docs.expo.dev/eas-update/runtime-versions/). For us that is:
- the MapLibre patch (`app/patches/@maplibre__maplibre-react-native@11.5.0.patch`, 129 KB) and the pinned MapLibre
  build (`app/tools/maplibre-android/pin.env`);
- `modules/bg-download`, `exit-info`, `memory-trim`;
- every config plugin;
- Expo, React Native or Hermes upgrades;
- permissions.

I believe the fingerprint does not pick up pnpm patches on its own, hence the extra sources in O1 (**not verified**).

**The measured fit (the honest part).** Script `native_share.py` (`native_share.txt`) diffed each app version's first
commit against the next one on `origin/release/0.10.0`:
- **32 version steps since 0.4.0. 20 touched native code or native config, 12 were JavaScript only.**
- Some of the 20 are borderline: 0.7.0 and 0.8.1 changed 3 and 2 code lines in `app.config.js`, and 0.6.8, 0.7.8
  and 0.7.9 touched the MapLibre patch with lines that only look native (`native_detail.txt`).
- So OTA would have carried **12 to 17 of 32** versions (37–53%).
- **Since 0.8.3 every version (5 of 5) touched native code.**

Because main's fingerprint usually moves ahead of the store build, an OTA built from main would reach nobody until
the next store build. OTA fixes would then come from the open release branch of the shipped runtime, with JavaScript
picks. We already do that for release fixes, so the tooling exists (T1062 rc tags).

**How it meets the data pointer and minAppVersion.**
- An OTA bundle carries its own `APP_VERSION` (`version-stamp.js:25-32`). The phone's data gate would compare the data
  against the **JavaScript reader's** version. That is the right thing: the readers are JavaScript.
- So a data format bump read only by JavaScript (regs, water, core and the other SQLite files) no longer needs a store
  build. It needs an OTA, published first, as the web site goes first today (`site_gate.py`).
- Formats read by native code do still need a store build: tiles, and a paint/style that uses newer MapLibre style
  features.
- New guard (section 4): a data release's derived `minAppVersion` must be at or below the newest **production-channel
  OTA or store version for every supported runtime**. Otherwise it stops.

**Rollback.**
- The phone's own recovery is limited. If an update crashes before its first screen shows, it is marked failed and
  the phone goes back to "an older update, whichever one was most recently launched successfully". After the first
  screen there is no automatic rollback, and "should not be relied upon" (https://docs.expo.dev/eas-update/error-recovery/).
- Our rollback is therefore server-side: flip `current.json` back to `previous.json` (seconds, like
  `deploy/prod/rollback.sh`), or send `rollBackToEmbedded`.
- Whether a phone accepts an *older* update id after a newer one is not stated. To be safe, rollback re-publishes the
  old bundle under a new id and time (**not verified**).

**Staged rollout.** Two channels, staging and production, set by the build (`requestHeaders`). Percent rollouts are
possible in the Worker with a hash of an install id. With a handful of testers that gives no signal, so I would not
build it.

**Size per update.**
- Android: the Hermes bundle of the 11-21 release build is **5,407,888 bytes**. Gzipped it is **2,442,752 bytes**
  (`gzip -9` of `android/app/build/generated/assets/react/release/index.android.bundle` in the main checkout, read
  only).
- Images and fonts: 98 files, 6.3 MB, fetched only when their hash changes.
- So about **2.5 MB per JavaScript-only update**, against about 480 MB of data. iPhone not measured.

**Offline.** `fallbackToCacheTimeout: 0` launches from what is on the phone and checks in the background, so a phone
in the backcountry always opens the last update it has, or the built-in one. `WIFI_ONLY` exists if you want it to follow
the app's mobile-data setting.

**What you click.**
- Once: keep the signing key safe. It goes in the `production` environment and in your offline backup. Losing it means
  a new store build with a new certificate.
- Per update: one approval.

**What it saves.** A JavaScript fix reaches testers without a store build, Play Closed review or Beta App Review. Today
those take about a day or more: 0.8.5's TestFlight external build was approved the next day, and 0.9.0's Closed
review was still pending a day later (`handoff/PLAN/play-production-access/releases.md`). By the measured share, that
is 12–17 of 32 versions.

**Risks.**
- A second production surface: the key, the server, source maps per update.
- A second "version" to reason about.
- R8 and the patched MapLibre build must keep working with `expo-updates` added (untested).
- The Apple wording above.

**Alternatives, and why not:**
- *Microsoft CodePush:* App Center was retired on 2025-03-31 and the repos were archived on 2025-05-20 (search
  results: https://learn.microsoft.com/appcenter/retirement and
  https://github.com/microsoft/react-native-code-push/issues/2675; I did not open the pages).
  Forks exist, but they are third-party SDKs on a dead base.
- *hot-updater:* self-hostable on R2 and D1 (https://gronxb.github.io/hot-updater/guide/getting-started/introduction.html,
  search result only). A younger third-party SDK. `expo-updates` is first-party for SDK 58 and has signing and recovery.
- *A hand-rolled bundle swap:* it would redo hashing, signing, crash recovery and asset handling that
  `expo-updates` already has. No.

**Verdict:** worth building for fixes, after steps R1–R6 below. First measure for two weeks how often main's
fingerprint moves (NEW TICKET, S).

---

## 2. Feature flags: the smallest honest design

There are three tools. Use the cheapest one that fits.

1. **Release flags at build time (most work).** One typed registry, `app/packages/core/src/flags.ts`:
   `{ name, ticket, kind: "release", expires: "YYYY-MM-DD", staging: true, production: false }`.
   - The value is read from `EXPO_PUBLIC_APP_ENV`, the same switch `app.config.js:20` uses. A half-built feature
     merges to main, shows on staging, web preview and staging phone builds, and is off on production.
   - It joins `EXPO_PUBLIC_MAP_LAB` (`app.config.js:25-28`) as the pattern.
   - No network and no third party.
2. **Gate on the data being there (for data-driven features).** The feature shows when the release carries its file
   or column. The app already does this for additive columns ("an older release has neither and the app says…",
   `contract.py:141-152`). The data release is then the switch, which fits "data first, then web".
3. **A remote kill switch (later, only if wanted).** `https://data.canifishthis.ca/config/flags.json`:
   `{format: "flags/1", minAppVersion, flags: {name: {on, minApp?, platforms?}}}`.
   - Read like a feed index: through `feedGate`, last copy kept, the built-in value when offline or absent.
   - Written only by a workflow behind the environment.
   - Use it to switch things **off**. Switching a feature **on** in a store build without review rubs against Apple
     2.5.2 / 2.5.19 (above), so features turn on through a store build or OTA, on the web freely.

**Merging switched off.** The PR adds the registry entry (production false), the code behind `flag("x")`, and tests for
both states. CI runs as today, with the production defaults.

**Tests for both states.** A `withFlags({x: true})` helper for vitest. Each flag's screens get one test per state.
Hodgson's advice: test "the current production toggle configuration plus any toggles which you intend to release
flipped On", the fallback with them Off, and optionally all On
(https://martinfowler.com/articles/feature-toggles.html, Pete Hodgson, 2017-10-09). Here that means one extra vitest
project with `ALL_FLAGS_ON=1` over the files that import `flags`. Not the whole suite.

**Removal.** `app/tools/check-flags.mjs`, run in `pnpm check`:
- every flag names a ticket and an expiry;
- past its expiry it fails;
- at most 5 live flags.

Removing a flag means deleting the entry. TypeScript then fails at every use, and the agent deletes the off branch.
Hodgson: release toggles "should generally not stick around much longer than a week or two" (same page).

Size: S–M (about half a day for 1 + 2 with tests; the kill switch another half day). Risk: low. Saves: no feature
waits for a release to merge.

---

## 3. Web deploys from main

**Today:** the site ships only inside a release.
- Staging: `site-all.sh`, about 15 min by its own comment (`:7`, not measured).
- Production: `CONFIRM_PROD=canifishthis.ca deploy/prod/site.sh` at the Mac (ship-workflow-design P7).

**Proposed, in three parts:**

| Stage | Trigger | What | Data | Time |
|---|---|---|---|---|
| **Preview per PR** | a PR touching `app/**` (not from a fork: no secrets there) | `expo export --platform web` (index bundle 3.9 MB + 351 KB, `app/dist/web-staging/_expo/static/js/web/`), app only, no SEO pages. Uploaded with `wrangler versions upload --preview-alias pr-<n>` to a separate `canifishthis-preview` Worker. `noindex`. URL in a PR comment | **staging** data host | guess 5–10 min |
| **Staging on merge** | push to main touching web paths | export + `--relink` the SEO pages built on staging's current release (stored in R2: the ship-workflow NEW TICKET) + deploy + `smoke-staging.mjs` | staging pointer, untouched | guess 10–20 min |
| **Production** | your approval (`production` environment), or automatic (a pick) | the same export, relinked to **production's** stored SEO pages, deployed with `--tag <commit>`; `wrangler rollback` on a failed smoke | production pointer, untouched | guess 10–20 min after the click |

Cloudflare facts: Version URLs come from `wrangler versions upload`, with `--preview-alias`. "If Version URLs are
enabled, the URL is public". They run "against production resources" and only on `workers.dev`
(https://developers.cloudflare.com/workers/configuration/previews/). Gradual deployments can split traffic, but
"Their open pages may still request files from the previous release"
(https://developers.cloudflare.com/workers/configuration/versions-and-deployments/gradual-deployments/). T1016's
auto-refresh handles that skew, so a split rollout is not needed. Testers are few.

**The data pointer stays independent.**
- A web deploy never moves a pointer. It reads the live one at run time.
- Two checks gate it. First, `site_gate` as today: the site is at least the live release's `minAppVersion`. Second,
  NEW: before production, the new web code's `readsRelease` (`manifest.ts:110-130`) is run against the **live
  production manifest**. That is "new code reads old data", the reverse of section 4's test.
- Fixed SEO keys (`map-assets/v1/**`) are untouched.
- T1016 (b) notes the web has no version gate of its own. That gap stays harmless while the site gate holds.

**Production: the options and their risk.**
- **(A) One click per deploy** (the default; it keeps `CONFIRM_PROD` yours). A web deploy is cheap, so batch: one
  click a day for whatever merged.
- **(B) Automatic for web-only changes** after a green staging smoke, with automatic rollback on a failed production
  smoke. Fastest. It changes your rule that production is yours, so it needs your explicit standing yes. The risk
  is a bug that passes CI and the smoke and reaches anglers for minutes to hours. The user count is tiny today.
- **(C) As today**, inside releases.

**Versioning.** Keep one version line. A web-only release is an ordinary cut (`release --cut --web`) that ships
web, data if changed, and the feeds worker if changed, and **skips the phone builds**. The next phone build takes a later
version; its What's-new covers everything since the last phone version. `app_reads` rows are written at the cut as now
(T1048), so the gates still know each version's readers.

Depends on: T1133 M0 (secret clean-up) and M3 (the site from CI), T1160 (agents' own identity, so your click means
you). Size: M (2–3 days of agent work, guess). Saves: the web leaves the release ceremony; merge → web production the
same day.

---

## 4. The data contract between releases and app versions

### Where formats are versioned today

| Part | Versioned by | Gate | Gap |
|---|---|---|---|
| Release files (SQLite and JSON) | `format` per file in the manifest; `contract.FILES` → `pack.generated.ts` | `app_reads.json` + `app_gate` derive `minAppVersion`; the phone refuses newer (`boot.ts:400`) | none for formats |
| **Answers sections** (ladder 1, rows 34, gear 12, licence 7, display 20, trout 5, glossary 5) | `manifest.regulations.versions`; the app needs **exact equality** (`manifest.ts:116-122`, `packages/core/src/regs/versions.ts:23`) | writer = reader at HEAD only (`pipeline/tests/test_answers_versions.py:1-20`) | **not in `app_reads.json`** (`app_reads.py:75-88` records files only). A section bump with no file-format bump would be refused by every older app, and `app_gate` would not raise `minAppVersion`. In history the bumps happened to coincide with format bumps (rows 34 + trout with regs-region/2 at 0.8.0; `section_versions.txt`) |
| **Required files** | `PACK_FILES` minus `PACK_OPTIONAL` (`manifest.ts:123-126`) | none in the gate | dropping a file an old app requires breaks that app silently |
| Tiles | `tiles.compatible` + `section_handles` | one-vintage rule (ship-workflow-design 2.4) | no format number. A tile schema change needs a store build if MapLibre must read it differently |
| Feeds | `FEED_FORMATS` + `FEED_MIN_APP` (all `0.0.0`) | `feedGate` | fine |

**History.** Script on `origin/release/0.10.0`'s `app_reads.json`: 11 distinct reader sets across 38 version rows.
Since 0.4.0 the formats moved at 0.5.0, 0.6.0, 0.7.0, 0.7.12, 0.8.0, 0.8.4 and 0.8.5.
- 0.6.0 and 0.8.5 only added or dropped an old format the reader still took.
- 0.8.4 is the textbook case: the reader learned `climate/2`, `down/2`, `near/2` and `paint/6` while still reading
  the old ones. That is Fowler's expand step ("Add the new version alongside the old one",
  https://martinfowler.com/bliki/ParallelChange.html, Danilo Sato, 2014-05-13).
- Production `minAppVersion` went 0.8.0 → 0.8.4 on 11-21, so the data cut off older phones twice in four days.

### Proposed

1. **Close the blind spots (S).** `app_reads.py` records `regulations` section versions (as `section:<name>/<n>`) and
   the required-file list in each row. `app_gate.needs` treats them like formats. `--backfill` proves the old rows
   from git, as it did for formats.
2. **The floor rule (S).** A data release stops when its derived `minAppVersion` is above the **oldest app version still
   on a store track** (and later, every supported OTA runtime's newest production update). The floor is read from
   production R2's `app/android/play.json` (ship-workflow-design P2) and the TestFlight record, else from a committed
   `pipeline/deliver/release/shipped_apps.json`. The escape is `--raises-floor "<why>"`, printed and kept in the
   ledger. This is the line that makes "a web-first release forced an app release" impossible by accident.
3. **The additive rule, as code (S–M).** A test diffs `contract.FILES` at the floor version's commit against HEAD.
   Within an unchanged format only these may happen: new columns appended last and nullable; new tables in
   `OPTIONAL_SECTION_TABLES`; new files (old apps skip unknown files, `app_gate.py:14-15`). Anything else (a dropped,
   renamed, retyped or reordered column, a dropped required file) must bump the format, so the gate sees it. Web-first
   features add new files or columns. A format is replaced only by expand → store/OTA build that reads both → contract.
4. **The old reader reads the new data (M).** The test you asked for:
   - **Keeping old readers runnable:** at each store build (the rc tag), bundle that version's data reader with
     esbuild into one Node file (`reader-<version>.mjs`: `readsRelease`, the SQLite opener over `node:sqlite` as
     `release-boot.test.ts` already does, and the golden page queries of `app/conformance`). Keep it as a GitHub
     Release asset with its sha256, which is self-hosted. No old `node_modules` and no old checkout at test time.
   - **CI:** in `pipeline-ci.yml` beside the mini-release check (`:134-137`), run every reader since the floor (2
     distinct today: 0.8.4, and 0.8.5–0.10.0) against the committed mini release. Each must accept it and open every
     file it holds, or be refused **by the gate as well**.
   - **Release:** a new follows row runs the same readers on the real candidate (guess: 2–5 min).
   - Until the bundling exists, a fallback: `git worktree` at the version commit + `pnpm install --frozen-lockfile`
     (cached by that lockfile) + `vitest run app/conformance/src/release.test.ts` with `RELEASE_DIR` (guess: 4–8 min
     per reader).

Saves: data and web ship alone without the fear of stranding phones. A format mistake is caught on the PR, not after
an upload, as the 0.2.0 paint/5 one was (`app_gate.py:5-6`).

---

## 5. The release-train calendar

| Train | What rides it | Cadence (proposed) | Merge → users, today (measured) | Target |
|---|---|---|---|---|
| **Data** | rules, curated data, pipeline output, feeds seeds | on demand, at most daily | inside the app release: median **24.7 h** merge → production data (n=37, 0.9.0; `merge_to_users.txt`) | build 30–35 min + follows 25–40 min clean + staging upload 2–5 min + smoke 1 min (release-timeline.md, ship-workflow-design S3b/S3d) → **2–4 h**, then your one click |
| **Web** | app code that the web runs, SEO pages, site worker | every day with merges; one click a day | inside the release, same 24.7 h | merge (40 min today, about 20 after xdist, guess) + staging 10–20 min (guess) + your click → **same day** |
| **Phone JS (OTA)** *(if built)* | JavaScript fixes, copy, small UI for the shipped runtime | weekly or as needed, from the open release branch | not possible today | staging channel about 15 min after the pick (guess); production on your click; a phone takes it at the next open (background download) and runs it the open after |
| **Native store build** | native modules, the MapLibre patch or pin, plugins, permissions, SDK upgrades, features Apple must review | every 2–3 weeks, batched; scope frozen at the cut | cut → production 13.6 h (0.9.0) after a 28 h batch; then store review: TestFlight external the next day (0.8.5), Play Closed still pending after a day (0.9.0) | the one-day patch day of release-timeline.md §5; store review outside our control |

Which train a change rides is worked out, not chosen:
- the fingerprint moved → store;
- `app/` changed for the web only, or the fingerprint is unchanged → web (plus OTA if built);
- only `pipeline/**`, `data/curated/**` → data.

The cut prints it (O6, and the `--web` path).

---

## 6. What the industry does, and what not to copy

- **Trunk-based development:** "developers collaborate on code in a single branch called 'trunk' … and resist any
  pressure to create other long-lived development branches". Release branches are "cut from the trunk on a
  just-in-time basis" and deleted after. Feature flags are used "in day to day development to allow for hedging on the
  order of releases". https://trunkbaseddevelopment.com/ — We already do this: `main` plus short `release/x.y.z`.
- **Continuous delivery metrics (DORA):** change lead time, deployment frequency, failed deployment recovery time,
  change fail rate, rework rate; "speed and stability are not tradeoffs". https://dora.dev/guides/dora-metrics/
  (updated 2026-01-05). Our lead time is the 24.7 h above.
- **Mobile release trains:**
  - Monzo cuts weekly on Tuesday. Beta to about 25,000 on Thursday, Android at 10% on Friday, everyone on Monday.
    Half-done work is hidden: "when a feature is half-done, we keep the feature flag disabled until it is complete."
    https://monzo.com/blog/2022/06/23/our-mobile-release-process-an-illustrated-story (2022-06-22).
  - Thoughtworks describes a weekly Friday-to-Wednesday train with toggles and store phased rollouts.
    https://www.thoughtworks.com/en-gb/insights/blog/mobile/release-mobile-apps-weekly (Tao Tang, 2022-12-16).
  - Skyscanner runs a 2-week train with flags as kill switches (search result only, not opened).
- **OTA for React Native:** Expo's protocol and `expo-updates` (cited in 1); CodePush retired (cited in 1).
- **Feature flags:** Hodgson (cited in 2): four kinds; release toggles short-lived; "Savvy teams view their Feature
  Toggles as inventory which comes with a carrying cost."
- **Contract tests:** "a technique for testing an integration point by checking each application in isolation"; with
  Pact, "The contract is generated during the execution of the automated consumer tests" (https://docs.pact.io/).
  Our `app_reads.json` is already a consumer-generated contract: the app's code writes its row.
  Parallel change (cited in 4) is the expand/contract rule.

**What one owner plus AI agents should NOT copy:**
- **Percentage canaries, A/B experiments and flag dashboards.** With a handful of testers, 1% is nobody and there are
  no statistics. Hosted flag services also break self-host-everything.
- **A train that leaves every week whether or not it has cargo.** Our store builds are cheap in machine time (2–2.5
  min Android, T1058). What costs is review and your attention, so cut when native changes are waiting.
- **A release captain or on-call rotation.** The equivalent here is your one sitting (release-timeline pick 3).
- **A Pact Broker or any extra service.** One JSON table in git and a test do the same.
- **Pure trunk with no release branch.** Two release chats overlap, and 26 code PRs landed on main during 0.9.0
  (release-timeline item 9). Keep short release branches; they are also where OTA fixes come from.
- **Automatic production deploys everywhere.** Only where you say so (pick 2).

---

## 7. Roadmap (biggest gain first)

| # | Step | Unblocks | Size | Saves |
|---|---|---|---|---|
| R1 | Contract blind spots + floor rule (4.1, 4.2) | safe web-first and data-only releases | S (1 day) | no accidental app release; catches a section bump that would strand phones |
| R2 | Web-only release path: `release --cut --web`, no phone builds, runbook section, releases.md "web" rows | web-first features **now**, with today's Mac tooling | S (½ day) | the phone builds and store reviews leave every web change |
| R3 | Release flags at build time + `check-flags` + both-state tests (2.1, 2.2) | half-built features merge to main | S–M (½–1 day) | no feature holds a cut |
| R4 | Additive rule as code + old-reader test (4.3, 4.4) | trust in R1 without reading diffs | M (1–1½ days) | format errors caught on the PR |
| R5 | CI speed rows 1–4 of ci-speed-build-plan (title check, caffeinate, xdist, no push run on main) | everything merges faster | S each | about 20 min per code PR (guess), 0–8 h per release |
| R6 | Web from CI: T1133 M0 + M3, PR previews, staging on merge, production one click (section 3) | the web train | M (2–3 days), after T1160 | merge → web production the same day; the Mac's 15-min site build leaves the heavy lane |
| R7a | Measure: a CI step prints the fingerprint of every main commit; two weeks of data | the OTA decision | S | — |
| R7 | OTA O1–O6 (section 1), if R7a shows a stable runtime | the phone JS train | L (3–5 days + one store build per platform) | 37–53% of past versions could have skipped the store |
| R8 | T1133 stage A (Android in CI), then T1133 M4 production workflow | one-click production for everything | M–L | your 5–7 terminal commands → 1 click |

R1–R3 fit one build chat in two days. After them, the owner's "web first, app later" works with no new infrastructure.

---

## Picks for the owner

1. **Trains:** (A) data, web and native trains now, and OTA decided after two weeks of fingerprint data (recommended);
   (B) build OTA now too; (C) one train as today.
2. **Web production:** (A) one approval click per deploy, batched to about one a day (recommended; production stays
   yours); (B) automatic for web-only changes after a green staging smoke, with automatic rollback; (C) only inside
   releases, as today.
3. **PR previews:** (A) app only, staging data, `noindex`, a public workers.dev link (recommended); (B) the same behind
   a Cloudflare Access login; (C) none.
4. **Flags:** (A) build-time release flags plus "shown when the data is there", no remote flags yet (recommended);
   (B) also a remote kill-switch file on the data host; (C) none.
5. **The floor rule:** (A) a data release that would cut off the oldest store build stops unless you give a reason
   (recommended); (B) it only warns.
6. **The old-reader test covers:** (A) every distinct reader since the production floor (2 today) (recommended);
   (B) only the floor; (C) only the newest shipped build.
7. **If OTA is built, it carries:** (A) fixes, copy and small UI only; features ride store builds (recommended, store
   rules); (B) features too, declared in review notes.
8. **Native changes on main while OTA exists:** (A) OTA fixes come from the open release branch of the shipped runtime
   (recommended); (B) native PRs merge only in a "native window" before a store cut.

## NEW TICKET lines

- NEW TICKET: `app_reads.json` records the answers-section versions and the required-file list per app version;
  `app_gate` derives `minAppVersion` from them as from formats (backfilled from git).
- NEW TICKET: The floor rule: a data release whose derived `minAppVersion` is above the oldest app version on a store
  track stops (`--raises-floor "<why>"`, printed, in the ledger); the floor is read from production R2's store records
  or a committed `shipped_apps.json`.
- NEW TICKET: The additive rule as a test: `contract.FILES` at the floor version's commit against HEAD; within one
  format only appended nullable columns, optional tables and new files.
- NEW TICKET: The old reader reads the new data: a frozen Node reader per store-built version (esbuild bundle, a GitHub
  Release asset with sha256), run against the committed mini release in pipeline CI and against the candidate in the
  release follows.
- NEW TICKET: A web-only release: `release --cut --web` ships web (and data or the feeds worker if changed) with no
  phone builds; runbook section; releases.md marks web-only versions.
- NEW TICKET: Release flags at build time: `packages/core/src/flags.ts` registry (ticket, expiry, staging/production),
  `tools/check-flags.mjs` in `pnpm check` (expiry, at most 5 live), `withFlags` test helper, an all-on vitest project
  for files that import flags.
- NEW TICKET: Web previews per PR: app-only export to a `canifishthis-preview` Worker with `--preview-alias pr-<n>`
  on staging data, `noindex`, link commented on the PR; skipped for forks.
- NEW TICKET: The web ships from main: staging on merge (export + relink to staging's stored SEO pages + smoke);
  production by one approval (or the pick-2 rule); before production the new code's `readsRelease` is run against the
  live production manifest. Builds on T1133 M0/M3 and T1160.
- NEW TICKET: Measure the native runtime: a CI step prints `@expo/fingerprint` (with `app/patches` and
  `apps/mobile/modules` added) for every main commit and the last store build; a two-week summary decides OTA.
- NEW TICKET (only after the measure says yes): Self-hosted OTA: `expo-updates` with fingerprint runtime, our signing
  certificate, an updates route on a Worker serving pre-signed manifests from R2, `ota-publish.mjs` (content-addressed
  assets, pointer + previous), staging and production channels behind the environment, update id in crash reports and
  source maps per update, "restart to update" in the notice (with T1073), and the cut naming the train.
- Line items, not new: T1133 (M0, M3, M4, stage A carry the web and phone workflows); T1160 (agents' own identity,
  needed before any one-click production); T1144 (gate workflow; a web preview job joins it); T1062 (rc tags are where
  frozen readers and OTA bases come from); T1016 (the version-skew reload already covers web deploys; its (a) wants a
  `previous` field on the pointer, which OTA's pointer shape copies); T1073 (the notice must not promise an update
  the phone cannot take, OTA included); T1048 (the cut's `app_reads` row stays the one writer).

## Not verified

- That Hermes bytecode counts as "interpreted code" for Apple §3.3.1(B). It is precedent from Expo's hosted service,
  not a ruling.
- That `@expo/fingerprint` misses pnpm patches by default (hence the extra sources), and that it sees our local
  MapLibre Maven build.
- That `expo-updates` 58.x builds cleanly with R8 on, the patched MapLibre and our three native modules; nothing was
  built.
- Whether a phone accepts an older update id served after a newer one (rollback by re-publishing is the safe design).
- Whether `expo-updates` sends a stable client id usable for percent rollouts (not needed for the design).
- iPhone bundle size; Android's 2.44 MB is `gzip -9` of an 11-21 local build. Brotli and the update's asset changes
  were not measured.
- All CI and web times marked guess: the web export alone on a runner, staging-on-merge, preview upload size and time.
  The site's 15 min is a script comment (`site-all.sh:7`).
- The CodePush retirement dates and hot-updater facts come from search results; I did not open those pages.
  Skyscanner the same.
- The native-share count (20 of 32) is by file path. A comment-only change in a plugin counts as native (the detail
  file shows 0.7.0 and 0.8.1 at 3 and 2 code lines). The MapLibre patch lines were classed by pattern, not read.
- Merge → production uses 0.9.0 only (n=37, feat/fix/perf titles, production data time); merge → phones was not
  measured.
- That the floor's source (production R2 `play.json`, the TestFlight record) holds the version each track serves;
  taken from ship-workflow-design, not opened.
