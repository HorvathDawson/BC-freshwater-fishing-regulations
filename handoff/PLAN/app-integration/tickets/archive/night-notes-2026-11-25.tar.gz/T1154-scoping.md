# T1154 scoping — the map engine seam, the imagery provider, one way to read our tiles

Read-only pass, 2026-11-25 night. Code read at `main` in the planning worktree (`e14d494b3`). Every `file:line` below is
from that tree (paths start at `app/` unless they say otherwise). Outside facts: the URL and the date read are given.
Helper script: `night/T1154-scoping/hunks.py` (sums the patch by hunk). Upstream files fetched for reading are in
`night/T1154-scoping/ext/`.

## The short version

1. **Moving MapLibre onto a `http://127.0.0.1` tile server does NOT leave behaviour unchanged. MapLibre's own code
   changes three things.**
   - (a) On Android, MapLibre stops sending any http request while the phone says it is offline. The request is held
     until the network comes back (`platform/default/src/mln/storage/online_file_source.cpp:497-504`; Android sets
     "offline" from `ConnectivityReceiver` → `connectivity_listener.cpp:19`; maplibre-native `main`, read 2026-11-25).
     So in airplane mode the map would be blank. That is the case the app is built for.
   - (b) Every http tile is written into MapLibre's own tile cache on the phone (`main_resource_loader.cpp`:
     `databaseFileSource->forward(...)` for every network answer). PMTiles tiles are not cached ("PMTiles sources do
     not support offline pack downloads or caching", `platform/android/docs/data/PMTiles.md`, read 2026-11-25). So
     ~423 MB of our tiles would flow through the 50 MB cache and push Esri tiles out of it.
   - (c) Our patch reads tile ids only for a `pmtiles://file` address (patch, `MLRNVectorSource.kt`:
     `if (!u.startsWith("pmtiles://file")) return`). On any other address it sends nothing, and the map loses all its
     colours with no error shown.

   My recommendation: MapLibre stays on `pmtiles://file://`. The tile server is built only for the Mapbox trial
   (T1155), where it is needed.
2. **The handoff is wrong or out of date in ~14 places** (section 2). The ones that matter most:
   - The native map's engine code is not only in `Map.native.tsx`. It is also in `native/labelHold.tsx` (it imports
     the SDK), in `native/useColouring.ts` (the patch's device event and patched methods), in `tile-hold.ts`, in
     `native/styleAssets.ts`, and in four mobile-shell plugins and modules.
   - The Android MapLibre build carries **no patch of ours**. Only the React Native binding is patched.
   - "The style build emits per engine" is the wrong place. `style.json` is engine-neutral. The per-platform style is
     put together at run time (`native-style.ts`, `runtime-style.ts`).
   - The real per-engine parity test is `adapter-contract.render.test.tsx` (1,286 lines), not `parity.test.ts`.
3. **Most of the seam can be built as pure refactors with no change the user sees.** Four lanes: (L1) a style "dialect"
   and tile-address seam; (L2) the imagery provider record and the offline-imagery interface; (L3) the native map
   split into a shell plus `native/maplibre/`; (L4) the build-time switch. Two gaps must be closed **before** L3 moves
   any code: no test covers the still-tap (`onTapUp`), and no test sends the patch's per-tile event (`MLRNTileIds`).
   Today a move could drop either one and every test would still pass.

---

## 1. Inventory: every place that knows the map engine

Marks used below:
- N = ENGINE-NEUTRAL
- M = MAPLIBRE-ONLY
- X = MIXED (the column says what moves)
- E = Esri-specific, but engine-neutral

Sizes are `wc -l` line counts.

### app/packages/map

| file | lines | mark | what knows the engine, and what would move |
|---|---|---|---|
| `src/adapters/contract.ts` | 495 | N | `MapHandle` (28-40), `MapRenderer` (55-87), `MapAdapter` (89-152), `baseAdapter` (193-495). `setBasemap` (127, 460-482) only shows or hides the `imagery` group and repaints. Nothing moves. Later it could gain an `engine` id beside `platform` (56, 90). |
| `src/adapters/native.ts` | 132 | X | Typed against a *slice* of the binding's refs (`NativeRefs` 35-49), with no SDK import. It also carries MapLibre Native quirks: unset a key by a null write (T345, 66-76); ids come back as strings on Android (86); `promoteId` is ignored (12-13); `easing: "ease"` because the binding defaults to "fly" (97-102). **Move:** `NativeRefs` becomes an engine-neutral `EngineHandle` in `contract.ts`. The quirks become engine "traits" in `native/maplibre/`. |
| `src/adapters/web.ts` | 106 | web | maplibre-gl slice. The web stays on MapLibre; out of scope. |
| `src/Map.native.tsx` | 1,161 | X | **MapLibre-only lines, about 170 of 1,161:** SDK import 46-49; `LayerSpec` 100; event types 116-119; refs 144-148; `LogManager` 178; copy-source writes 186-203 and 221-223; `nativeTag` 371-377; direct `queryRenderedFeatures` 469-477, 759, 767, 806, 813, 851, 881; `getFeatureState` 589; `removeFeatureState` 568; the component tree 1011-1095 (85 lines); prop/event names 1016-1050 (`onDidFinishRenderingMapFully`, `onTapUp`, `maxPixelRatio`, `prefetchZoomDelta`, the off-screen `scaleBar` N2 workaround). **The other ~990 lines** are engine-neutral logic written against the binding's events: fit and refine, water copy, label hold, look tracker, "drawn whole", tap order, spots, marks, pins, callout, scale bar, zoom buttons, credits, screen-reader buttons. These stay in the shell. |
| `src/native/useColouring.ts` | 346 | X | `StateQueue` (42-87) and the `Colouring` wiring are neutral. MapLibre/patch-only: the `AtlasSource` interface uses the patched `setFeatureStates`, `watchTiles` and `nativeTag` (31-37); `DeviceEventEmitter` and `"MLRNTileIds"` (18, 207-241); the T420 send-gap note (147-153) is MapLibre behaviour. **Move:** the tile event source and the batch call go behind the engine (`onTileIds(cb)`, `setStates(layer, ids, states)`). |
| `src/tile-hold.ts` | 66 | X | Neutral, except `NATIVE_SENT_MAX = 256` (17) and `TILE_IDS_EVENT = "MLRNTileIds"` (20). Both are tied to the patch's `SENT_MAX`. Move those two constants to the engine folder. |
| `src/colouring.ts` | 499 | N | Platform-free. It takes the ids per tile. Feature-state as an idea exists in Mapbox too. |
| `src/native/labelHold.tsx` | 57 | M | `import { Layer } from "@maplibre/maplibre-react-native"` (15). It relies on the binding taking over a style layer that has the same id (5, `MLRNLayer.addToMap`). Split: the store (`holdStore`, `useAdoptedIds`) is neutral; `HeldLabels` goes to the engine folder. |
| `src/native/styleAssets.ts` | 48 | M | Parses MapLibre Native's log through `LogManager.onLog` (35-43). |
| `src/native/labelAnchor.ts` | 31 | X | Needs the binding's `project` (15-17, 29). The logic is neutral. |
| `src/native/goneView.ts` | 42 | X | Recognises the binding's "view gone" errors (T445). |
| `src/native/panProbe.ts`, `probe.ts`, `camProbe.ts` | 162 / 51 / 65 | N | Test-bed probes over JS events. |
| `src/native-style.ts` | 186 | X | The look is applied the neutral way (`applyLook` 132). The MapLibre Native dialect parts: `promoteId` dropped (156); area-layer literal tables because MLN ignores `promoteId` (168-181); images renamed per theme because the binding adds a name only once (162-167); the Esri credit deleted while satellite is off (145-149). **Move:** a `maplibreDialect()` pass. |
| `src/runtime-style.ts` | 617 | X | Neutral composition. The `pmtiles://` scheme is baked in at 121 (field sources), 378 (basemap), 388 (atlas). `externalRasters` (103-111) handles the imagery source. **Move:** tile addresses behind a `TileAccess` record. |
| `src/endpoints.ts` | 79 | X/E | `TileEndpoints` (8-51) is neutral. `ESRI_KEYED` and `imageryTiles` (56-69) are Esri. Note `at.atlas` is also the route reader's path (`readRange`, 45-54). |
| `src/images.ts`, `gestures.ts` | 87 / 87 | X | `nativeMapGestures` returns the binding's prop names (`NativeMapGestureProps`, gestures.ts ~74-87). |
| `src/MapCredits.tsx`, `credits.ts`, `chrome.ts` | 150 / 129 / — | E | Esri badge `ESRI_BADGE` (chrome.ts:82, MapCredits.tsx:85-89); `IMAGERY_LINE` (credits.ts:72, 105). |
| `style/layers.source.json` | 2,977 | N/E | `"url": "pmtiles://atlas"` placeholders (7, 23, 29). The Esri imagery source with its credit (10-20). |
| `style/style.json`, `style.meta.json` | 1,870 / 4,743 | N | Generated by `tools/build-style.mjs` (1,248). One output, not one per engine. |
| `src/parity.test.ts` | 679 | N | Runs one op script over recorders (the native recorder answers the way Android does). |
| `src/adapter-contract.render.test.tsx` | 1,286 | M | Mocks `@maplibre/maplibre-react-native` at the module boundary (136-198) and runs `Map.native` against `Map.web`. **This is the real per-engine parity test.** |
| `src/label-hold.render.test.tsx` | 249 | M | Same mock (17-53). |
| `src/map-props-gate.test.ts` | — | N | Reads `Map.native.tsx` as text (11). Keeping the shell's file name keeps this test working. |
| `tools/*.test.ts` that read `Map.native.tsx` as text | — | — | `map-gestures.test.ts:33`, `map-credits.test.ts:12`, `one-colouring-engine.test.ts:146`, `one-parts-list.test.ts:56`, `one-section-layers.test.ts:157`, `clock.test.ts:26`, `failures.test.ts:187`. They pin by path: the pins must follow the lines that move. 27 of the 157 `tools/*.test.ts` name MapLibre; classifying all of them is left to L3. |

### Outside app/packages/map

| place | mark | what |
|---|---|---|
| `packages/core/src/imagery.ts` (94) | E | Esri's outage rule (64-68, `blankTile=false` → 404 is a hole); `basemapInUse` (71-72); `SATELLITE_OFFLINE` (75-76); `IMAGERY_ATTRIBUTION`/`IMAGERY_CREDIT` (84-86); `withImageryCredit` (89-90); `imageryProbeUrl` (93-94). |
| `packages/core/src/offline.ts` (140) | N | The Offline maps page in words. There are no imagery rows today. |
| `packages/core/src/layers.ts:28,102,143-144` | E | "online-only" reason; the Satellite row `needs: { network: true }`, "Photo map · needs internet". |
| `packages/core/src/menu/words.ts:147` | E | "…Shown only while online, never stored." (T1148 changes this). |
| `packages/data/src/release/offline.ts` (49) | N | Sizes from the manifest. |
| `packages/ui/src/imagery.ts` (`useImageryReach` 67-93), `ui/src/mapModes.ts:181-182`, `ui/src/offline.ts` | E/N | Reach, the ground drawn, the Layers line. |
| `packages/ui-native/src/shell/useMapColouring.ts:15,138-139,206`; `imageryProbe.ts`; `menu/OfflinePage.tsx` | E/N | The probe, the credit, the Offline page. |
| `apps/mobile/src/config.ts:17,104` (`IMAGERY_TILES`); `App.tsx:554-567` | E | The Esri template handed to the map. |
| `apps/mobile/app.json` plugin `["@maplibre/maplibre-react-native", {"android":{"nativeVariant":"vulkan"}}]` | M | Config plugin. |
| `apps/mobile/app.config.js:30-67`; `plugins/with-local-maplibre.js` (40); `plugins/with-pinned-maplibre.js` (59) | M | The pinned Android SDK; a production build is refused without it. |
| `apps/mobile/plugins/r8-keep-rules.pro:28-41` | M | Keep rules for MapLibre classes (memory trim, surface guard). |
| `apps/mobile/modules/memory-trim` (`MemoryTrimModule.kt:14-17,60,77`; `src/memoryTrim.native.ts`) | M | Finds `org.maplibre.android.maps.MapView` by class name. |
| `apps/mobile/plugins/with-backup-rules.js:10` | N | An include list; MapLibre's cache stays out by construction. |
| `apps/mobile/modules/bg-download` (Kotlin 6.6 kB, Swift 15.7 kB) | N | Release downloads. Engine-neutral. A model for a new local module. |
| `apps/mobile/package.json:25`; `packages/map/package.json` | M | The binding as a dependency (autolinking). |
| `apps/mobile/metro.config.js` (29) | N | No alias today. |
| `app/layers.json:12-13,42-43,53-54,89-90,112-113` | M names | Bans or allows the two MapLibre packages per layer. |
| `app/tools/check-boundaries.mjs` (140) | N | Most specific layer wins (94-107). **Relative imports are skipped (124)**, and engine knowledge that is not an import (event names, patched method names) is not seen. |
| `app/tools/check-platform.mjs` rule 5 | N | `src/native/` is imported only from native files. A `native/maplibre/` folder fits under it. |
| `app/patches/@maplibre__maplibre-react-native@11.5.0.patch` | M | 2,703 lines in the file; **1,784 added lines** (Android 991, iOS 626, TS source 63, built copies under `lib/` 104), 16 removed. |
| `app/tools/maplibre-android/` (README, `build.sh`, `pin.env`, `check-loaded.sh`, `jobpool.init.gradle`, `archive-t420/`) | M | Builds the pinned upstream commit `3a6b9557…` with **no patch** (pin.env; README "T978"). |
| `deploy/staging/build-apk.sh` (42 MapLibre mentions), `app/tools/testbed/session.sh` (21), `testbed/lib/build-stamp.mjs` (20) | M | AAR and build-id checks, test-bed stamps. |
| `app/tools/seo/html.ts:254-255` | E | Privacy page: Esri sees tile requests; "not stored" (T1148). |
| `.github/workflows/app-ci.yml:122-146` | N | `bundles` = JS bundles only (`expo export`). No native compile in CI. |

### The patch, feature by feature (added lines; approximate)

Counted by hunk with `hunks.py`. The two large `MLRNMapView.kt` hunks were divided at function boundaries, so the
per-feature split is an estimate. The total is exact.

| feature | tickets | Android | iOS | TS + built copies | about |
|---|---|---|---|---|---|
| Per-tile feature ids from the local PMTiles archive (`TileIds.kt`, `MLRNPmTilesIds.m`) + `watchTiles` + the `MLRNTileIds` device event + batched `setFeatureStates` | T74, T217, T420 | ~376 | ~515 | ~51 | ~940 |
| Fling glide on the frame clock, fling length, pinch carry, `MLRNCameraCache` | T312, T452, T707 | ~325 | — | — | ~325 |
| Still-tap at lift (`onTapUp`) | T716, T719 | ~60 | ~89 | ~26 | ~175 |
| Max pixel ratio (surface cap) + prefetch zoom delta | T448, T401 | ~75 | — | ~35 | ~110 |
| Stretchable images (`stretchX/Y`, `content`) | T74, T217 | ~33 | ~25 | ~34 | ~92 |
| Old picture held over a style swap (`PixelCopy` cover) | T451 | ~70 | — | — | ~70 |
| Camera probe (test bed only) | T452 | ~40 | — | — | ~40 |
| Safe calls before the map is ready (`ReactTagResolver`, `readyMap`) | — | ~30 | — | — | ~30 |
| **total** | | **991** | **626** | **167** | **1,784** |

Five of the eight features are Android-only: gestures, pixel cap and prefetch, swap hold, camera probe, safe calls.
The patch's PMTiles readers (`TileIds.kt`, `MLRNPmTilesIds.m`) already hold a PMTiles directory and tile reader in
Kotlin and Objective-C. A local tile server could reuse them.

## 2. Where the handoff is wrong or out of date

1. **"`Map.native.tsx` … That's where engine-specific code lives."** Only partly. See the table above: `labelHold.tsx:15`
   imports the SDK; `useColouring.ts:18,31-37,207-241` uses the patch's event and methods; `tile-hold.ts:17,20`;
   `styleAssets.ts`; `native-style.ts` (the dialect); `adapters/native.ts` (quirks). Outside the package: memory-trim,
   r8 rules, the two maplibre plugins, `build-apk.sh`, the test-bed stamps.
2. **`deps.md:56` and `adapters/native.ts:7` say the SDK is imported by `Map.native.tsx` only.** `native/labelHold.tsx:15`
   imports it too. `layers.json` cannot see the difference: it rules a whole package.
3. **"~2,700 lines" of patch.** That is the file size. The added code is 1,784 lines, and 104 of those are duplicated
   built copies.
4. **"Android uses a local MapLibre Native build."** True, but it is the pinned upstream `main` commit with **no patch
   of ours** (`tools/maplibre-android/pin.env`, README). The feature-state fix is upstream (PR #4919). iOS uses the
   stock pod.
5. **The patch table (handoff section 5) misses four features:** the held picture over a style swap (T451, ~70 lines),
   the surface pixel cap (T448), the prefetch zoom delta (T401), and the camera probe (T452). Stretch images are T74
   (Android) and T217 (iOS).
6. **"`parity.test.ts` runs one op script against both."** True at the adapter level. The component-level parity — what
   a second engine must pass — is `adapter-contract.render.test.tsx` (it mocks the SDK module), plus
   `label-hold.render.test.tsx`.
7. **"`pnpm style:build` emits both a MapLibre and a Mapbox style."** `style.json` is engine-neutral. The phone's style
   is built at run time (`nativeStyle`, `runtimeStyle`). The per-engine step belongs there, and `style-valid.test.ts:22`
   validates those run-time outputs with `@maplibre/maplibre-gl-style-spec`.
8. **"`layers.json` rule: only `native/mapbox/**` may import `@rnmapbox/maps`."** Necessary but not enough: the checker
   skips relative imports (`check-boundaries.mjs:124`) and does not see event or method names like `"MLRNTileIds"`. A
   second, grep-style rule is needed.
9. **"CI builds both native engines on every PR (app-ci.yml already splits bundles)."** CI builds JS bundles only
   (`app-ci.yml:138-146`, `expo export`). No native compile runs in CI; that happens on the Mac (heavy).
10. **"Tiles … installed to disk (`pmtiles://file://…`)."** True. But `at.atlas` is also the pairing identity
    (`ui/src/release.ts:139-145`), the colouring engine's relabel key (`useColouring.ts:249`), and the route reader's
    path (`Map.native.tsx:338-356`). A tile server's URL must be a **new** field, not a replacement for `at.atlas`.
11. **"Move MapLibre onto [the local server] first, with no change in behaviour."** Not possible as written: see the
    short version, 1(a)-(c).
12. **"Because the server has each tile in hand, it can report feature ids per tile."** Only for tiles the engine's own
    cache misses. MapLibre's cache sits in front of http sources (`main_resource_loader.cpp`), so a cached tile never
    reaches the server, and its ids would never be reported. Today the patch hooks MapLibre's *request* listener, which
    fires for cache hits too (`OnTileActionListener`, `RequestedFromCache`). For Mapbox this still has to be measured.
13. **The satellite wiring list is incomplete.** Not named in the handoff: the credit in `layers.source.json:18`,
    `credits.ts:72`, the badge in `chrome.ts:82` / `MapCredits.tsx:85-89`, `menu/words.ts:147`, `layers.ts:102,144`,
    `ui/imagery.ts`, `imageryProbe.ts`, `useMapColouring.ts:138-139,206`, `config.ts:104`, `App.tsx:561-567`,
    `seo/html.ts:254-255`.
14. **T1108's "225 MB basemap and atlas".** On the owner's checkout (2026-11-25, `ls -la`): `atlas.pmtiles` 197.7 MB
    (z4-13) and `basemap.pmtiles` 225.4 MB (z0-13), 423 MB together. Both have gzip tiles (PMTiles header byte 98 = 2;
    read with a 127-byte header read).

## 3. The imagery provider

### Today's Esri wiring, end to end

1. **Style source.** `layers.source.json:10-20` holds the Esri URL with `blankTile=false`, 256 px tiles, maxzoom 19,
   and the credit on the source.
2. **Into the style.** `runtime-style.ts:103-111` copies the source into the runtime style. A keyed template, if given,
   replaces only its `tiles`.
3. **The keyed path.** `imageryTiles(key)` (`endpoints.ts:56-69`) builds it. On a phone, `config.ts:104` calls it with
   `EXPO_PUBLIC_ARCGIS_API_KEY` (unset = keyless), and `App.tsx:567` hands it to the map as `tiles.imagery`.
4. **Reach.** `useMapColouring.ts:138` probes one z0 tile (`imageryProbe.ts`: `no-store`, asked twice). `ui/imagery.ts`
   reduces the probe, the device's network state and (on the web) tile errors. Outage rule: anything but 404
   (`core/imagery.ts:68`).
5. **The ground drawn.** `basemapInUse(chosen, up)` (`core/imagery.ts:71`) is used in `mapModes.ts:181`. When satellite
   is chosen but down, the map shows the drawn map with `SATELLITE_OFFLINE` (`mapModes.ts:182`, `layers.ts:102`). The
   choice is kept, so satellite comes back by itself.
6. **The map.** `setBasemap` (`contract.ts:460-482`) shows the `imagery` group, repaints the water for imagery (T594),
   and relights the labels. On a phone this is a style rebuild; `native-style.ts:148-149` deletes the Esri credit unless
   satellite is drawn.
7. **Credits.** `withImageryCredit` (`useMapColouring.ts:206`), `MapCredits` badge "Powered by Esri"
   (`MapCredits.tsx:85-89`), `IMAGERY_LINE` (`credits.ts:72`). `tools/imagery.test.ts` holds the core words and the
   style words equal.
8. **Device cache (T1148).** MapLibre Native's ambient cache (50 MB default; never set by the app) very likely stores
   Esri tiles. The privacy page (`seo/html.ts:255`) and the style comment (`layers.source.json:19`) say "not stored".
   Not verified on a device (T1148).

### The provider record, as it would fit this code

Where it lives: `core` (no URLs that need a key). The tile template stays in the style source, so it has one home. The
build checks that the provider's credit equals the source's, as `tools/imagery.test.ts` does today.

```ts
// packages/core/src/imagery.ts
export type MapEngineId = "maplibre-native" | "maplibre-gl" | "mapbox-native";

export interface ImageryProvider {
  readonly id: "esri" | "mapbox" | "own";
  /** where it may be drawn (Mapbox Satellite: only through the Mapbox SDK, T1108 terms s2.9.1) */
  readonly engines: readonly MapEngineId[];
  /** the style source that draws it (`layers.source.json`); null when the engine supplies it (`mapbox://`) */
  readonly source: string | null;
  readonly offline: "none" | "file" | "engine-pack";
  /** the map's own credit, and the app's credit line (today IMAGERY_ATTRIBUTION / IMAGERY_CREDIT) */
  readonly attribution: string;
  /** a badge that must stay on screen while drawn ("Powered by Esri"), or null */
  readonly badge: string | null;
  /** is this tile status an outage (Esri: anything but 404, `blankTile=false`) */
  readonly outage: (status: number | undefined) => boolean;
  readonly words: { readonly offline: string; readonly note: string; readonly sources: string };
}
export const ESRI: ImageryProvider = { id: "esri", engines: ["maplibre-native", "maplibre-gl"], source: "imagery",
  offline: "none", attribution: IMAGERY_ATTRIBUTION, badge: "Powered by Esri", outage: (s) => s !== 404,
  words: { offline: SATELLITE_OFFLINE, note: "Photo map · needs internet", sources: `${IMAGERY_ATTRIBUTION}. …` } };

/** unchanged for Esri: offline "none" means up is required. A held corridor ("file"/"engine-pack") may draw offline. */
export const basemapInUse = (chosen: Basemap, up: boolean, p: ImageryProvider = ESRI, heldHere = false): Basemap =>
  chosen === "satellite" && (up || (p.offline !== "none" && heldHere)) ? "satellite" : "map";
export const withImageryCredit = (lines: readonly string[], drawn: Basemap, p: ImageryProvider = ESRI) =>
  drawn === "satellite" ? [...lines, `Satellite imagery: ${p.attribution}`] : lines;
```

### The offline-imagery interface

It plugs into `ui/src/offline.ts` → `core offlineVM` → `OfflinePage.tsx`. The page never learns the method.

```ts
// packages/core/src/offline.ts (types) — implementations in packages/data/src/release/
export interface ImageryRegion {
  readonly id: string; readonly name: string; readonly provider: ImageryProvider["id"];
  readonly bytes: number | null; readonly state: "kept" | "downloading" | "waiting-wifi" | "failed";
}
export interface OfflineImagery {
  readonly method: ImageryProvider["offline"];
  list(): Promise<readonly ImageryRegion[]>;
  size(id: string): Promise<number | null>;
  /** starts or resumes; progress comes back through list() (as bgDownload's jobs do), never a promise held by a screen */
  download(r: { id: string; corridor: GeoJSON.Geometry; zooms: readonly [number, number] }): Promise<void>;
  remove(id: string): Promise<void>;
}
// OfflineInput gains `imagery?: readonly ImageryRegion[] | null`; with none (today) the VM and the page are unchanged.
```

Implementations now:
- `none`: `list()` → `[]` (Esri).
- `file`: reads a manifest key that does not exist yet, so it also lists nothing. Its real download over
  `release/bgDownload.ts` waits for a corridor product (NEW TICKET).

Note: `download` returns no `Progress` object as the handoff sketched. In this code a download is a JS state machine
over native jobs that survive the app being closed (`bgDownload.ts`, T722). Progress is read back from the jobs.

### Call sites that change

- `core/imagery.ts`, `core/layers.ts:102,143-144`, `core/menu/words.ts:147`
- `ui/imagery.ts:93` (`isImageryOutage` → `provider.outage`), `ui/mapModes.ts:181-182`, `ui/offline.ts`
- `ui-native/shell/useMapColouring.ts:138-139,206`, `ui-native/imageryProbe.ts`, `ui-native/menu/OfflinePage.tsx`
- `map/endpoints.ts:56-69` (`imageryTiles(provider, key)`), `map/credits.ts:72,105`, `map/chrome.ts:82`,
  `map/MapCredits.tsx:85-89`, `map/native-style.ts:148-149` (delete the credit of the provider's source),
  `map/runtime-style.ts:103-111`
- `apps/mobile/src/config.ts:104`, `App.tsx:561-567`
- tests: `tools/imagery.test.ts`, `tools/map-credits.test.ts`, `tools/imagery-casing.test.ts`, `OfflinePage.test.tsx`,
  and the core and ui imagery tests

`seo/html.ts:254-255` belongs to T1148. Do T1148 first: it rewrites the same words (see the picks).

## 4. The engine split of the native map

### File layout (after L3 and L4)

```
packages/map/src/
  Map.native.tsx            the SHELL: today's logic (~990 lines), talks only to EngineHandle / <EngineView>
  native/engine.ts          EngineHandle, EngineViewProps, EngineTraits — engine-neutral types (+ engine.d.ts for the alias)
  native/maplibre/
    index.ts                export { EngineView, traits, tileEvents }
    View.tsx                the component tree of Map.native.tsx:1011-1095, unchanged in order and nesting
    handle.ts               binding refs -> EngineHandle (queryRendered, querySource, get/setFeatureState(s), bounds,
                            project, easeTo/fitBounds)
    tiles.ts                DeviceEventEmitter "MLRNTileIds", watchTiles, nativeTag, SENT_MAX (from useColouring/tile-hold)
    HeldLabels.tsx          from native/labelHold.tsx (the Layer adoption)
    log.ts                  LogManager -> styleAssets
    dialect.ts              promoteId drop, area tables, per-theme image names, `pmtiles://file://` addresses
  native/mapbox/            (T1155 only) the same five files over @rnmapbox/maps
```

### What the shell keeps

Everything that decides, as opposed to what draws:
- fit and refine; the water copy; the label hold; the look tracker and "drawn whole"
- the settle ask; tap precedence (spot → mark → pin → obstacle → water → not-fishing) and the tap lift
- spots, marks, pins, callout, scale bar, zoom buttons, credits, screen-reader buttons
- the colouring hook's `StateQueue` and the `Colouring` wiring

### `EngineViewProps`

Engine-neutral names:
- style; GeoJSON sources by id; images; overlay layers; held label ids
- events: `onPress`, `onTapUp`, `onLongPress`, `onRegionWillChange` / `IsChanging` / `DidChange`, `onStyleLoaded`,
  `onRenderedFully`, `onFrame(full)`, `onFail`, `onLayout`
- options: gestures, camera limits, pixel cap, prefetch delta

Event payloads are copied out before any await. That rule (N1 §3) moves into the engine.

### The build-time switch (one SDK linked per build)

- `EXPO_PUBLIC_MAP_ENGINE` (default `maplibre`; any other value fails the config and the bundle with a named error).
- **Metro:** `resolver.resolveRequest` maps `@app/map-engine` → `packages/map/src/native/<engine>/index.ts`, so only one
  engine's JS is in the bundle. Vitest gets the same alias, tsconfig gets `paths`, and knip gets both folders as
  entries. tsc checks both engines against `native/engine.d.ts`, the same idea as `Map.d.ts`.
- **Expo config plugin** `plugins/with-map-engine.js`: for maplibre, today's plugin list byte for byte (the binding's
  plugin with `vulkan`, `with-local-maplibre`, `with-pinned-maplibre`). For another engine: that engine's plugin, and
  the MapLibre binding left out of autolinking (`expo.autolinking.exclude` / `react-native.config.js`).
- **MapLibre-only native glue** must follow the engine: the memory-trim module's class-name match, the r8 keep rules,
  and the `build-apk.sh` AAR checks. Two ways: each becomes engine-aware, or it is skipped when the engine is not
  maplibre.

### The boundary rule

- `layers.json`: `packages/map` bans `@maplibre/maplibre-react-native` (and later `@rnmapbox/maps`). Nested layers
  `packages/map/src/native/maplibre` and `native/mapbox` may each import only their own SDK.
- A grep-style rule, in `check-boundaries.mjs` (or `check-platform.mjs` rule 5): outside `native/<engine>/`, no file in
  `packages/map/src` may contain the SDK names, `"MLRN`, `DeviceEventEmitter`, or a relative import into another
  engine's folder. Only `@app/map-engine` reaches an engine.
- **Mutations:**
  - add `import { Layer } from "@maplibre/maplibre-react-native"` to `Map.native.tsx` → fails;
  - add `"MLRNTileIds"` to `native/useColouring.ts` → fails;
  - add `import "./native/maplibre/View"` to `Map.native.tsx` → fails.

### Parity test per engine

`adapter-contract.render.test.tsx` and `label-hold.render.test.tsx` become a table over engines `{ id, sdkMock }`: the
same op script, the same expected command log. Today the table has one row (maplibre). `parity.test.ts` stays as it
is: it tests the adapters, which do not change.

**Two gaps to close first.** Neither exists as a test today (grep: `onTapUp` appears only in `Map.native.tsx` and
`tapLift.ts`; `DeviceEventEmitter` only in `useColouring.ts`):
- a tap-up case: the lift says `onPressStart`, the click reuses the lift's answer;
- a tile-event case: an `MLRNTileIds` event labels the tile; a repeat that is not held re-watches.

### The style, per engine

The run-time composition gets a dialect step: `nativeStyle(o, dialect)`, with `maplibreDialect` holding today's
`native-style.ts:145-181` engine parts, and `TileAccess` handing out the archive addresses. `style-valid.test.ts`
runs per dialect: the maplibre spec today, the mapbox spec added in T1155. `pnpm style:build` does not change.

### What stays identical for the user, and how it is proven

- **L1 (style dialect).** A golden test: `nativeStyle` and `runtimeStyle` output for a fixed set of looks (every view ×
  theme × basemap, as `style-valid.test.ts` already loops) must equal the pre-refactor output **byte for byte**. Take
  the snapshot before the change.
- **L2 (imagery).** The words are asserted whole (AGENTS 33). `imagery.test.ts` and `map-credits.test.ts` are unchanged
  in what they expect.
- **L3 (component move).** The render contract tests are unchanged, plus the two new cases. The SDK-mock tree must keep
  the same children in the same order. The known traps are a wrapper `View` around the map (black rectangle, N2,
  `Map.native.tsx:1143-1145`) and switching the scale bar off (`:1027-1031`).
- **L4 (switch).** A test that the resolved Expo config for `maplibre` equals today's. After a build, `check-loaded.sh`
  shows the same `libmaplibre.so` build id.
- **Device bench** (L3 and L4, one APK and one iPhone build): testbed `perf` (budgets cold start 4,000 ms, memory
  400 MB, pan 45 fps: `scenarios/perf.mjs:13`), `pan`, `glide`, `zoom-pinch`, `switch` (colours over a style swap),
  `regs-open` (tap to page), `offline` (airplane-mode cold start), `satellite`, `back-flash`, and the iOS
  `scenarios-ios/regs-open`.
- **Pictures** at the same places before and after: the test bed's shot scenarios (`step-shots`, `small-looks`;
  names only, not read), one set per theme and basemap.

## 5. The local tile server for the installed PMTiles

### Options

| option | how | for MapLibre | for Mapbox |
|---|---|---|---|
| A. Native Expo module with an HTTP server on 127.0.0.1 | Beside `bg-download`; Kotlin (e.g. a small `ServerSocket` loop or NanoHTTPD) and Swift (`Network.framework` `NWListener`). It serves `/{token}/{atlas\|basemap}/{z}/{x}/{y}.mvt` from the file, reusing the patch's PMTiles readers. | Hits (a)-(c) of the short version: Android offline gate, ambient-cache writes, the id reader stops. | The handoff's route. Needs a test of Mapbox's own offline and network gating (not verified). |
| B. A protocol hook, no TCP port | Android: our own OkHttp `Call.Factory` with an interceptor that answers a private host from the file (`HttpRequestUtil.setOkHttpClient`, maplibre-native `HttpRequestUtil.java:42-50`, read 2026-11-25). iOS: a `URLProtocol` subclass in `MLNNetworkConfiguration.sharedManager.sessionConfiguration.protocolClasses` (`MLNNetworkConfiguration.h:69`). Mapbox v11: `HttpServiceInterceptorInterface`, whose request continuation "can also be invoked with a HttpResponse, in which case the request completes immediately" (docs.mapbox.com iOS 11.0.0-beta.5, read 2026-11-25; **beta page**, confirm on current v11). | Still an "online" request inside MapLibre, so (a) and (b) apply. No port, no other app can reach it, no iOS background socket problem. | Likely the cleaner route for Mapbox if the interceptor works on current v11. |
| C. Keep MapLibre's `pmtiles://file://` | As today. | No change, no risk. | Not available: Mapbox native reads no PMTiles (T1108 passes). |

### Platform rules for 127.0.0.1 (option A)

- **iOS ATS.** "In iOS 17, iPadOS 17, and macOS 14, ATS no longer allows connections to IP addresses by default."
  Set `NSAllowsLocalNetworking` = YES, which "controls whether ATS allows your app to connect to unqualified domains,
  .local domains, and IP addresses" (developer.apple.com NSAllowsLocalNetworking, read 2026-11-25). The app sets no ATS
  key today (`app.json`, plugins: grep found none).
- **iOS local network prompt.** Not expected for loopback, if the server binds 127.0.0.1 only. A local network is "an IP
  network associated with a broadcast-capable network interface", and "Listening for and accepting incoming TCP
  connections" does not require local network access (TN3179, read 2026-11-25). Never bind 0.0.0.0.
- **iOS backgrounding.** "Your app should close the listening socket when it goes into the background and reopen it
  when it comes back into the foreground." A suspended app's socket may be reclaimed, and the error is often `EBADF`
  (TN2277, read 2026-11-25). So: close on background, reopen on foreground **on the same port**. A new port means new
  tile addresses, so a style swap (≈225 ms, N1) and every feature-state dropped. Measure a 1-minute and a 30-minute
  background.
- **Android cleartext.** From Android 9, "cleartext support is disabled by default". An implicit localhost exemption
  exists only "From Android 17 (API level 37)" (developer.android.com security-config, read 2026-11-25). So add a
  network security config with `<domain-config cleartextTrafficPermitted="true"><domain>127.0.0.1</domain>` via a
  config plugin.
- **Port.** A fixed preferred port kept in app storage, with the next free one on a clash. Port 0 (any) would change the
  address every launch. Guess: a clash is rare.
- **Security.** Any app on the phone can reach a loopback port. The data is our public tiles (the same bytes are on R2),
  so the harm is small. Still: a random token per launch in the path, GET only, the two archives only, nothing else on
  the file system, and refuse a `Host` other than `127.0.0.1:<port>` (stops a web page in the phone's browser using DNS
  tricks).
- **Startup cost.** Opening two files and reading each archive's root directory and header (tens of kB). Guess: a few
  ms. Measure it.
- **Range reads.** Not HTTP ranges. The server reads each tile by its offset from the PMTiles directory, the same way
  `TileIds.kt` does today.
- **gzip.** Both archives store gzip tiles (header byte 98 = 2). Send the bytes as they are, with
  `Content-Encoding: gzip`; no work on the server. That the engines' HTTP stacks unpack it is believed, not verified.
- **Ids per tile from the server.** Possible: the server holds the bytes and the readers exist. But the engine's cache
  answers repeats without asking the server, so the server cannot replace the request listener unless that cache is
  off for our sources. MapLibre has no per-source cache switch that I found. The headers test shows `no-store` parsed
  only as `max-age=0` (`test/storage/headers.test.cpp:50-53`), so whether it keeps tiles out of the cache is not
  verified. Turning the whole cache off would drop the Esri cache the owner chose to keep (T1148).

### What to measure, before and after (each arm a cold start, on the owner's mid Android phone and an iPhone)

| measure | how | today's figure |
|---|---|---|
| cold start to drawn map | testbed `perf` (`coldStartMs`), median of 5 | budget 4,000 ms |
| frames missing tiles while panning; camera at rest → first full frame | `pan` (`[drawn]` lines) | — |
| pan frame time p50 / p95, fps | `perf`, `glide`, `zoom-pinch` (Perfetto) | budget 45 fps |
| memory peak (PSS) | `perf` | budget 400 MB |
| colour on first frame | `switch`, colour probe | — |
| tile latency per request | server log (μs per tile) | — |
| MapLibre cache size | before and after a 5-minute pan | — |
| battery over 10 minutes | owner's phone, `dumpsys batterystats` | — |
| airplane-mode cold start draws the map | `offline` scenario | pass/fail |
| iOS: background 1 min and 30 min → map draws and colours within 1 s | — | pass/fail |

### Proposed "not slower than" margin

- **Pure refactor lanes L1-L4: within noise.** Cold start no more than +5% and +150 ms (median of 5), pan no more than
  2 fps lower, memory no more than +10 MB.
- **The server, if MapLibre is ever moved onto it:** first paint and pan frame time p95 no more than +10% (the ticket's
  default), memory no more than +15 MB, battery no more than +5%, and the two pass/fail items must pass.

---

## 6. Lanes

Order: **L1 → (L2 ∥ L3) → L4.** L2 and L3 touch different files. L1 goes first because L2 and L1 both touch
`native-style.ts` and `endpoints.ts`. All four are no-behaviour-change. The tile server moves to T1155 (see pick 1).

### L1 — style dialect and tile addresses (size S-M, Opus; no device)

- **Files:** `runtime-style.ts` (121, 378, 388), `native-style.ts` (145-181 → `native/maplibre/dialect.ts`; neutral
  part stays), new `tile-access.ts`, `endpoints.ts` (a tile-address field beside `atlas`), `style-valid.test.ts`,
  `native-style.test.ts`, a new golden test.
- **Test:** the golden output is unchanged for every view × theme × basemap.
- **Mutation:** the dialect stops dropping `promoteId` → `native-style.test.ts` and the golden test fail. A second one
  closes risk (c): pin that the phone's atlas address starts with `pmtiles://file`; change it to `http://` → fails.

### L2 — imagery provider and offline-imagery interface (size S-M, Sonnet; no device; web shots of credits)

- **Files:** the call sites in section 3.
- **Tests:** `imagery.test.ts` (provider credit = style source credit); `OfflinePage.test.tsx` (no imagery row when
  `list()` is empty; a row when a fake lists one).
- **Mutation:** `basemapInUse` ignores `up` → the mapModes test fails; change one character of the provider's credit →
  `imagery.test.ts` fails.

### L3 — native map split into shell + `native/maplibre/` (size M-L, Opus; device bench + pictures)

- **Step 1, before any move:** add the two missing contract cases (tap-up, tile event).
- **Then:** move the code per section 4; turn the render tests into a one-row engine table; update the 7 source-reading
  tools tests to the new paths (same assertions); add the `layers.json` nested layer and the grep rule with its test in
  `tools/check-boundaries.test.ts`; update `deps.md`, `map/README.md`, `MAP.md`.
- **Mutations:** the three boundary mutations in section 4; drop the `onTapUp` mapping in `View.tsx` → the new tap-up
  case fails.
- **Device:** one test-bed APK and one iPhone build, the bench list in section 4, pictures before and after.

### L4 — build-time switch (size S, Opus; one build)

- **Files:** `metro.config.js` alias, vitest alias, tsconfig `paths`, `knip.jsonc`, `plugins/with-map-engine.js`,
  `app.config.js`, CI `bundles` run with `EXPO_PUBLIC_MAP_ENGINE=maplibre`; memory-trim, r8 rules and `build-apk.sh`
  checks gated on the engine.
- **Test:** the resolved config for maplibre equals today's.
- **Mutation:** `EXPO_PUBLIC_MAP_ENGINE=nope` → config and bundle fail with the named error.
- **Device:** `check-loaded.sh` shows the same build id.

### Risks, ranked

1. **The component move brings back a fixed native bug.** Known traps: a wrapper `View` (black rectangle), the scale bar
   off, `GeoJSONSource` taking over a style source (T831), attach-once (`Map.native.tsx:367-377`), queries before the
   first full render (SIGSEGV, N2, `:423-428`). Mitigation: the tree is moved unchanged; tree-order assertions; the
   two new contract cases; the bench.
2. **The tile server under MapLibre** (Android offline gate, cache writes, the id reader stops). Mitigation: do not move
   MapLibre (pick 1).
3. **Metro alias, tsc and knip friction** with an engine folder nothing imports directly.
4. **Tests that pin source text by path** get "fixed" by loosening them. Rule for the lanes: move the pin, never drop it.
5. **T1148 and L2 change the same words** (`seo/html.ts:255`, `layers.source.json:19`, `menu/words.ts:147`).
6. **The 0.10.0 release branch is open.** Every lane lands on `main` after it.

## 7. Proposed replacement text for T1154

### Work
1. Done: the read-only scoping (`night/T1154-scoping.md`): the inventory, the corrections to the handoff, the lanes.
2. **L1, style dialect and tile addresses.** The phone's style composition gets a dialect step (`native/maplibre/dialect.ts`:
   promoteId, area tables, image names) and a `TileAccess` record for the archives' addresses, kept apart from
   `at.atlas` (still the file, the pairing key and the route reader's path). A golden test holds the composed styles
   byte-identical; a test pins the phone's atlas address to `pmtiles://file` (the patch's id reader reads nothing else).
3. **L2, imagery as a provider.** `ESRI` as a provider record in core (engines, style source, offline method, credit,
   badge, outage rule, words); `basemapInUse`, `SATELLITE_OFFLINE`, `withImageryCredit`, the outage rule, the credits,
   the badge and `imageryTiles` read it. An `OfflineImagery` interface (list, size, download, remove) reaches the
   Offline maps page through `offlineVM`; implementations `none` (Esri) and `file` (lists nothing until a corridor
   product exists). After T1148's wording lands.
4. **L3, the native map split.** First the two missing contract cases (tap-up; the per-tile event). Then `Map.native.tsx`
   becomes the engine-neutral shell over `EngineHandle` / `<EngineView>`, and MapLibre's tree, refs, tile event,
   log and held labels move to `native/maplibre/` unchanged. The render contract tests run as a table over engines.
   A nested `layers.json` layer plus a grep rule (SDK names, `"MLRN`, `DeviceEventEmitter`, relative imports into an
   engine folder) keep engine code in its folder.
5. **L4, one engine per build.** `EXPO_PUBLIC_MAP_ENGINE` (default maplibre; unknown fails), a Metro alias
   `@app/map-engine`, a config plugin that gives today's plugin list for maplibre, and the MapLibre-only native glue
   (memory trim, r8 rules, AAR checks) gated on the engine. CI bundles name the engine.
6. The local tile server is built in T1155 for the Mapbox engine (option A or B of the scoping), not here. MapLibre
   stays on `pmtiles://file://`: MapLibre Native holds http requests while Android says it is offline, caches every
   http tile, and the patch's id reader reads only `pmtiles://file`.

### Acceptance
- The app looks and behaves the same:
  - the golden style test and every existing test pass unchanged in what they assert;
  - the two new contract cases pass;
  - the device bench (`perf`, `pan`, `glide`, `zoom-pinch`, `switch`, `regs-open`, `offline`, `satellite`,
    `back-flash`, iOS `regs-open`) is within noise of the build before: cold start no more than +5% and +150 ms (median
    of 5), pan no more than 2 fps lower, memory no more than +10 MB;
  - pictures before and after at the same places.
- Each boundary mutation fails the check (an SDK import, `"MLRNTileIds"`, or a relative import outside the engine
  folder).
- The resolved Expo config for maplibre equals today's, and the APK carries the same `libmaplibre.so` build id.
- The MapLibre patch is unchanged.
- Severity: enabling work. Release: its own minor after the hardening release. Model: Opus (L1, L3, L4), Sonnet (L2).
  Size: L (four lanes). Owner: the margin and a look at the bench pictures.

---

## Picks for the owner

1. **The local tile server.**
   (a) Build it only for the Mapbox trial (T1155); MapLibre stays on `pmtiles://file://` **(recommended)**.
   (b) Build it in T1154 as a test-only switch, measured, never the default.
   (c) As the ticket says now: move MapLibre onto it first.
2. **The "not slower than" margin.**
   (a) Refactor lanes within noise (≤ +5% / +150 ms cold start, ≤ 2 fps, ≤ +10 MB); the server, if ever used for
   MapLibre, 10% **(recommended)**.
   (b) 10% everywhere.
   (c) Identical numbers only.
3. **Order of the lanes.**
   (a) L1 style dialect → L2 imagery ∥ L3 native split → L4 switch **(recommended)**.
   (b) The native split first.
4. **The offline-imagery "file" method.**
   (a) The interface plus `none`/`file` that list nothing; real downloads when a corridor product exists (new ticket)
   **(recommended)**.
   (b) Build the real `file` downloads now over `bg-download`, with no corridors to offer yet.
5. **T1148 and L2 change the same words.**
   (a) T1148 lands first, in the hardening release; L2 builds on its words **(recommended)**.
   (b) Fold T1148's rewording into L2.

## NEW TICKET

- NEW TICKET: A local tile server module (Android + iOS) for the Mapbox engine, with option A against B measured
  (port, ATS, cleartext, backgrounding, cache, ids per tile). Belongs with T1155 if pick 1(a).
- NEW TICKET: Offline corridor imagery, the `file` method (download, list, size, remove over `bg-download`), once a
  corridor product exists (T79 line).
- NEW TICKET: `deps.md:56` and `adapters/native.ts:7` say the SDK is imported by `Map.native.tsx` only;
  `native/labelHold.tsx:15` imports it too. A doc fix; fold into L3 if it runs soon.
- NEW TICKET: Contract tests for the still-tap (`onTapUp`) and the per-tile event (`MLRNTileIds`). Neither path has a
  test today. These are also L3's step 1; ticket them alone if L3 waits.

## Not verified

- Nothing was run on a device. Every behaviour claim about the phones comes from reading code or docs.
- Whether iOS MapLibre holds http requests while offline. I read only that `MLNMapView.mm` uses reachability
  (lines 772-782); only Android was found calling `NetworkStatus::Set`. GitHub code search hit its rate limit
  mid-search.
- Whether MapLibre keeps a `no-store` tile out of its cache (headers test only).
- Whether the binding 11.5.0 exposes MapLibre's `setConnected` (the binding is not installed in either checkout I could
  read).
- Mapbox's interceptor on current v11 (only a beta page was read); rnmapbox's events and APIs; whether Mapbox native
  honours `promoteId`; Mapbox's own offline gating.
- The per-feature line split of the patch is an estimate (the total of 1,784 is exact).
- The 27 `tools/*.test.ts` files that name MapLibre were not each classified. The test-bed shot scenarios were named,
  not read.
- Startup cost, latency, battery and memory of any tile server: not measured (guesses are labelled).
- I did not read `gestures.ts` in full, `look.ts`, or `Map.web.tsx` past its imports.
