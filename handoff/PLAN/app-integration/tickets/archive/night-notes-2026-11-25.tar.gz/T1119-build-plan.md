# T1119 build plan: boat launches, marinas and named piers on the map (read-only scoping, 2026-11-25)

Owner picks (2026-11-25): kinds = launches, marinas, named piers; private docks = hide, drop unnamed piers; coast = all of BC
including the coast; tap = drawn only. Plan = design C from the earlier scoping: our own OpenStreetMap (OSM) layer in the
ATLAS tiles, built like the `obstacle` layer, always on.

Code claims below were read on the planning worktree at main (commit 8d2637f94). Data claims were read from the owner's
main checkout (read only).

## 1. Sources and licences (checked 2026-11-25)

| Source | What it gives | Licence (URL, date) | Use? |
|---|---|---|---|
| OpenStreetMap, `leisure=slipway`, `leisure=marina`, `man_made=pier` | the three kinds, all of BC | ODbL. https://www.openstreetmap.org/copyright (read 2026-11-25): credit OSM, say it is ODbL, link the copyright page | YES, the only source |
| BC Data Catalogue "Coastal BC Boat Launches" | coast only, "circa 2004", "may not be accurate or complete", no plans to update | OGL-BC per https://open.canada.ca/data/dataset/d5f9003d-a8f2-4065-ae5b-abe6f36d611b (read 2026-11-25) | NO (old, and mixing it with OSM launches brings those under share-alike) |
| BC Data Catalogue Recreation Sites and Trails launches, BC Parks facilities | I found no dataset that lists boat launches as a facility. A "Recreation Sites Subset" and a BC Parks API exist; neither showed a launch layer in search results | not confirmed | NOT USED. The recall check needs a human to pull the Rec Sites list (see lane 0) |
| DFO Small Craft Harbours | harbours (core, non-core, recreational); updated 2025-02-11 | OGL-Canada, per the map service and https://open.canada.ca/data/en/dataset/262451e7-6416-47b5-8453-f31d212ea657 (search result 2026-11-25, page not opened) | NO as a layer (same share-alike mixing problem for marinas). Fine as a recall check only |
| Municipal open data | not searched; no known city list of launches | not checked | NO |

ODbL points (not legal advice):
- OSMF "Horizontal Map Layers" guideline, https://osmfoundation.org/wiki/Community_Guidelines/Horizontal_Map_Layers_-_Guideline
  (read 2026-11-25). If all data of a feature type comes from non-OSM sources, share-alike does not apply to it. If OSM and
  non-OSM data are mixed for the SAME feature type, share-alike applies to the mix, even in a separate layer. So keep launches,
  marinas and piers OSM-only. Do not add Rec Sites or DFO points to the same layer without asking.
- The guideline does not directly speak to a layer that is all OSM. The repo already treats OSM-derived files as offered
  under the ODbL (`data/LICENSE-ODbL.md`, owner decision 2026-10-28). Same treatment here: the pinned file gets a `_licence`
  record and a row in that file.
- Could not confirm: the OSMF "Licence/Community_Guidelines/..." URL in the earlier notes returns 404; the URL above is the working one.

### Counts, one polite Overpass query (generic client name), 2026-11-25, OSM base 2026-11-26T03:43Z, all of BC (`nwr`)

| Kind | nodes | ways | relations | total | named (total) |
|---|---|---|---|---|---|
| leisure=slipway | 437 | 327 | 0 | 764 | 103 |
| leisure=marina | 59 | 153 | 75 | 287 | 218 |
| man_made=pier | 3,851 | 12,296 | 36 | 16,183 | 545 |

Query file: `/private/tmp/claude-502/-BC-freshwater-fishing-regulations/3412ea98-8ed4-4288-872f-61b07e9662f9/scratchpad/night/q.ql`.
Finding: the live data has 75 marina RELATIONS. The current fetch (`data/fetch_data.py:826-840`) asks only for nodes and
ways, so those would be missed. Lane 1 must ask for relations (`out center`).

### The July snapshot on disk (`data/source/bc_fisheries_data.gpkg`, table `water_access_points`, 16,704 rows; measured by a read-only sqlite query)
| Kind | rows | named | tagged private/no | named and not private |
|---|---|---|---|---|
| boat_launch | 742 | 98 | 35 | 95 |
| marina | 208 | 145 | 4 | 142 |
| pier | 15,712 | 521 | 916 | 488 |
| fishing_platform | 42 | 16 | 0 | 16 |

Expected drawn points under the owner's picks, a guess from the snapshot: about 707 launches (all non-private launches, named
or not; only 98 launches have a name, so ~640 would be unnamed icons), about 204 marinas, about 490 named piers, plus the
unnamed piers next to a launch or marina (unmeasured). Roughly 1,400 to 1,600 points. Launches: 14 of 742 carry `trailer`, 56 carry `fee`, so those tags cannot drive the look.
Some "named" piers are road or trail names on a pier-tagged way ("Yellowhead Highway", "Sasamat Lake Loop Trail", "Wharf
Street"): see pick 4.

Fresh water vs coast split and recall against Rec Sites: NOT measured (see "Not verified").

## 2. The data path in this repo's shape

1. Fetch. `fetch_overpass_water_access` (`data/fetch_data.py:803-931`) already queries slipway, pier, fishing, but: it
   deliberately drops marinas (docstring, `:807-` "Marina ... deliberately excluded"), drops private rows before writing
   (`:886-904`), reads nodes and ways only, and writes into the gpkg layer `water_access_points`. The July pin
   (`data/source/pins.json:92-96`) records only date and row count, with no `osm3s` base time kept. The gpkg is NOT a
   pinned file (only `fish_obstacles/fish_obstacles.gpkg` is, `pins.json:129-134`).
   Plan: a new, separate fetch for this layer (so the old layer and anything reading it stay as they are): kinds slipway,
   marina, pier, `nwr`, `out center tags`, and record the `osm3s` timestamp. Stop if any kind comes back empty
   (`_require_rows` pattern, `:920`).
2. Pin. How this input gets a pinned checksum without a fetch command in `data/source`: copy the `fish_obstacles` pattern.
   The cleaned file is committed small (about 1,500 points, under 1 MB as GeoJSON) at `data/source/water_access/water_access.geojson`
   with a top-level `_licence` record (`pipeline/common/licence.py` skips it) and its sha256 in `pins.json` the way other
   files are pinned (`bytes`, `sha256`, `url`, `upstream`; see `pins.json:129-134`; checker `pipeline/tools/source_pins.py`).
   Because it is small and OSM (ODbL, already public), it can live in git directly, so no hosted copy is needed; the
   `pins.json` entry still gets the date and `osm3s` base. Add a row to `data/LICENSE-ODbL.md` and `ODBL_FILES`
   (`app/packages/core/src/menu/licences.ts:60-72`).
3. Clean (new `pipeline/deliver/tiles/water_access.py`, shaped like `obstacles.py`):
   - drop anything with `access` or `mooring` of private or no (owner pick: hide);
   - drop unnamed piers unless within N m of a launch or marina (N = 100 m, a guess to be tuned; see pick 5);
   - way or relation to ONE point (a pier way: its landward end or centre; a marina polygon: centre point);
   - dedupe across kinds and within kinds: same kind within 30 m is one (a guess), a launch inside a marina polygon stays a
     launch;
   - drop points outside BC (the Overpass area is BC; still check against `data/source/bc_boundary.geojson`);
   - private marinas: `access=private` is dropped by the same rule; a marina with `access=customers`/`permit` is kept
     (16 and 5 rows in the snapshot all kinds; owner may want a different call, pick 6).
   No water-adjacency filter, because the owner said all of BC including the coast.
4. Tiles. The ATLAS tiles (the file phones already download; not the basemap file, which is 225 MB re-download per change).
   New `LayerSpec` in `FEATURES` next to `obstacle` (`pipeline/deliver/tiles/layers.py:415-434`), point, `ladder="none"`,
   `minzoom=10` (proposal: icons from z11, names from z14; the tile layer starts at z10 like obstacle), attrs
   `access_id` (`osm:node/123`, string, so no MVT id), `kind` (launch | marina | pier), `name`. Add the layer to
   `pipeline/deliver/tiles/tile-contract.json` (obstacle is at `:268`), to the export in `tiles/__main__.py:87-123`
   (obstacle is exported at `:122-124`), plus an `--water-access-only` flag like `--obstacles-only` (`:46-57, :87-90`).
   Size expected: obstacle's 27,267 marks cost +5.7 MB (`layers.py` docstring). We have about 1,500 points, so about
   0.1 to 0.5 MB, labelled a GUESS (earlier notes said 1 to 2 MB; the point count suggests less). The spike measures it
   (append the tiles to the live atlas tile and gzip, as T173 did).
5. Style. `app/packages/map/style/layers.source.json`: a new group (like `obstacles` at `:81-86`, but `toggleable: false`,
   `defaultVisible: true`) and a layer next to `obstacle` (`:2708+`), `geometry: point`, `highlightable: false`, icon `by: kind`,
   name label from z14, then `pnpm style:build` (rule 28, `AGENTS.md:251`). Check the Conditions `covers` list and label
   collision order (T299) so names do not hide water names.
6. Not touched: Protomaps basemap file (`data/source/bc.pmtiles`), which already draws piers as a grey shape. Our icon
   must not double up with it (spike picture: icon on top of the grey pier).

Existing point layers for comparison: `obstacle` (above); gauges are a data-driven provider on water layers
(`layers.source.json:1005`, `"provider": "gauges"`) and stocked is a lake property (`:1473-1476`), so neither is a good template; obstacle is.

## 3. The app side

- Icons: drawn in code, like obstacles. Shapes in `@app/core` (`obstacleIcons.ts`, `OBSTACLE_ICON_SHAPES`, 16 grid); new
  `app/packages/core/src/waterAccessIcons.ts` with three shapes (launch: ramp sloping into waves; marina: a boat or an anchor;
  pier: a T-shaped jetty line), rasterised by a copy of `app/packages/map/src/obstacle-icons.ts` and added in `images.ts:49-50`
  (obstacle loop) for web and phone. Colour: the owner's rule says colours on the map are answers, so neutral ink in a paper halo
  (a new token `color.access.mark`/`ring`, copying `color.obstacle.*`).
- Map key row: `app/packages/core/src/mapKey.ts:28-29` (`obstacle:` words per icon kind); add `waterAccess: { launch: "Boat launch", marina: "Marina", pier: "Pier" }`.
  Layout rule (memory `map-ui-layout-rule`): the legend sits in the bottom bar and the Map legend bar holds the legend only; so
  the three rows go into the existing legend there, not a new control at the top. Always on means no Layers-sheet row
  (`layers.ts:165-166` is obstacle's toggle; we add none).
- "Drawn only": the ticket says no tap target. Facts: obstacles tap through `OBSTACLE_LAYERS` (`sections.ts:72`),
  `queryRenderedFeatures` (`native.ts:109`, `web.ts`), `onPressObstacle`. We add NOTHING to those lists, so a tap on an icon
  falls through to whatever is under it (the water or the area). Risk: a reader taps an icon and gets the lake sheet; fine and honest.
  `highlightable: false`.
- Offline: the points are inside the atlas tiles, which are the offline download, so they come offline with the map. The
  atlas bytes change, so the next release re-downloads the changed tiles (size of that delta is the spike's number).
- Search: no. Search reads waters and places, not tiles; the ticket does not ask. A named marina or launch is not searchable.
  If wanted, pick 8.
- Attribution: OSM is already credited. `app/packages/map/src/credits.ts:52-56` (`BASEMAP_LINE`, `OSM_PART`) is the map
  credit while the drawn ground shows; the atlas credit (always on) already names OSM-sourced names and side channels
  (`credits.ts`, atlas line). Add "boat launches, marinas and piers" to that atlas line so the credit stays true on the
  Satellite map. Sources page: `app/packages/core/src/menu/licences.ts` (`ODBL_FILES`, add the pinned file; and a Sources row
  naming the layer and the date of the snapshot). Test: `legal.test.ts` (Sources and licences, `:56`) must list the file.

## 4. Lanes, files, tests, mutations, sizes, release

Lane 0, spike (Opus, S/M, read plus one polite Overpass run, no tiles build): fresh vs coast split; piers within 100 m of a
launch or marina; recall against the Rec Sites list and DFO harbours (the owner or a lane pulls them; they are used for
checking only); atlas byte cost; Protomaps pier double-draw; then the pictures (section 5).

Lane 1, source and snapshot (Opus, M). Files: `data/fetch_data.py`, `data/source/pins.json`, `data/source/water_access/water_access.geojson` (new),
`data/LICENSE-ODbL.md`, `app/packages/core/src/menu/licences.ts`, `pipeline/tests/test_water_access_fetch.py` (new).
Tests: kinds present, relations handled, private dropped, empty kind stops. Mutation: make the query omit marinas, test must fail;
make an empty kind pass, test must fail.

Lane 2, tile layer (Opus, M). Files: `pipeline/deliver/tiles/water_access.py` (new), `layers.py`, `tile-contract.json`, `tiles/__main__.py`,
`pipeline/tests/test_tile_water_access.py` (new, modelled on `test_tile_obstacles.py`), the count-against-last-build check. One full
tiles build, owner's heavy job through `scripts/heavy.sh` (not run by this agent).
Tests: unnamed pier dropped far from a launch, kept near one; private dropped; dedupe; layer spec equals app kinds.
Mutations: keep unnamed piers; flip the private test; halve the dedupe radius; empty the file (the count check must stop the build; a large fall vs last build stops it).

Lane 3, style, icons, legend, credits (Sonnet, M, beside lane 2 on a fixture). Files: `layers.source.json` (+ `pnpm style:build`
output), `app/packages/core/src/waterAccessIcons.ts` (new) with test, `app/packages/map/src/water-access-icons.ts` (new), `images.ts`,
`mapKey.ts`, `credits.ts`, `licences.ts`, theme tokens, a render test (one known launch and one known dock draw; no
tap handler registered). Mutations: remove the image for one kind (a missing image draws nothing, per `images.ts` comment); set
`toggleable: true`; drop the credit line; each must fail a test. Run only the changed tests plus the style build (memory `test-only-what-changed`).

Lane 4, device and offline check (Sonnet, S): Android, iPhone, web, offline, both map kinds; rides the APK batch (memory `apk-hold-until-batch`).

Sizes: lane 0 S/M, 1 M, 2 M, 3 M, 4 S. Release: 0.11 (ticket header says 0.11). It does not fit 0.10.0 (the release branch is cut,
release candidates are being made); do not add it to 0.10.0.

## 5. Pictures the owner must see first (described; the spike makes them)

1. Okanagan Lake at z11, z13, z15: icon only, icon plus names from z14, icon plus names at every zoom. Busy lake; shows clutter.
2. Shuswap Lake, same three.
3. One small lake with a single launch (rec site), z14 and z16.
4. One coastal harbour (Vancouver Island or Howe Sound area) with a marina and many piers: before and after dropping unnamed piers.
5. The same crop on the Satellite map to check the paper halo reads on photos.
6. A pier crop showing our icon over Protomaps' grey pier shape (double-draw check).

## Picks for the owner

1. Names on the map?
   a) Icon from z11, name from z14 (recommended); b) icon only, no names; c) names at every zoom.
2. Unnamed launches (about 640 of 740 in the snapshot): keep them as icons?
   a) Keep all launches, as picked (recommended); b) keep only named launches; c) keep unnamed ones only from z13.
3. Marinas that are `customers` or `permit` access:
   a) Keep (recommended); b) drop with the private ones.
4. Piers whose name is clearly a road or trail ("Yellowhead Highway", "Sasamat Lake Loop Trail")? (Memory says never filter content without asking.)
   a) Show them as named (recommended: no filtering); b) hide piers whose name matches a list you approve; c) show the icon without the name.
5. How close to a launch or marina does an unnamed pier have to be to stay?
   a) 100 m (recommended, a guess to be tuned from the spike pictures); b) 50 m; c) 250 m.
6. Marina polygon: one icon at the centre? a) Yes (recommended); b) also draw the outline.
7. Release: a) 0.11 (recommended); b) hold for the 0.10.0 RC only if the spike shows a tiny delta.
8. Search for named launches and marinas? a) Not now (recommended); b) yes, as a later ticket.
9. Fishing platforms (`leisure=fishing`, 42 rows) and boat rentals: a) not now, since you picked three kinds (recommended); b) add platforms.

## NEW TICKET lines
- NEW TICKET: Spike for T1119: coast/fresh split, pier-near-launch rule, recall vs Rec Sites and DFO harbours, atlas byte cost, six pictures.
- NEW TICKET: Fetch refresh must ask for OSM relations (75 BC marinas are relations) and keep the `osm3s` timestamp in the pin (`data/fetch_data.py`, `pins.json`).
- NEW TICKET (optional): Name water-access points in search.

## Not verified
- Fresh-water vs coast split, and how many points sit near an atlas water: not measured (needs the atlas on disk; heavy).
- Recall against Rec Sites and BC Parks launches: no launch dataset found in the BC Data Catalogue; BC Parks facilities not confirmed; municipal open data not searched.
- DFO Small Craft Harbours licence read from a search summary, not the page. Coastal BC Boat Launches licence read from its page (OGL-BC).
- Atlas bytes: a guess (0.1 to 0.5 MB), not measured. The 30 m dedupe and 100 m pier radius are guesses.
- Whether the obstacle tap list `OBSTACLE_LAYERS` leaves an untapped point truly falling through to the water: read the code path, not run it.
- The ODbL wording for an all-OSM derived layer: the guideline does not address it directly; not legal advice.
- Did not run any build, test or tiles step.
