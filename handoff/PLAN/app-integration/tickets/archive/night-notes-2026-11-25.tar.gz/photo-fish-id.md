# Offline PHOTO fish identification: should we add it, and how (2026-11-25)

Read-only research. Repo read at main (planning worktree). Web facts carry URL + date 2026-11-25. "UNCONFIRMED" = not verified.

## 0. Short answer

- Do NOT ship a photo-recognition model now. No ready model covers our hard pairs, none has a clear licence we can redistribute, and no source shows a photo can separate them.
- Ship a guided key ("questions with pictures") built on the guide we already have, then, only if the owner wants, a photo model that proposes candidates the key must confirm, and that says "not sure" often.
- The site may truthfully say "fish identification guide with pictures and plain-words tips for N species". It may not say "photo ID", "identify from a photo" or "camera".

## 1. What is shipped today (the guide)

Source of truth: `app/apps/mobile/assets/fish/manifest.json` (its `_about` line says: "The owner holds permission for every image here (2026-10-20; IMPLEMENT-HANDOFF §6 item 1)"), generated into `app/packages/core/src/regs/fish.generated.ts` (header lines 1-2; FISH starts line 13).

Pictures
- 41 picture files, 1.9 MB in total (`du -sh` of the fish folder, thumbs included), each 800x400 webp, 25 to 70 KB.
- 27 fish codes: BB burbot, BCB black crappie, CH chinook, CM chum, CO coho, CRA signal crayfish, CT coastal cutthroat, DV bull trout + Dolly Varden (two pictures), EB brook trout, GB brown trout, GE goldeye, GR Arctic grayling, IN inconnu, KO kokanee (2 looks), LMB largemouth bass, LT lake trout, LW lake whitefish, MW mountain whitefish, NP northern pike, PK pink, RB rainbow, SK sockeye, SMB smallmouth bass, ST steelhead (2 looks), WP walleye, WSG white sturgeon, YP yellow perch, plus green sturgeon, westslope cutthroat, and three stand-ins for rare fish (Salish sucker, Nooksack dace, Cultus pygmy sculpin, drawn with a related fish: `fish.generated.ts`, `standInFor`).
- Salmon (chinook, chum, coho, pink, sockeye) and steelhead have two looks: ocean and spawning.
- Where the pictures come from (counted from `fish.generated.ts`): 13 "Regulations photo" from WDFW via eRegulations WA; 11 studio photos (8 Freshwater Fisheries Society of BC via GoFishBC, 2 What To Fish, 1 DFO sturgeon guide, and Photo Ark photos); 7 paintings (USFWS Raver and others); 4 colour plates; 4 B&W engravings; 1 tinted engraving. Several are Commons public-domain works (Jordan & Evermann 1900, Fishes of Alaska 1907, Faxon 1885, Denton).
- Licence: the code does not state a licence per picture. The only statement is the manifest `_about`: the owner holds permission. NOTICE has no fish-picture entry (grep of NOTICE for fish/WDFW/GoFishBC found none). Credit lines are shown in the app (the credit list near `fish.generated.ts:195-206`). So: permission by the owner, not an open licence. Not verified: what the permissions say, and whether they cover redistribution of the repo's public copy (the repo is public, so the images are published in it). NEW TICKET: record each picture's licence or permission in NOTICE.

Words
- "What to look for" tips: `FISH_TIPS` (`fish.generated.ts:~209`, 21 codes: BB BCB CT DV EB GB GE GR IN KO LMB LT LW MW NP RB SMB ST WP WSG YP), described as page v36's FISHART table; 2-4 short lines each. Salmon tips are `SALMON_TIPS` in `app/packages/core/src/regs/sheets/salmonTips.ts:7-` (CH, CO, SK, PK, CM; "the ones DFO / WDFW identification guides lead with": that file says so; the words are our own paraphrase, no per-line source).
- Not covered by tips: green sturgeon, westslope cutthroat extra, the stand-ins.
- Hatchery or wild: a drawing sheet of the two fins (`app/packages/core/src/regs/sheets.ts:147-160`, `hatchSheet`, words `SHEET_HATCH_*` in `words.ts:231-232`). It is drawings, not photos.
- Where it appears: the species sheet "Identification" tab (`app/packages/core/src/regs/sheets/species.ts:1-12`: Identification = pictures + what to look for; Sources = the rule's source). Opens from a trout row, an Other-fish row, a salmon row, or a picture.
- T46 itself (closed, e3332e62) only fixed the layout: looks side by side on desktop with a max width. It did not add identification.
- Bull trout vs Dolly Varden: one DV code, two pictures (bull trout studio photo, Dolly WDFW) and one tip list ("Bull trout: big, broad, flat head", `fish.generated.ts:212`). No side-by-side key.

## 2. Ready models and datasets

| Item | What it is | Accuracy / size | Licence | Hard pairs? | Source (all fetched 2026-11-25) |
|---|---|---|---|---|---|
| Fishial.ai repo | Open code, 866-species classifier (DinoV2-224 + ViT), also 775/640 class models, TorchScript | 93.22% for 866 classes (what test set: not stated); no file sizes listed; ViT-class model, likely tens to hundreds of MB (GUESS) | Code MIT. Weights and training data: NO licence stated on the page | Not tested for look-alikes; no BC list. Not stated if our species are in the 866 (`labels.json` not read) | https://github.com/fishial/fish-identification |
| Fishial reviewed 2022 | Reef Builders said the app "just didn't work" then | old | | | https://reefbuilders.com/2022/10/14/fishial-project-uses-artificial-intelligence-to-identify-fish |
| FishNet (ICCV 2023) | 94,532 images, 17,357 aquatic species, benchmark | No accuracy given on the page | Page is CC BY-SA 4.0; the DATA licence is not stated | World fish, mostly marine; not BC-focused (inference) | https://fishnet-2023.github.io/ |
| iNaturalist / Seek model | On-device model in Seek, about 80,000 taxa (v2.13, Feb 2025) | n/a | No source found saying the weights can be downloaded or reused; a 2020 forum reply says the model is not downloadable (old) | n/a | https://forum.inaturalist.org/t/inaturalist-updates-for-february-2025/62406 ; https://forum.inaturalist.org/t/where-to-find-inat-vision-model/12341/2 |
| iNaturalist Open Data | 400M+ photos on AWS S3, Creative Commons mixed licences, CSV with licence and observer | n/a | Each photo keeps its own CC licence; attribution needed; page is silent on machine-learning use | n/a | https://github.com/inaturalist/inaturalist-open-data |
| iNat general accuracy | 2017 dataset paper: 67% top-1 over about 5,000 species | old, not fish | | | https://ar5iv.labs.arxiv.org/html/1707.06642 |
| Fish4Knowledge and Roboflow sets | Underwater/coral-reef and hobby sets, CC BY 4.0 or public domain (Roboflow pages) | n/a | varies | No BC freshwater coverage seen | https://universe.roboflow.com (search 2026-11-25) |

Findings
1. No ready, clearly-licensed, small model covers BC freshwater fish. Fishial is the closest and its weights have no stated licence (ask them; UNCONFIRMED whether they would allow redistribution).
2. A top-1 figure such as 93% over hundreds of classes says nothing about the pairs we care about. Not found: any published accuracy for bull trout vs Dolly Varden, coho vs chinook jacks, or juvenile salmon vs trout from photos.
3. Can the hard pairs be separated from a photo at all?
   - Bull trout vs Dolly Varden: COSEWIC says no single character separates them; a set of characters, with fin-ray and gill-ray counts and head shape, does. Yukon government calls them "extremely difficult to tell apart" and uses range. Juveniles are worse. No photo-only accuracy study found. https://www.canada.ca/en/environment-climate-change/services/species-risk-public-registry/cosewic-assessments-status-reports/bull-trout-2012/chapter-5.html ; https://yukon.ca/en/bull-trout (2026-11-25). Conclusion: a photo model cannot be trusted here; location plus the rule is the only honest answer (our regulation data already knows the water).
   - Wild vs hatchery steelhead and coho: the clue is a small missing fin, or a healed scar. A blog's detector (YOLO, fish-ladder camera) found adipose present/absent but gave no headline accuracy, and noted a scar can look like a small fin. A phone photo of a wet fish in a hand is much worse than a fish-ladder window. No study found with a figure. https://blog.roboflow.com/using-computer-vision-to-count-fish-populations/ (2026-11-25). Better as a question to the angler ("is the small fin behind the back fin there?") with our drawing.
   - Juvenile salmon vs trout: parr marks and spots; no source found. UNCONFIRMED.
4. BetterFish: the only source found is a store aggregator saying users "photograph a fish for species identification, with an offline identifier and illustrated guides" (https://mwm.ai/apps/betterfish/6794007475, 2026-11-25). Its own site could not be fetched (connection refused). UNCONFIRMED whether it is a real image model or a guide with photos; the Google AI answer pasted in COMPETITORS.md is not evidence either. Their accuracy is not published (none found).

## 3. Running it on the phone

- react-native-fast-tflite (MIT, Nitro Modules): Expo config plugin with `enableCoreMLDelegate` and `enableAndroidGpuLibraries`; needs prebuild; models bundled with `require('x.tflite')` after adding `tflite` to Metro assetExts, or loaded from a file or URL; Android NNAPI deprecated on Android 15, GPU preferred; maintained "in free time" by one developer; new-architecture support not stated on the page. https://github.com/mrousavy/react-native-fast-tflite (2026-11-25).
- LiteRT is Google's runtime built on TensorFlow Lite, for Android, iOS, web; migration guide offered. https://developers.google.com/edge/litert (2026-11-25).
- onnxruntime-react-native: install page only; Expo and new-architecture support not confirmed on the pages read. Prebuilt Android AAR about 24.4 MB; a custom minimal build about 7.5 MB (for ResNet50, v1.18) but needs ORT-format models. CPU default; NNAPI/XNNPACK on Android, CoreML/XNNPACK on iOS. https://onnxruntime.ai/docs/tutorials/mobile/ , https://onnxruntime.ai/docs/get-started/with-javascript/react-native.html (2026-11-25). App-size cost is the runtime plus the model.
- react-native-executorch (MIT): `useClassifier`; needs the New Architecture and a development build, not Expo Go; ready models are ImageNet-1k, our fish would be a custom export. https://docs.swmansion.com/react-native-executorch/docs/extensions/image-classification (2026-11-25).
- Web: onnxruntime-web has a WebGPU provider available in Chrome and Edge, Firefox behind a flag, Safari in Technology Preview; WASM runs everywhere. https://onnxruntime.ai/docs/tutorials/web/ep-webgpu.html (2026-11-25).
- Our camera: not looked at; the repo has no TFLite or ONNX package today (grep of the two package.json files: only react-native-pdf and pdf-lib hit). Adding any runtime means native code and a new Android and iPhone build.
- Size and speed (GUESS from general knowledge, not measured here): a MobileNet or EfficientNet-class model with 30 classes is about 3 to 15 MB quantised, tens of milliseconds a photo on a recent phone. The runtime adds a few to 25 MB. The guide pictures already weigh 1.9 MB, so the model is the largest asset in the app.

## 4. Training our own

- Photos: iNaturalist open data. Each photo has its own CC licence. We can filter to CC0, CC-BY (and perhaps CC-BY-SA) to avoid NC problems; the page is silent on training use, so the licence terms govern (attribution and compliance). Whether a model trained on CC-BY photos must carry attribution is a legal question: UNCONFIRMED, ask a lawyer. Only the model is shipped, not the photos, which is the lower-risk path. Government sets: the guide's own WDFW/GoFishBC pictures are permission-only and one photo per fish, far too few.
- Count: a fine-grained classifier usually wants several hundred research-grade photos per species (GUESS). Common species (rainbow, pike, perch) are plentiful. Rare in iNaturalist (bull trout, wild vs hatchery steelhead, coho jacks) will be thin, and iNaturalist labels on exactly these pairs are themselves often wrong (consistent with the COSEWIC point). Not measured: actual counts by species; a script could count them with the iNat CSVs (heavy: do not run tonight).
- Cost: fine-tuning a small pretrained network on about 25 species x 500 photos is a few GPU-hours (GUESS), tens of dollars or less. The labour is in data cleaning and the look-alike test set, not compute.
- Honest accuracy: build a held-out test set of look-alike pairs that is NOT scraped from the same observers as the training set, labelled by a person who can tell them (a biologist; the owner would have to find one). Report per-pair results and the "not sure" rate, and measure how often a wrong answer is given with high confidence on the protected-fish pairs. Selective prediction (abstain below a threshold) is the standard method; one paper warns that post-hoc calibration changes little and the model's ranking matters (https://arxiv.org/abs/2208.12084 , https://arxiv.org/pdf/2510.20242, 2026-11-25). Also needed: a "not a fish / not one we know" class, since an angler may photograph a sculpin or a squawfish.

## 5. The cheaper alternative: a guided key

Built on what we have: the pictures, `FISH_TIPS`, `SALMON_TIPS`, the adipose drawing sheet.
- The angler answers 4 to 6 yes/no questions, each with a picture: Is the small fin behind the back fin there? Spots on the tail (none, upper lobe, both lobes)? Mouth/gum colour? White front edge on the lower fins? Worm-like marks on the back?
- Each answer narrows the list; a result states "matches X and Y; these two cannot be told apart from looks; the rule for this water is ...". For bull trout vs Dolly Varden the key ends with the regulation for the water in view (which the app already holds), not a guess.
- No camera, no model, no new native code, no privacy question, and it works on the web too. Effort: about 1 to 2 weeks (pictures reused; a decision table; a UI sheet; tests that every outcome is reachable and that protected-fish questions never end on a confident single answer). Risk: low; the table needs a biologist's review (UNCONFIRMED who).
- Hybrid: the model proposes 3 candidates, the key's questions then confirm or contradict. Only worth building after the key exists and the model's held-out look-alike test shows it beats a coin on the pairs; the key remains the decider.

## 6. Options

| Option | Effort | Risk | App size | Notes |
|---|---|---|---|---|
| A. Keep the guide, add the guided key | 1-2 weeks | low | about 0 to 1 MB | Recommended. Works on web. |
| B. A plus a "compare these two" page for the hard pairs (bull vs Dolly vs lake/brook char; wild vs hatchery; coho vs chinook; juvenile salmon vs trout) | 3-5 days after A | low | small | Also needs a biologist's check |
| C. Photo model proposes, key confirms | 4-8 weeks incl. data and test set | medium-high: wrong keep of a protected fish; licence questions; Expo native code | +10 to 40 MB (GUESS) | Only after A and only with a measured test |
| D. Photo model alone, top-1 answer | 3-6 weeks | high | same | Not recommended |
| E. Cloud photo model | cheap to build | breaks "no photo leaves the phone" and self-host; owner pays per call | none | Not recommended; if ever, say plainly "this photo is sent to our server" |

## 7. Wording

In the key and in any later model, never "This is a bull trout". Use:
- Certain only from the key's questions: "Your answers match: coastal cutthroat trout."
- Several: "Could be rainbow trout or coastal cutthroat. Check the red slash under the jaw."
- Protected pairs: "We cannot tell these apart from looks. Check the rules for this water; if in doubt, release it."
- No match: "Not sure. Release it unhurt and check the rules for this water."
- Footer: "This is a guide, not a ruling. You are responsible for the fish you keep."
If a model is ever added, show "a guess from the photo, about X% right on our test of N photos" only after that test exists; never a percentage the model gives itself.

## 8. What the site may say today (T1152)

Allowed (backed by code): "Fish identification guide with pictures and plain-words tips for about 27 fish, including salmon and steelhead in ocean and spawning looks, and a hatchery-or-wild drawing guide (the small adipose fin). Works offline in the app" — offline: not verified for the guide (the pictures are bundled in `app/apps/mobile/assets/fish`, so likely, but check the web build and the store builds before saying so).
Not allowed: "photo ID", "identify fish from a photo", "AI fish identification", "scan a fish".
The count of species should be generated from the manifest (27 codes, 41 pictures) so the text cannot drift. The tips cover 26 codes (21 + 5 salmon).

## Picks for the owner

1. Photo identification: (a) Not now; build the guided key first [recommended]; (b) key, then a hybrid model later if the test set looks good; (c) a photo model now.
2. Picture licences: (a) Record each picture's permission in NOTICE now [recommended]; (b) leave as is.
3. Hard pairs: (a) The key ends on "cannot tell; see the rule for this water" for bull trout vs Dolly Varden [recommended]; (b) the key names one species by size/place.
4. Expert check: (a) find a BC fisheries biologist or guide to review the key before release [recommended]; (b) the owner reviews alone.
5. Cloud fallback: (a) never send photos off the phone [recommended]; (b) allow it only with a plain notice.

## NEW TICKET lines

- NEW TICKET: Guided fish key (questions with pictures) on the species sheet, ending in "not sure" for look-alike pairs.
- NEW TICKET: A "compare the look-alikes" page for the protected pairs.
- NEW TICKET: Record the licence or permission of every fish picture in NOTICE and the manifest.
- NEW TICKET: Site wording on fish identification generated from the manifest (part of T1152).
- NEW TICKET (only if pick 1b): Count iNaturalist CC photos per BC species and build the held-out look-alike test set.

## Not verified

- Fishial's labels list, weight licence and size; whether our species are in the 866.
- iNaturalist's licence terms on training use; photo counts per BC species; research-grade share of fish photos.
- BetterFish's actual feature (its site was unreachable; only an aggregator summary).
- onnxruntime-react-native Expo and new-architecture support; fast-tflite new-architecture support; Expo SDK documentation (404).
- All model sizes, speeds, GPU costs, per-species photo needs (marked GUESS).
- That the guide works offline in the store builds; the permissions' exact terms; the 2026-10-20 handoff document.
- iNaturalist's own pages returned 403, so its training rules were not read.
