# Audit: pipeline and data changes in 0.10.0 (written 2026-11-25 21:22 MST)

Read-only. Refs: tag `v0.9.0`, `origin/release/0.10.0` (e2b789bb6), merged PR #264 (T1146, 1048b7385 on main), and
T1140. **T1140 note:** the PR head on GitHub is da141d1cf, but the local branch `fix/T1140-part-label` is at cf449ed75,
11 commits further. Those commits hold all of tonight's new steps (95% inside, the derived join with a 50 m snap limit,
the touch rule) in `pipeline/deliver/bundle/side_channels.py`. I reviewed **cf449ed75**. Whatever gets cherry-picked
must be that commit or a later one, and it must be pushed.

Helpers and outputs: `night/audit-0100-pipeline/` (`handcheck.py`/`.out`, `mac.py`, `inseason_diff.py`, the saved
in-season resolution, the saved diffs).

## Verdict: ship. One check to run before `--prod`

**I found no HIGH finding.** No change I read can put a wrong rule on a water in today's data, and production cannot
ship a tree other than the tested rc. One change has not been measured: the in-season notices (M1). Run the diff below
after tonight's in-season step and before `--prod`.

## 1. Commits in range (pipeline, data/curated, scripts, deploy; merges left out)

Counted with `git log --no-merges --numstat v0.9.0..origin/release/0.10.0`. There are 41 merge commits on top.

| ticket | commits | lines | of which tests |
|---|---|---|---|
| T1047 (gauge datum changes) | 5 | +1474 −66 | +596 |
| T1029 (bank sides, one-bank tributaries) | 10 | +1092 −175 | +360 |
| T1030 (release digest list) | 4 | +844 −36 | +388 |
| T1053 (the walk climbs head lakes; the all-year closure yields) | 9 | +684 −37 | +407 |
| T1062 (release candidates) | 1 | +660 −78 | +351 |
| T1021 | 3 | +375 −61 | +175 |
| T1059 (CI check) | 2 | +373 −45 | +270 |
| T1058 (Gradle and watcher) | 4 | +311 −19 | +172 |
| T1048 | 4 | +302 −39 | +148 |
| T905 (DFO publisher) | 2 | +264 −34 | +166 |
| T1041 (ledger, repo move) | 5 | +210 −30 | +103 |
| T1024 | 2 | +141 −68 | +50 |
| T1050 (ice fishing words) | 2 | +120 −5 | +84 |
| T1020 | 2 | +99 −1 | +92 |
| T1117 (the "ANDERSON" lake row binds Walbran) | 2 | +55 −12 | +37 |
| T1072 | 2 | +50 −21 | 0 |
| T1051 (treble and barbed words) | 1 | +39 −1 | +24 |
| T1086, T1099, T796, other | 5 | +50 −13 | |

T1052 ("fully closed says it once", 4376ceae7) is in the range but touches only `app/`. I did not review it.
Tonight's picks: T1146 is +88 lines in `tributaries.py` and +7 in `cache.py` (POLICY_VERSION 51). T1140 at cf449ed75
is +1298 −14 under `pipeline/`, of which +608 are tests.

## 2. Findings

### M1 (MED, process). The T1146 walk changes in-season notices, and nobody measured it

- **Where:** `pipeline/regs/inseason/points.py:241` calls `T.expand(..., registry=reg)`. That makes it take side channels
  through `tributaries.py:1078`.
- **Why it is unmeasured:** the binding diff compares the reach run only: rules, licensing and
  `dfo_salmon.jsonl.gz` (`binding_diff.py:124`). So **DFO places are covered** (1 place moved: the Cowichan, +9).
  **In-season is not.** The release's in-season stage (`release.py`, `stage_inseason`) resolves the notices again and
  overwrites `data/generated/inseason/resolved.json`, but compares nothing.
- **Exposure:** 7 curated in-season extents walk tributaries (`notice_waters.json`): Salmon River (R3), Lodgepole Creek,
  Granby River's tributaries, Similkameen River, Stave River, Bessette Creek and Alexander Creek. None of them is one
  of the 8 waters the rule diff moved. My guess is that few or no sections change, and only by gaining. Not measured.
- **Fix, no code needed:** I saved the candidate's resolution as
  `audit-0100-pipeline/inseason-resolved-r-71d09ad82e81.json`. After tonight's in-season step, run
  `python -I inseason_diff.py <saved> data/generated/inseason/resolved.json`. It reads two 40 KB files.
  - Caveat: the file keys waters by named item, so gains on unnamed feeder creeks may not show.
- **Confidence:** high that it is unmeasured, low on its size.
- The PR's own review listed this too (T1146 ticket, "Open notes").

### L1 (LOW). T1146 has no outflow guard: a channel draining to another basin takes the walked rule

- **Where:** `tributaries.py:1154–1159` (main). The guard checks only INFLOWS into the channel. Where the channel's
  water goes is never checked.
- **The case today:** MacMillan Creek's channel 360244113:889 (815 m) drains into Diana Lake, in another basin (T1146
  ticket, lines 129–130). It gains `skeena_river.r1`, the bait ban.
- **Effect for anglers: none.** It already carries `skeena_nass_bait_ban.r1` (`mac.py` on the candidate's
  `rule_section`: 102 rules before, the Skeena/Nass bait ban among them).
- **Smallest fix:** mirror the inflow test. Skip a component when an edge leaving it reaches a node whose code is
  neither the channel's nor one the channel drains into (`wsc.relation` APART).
- **Confidence:** high on the code, high on "no effect today".

### L2 (LOW, words only). The derived join distance can be measured from the wrong end

These are tonight's T1140 steps, in `side_channels.py`.

- **(a) A distributary into another named water is measured from its far end.**
  - `:273–275`: when the flow pointer leaves the channel for one shaped section, the DOWNSTREAM end is snapped.
  - For a channel that leaves the river and flows into another named water, that end is the far one. The place it
    leaves the river is the other end.
  - Beyond 50 m it becomes `how='nearest'` (`:297`). There is no distance cap at all, so "Side channel, N km from the
    mouth" can sit off by about the channel's own length.
  - The usual case is saved by `_flows_into` (builders.py), which says "into <Lake>" instead. That only covers the
    lowest channel of a part (`side_channels`, `k == 0`), so a second channel in the same part keeps the wrong distance.
- **(b) "into" can name a lake the channel flows out of.** With no usable pointer, both ends are tried for the touch.
  An upstream end on a named lake on the main line then reads "Side channel into <Lake>".
- **(c) Orientation picks a section near the line, not the next one down.** `:164–170` picks "the stem section below"
  by summed distance, not the one directly below. On a tight meander this could flip which end is the mouth's, an
  error of up to one section's length. Fix: take the `below` section with the highest `hi_m`.
- **(d) A crash, not a wrong word.** `:249` sorts tuples that end in shapely geometries. Two stem sections with the same
  (lo, hi) would raise TypeError. It fails loudly.
- **Today:** no instance known. Manson, Omineca, Shelagyote and MacMillan, the far-off ones, merge away after T1146.
  The build log of tonight's bundle stage ("side channel NEAREST" lines) will show any.
- **Confidence:** medium. I read the code only and did not run it.

### Checked and sound

- **"Inside <area>" cannot be claimed wrongly.**
  - Every inside/at pair must be in `part.REVIEWED_INSIDE` (`part.py:576`). A new one stops the build, and so does a
    reviewed one that stops being inside.
  - The area catalogue is EPSG:3005 like the shapes (`pyogrio.read_info`: 302 cut areas; regions, MU groups and sign
    zones excluded).
  - Two overlapping areas give no name (`len(hits) == 1`).
- **Determinism (T1140):** every query is ORDER BY, the STRtree hits are sorted, and ties are broken by id and then by
  place. I found no dependence on build order. T1146's seeds are sorted, and its cache is keyed by the registry object.
  A caller that mutates the registry in place would read a stale cache. None does today, as far as I read; not verified.
- **`_unnamed_lakes` keys:** the pickle keys are `lake:<wbk>` (`atlas/build.py:1537`), the same as section ids, so
  "owned" works.
  - The bundle stage now loads the whole 763 MB `waterbody_polys.pkl`. Its memory peak is not measured, and the tests
    inject `unnamed=` instead, so only a real build runs this path.
- **T1146 against carve-outs and lakes:**
  - Carve-outs walk without `registry` (`reach/build.py:821`). A carve-out therefore never takes side channels, but the
    rule's seeding needs every touching piece of the item in its own set, so a carve-out's channel is never handed to
    the rule.
  - Only `NodeKind.stream` pieces of STREAM items are seeded, so "a lake must not answer to its river" holds.
  - Barriers, blocked and own-water pieces are excluded.
- **T1062 (release candidates):** production cannot ship an untested tree.
  - `--prod` refuses unless all of these hold: the fingerprint is unchanged, staging serves that r-id, `data/<r-id>` is
    at the ship commit, `v<x.y.z>` is at the newest rc, and the rc holds the ship commit (`release.py:2765–2800`).
  - `--final` refuses unless HEAD and origin's branch are the newest rc apart from the store build numbers, and no
    `v` tag exists anywhere (`:2820`). No tag is ever moved.
  - Store builds check the rc and the same HEAD after the lock (`build_check_rc`, `build_same_head`).
  - Residual (info only): a staging rerun at a new HEAD with an unchanged r-id tags a new rc without rerunning the
    smoke (`:2162` returns into `tag_release`, `:2104`). Pipeline changes force a rebuild (`built_by_this_release`), so
    only app or script changes take this path. Off `release/x.y.z` the rc check is "not asked".
- **Silent fallbacks:** the only `except Exception` added in the range is `scripts/mutation_report.py`, and it is
  report-only. T1146 and T1140 add none. T1140 stops loudly on a part it cannot name.
- **T1053's "the all-year closure yields" (ladder step 3c):** measured by its lane. 123 parts change, of which one
  changes status: Dove Creek, approved by the owner on 2026-11-25. The guards are pinned by tests.
- **T1029's one-bank tributaries:** a side it cannot read keeps the tributary and reports it. It never guesses
  (`dfo_salmon.py`, `one_bank_tributaries`).

## 3. Hand check of the T1146 gains (all 56 sections, 10 read against the rule text)

**Method (`handcheck.py`):** one pass over the candidate's `rule_section.jsonl.gz` plus `registry.json`, at 1.2 GB peak
in about 3 min. For each of the 22 gained channel pieces, I compared its rules after the change (before plus gained)
with its river's other pieces.

**Result:** all 22 carry every rule that all their river's other pieces carry. None carries a rule that no other piece
of its river has. All 34 feeders had region rules before, and each gained only the walked rule.

| # | section | gains (rule text) | the river's other pieces |
|---|---|---|---|
| 1 | Koksilah 354088055:0 | cowichan_river.r2 "No Fishing July 15-Aug 31", tributaries | all 8 carry it ✓ |
| 2 | Koksilah 354088059:0 | same | ✓ |
| 3 | Shelagyote 360236653:0 | babine r6 "Bait ban", r7 "No angling from boats … fence downstream to the Skeena", skeena r1 bait ban | all 44 carry all three ✓ |
| 4 | Manson 359006961:0 | williston_lake.r4 grayling catch and release from tributaries (zone A) | all 40 ✓ |
| 5 | Omineca 359024302:0 | same | all 51 ✓ |
| 6 | Old Kootenay Channel 356365662:1210 | kootenay_river_lower.r4 burbot catch and release, tributaries of the stretch | all 3 ✓ |
| 7 | Halfway 359007640:0 | peace r2/r3 grayling and whitefish catch and release, Hwy 29 to Site C, tributaries | carried by some Halfway pieces, not all (the 3 left in p2 lack it) ✓ |
| 8 | Forsyth 356370830:0 | elk_river_s_tributaries r1–r4 (No Fishing Sept 1–Oct 31; trout/char 1, none under 30 cm; bait ban Jun 15–Aug 31; bull trout catch and release) | on some Forsyth pieces only; whether the channel lies beside those I did not check |
| 9 | MacMillan 360244113:889 | skeena_river.r1 bait ban | 15 of 16 pieces; 360874166:0 has no rules at all (not checked why); drains to Diana Lake (L1) |
| 10 | feeder 360741246:0 (3.0 km) | babine r6/r7, skeena r1 | a feeder of the Shelagyote channel; its flow into the channel is not checked (graph not loaded) |

## Picks for the owner

1. **The in-season notices after T1146 (M1).**
   - **A. (recommended)** Before `--prod`, run `inseason_diff.py` on tonight's resolution and read it.
   - B. Ship without measuring it.
   - C. Turn the side-channel step off for in-season in 0.10.0 (pass no `registry` at `points.py:241`).
2. **MacMillan's channel into Diana Lake (L1).**
   - **A. (recommended)** Leave it for 0.10.0. Anglers see no change, since the Skeena/Nass bait ban binds already. Add
     the outflow guard next release.
   - B. Add the guard now. That means a reach rerun and a new binding diff tonight.
3. **A side channel said at its "nearest" point, with no distance cap (L2a).**
   - **A. (recommended)** Keep it as proposed for 0.10.0, and read tonight's "side channel NEAREST" log lines.
   - B. Cap it (for example 1 km) and stop the build beyond the cap.

## NEW TICKET

- NEW TICKET: The side-channel seed checks where the channel flows: never seed one that drains to another basin
  (outflow guard, mirror of the inflow guard).
- NEW TICKET: The release compares the in-season resolution with the live one (`stage_inseason` resolves and overwrites
  it, and diffs nothing).
- NEW TICKET: T1140 join measure:
  - measure a distributary from where it leaves the river;
  - orient the stem by the section directly below;
  - say "into" only on a known downstream end.

## Not verified

- **Feeder topology:** `graph.pkl` (660 MB) was not loaded. That the 34 feeders drain into their channels rests on the
  PR's attribution, not on my check.
- **The in-season change:** its size is unknown (M1).
- **T1140 tests:** not run. Its new log lines from a real bundle build are not seen. Its bundle-stage memory is not
  measured.
- **Forsyth:** the channel's place beside `forsyth_creek.r1` "No Fishing from Connor Lake downstream 3 km" is not
  checked. That is a stretch rule; T1146 does not change stretch extents.
- **Not reviewed in depth:** T1047, T1030, T1059, T905, T1058, T1021, T1020, T1024. Nor T1052 and the app side of
  T1140.
- **T1051's line** "Every river, stream, creek and slough in B.C. needs a single barbless hook" is taken from the
  ticket. I did not check it against the book.
