# Launch plan: Can I Fish This (notes, 2026-11-25 night, read-only)

Read from: repo main worktree (HEAD 8d2637f94), `origin/release/0.10.0`, the live site (curl, 2026-11-25), Google and Apple pages (fetched 2026-11-25). Everything below is a proposal for the owner.

## 0. Three things to know first

1. **The stocked-lake layer and the depth layer are NOT shipped.** Stocked and Depth are menu entries that stay off because the release carries no values (`app/packages/core/src/layers.ts:25,150-151`; `app/packages/core/src/lakeFacts.ts:12`). Tickets T200 and T201 are OPEN, planned for 0.11 (`handoff/PLAN/ROADMAP-after-0.9.0.md`, rows 4a/4b). So T1152's "make it think we have stocked and bathy layers" cannot be written yet without saying something false. Say "coming" at most, or nothing.
2. **The home page says almost nothing to a crawler.** `https://canifishthis.ca/` is the app shell: a `<title>`, one meta description, no visible text, no JSON-LD (0 `ld+json` blocks on `/`), and `<noscript> You need to enable JavaScript to run this app.</noscript>`. No `llms.txt` (404 on 2026-11-25). The only server-rendered "what it is" text is `/about` (`app/tools/seo/html.ts:204-216`), which is two sentences and names no phone app, offline use, forecasts or fish ID.
3. **The About page names "stocking records from the Freshwater Fisheries Society of BC" as a source** (`html.ts:211`) while no stocking layer ships. Not verified against the live release data; check it and reword if no stocking value reaches the app.

## 1. What is SHIPPED, with proof

| Claim | State | Proof |
|---|---|---|
| Web app | Live, free | canifishthis.ca returns 200; `app/store-listing/listing.json` urls |
| Android app | Play **closed testing** only; not installable by the public. Production access applied for from 2026-12-07 | `handoff/PLAN/play-production-access/README.md` (clock); `releases.md` (0.9.0, build 44, Closed 2026-11-24) |
| iPhone app | TestFlight (internal and external). App Store version page saved as 0.10.0, not yet submitted | `handoff/PLAN/ios/APP-STORE-SUBMISSION.md` section 0 |
| Release 0.10.0 | HELD by the owner for river-part names; ships as rc.1 then final | `ROADMAP-after-0.9.0.md` "Order from here"; `changelog.ts` 0.10.0 on `origin/release/0.10.0` (draft) |
| Offline | After the first download (about 500 MB, Wi-Fi advised) the rules and the map work with no signal. Needs signal: live gauge readings, in-season and salmon feeds, weather, satellite imagery, sending reports. Device shows "Offline - showing what's saved on this device" | `handoff/PLAN/play/listing.md` "Offline and updates"; `core/src/menu/words.ts:41` ("Offline maps" page); first-download note in `store-listing/full-description.txt` |
| Real-time gauges | Live flow and level from Water Survey of Canada; compared with past years (HYDAT); plain-word standings | `listing.md` "Flows and conditions"; changelog 0.7.3, 0.8.5 |
| River forecasts | BC River Forecast Centre, three models, each seasonal and none always running: CLEVER hourly 10 days (freshet), COFFEE daily 5 days (fall floods), ELF daily 30 days (low flow). Map forecast-day picker 1 to 10 days. Labelled "CLEVER run issued ... 10-day outlook", marked likely out of date when stale | `pipeline/gauges/feed/forecast.py:10-14,125-148`; `app/packages/core/src/gauge-policy.generated.ts:94`; `core/src/conditions.test.ts:361-380`; app since 0.5.0 (10-day forecast) per `releases.md` |
| Salmon openings | DFO federal salmon limits and closures per water, a Salmon map mode, run timing mode (Runs tab) | `listing.md` "Salmon..."; changelog 0.7.x, 0.8.2 |
| In-season changes | Province (BC Fish and Wildlife) notices placed on their waters; bell inbox with New / Updated; some may not be placed on the map | `listing.md`; changelog 0.7.4, 0.7.8, 0.9.0 |
| Stocked-lake layer | **NOT shipped** | see section 0 |
| Depth / bathymetry | **NOT shipped** | see section 0 |
| Fish identification | A guide, not photo recognition. 40 pictures for 31 species (paintings, colour plates, studio photos; each credited), "What to look for" tips for about 21 species (for example bull trout: "Pale pink or cream spots, smaller than the pupil"), and a "Hatchery or wild?" sheet with two drawn rainbow trout showing the adipose fin. Reached by tapping a fish on a water's trout/char table (0.8.0) | `app/apps/mobile/assets/fish/manifest.json` (counted 40 images, 31 codes); `app/packages/core/src/regs/fish.generated.ts:208` (FISH_TIPS); tickets T20, T36, T38 (closed); changelog 0.8.0 "Tap a fish for how to tell it apart" |
| Notifications | Optional, off until switched on: gauge alerts (flow or level threshold, or a level for the day against other years), "New regulations data", "New app version". Raised on the phone; server sends only a silent wake-up. iPhone production push NOT proven (T996, no longer a gate) | `listing.md` "Notifications"; `APP-STORE-SUBMISSION.md` section 8 and 10; changelog 0.6.0, 0.7.0 |
| Sharing | A water's link opens the same water, part, tab and day; a gauge link opens a live gauge page | changelog 0.7.1, 0.7.4, 0.9.0 |
| Saved spots | Notes, photos, parking pin, weather and flow for the day; stay on the phone | `listing.md` "Saved spots" |
| Price, account | Free, no ads, no purchases, no account, non-profit wording on site | `listing.md` "Cost"; `html.ts:208,227-228` (privacy page); App Store pricing Free (`APP-STORE-SUBMISSION.md` section 0) |
| Boat launches | Not shipped (T1119 not built). Do not claim | T1152 text |

Competitor facts for the same claims: `handoff/PLAN/COMPETITORS.md` (BetterFish CA$24.99/yr, offline; River Atlas iPhone only with account). We are free with no account; we do not match "offline photo fish ID" (ours is a read-only guide) or boat launches.

## 2. What the site and listings say today

- Home meta description (one source `app/store-listing/listing.json` `websiteHomeDescription`, injected by `app/tools/web-shell.mjs:178-189`): "Your pocket guide to BC fishing regulations: tap any lake, river or stream on an interactive map to view its fishing regulations and river conditions." No phone app, offline, forecast words.
- Title: "Can I Fish This?" Home body: none for crawlers.
- `/about`: description at `app/tools/seo/site.ts:377`; body at `html.ts:204-216`. Says "free, non-profit app", sources, disclaimer. Not the phone apps.
- JSON-LD: `app/tools/seo/jsonld.ts` has WebSite, WebPage, BreadcrumbList, Place, Organization (About only). No SoftwareApplication. `site.json` has `contact: null`.
- robots.txt: `User-agent: *`, `Allow: /`, disallow /api/ and /data/, Sitemap line (`site.ts:407`). It does not block AI crawlers. sitemap.xml exists (200).
- llms.txt: none (grep of `app/` and live 404).
- Store words: `listing.json` short = "Your pocket guide to BC fishing regulations. Less searching, more fishing!" (75 chars); full description 3925 chars (limit 4000); it already says river forecasts, works without cell service, flow alerts, sharing; it does not name the fish ID guide, forecast models or horizon.
- Description tests: `app/tools/seo/description.test.ts` (water pages); `app/tools/store-listing.test.ts` checks the store limits and forbidden words.

## 3. Proposed words (owner's to change)

### 3.1 Home "What it is" block (85 words; server-rendered, visible)
> Can I Fish This? is a free map of British Columbia's freshwater fishing rules. Tap a lake, river or stream and it shows, in plain words, what is open on the day you pick, what you may keep, the gear rules and any closure, with the rule book's own page one tap away. Beside the rules it shows live river gauges and forecasts, federal salmon openings and in-season changes. It is a reading aid, not the official regulation. There is no account and no price.

Add the line "Apps for iPhone and Android" only once the stores are public (see 3.3 gate).

### 3.2 Features list (one line each; all shipped)
- Map of BC lakes, rivers and streams coloured by the rules for the day you pick
- Rules per water, section by section: seasons, limits, sizes, gear, closures, licence, with the rule book's page
- Federal (DFO) salmon limits and closures, a salmon map and run timing
- In-season changes from BC Fish and Wildlife on the waters they apply to
- Live river flow and level from Water Survey of Canada gauges, compared with past years
- River forecasts from the BC River Forecast Centre: 10 days (CLEVER), 5 days (COFFEE), 30 days (ELF), shown in the season each model runs
- Fish identification guide: pictures and plain-word tips for how to tell fish apart, and hatchery from wild rainbow (a guide, not photo recognition)
- Works offline after a first download of about 500 MB (live gauges, notices, weather and satellite need a signal)
- Flow alerts and optional notifications
- Saved spots with notes and photos that stay on your phone
- Share a water: the link opens the same water and day
- Free, no ads, no account

Left out on purpose: stocked lakes, depth maps, boat launches, "real-time forecasts" (the models are the Forecast Centre's, seasonal).

### 3.3 Meta descriptions (limit 155)
- Now (web only true today), 140 chars: "Free BC freshwater fishing rules, by the water, on a map. See what is open and what you can keep, plus river flow and forecasts. No account."
- When both stores are public, 143 chars: "Free BC fishing rules by the water, on a map. App for iPhone and Android, works offline. River flow and forecasts, salmon openings. No account."
Gate: the second only after both store apps are public (T1152 rule 2, T1073's rule). One source file, `listing.json`, drives both.

### 3.4 JSON-LD (home and About)
```json
{"@context":"https://schema.org","@type":["SoftwareApplication","WebApplication"],
 "name":"Can I Fish This?","url":"https://canifishthis.ca/",
 "applicationCategory":"TravelApplication","operatingSystem":"Web, Android, iOS",
 "inLanguage":"en-CA","isAccessibleForFree":true,
 "offers":{"@type":"Offer","price":"0","priceCurrency":"CAD"},
 "description":"A free map of British Columbia's freshwater fishing rules by the water, with river flow, river forecasts, salmon openings and in-season changes. Works offline in the phone apps.",
 "featureList":["Rules per water on a map, by the day you pick","DFO salmon limits and closures, run timing","In-season changes from BC Fish and Wildlife","Live river flow and level, compared with past years","River forecasts from the BC River Forecast Centre: 10, 5 and 30 days by model","Fish identification guide with pictures and plain-word tips","Offline use after the first download","Flow alerts","Saved spots that stay on the phone","Share a water link","No account, no ads"],
 "downloadUrl":["<Play listing, when public>","<App Store page, when public>"]}
```
Rules: `operatingSystem` lists Android and iOS only once each store is public (until then "Web"); `downloadUrl` and `sameAs` store links only when live; applicationCategory is a guess (schema.org has no fishing category; "TravelApplication" or "SportsApplication", owner's pick); `checkJsonLd` (`jsonld.ts:74`) must learn the new type; the T1152 acceptance gate (one feature source file) should read from `listing.json` or a new `features.json`.

### 3.5 llms.txt (served at /llms.txt; same facts, plain markdown)
```
# Can I Fish This?
> A free map of British Columbia's freshwater fishing rules, by the water. Not an official source; the BC Freshwater Fishing Regulations Synopsis and DFO notices rule.

## What it does
- Shows, for the day you pick, what is open on each lake, river and stream, what you may keep, gear rules, closures and licence notes
- Live river flow and level (Water Survey of Canada) and river forecasts (BC River Forecast Centre: CLEVER 10 days, COFFEE 5 days, ELF 30 days)
- DFO salmon openings, run timing, and BC in-season changes
- A fish identification guide (pictures and tips; not photo recognition)
- Works offline in the phone apps after a first download of about 500 MB
- Free, no account, no ads

## Where
- Web app: https://canifishthis.ca/
- Android and iPhone apps: <links when public>
- About: https://canifishthis.ca/about
- Privacy: https://canifishthis.ca/privacy
```
The mention "phone apps" is true of the build and not of public access; keep the store links blank until public. llms.txt has no proven effect on Google AI answers (guess; not verified), but costs nothing.

### 3.6 Play and App Store text
- Short (Play, limit 80): "Free BC fishing rules, by the water. Works offline. River flow and forecasts." (77 chars). The current line (75) is fine too; the new one says three real things.
- App Store subtitle (30): keep "BC fishing rules, by the water" (30). Promotional text (170): "Free BC fishing rules by the water. Works offline after the first download. River flow, forecasts, salmon openings and a fish ID guide." (about 135 chars, count again before pasting).
- Keywords (100): current set is fine; "forecast" could replace "synopsis" (owner's pick, not tested).
- Full (limit 4000): the current text is 3925 chars. Replace the conditions block and add a fish ID block, and cut to fit. A tested draft at 3827 chars is in `/private/tmp/claude-502/-BC-freshwater-fishing-regulations/3412ea98-8ed4-4288-872f-61b07e9662f9/scratchpad/night/launch-plan-fulldesc.txt`. Changes: forecasts named with model horizons and the "shows only in season" caveat; a "Fish ID Guide" block ("a guide you read, not a photo scanner"); the "Designed and developed by a passionate BC angler" paragraph, the glossary line and the Save bullets shortened (owner's words: his call). The same text goes to both stores (the App Store text names no other platform).
- Rule: stocked, depth, boat launch words stay out of all store text until 0.11 ships.

## 4. Play production access

Source: https://support.google.com/googleplay/android-developer/answer/14151465 (fetched 2026-11-25).
- New personal accounts: at least 12 testers opted in continuously for the 14 days before applying. Review usually 7 days or less, sometimes longer.
- Form: (1) about the closed test: ease of recruiting, engagement and how it differed from production, feedback summary and how collected; (2) about the app: audience, value proposition, first-year install range; (3) production readiness: changes made from the test, how you decided it is ready.
- The repo's record already matches this: `README.md` (rules, clock, checklist), `questionnaire-draft.md` (all 8 answers drafted from facts; Q7 done through 0.9.0; Q8 has the 0.9.0 numbers), `feedback-log.md` (39 rows as of 2026-11-24), `releases.md` (every release since 0.4.0).
- **Earliest apply date: 2026-12-07** (14 full days from 2026-11-23, all testers opted in that day). If any tester opted out and back in, that tester's 14 days restart.
- **Missing (owner fields), from the questionnaire's own TODO list:** opted-in count today and whether anyone left (Play Console, Testing > Closed testing > Testers); Q1 recruiting-ease pick and asked-vs-joined counts; Q2 features testers did not reach, where testers live, weekly active testers and sessions; Q4 target age group matching Play Console; Q5 rule book page count and the no-ads/no-account wording; Q6 first-year install range, BC licence-sales figure with source, site visits; Q8 Android vitals crash and ANR rates (28 days), crash-free share, how much of the regulations the owner reviewed, privacy URL confirmed; refresh the counts and the newest release row (0.10.0 once on Closed); all answers in the owner's own words. The newest production build must be on Closed so testers use what is applied with.
- Not mine to settle: the 0.10.0 hold means the build on Closed on 2026-12-07 may still be 0.9.0 (build 44). Applying with 0.9.0 is allowed; the answers must say which build.
- After approval: production release still needs the listing pictures, which wait for T1128 (the 360 px Change-panel fix) and are held until just before production (owner 2026-11-25 13:43). Earliest realistic public Android date: apply 2026-12-07, answer up to about 2026-12-14 (usually), then the owner's production rollout.

## 5. App Store path (0.10.0 build to public)

Apple pages read 2026-11-25: https://developer.apple.com/app-store/review/guidelines/ (edition date not shown to me).
Steps, from `APP-STORE-SUBMISSION.md`:
1. 0.10.0 final (after the held river-part tickets, one data build, rc.1, owner's look, `release --final`) and its iPhone build on TestFlight. If the 0.10.0 build is not ready, 0.9.0 (45) is fit for review (the doc says so) but the version page is named 0.10.0 and would have to be renamed.
2. Pictures: the required medium-display size is uploaded as a stopgap; T1072 / PR #238 set and T1128 (frame 3's clipped day column also on the appstore-6.3 set) may change them.
3. Owner: pick the build, Add for Review, Submit. Contact name and phone, copyright line, notes paste (all in the doc). Apple review usually 1 to 2 days (the doc's estimate; not checked against Apple).
4. Approved: "Pending Developer Release"; version release is manual, so the owner presses Release when the plan says. Rejected: paste Apple's message to a chat.
5. After public: T996 push proof on production, T1153 switch for the iPhone, T514 store link.
Ready already: accounts and agreements, DSA not-a-trader, App Privacy (9 types ticked; Performance Data ticked but not yet sent, a known mismatch until T1132 ships in 0.10.1), age rating 4+, pricing Free in 175 countries, descriptions, keywords, review notes, export compliance (`ITSAppUsesNonExemptEncryption = NO`).
Review risks for this kind of app:
- **Accuracy of regulations:** Apple's 1.4.1 scrutiny is worded for medical apps, so it should not bite, but the app carries a "Before you fish" first-run notice and a disclaimer in the listing. Keep "not an official source, not affiliated with the Province or DFO" in the description and the review notes (it is). Also confirm the app name does not look like a government app (not verified against 5.2).
- **Content rights:** 5.2 needs a license for third-party content. The doc answers "Yes, third-party content" with a sources table; Esri's tile terms are flagged as the owner's to confirm (`imagery.ts` header). That is the most likely real question from review.
- **Location:** 5.1.5 says location only where relevant: when-in-use, asked once after the first download, works if refused; the Android crash on refusal has no iPhone twin (doc section 9). Reviewer will likely tap Don't Allow.
- **Heavy first download (about 500 MB):** the reviewer sees a progress screen; the notes say "review on Wi-Fi". A stuck first open is the likeliest 2.1 rejection; the download resumes by itself.
- **4.2 minimum functionality:** the app is far beyond a website (offline, notifications, saved spots).
- **Export compliance:** HTTPS plus SHA-256 only; "None of the algorithms mentioned" if asked.
- **Background modes:** the silent push and background task are explained in the notes; the production push proof is open (T996, not a rejection risk, a user-experience risk).

## 6. Launch-week checklist, in order

Before day one (must be true):
1. Both stores approved and the owner has released them (Play production rollout after approval, App Store Release pressed). Not before: T1073 says a notice offers only what the phone can install.
2. 0.10.0 final is on production (site, data, feeds) and the same build is the one on both stores, or the store text names features of an older build only.
3. Play listing pictures uploaded after T1128 ships (frame 3) and T1072's set is chosen.
4. T1152 wording approved by the owner with a picture of the home block; the one feature source file and its gate in place; site, JSON-LD, llms.txt live. `contact` in `site.json` set (it is null; the About page then names no contact).
5. A working support address (support@canifishthis.ca per `listing.json`) and the privacy page matching what the build sends (T1098, T1132 words).
6. Crash and report reading works for production builds (`python -m pipeline reports`); Android vitals visible.
7. T240's remaining list and T404's owner step (PROD_R2 secrets) closed; T463 code review done; T514 store link value ready.
8. Banned claims check: no stocked, depth, boat launch, "real-time forecast", or "photo recognition" anywhere.

Order of the week:
- Day 0: store pages public. Open both listings on a phone and a fresh install; first download over Wi-Fi works; location Don't Allow works.
- Day 0: set T514's `OPEN_IN_APP_URL` (`app/packages/core/src/share.ts`); switch T1153 on per store, one at a time, only for the store that is public; check on a real iPhone and a real Android phone that the prompt opens the right page and, with the app installed, the same water.
- Day 0: site wording live (home block, meta B, JSON-LD with store links, llms.txt). Submit the home page in Search Console for recrawl (needs the owner's token; `site.json` verification is null).
- Day 1 to 2: announce (below). One post per place, not a blast.
- All week: watch crash and problem reports daily, Play reviews, App Store reviews, Android vitals, TestFlight is no longer the channel for the public build; each item gets a ticket and a feedback-log row (the Play record keeps counting after approval).
- Day 7 and monthly: ask Google's AI and two other assistants the owner's question again; note the answer in `COMPETITORS.md` (an answer only changes after a recrawl: weeks).

Where to announce (rules NOT confirmed; I could not read the live rules: Reddit refused my fetch, and web search found nothing for BC fishing subs). Read each sidebar and ask the moderators first:
- Reddit: a BC fishing subreddit (name not confirmed; check r/fishingbc style names), r/flyfishing (the only evidence I found was an unofficial mirror listing a rule against self-promotion and a ban on YouTube-channel link posts, 2026-11-25; unconfirmed), r/vancouver or r/britishcolumbia (rules not read). Common pattern: a ratio rule (about 9 other posts to 1 of your own) and a ban on bare ads; a "I built a free tool, here is what it does and what it gets wrong, feedback welcome" post with the owner as the maker is the safer form.
- BC fishing forums and Facebook groups: names not confirmed here; the owner or the planning chat should list the three he reads. Same rule: read the sticky, ask a moderator.
- Local clubs and the Freshwater Fisheries Society of BC community; fishing clubs' newsletters; tackle shops: an email with two screenshots and the web link. Say "free, no account, not official".
- Do not post the same text in many places on one day; do not claim features outside section 1.

## Picks for the owner

1. Wording of the store and site claims about forecasts and fish ID: (a) use the proposed words (recommended: true, named models, "a guide, not photo scanner"); (b) shorter, no model names; (c) hold all until after 0.10.0.
2. Stocked and depth: (a) say nothing until 0.11 ships (recommended); (b) say "coming" on the site only; (c) say "coming" on site and stores.
3. The home page "What it is" block: (a) visible server-rendered text on `/` under the app, as in 3.1 (recommended; needs a picture first, and a care that Google's hidden-links note, T1045, does not apply to text that users see); (b) only on /about and meta/JSON-LD; (c) wait.
4. The About page's "stocking records" line: (a) remove until stocking ships (recommended unless the data check shows stocking in the release); (b) keep.
5. Apply for Play production access on 2026-12-07 with whichever build is on Closed: (a) yes, apply that day with the tracked build named in Q7/Q8 (recommended); (b) wait for 0.10.0 on Closed first.
6. T1153 prompt: dismiss time 30 days (default) or 90 days or each visit; and iPhone first or Android first when only one store is public (default: each store switched on alone).

## NEW TICKET lines
- NEW TICKET: Site words: home "What it is" block, features list, meta descriptions, JSON-LD SoftwareApplication, llms.txt, from one feature source file with a build gate (this is T1152's work; the planning chat may fold it in).
- NEW TICKET: About page "stocking records" claim checked against the live release, reworded if no stocking is shown.
- NEW TICKET: Launch-day runbook: store switch order, T514 link, T1153 switch, Search Console recrawl, announcement list with each place's rules read from its live page.
- NEW TICKET: robots.txt and AI-crawler stance (currently all allowed; confirm that is intended).

## Not verified
- Live subreddit, forum and Facebook group rules and their exact names; any approval for self-promotion there.
- Whether llms.txt or SoftwareApplication JSON-LD changes Google's AI answers (a guess that it helps; weeks to see).
- Apple's current review time and the November 2025 guideline edition text for 5.2 and any government-association rule; Google Play's rule for apps that resemble a government source.
- Whether the live release holds any stocking values (assumed none from T200 and the disabled Stocked layer).
- Real counts: testers opted in, Android vitals, site visits, BC licence sales.
- That Esri's public tile address fits their terms (the owner's, flagged in the doc).
- Whether the proposed full description passes `store-listing.test.ts`'s forbidden-word list (length 3827 checked; words not run through the test).
- Apple's "Fish ID" 40 pictures counted from the manifest file; I did not open the app to see them.
