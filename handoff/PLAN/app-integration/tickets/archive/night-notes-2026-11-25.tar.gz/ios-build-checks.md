# iPhone parity: a short check set for iOS builds (2026-11-25)

Source: the audit of app 0.7.9 (2026-11-14), read from git: `git show ed05f01e6^:handoff/PLAN/ios/parity-audit.md`
(deleted by ed05f01e6; a plain-text copy is at `night/ios-audit-old.txt`). Code read at main (`app.json` there says
0.9.0; the 0.10.0 branch differs from main in `app.json` only by the version line, checked with `git diff`). Paths
are under `app/`. Read only: nothing was built or run.

## 1. Each finding today

Short answer: most were fixed by T721-T723, T722's native download module, and later work. Four are still open.

| # | Finding | Today | Evidence |
|---|---|---|---|
| F1/G1 | First download only in the foreground / restarts from zero | FIXED (system background session, resumes same jobs). Real lock and swipe-away never proven on a phone | T722 (closed); `apps/mobile/modules/bg-download/ios/BgDownloadModule.swift`; `packages/core/src/install.ts:228-238` (iOS wording) |
| F2/G10 | Keyboard covers inputs; first tap eaten; no Done key | FIXED, simulator proof 7 of 7; other keyboard heights and a real thumb not tried | T723; `ui-native/src/KeyboardBar.native.tsx`, `DoneBar.native.tsx`, `ConditionsPanel.tsx:356`, `Sheet.tsx:328`; tests `SpotScreen.keyboard.test.tsx`, `ConditionsPanel.keyboard.test.tsx` |
| F3/G3 | Alert wording vs BGProcessingTask | FIXED in words ("while the phone is idle, often overnight ... hours late") | `packages/core/src/alerts.ts:334-341`, pinned by `alerts.test.ts:404-407`. The behaviour itself (hours late) is a product limit, not a bug |
| F4 | Tap opens ~300 ms late on iOS | OPEN, no fix, no ticket found | T723 "Left" list; T719 closed (bench only) |
| F5 | Grey streams flash after tab switch | OPEN, no fix; cause in shared MapLibre core | T723 "Left" list |
| F6 | 480 MB data not excluded from iCloud backup | FIXED. Release folder, rule book and bg-download folder flagged; spots stay backed up | `BgDownloadModule.swift:95,334`; `data/src/release/boot.ts:267-272,548,580`; `App.tsx:349`; T722 `xattr` proof on the simulator |
| F7 | Back swipe over Modals | FIXED (T721; ModalBack) | T721 closed; `ui-native/src/ModalBack.native.test.tsx` |
| F8 | "Waiting for Wi-Fi" promise on iOS | FIXED in words | `install.ts:235-239`, used at `App.tsx:830` |
| F9 | No low-disk check | FIXED, before the download, and a clear message | `data/src/release/boot.ts:240-262` (`SpaceError`), `drivers/install.native.ts:192-194`; tests `space.test.ts`, `install.native.test.ts:74` |
| F10 | Camera on simulator fails | Test-bed only; the refusal now counts as an environment error (not a defect report) | `apps/mobile/src/pickPhoto.native.ts:27` |
| F11 | iOS `location` scenario skips a step | Test-bed only, unfixed (the scenario scripts were later dropped by owner 2026-11-20) | T723 |
| F12 | `deps.md` says background URLSession but code forced foreground | Moot: it is a background session now | T722 |
| F13 | Sheet foot inset | Unproven, cosmetic | none |
| F14 | JS hashing stalls | Unproven (needs a device); likely smaller now that the module downloads in the system session | none found |
| F15 | Pill padding | By design | |
| F16 | "Copy" reports success if share is dismissed | Not checked, cosmetic | |
| F17 | Permission strings name vs home-screen name | Strings say "Can I Fish This?", app name "Can I Fish?" (`app.json:3,14,15,22`). Store name is settled; not re-checked | |
| F18 | Orientation | `portrait` (`app.json:7`); `supportsTablet:false`. Built plist not read | |
| F19 | Map patch drift | Superseded by the pinned upstream map (owner 11-22) | |
| F20 | Shared links | `associatedDomains` present (`app.json:37`); T724 | |
| F21 | In-app update on iOS | By design until the listing exists | |
| G2 | Update applied on "inactive" | FIXED (background only) | `App.tsx:457` (T723) |
| G4 | "Wi-Fi only" over hotspot / Low Data Mode | FIXED in the iOS module for the background download (`isExpensive \|\| isConstrained`), `BgDownloadModule.swift:115`. Hotspot and Low Data Mode on a real phone never proven | T722 says "needs a device" |
| G5 | Approximate location saved silently | PARTLY. Spot path fixed; the parking pin "here" still not (T723 "Left") | T723 |
| G6 | Refused camera/location has no Settings link | PARTLY. Camera and notifications done; parking "Use my location" still says "Could not find your location" with no button | `notify.native.ts:154`; T723 "Left" |
| G7 | Location purpose string | FIXED, covers map centring and pinning | `app.json:21` (expo-location string) |
| G8 | Directions open Google Maps in Safari | FIXED, iOS uses Apple Maps (`http://maps.apple.com/`, which iOS hands to Maps) | `packages/core/src/spotWords.ts:153-154` |
| G9 | Link that cannot open does nothing | FIXED (`linkFailedLine`, Settings) | `ui-native/src/openLink.ts:7` |
| G11 | What's new talks about Android/Play | FIXED (per-note `only` filter) | `core/src/changelog.ts:28-33` |
| G12 | Push entitlement unused | MOOT: push is used now (silent push, T822/T996). Production push NOT proven; owner moved it after the iPhone release | T1071 owner answers 00:12 |
| G13 | Dropped download reported as defect | Not checked | |
| G14 | Android backup | Plugin `with-backup-rules.js` exists (Android) | |
| G15 | No "not affiliated with the Province" line | OPEN. First-run notice has "Not the official regulations" but no non-affiliation sentence; only the DFO licence text has one | `core/src/menu/legal.ts:20-30`; `licences.ts:100` |

Open or unproven after this read: F4, F5 (feel, cosmetic), G5 parking pin, G6 parking button, G15, and the
device-only items (lock/suspend, swipe-away resume, hotspot, Low Data Mode, F14 stalls).

## 2. What a unit or static test can prove (only for the open or unproven)

1. **Backup flag is called after install and each boot** (F6 regression). Already covered at the seam
   (`bgDownload.test.ts:40-46`); add in `packages/data/src/release/boot.test.ts`: a fake `noBackup` is called with the release
   folder after `install` and at boot. Fails if `outOfBackup` (`boot.ts:267`) is dropped.
2. **Low disk stops the download before it starts** (F9). Covered by `space.test.ts`; confirm there is a case "free < need throws
   `SpaceError` before any `toDisk` call". If missing, add it there.
3. **Declared background modes match use** (App Store review). New `apps/mobile/src/appConfig.test.ts`: read `app.json`,
   assert plugins include `expo-background-task` and `expo-notifications` with `enableBackgroundRemoteNotifications`, and that
   the privacy manifest lists DiskSpace `E174.1`. Fails if a mode is added or removed without a decision.
4. **Built plist check** (the only way to see real modes): in `deploy/staging/build-ios-testflight.sh` after the archive
   (about line 211), `plutil -extract UIBackgroundModes json` and `aps-environment`; fail unless the set is the expected
   `fetch, processing, remote-notification` (the set `APP-STORE-SUBMISSION.md:250` names; never read from a built plist for build 45).
5. **First-run notice carries a non-affiliation sentence** (G15, if the owner wants it): `packages/core/src/menu/legal.test.ts`
   asserts a point contains "not affiliated" . Fails until the sentence exists.
6. **Parking pin refusal shows the Settings link** (G6): `ui-native/src/SpotScreen.keyboard.test.tsx` style test with a `here()` that rejects with a
   denied error; assert `OpenSettings` is rendered. Needs the stay-out file `shell/SpotHost.tsx` change first.
7. **Hotspot / Low Data Mode**: no unit test can prove the OS flag. Only the "metered stays queued" decision around `BgDownloadModule.swift:115` could be mocked; real proof is device.

## 3. Device checklist (iPhone, TestFlight build of 0.10.0; about 12 minutes)

Do the first two before anything else; the download needs a clean install and Wi-Fi.

1. Delete the app, install from TestFlight, open on home Wi-Fi, accept the notice. Expect: the download bar runs with a size near 480-500 MB.
2. Press Home for 60 s, then lock the phone for 60 s, then reopen. Expect: the bar kept moving (more bytes than before).
3. Meanwhile, Settings > General > iPhone Storage > the app. Expect: "Documents & Data" grows; this is the backup size to note.
4. When the map shows: tap a river once. Expect: its page opens in under about a second.
5. Back swipe from the left edge on a water page, a menu page and the photo viewer. Expect: each goes back one step, no flash of the previous page.
6. Spots tab > add a spot > tap the notes field. Expect: the keyboard does not hide the field; "Save spot" bar sits on top of the keyboard.
7. Water > Conditions > Alert me > tap the value field. Expect: the field stays above the number pad, a Done key shows.
8. Spots > "At my location". Expect: a pin at your place (turn Precise Location off in Settings and retry: expect a warning, not a silent far pin).
9. Settings > the app > Location > Never; open Spots. Expect: a line and an Open Settings button (and the parking-pin path: expect the same, known to be missing).
10. Pull down Control Center, release. Expect: the page you were on does not reload.
11. More > About > What's new. Expect: no mention of Google Play or Android.
12. Cold start in Airplane Mode after the first install is whole. Expect: the map and a water's regulations still open offline. (If time allows after step 12: switch to an iPhone hotspot with "Wi-Fi only" set and start an update; expect it waits.)

Separate, not in the 15 minutes: one day of gauge alerts (a BGProcessingTask runs when iOS chooses; hours late is expected), and the low-disk screen (fill the phone; skip unless a spare phone is free).

## 4. What matters for App Store review

- **The ~500 MB first download.** Open and the highest risk. The app and the listing both say about 500 MB, nobody measured the 0.9.0 size (T1071 "Not verified"). Apple's guideline on apps that download most of their content after install is the thing a reviewer could raise; I did not look up the current wording (not confirmed). Mitigations already there: Wi-Fi only default, space check, clear waiting words, review notes. Confirm the review notes say plainly what is downloaded and why, and that the app opens with something useful while it downloads (it does not today: the boot screen waits).
- **Backup size.** Fixed in code (the 480 MB is excluded); only the device step 3 proves it. A large "Documents & Data" would be a visible, user-facing fault.
- **Background modes.** `fetch` and `processing` come from expo-background-task and are used (`notify.native.ts:32,104`), `remote-notification` is for the silent push. They are used, so not "declared but unused". The risk is that production push is unproven (T996) and review notes say a data update is downloaded by silent push; the notes were corrected for that. Read the built plist once (item 4 above).
- **G15 non-affiliation line.** Low risk, one sentence, cheap. Reviewers of government-information apps sometimes ask; not confirmed against current rules.
- **Privacy answers** are already submitted (T1071); not in scope here.

## Picks for the owner

1. Where should the iOS parity check live? (a) the 12-line device list above, kept in `handoff/PLAN/ios/` and run before each iOS submit [recommended]; (b) also add the built-plist check to the TestFlight build script; (c) only the list.
2. G15 non-affiliation sentence in the first-run notice? (a) add it, with the unit test (it re-asks everyone once, via `FIRST_RUN_VERSION`) [recommended: 0.10.1 not blocking]; (b) skip; (c) add it only to About.
3. The parking-pin Settings button and approximate-location warning (G5/G6 leftovers)? (a) fix in 0.10.1 [recommended]; (b) before submit; (c) leave.
4. F4 (iOS tap about 300 ms slower) and F5 (grey flash)? (a) leave as known cosmetic [recommended]; (b) one ticket each.

## NEW TICKET lines

- NEW TICKET: iOS device check list (12 steps) saved as a runbook page, plus a TestFlight-script check of the built Info.plist background modes and `aps-environment`.
- NEW TICKET: parking pin "Use my location" shows Open Settings on refusal and a warning on a rough fix (T723 G5/G6 leftovers; touches `shell/SpotHost.tsx`).
- NEW TICKET: `appConfig.test.ts` pinning the plugin set, the background modes' source and the privacy manifest's DiskSpace reason.
- NEW TICKET: add a non-affiliation sentence to the first-run notice (G15) with a test.

## Not verified

- No build, simulator or phone run. Nothing in the built Info.plist or entitlements was read (not on disk).
- The 0.10.0 release branch was compared with main only for `app.json`; the code lines cited are from main.
- G13, F16, F17, F18, F13 not re-read in code. F14 effect of the new downloader not measured.
- Apple's current wording on large post-install downloads and on non-affiliation lines not looked up.
- Whether `http://maps.apple.com/` opens Apple Maps on a real phone (the usual behaviour; not tried).
- The `space.test.ts` content was not read for the "before any download" case (idea 2).
