"""What the T1146 walk changed in the in-season notices: diff two in-season resolutions, match by match.
before = this folder's inseason-resolved-r-71d09ad82e81.json (copied 2026-11-25 ~21:00, the candidate's resolution);
after  = data/generated/inseason/resolved.json once tonight's release has resolved them again.
  python -I inseason_diff.py <before.json> <after.json>
Light: two 40 KB files. Prints, per match, the waters gained / lost / whose runs changed."""
import json, sys

a, b = (json.load(open(p))["matches"] for p in sys.argv[1:3])
print("release", json.load(open(sys.argv[1]))["release"], "->", json.load(open(sys.argv[2]))["release"])
for k in sorted(set(a) | set(b)):
    wa, wb = (a.get(k) or {}).get("waters") or {}, (b.get(k) or {}).get("waters") or {}
    gain, lost = sorted(set(wb) - set(wa)), sorted(set(wa) - set(wb))
    moved = sorted(i for i in set(wa) & set(wb) if wa[i] != wb[i])
    if gain or lost or moved:
        print(f"{k}: +{len(gain)} {gain[:8]} -{len(lost)} {lost[:8]} changed {len(moved)} {moved[:8]}")
