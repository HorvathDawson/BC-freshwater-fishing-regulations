# Why a pull request takes 30-40 minutes to land, and how to make CI faster (2026-11-25 night)

Read-only audit. Repo `canifishthis/canifishthis`, workflows read at main `8d2637f94` (the planning worktree).
Data: every GitHub Actions run from 2026-11-25 06:19 UTC to 2026-11-26 03:27 UTC (1,000 runs: the API's cap for one
query), the jobs of every pull_request / merge_group / push run among them, and PRs #185-#268 (files + timeline).
The merge queue was switched on at about 22:20 UTC on 11-25 (the first `merge_group` run is 22:20:58).
Helper scripts and raw data: `night/ci-merge-queue/` (collect.py, analyze.py, concurrency.py, refetch.py, raw/,
timing.txt = the full raw output).

## The short answer

- **A code PR takes ~40 minutes because one 11-19 minute test step runs twice in a row**: the pipeline tier's
  `Tests` step (`.github/workflows/pipeline-ci.yml:126-127`, one runner, no parallelism) runs on the PR, then again in
  the merge queue. Measured, merged code PRs through the queue: median **40.1 min** from last push to merge = PR CI
  **22.4 min** + queue **19.7 min** (n=7). Before the queue (direct merge), code PRs took a median 12.4 min (n=17;
  many of those were docs edits that only reached the app tier, see fault 1).
- **Waiting for a runner is usually not the cause.** Median wait per job is 0.0 min in every workflow (table A).
  The exception was the first hour after the move (22:20-23:20 UTC): only 2-10 jobs ran at once while up to 35
  waited. From 00:00 UTC on, up to 20 jobs ran at once (the Free plan's limit) and waits were mostly zero.
- **A docs PR is fast on its own (1.3 min in the queue) but waits behind any code PR ahead of it**: #267 (one
  markdown file) sat 14.9 min in the queue because #264's 21-minute pipeline group was ahead of it.
- **Money: Actions costs $0 today.** Standard runners are free on public repos; the org's November usage shows
  2,197 Linux minutes ($13.18 list price) and 4 macOS minutes ($0.25), both 100% discounted, net $0.00
  (`gh api organizations/canifishthis/settings/billing/usage`). The real cost is waiting time, plus agent credits
  burnt while chats wait on CI (a guess, not measured). Every fix below keeps the bill at $0 except larger runners
  and the Team plan.

## 1. Timing: waiting for a runner against real work

How measured: for each job, `wait = started_at - created_at` (GitHub creates a job when the jobs it `needs:` finish,
so this is pure runner waiting) and `run = completed_at - started_at`. Jobs skipped by `if:` never take a runner and
are counted as `nr`. "docs" = every file of the PR is only in the docs area of `scripts/ci_paths.py` AREAS; "code" =
anything else. Minutes.

### A. Per workflow and job (the last 60 merged PRs; all 14 merge groups)

```
--- pull_request, last 60 merged PRs / DOCS PRs (42 PRs) ---
workflow       job                             ran   nr canc |  q med  q p90  q max |  r med  r p90  r max
app            app ok                           54    0    0 |    0.0    0.4    7.5 |    0.1    0.1    0.2
app            changes                          53    1    3 |    0.0    0.1    4.4 |    0.4    0.5    1.1
app            gates / vitest / bundles          0   54    3 |      -      -      - |      -      -      -
docs           changes                          54    2    2 |    0.0    0.5    7.5 |    0.4    0.5    1.0
docs           commits                          53    3    5 |    0.0    0.3    7.5 |    0.6    0.8    2.1
docs           docs ok                          55    0    0 |    0.0    0.9    8.1 |    0.1    0.1    0.2
docs           ledger                           50    6    9 |    0.0    0.0    1.0 |    0.8    0.9    1.3
feeds worker   changes                          52    3    4 |    0.0    0.1    7.0 |    0.4    0.5    0.8
feeds worker   feeds worker ok                  55    0    0 |    0.0    1.1    6.0 |    0.1    0.1    0.2
mutation       mutation (app TypeScript)        51    4    6 |    0.0    0.1    3.0 |    0.4    0.6    0.7
mutation       mutation (pipeline Python)       54    1    3 |    0.0    0.6    6.3 |    0.4    0.5    1.1
pipeline       changes                          54    0    3 |    0.0    0.3    5.8 |    0.4    0.7    1.1
pipeline       pipeline ok                      54    0    0 |    0.0    0.7   10.2 |    0.1    0.1    0.2

--- pull_request, last 60 merged PRs / CODE PRs (18 PRs) ---
app            app ok                           27    0    0 |    0.0    2.7    8.8 |    0.1    0.1    0.2
app            bundles                          21    6    1 |    0.0    0.2   12.8 |    2.4    2.6    3.4
app            changes                          27    0    0 |    0.0    1.1    2.6 |    0.4    0.5    0.7
app            gates                            21    6    1 |    0.0    0.4    6.7 |    3.0    3.5    3.6
app            vitest (n/4)                     84    4    4 |    0.0    0.8   12.9 |    5.6    7.0    7.8
docs           changes / commits / ledger / ok  ~27   -    - |    0.0  0.9-1.9 3.9-10.2 |  0.1-0.8 (each)
feeds worker   worker                           10   17    0 |    0.0    0.4    1.1 |    1.9    2.1    2.6
mutation       mutation (pipeline Python)       26    1    1 |    0.0    0.5    2.2 |    0.4    8.2   18.3
pipeline       check                            19    8    4 |    0.0    1.3    1.7 |   20.4   22.9   23.2
pipeline       pipeline ok                      27    0    0 |    0.0    0.5    5.1 |    0.1    0.1    0.8

--- merge_group / DOCS entries (6) ---   9 jobs each, every job <1 min, waits <=0.7
--- merge_group / CODE entries (7) ---
app            vitest (n/4)                     20    0    0 |    0.0   12.1   16.0 |    5.8    7.2    7.4
app            bundles                           5    2    0 |    0.0   14.8   14.8 |    2.4    3.0    3.0
docs           docs ok                           7    0    0 |    0.0   15.7   15.7 |    0.1    0.1    0.1
pipeline       check                             7    0    0 |    0.0    4.0    4.0 |   17.8   22.2   22.2
```
(The full table, every row, is in `night/ci-merge-queue/timing.txt`, section A.)

Inside the slow jobs (step times from `gh api .../actions/jobs/<id>`):

| job | setup (checkout + installs) | the work |
|---|---|---|
| pipeline `check` (139648424848) | checkout 10 s, pip 32 s, tile tools 8 s, `emit --check` 68 s | **Tests 1,120 s** (8,450 passed, 1,673 deselected, "in 1118.41s"); mini release 15 s |
| pipeline `check` (139642972501) | 10 + 20 + 6 + 35 s | **Tests 643 s** |
| app `vitest (2/4)` | checkout 12 s, app-setup 42-49 s | tests 265-279 s |
| app `gates` | 8 + 42-49 s | 75-90 s |
| app `bundles` | 12 + 11-14 s | web 38 s, native 61 s |
| feeds `worker` | 12-14 + 52 s | 30 s |
| docs `ledger` | 8-9 + 9-12 s | 8-10 s |

The slowest 25 pipeline tests sum to about 470 s of the 1,118 s (top: `test_dfo_vectors` 67 s,
`test_curation_review_safety` CORS 31 s, `test_before_push` 27 s); the rest is a long tail of ~8,400 tests.
`pytest-xdist` is not in `requirements.txt` / `constraints.txt`: the tier runs on one core of a 4-core runner.

### A2. Job-minutes waiting against running, by period

```
                 event         kind   jobs   waiting   running  (billed, each job rounded up)
after queue on   merge_group   code    103    144 min   295 min   362
after queue on   merge_group   docs     54      4 min    13 min    54
after queue on   pull_request  code    218    191 min   503 min   637
after queue on   pull_request  docs    173    201 min    49 min   173
after queue on   push          (main)  157    161 min   421 min   515
before queue on  pull_request  code    535    125 min  1311 min  1627
before queue on  pull_request  docs    585     24 min   219 min   597
before queue on  push          (main)  586     48 min  1160 min  1511
```
After the move, docs PRs spent 4x longer waiting than working (201 against 49 job-minutes), almost all of it in the
first hour.

### B. How many jobs ran at once

Per-minute sweep over every job's start and end (`concurrency.py`):

- Before the move (19:00-22:14 UTC, the old account): up to 19-20 running, never more than 3 waiting.
- **22:20-23:20 UTC (the first hour on the new org): 2-10 running while 6-35 waited.** At 22:36: 5 running,
  35 waiting (waiting: #1134 ×6, a merge group ×5, #1143 ×4, three Dependabot PRs ×10, #1141/#1142 ×6). Dependabot
  and CodeQL jobs (not counted above) also waited up to 13 min. So the new org ran far fewer jobs than its limit.
  GitHub's limits page says nothing about new accounts; **why is not known** (a guess: a warm-up limit on a brand-new
  org, whose runner numbers started at "GitHub Actions 1000000000" at 22:16).
- From 00:00 UTC: up to 14-20 running; at 01:30, 20 running and 14 waiting (the 5,494-file PR #262 and #263 at
  once). **20 is the Free plan's limit** (Free 20 jobs / 5 macOS; Pro 40; Team 60, docs.github.com/en/actions/reference/limits,
  read 2026-11-26).

### C. Per PR, last push to merge (medians)

| period | kind | n | last push -> merged | PR CI | PR CI done -> queued | in queue (max) | own queue build |
|---|---|---|---|---|---|---|---|
| before queue (direct merge) | docs | 44 | 1.8 | 1.5 | - | - | - |
| before queue (direct merge) | code | 17 | 12.4 | 12.2 | - | - | - |
| through the queue | docs | 6 | 11.0* | 3.1 | 0.1 | 2.0 (14.9) | 1.3 |
| through the queue | code | 7 | **40.1** | **22.4** | 0.1 | **19.7** (32.1) | 19.1 |

\* the docs median is pulled up by #266 (title too long, 5 red pushes) and #258/#248 (agent gaps).

Worst cases, explained:
- #217 (32 min in the queue; T1144 says "all of it waiting"): its group's app path waited 4.8 + 16.0 + 2.8 min and
  worked 7.8 min; its pipeline path waited 5.4 min and worked 20.2 min. So **about 24 of 32 minutes were waiting**,
  and even with no waiting it would have taken ~22 min (the pipeline tier). Partly confirmed.
- #264 (22 min): the pipeline `check` alone, 21.2 min of work, zero waiting.
- #267 (docs, 14.9 min): its own build took 1.1 min; it waited for #264 ahead of it (both merged 02:42:54).
- #262 (5,494 files): failed once in the queue (ledger + app suite: a clash with #263 that each PR passed alone),
  44 min. The queue did its job here.

Runner jobs per PR push: **docs 12** (5 workflows: four `changes`, four `ok`, `ledger`, `commits`, two mutation gates),
**code 18-20**. Per queue build: docs 9, code 16-17. Then a push to main runs again (see 2).

## 2. Merge queue settings, runners, duplicate checks

Ruleset 14082789 "main trunk (T995)" (`gh api repos/canifishthis/canifishthis/rulesets/14082789`):
- merge queue: merge method MERGE, **build concurrency (max_entries_to_build) 5**, min group 1, max group 5,
  **wait 0 min**, grouping ALLGREEN (only merge non-failing PRs), check timeout 60 min.
- required checks: `docs ok`, `app ok`, `feeds worker ok`, `pipeline ok` (GitHub Actions app, id 15368); strict
  (up to date) off. PR merges: merge commits only; title = PR title.
- With min 1 / wait 0, every entry gets its own build (14 builds, 14 PRs, one PR each); an entry builds on top of
  the one ahead (#267's build skipped the app tier, so its diff was its own PR only). With ALLGREEN, entries behind
  merge only when the ones ahead pass.

Org: plan **free**, 1 seat, created 2026-11-25 20:10 UTC; **no self-hosted runners**; the Default runner group does
not allow public repos (`allows_public_repositories: false`); fork PR approval: first-time contributors. Runner
types used: `ubuntu-latest` for every CI job; `macos-latest` only by CodeQL's swift analysis (4 billed minutes).
Cache: 3.8 GB of the 10 GB free per repo (13 caches: pnpm store ~230 MB, pip ~290-520 MB, CodeQL 98 MB; 2 GB of it
is pip caches of the old `redesign/stream-sections` branch).

**What runs again in the queue that already ran on the PR**: all four required workflows, each with the same area
filter as the PR (`.github/actions/changes/action.yml:29-31`, `scripts/ci_paths.py:188-209`). For a code PR that
means the pipeline `check` (15-22 min), the 4 vitest shards, gates, bundles, the worker suite. Only docs-ci's
`commits` job is PR-only (`docs-ci.yml:86`).

Must they run again? Only when something they read changed underneath. The queue's value is catching two PRs that
pass alone and fail together (#262 + #263 tonight; T978's mini release earlier). If `main` (plus the entries ahead)
changed **no path in that area** since the PR's own green run, the area's inputs are the same files, so the result
is the same (the area lists are pinned complete by `pipeline/tests/test_workflow_pins.py`, per
`scripts/ci_paths.py:61-62, 88-91`). Of the 7 code PRs queued tonight, 3 (#256, #257, #264) had no change in their
areas land meanwhile and could have skipped the 15-21 minute re-run; 4 could not (#217, #238, #260, #263 had a code
PR land just before).

**A third run: the push to main.** After the queue merges, `main` moves to the group's commit and the `push`
trigger (`branches: [main, "release/**"]` in all four workflows) runs them again. After queue-on, **31 of 31** push
runs on main were at a sha a merge_group run had already tested green (157 jobs, 421 run-minutes, about 21% of all
jobs after queue-on). `scripts/ci_status.py:96` looks runs up with `gh run list --commit <sha>` (any event), so the
merge_group run at the same sha would answer it. One catch: caches made in merge_group or PR runs are scoped to those
refs; main's push runs are what create the pnpm / pip caches every PR restores (`gh api .../actions/caches`: the
main-scoped entries), so keep one small cache-warming job on main.

## 3. The known faults

1. **"A docs-only PR triggers code workflows" (docs-ci triggers on any `*.md`)** - partly true.
   - docs-ci's area has `"*.md", "**/*.md"` (`scripts/ci_paths.py:56`, `docs-ci.yml:23`): any markdown file in a
     code PR runs the ledger job (~1 min, 1 job). Cheap.
   - Every PR starts all five workflows (bare `pull_request:` at `app-ci.yml:37`, `pipeline-ci.yml:29`,
     `feeds-worker-ci.yml:25`, `mutation.yml:16`, `docs-ci.yml:30`): a docs PR = 12 runner jobs, ~4.5 runner-minutes,
     the heavy jobs skipped. In the queue 9 more, then 4 on the push to main: ~25 jobs to land one markdown edit.
   - Real leak: some handoff docs ARE code inputs. `handoff/PLAN/ios/APP-STORE-SUBMISSION.md` is in the app area
     (`ci_paths.py:67`, the privacy-manifest test) and `handoff/PLAN/runbooks/**` is in the pipeline area
     (`ci_paths.py:93`). 8 of the 61 merged PRs were docs edits of APP-STORE-SUBMISSION.md that ran the whole app
     tier (#198, #200, #204, #215, #232, #234, #236, #240: 18 jobs, ~7-8 min each). A runbook edit would run the
     20-minute pipeline tier.
2. **"A conflicted PR starts no workflow and says nothing"** - true by GitHub's design, not seen tonight.
   GitHub: "Workflows will not run on `pull_request` activity if the pull request has a merge conflict"
   (docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows, read 2026-11-26). The
   four required checks then just stay "expected". In tonight's data every PR's final head had runs (no conflicted
   head found), so I could not show an instance. Nothing in the repo tells an agent: `before_push.py` and the hooks
   never ask `gh pr view --json mergeable`.
3. **"The PR title plus ' (#NNN)' is checked against 100 characters"** - confirmed.
   `app/tools/versioning.json:23` `headerMax: 100`; `app/tools/check-commits.mjs:33-36` appends ` (#N)`;
   `docs-ci.yml:98-104` passes the title and number. #261 failed at 101 and was closed; **#266 failed 5 pushes in a
   row (01:59-02:56 UTC) at 103** (a 96-character title + " (#266)"), 26 PR runs, 77 min to land a docs PR. The
   commit-msg / pre-push hooks check commits only, never the title. The safe title length is 100 - 7 = **93** for a
   3-digit PR number, 92 from #1000.
4. **"One docs PR at a time was needed to keep runners free"** - true only for the first hour after the move. Then
   the org ran 2-10 jobs at once; since 00:00 UTC it reaches 20 and docs PRs (12 jobs of ~0.4 min) do not fill it.
   What fills 20 slots now is code: one code PR push is 18-20 jobs, a code queue build 16-17, and up to 5 queue builds
   run at once (build concurrency 5).
5. **"Vitest shards time out under load (Timeout calling onTaskUpdate)"** - not on CI in this window. Fixed on CI on
   2026-11-18 with `maxWorkers: 2` (`app/vitest.config.ts:108-115`); each GitHub runner is its own machine, so queue
   load does not load it. All 5 failed vitest shard jobs tonight were real test failures (check-tickets ledger,
   check-size exception map, store-shots video, appUpdate changelog), read with `gh run view --job <id> --log-failed`.
   One earlier ledger.test.ts 5 s test timeout (job 139117527827, 09:47 UTC) is a different, single case. The
   onTaskUpdate failure is a laptop problem (T1041 item 5, T1070).

Also found:
- 140 runs were cancelled (superseded pushes); their `ok` jobs (`if: always()`) still took a runner 113 times. Leave
  it: switching to `!cancelled()` would make a cancelled required check report "skipped", which GitHub counts as a
  pass.
- mutation.yml: 277 jobs, only 35 did more than 1.5 min of work (the gate skips the rest after setup-free checkout).
- docs-ci's `edited` trigger re-ran docs only twice in 83 PRs: not a cost.
- CodeQL default setup (now off) analysed 7 languages including swift on macOS; ruby, swift and java-kotlin failed
  every time; 19 runs in its first hour, 11 cancelled.
- The first-hour flood came with 3 Dependabot security PRs (#250, #252, #254) at 22:22-22:31, each running full CI.

## 4. Fixes, ranked (minutes are estimates from the numbers above; label "guess" where so)

| # | Fix | Saves per code PR | Saves per docs PR | Runner jobs | $ / month |
|---|---|---|---|---|---|
| 1 | **Run the pipeline tier in parallel**: `pytest -n 4` (pytest-xdist) on the same 4-core runner, or 3-4 shards like vitest's | ~10-14 min on the PR + the same in the queue (guess: ~3x on 4 cores; must be measured, tests that start servers or share temp/git state may need fixing) | head-of-line wait behind code drops by the same | xdist: +0; shards: +3 per run | 0 |
| 2 | **Skip a heavy area in the queue when nothing in that area changed** since the PR's green run (compare the PR run's base with the group's base over `AREAS[area]`) | ~15-21 min on the PRs that qualify (3 of 7 tonight: ~8 min average) | indirect (shorter queue ahead) | -16 per qualifying build | 0 |
| 3 | **Drop `main` from `on: push`** in the four workflows (keep `release/**`); keep a small cache-warm job on main when the lockfile / requirements change | 0 latency; frees slots for the queue | 0 | -21% of all jobs after queue-on | 0 |
| 4 | **One CI workflow (or one gate workflow, T1144 item 2) with one required check** | ~1-3 min at busy times (four `ok` jobs each waited up to 6-16 min for a slot) | docs PR 12 -> ~4 jobs per push, queue 9 -> ~3 | large | 0 |
| 5 | **Title-length check before the PR opens** (`before_push.py`/the PR helper: title <= 93, or 100 minus " (#<next number>)") | - | saved the 77 min #266 lost | - | 0 |
| 6 | **Say when a PR is conflicted** (the PR helper or a `ci_status` mode runs `gh pr view --json mergeable,mergeStateStatus` and stops on CONFLICTING) | stops silent waits (not measured) | same | 0 | 0 |
| 7 | **Move the doc-reading app test off the app tier** (APP-STORE-SUBMISSION.md -> a docs-ci job running only privacy-manifest.test.ts) | - | ~6 min for the 8 such PRs (13% of PRs tonight) | -6 | 0 |
| 8 | mutation.yml `paths:` filter (T1144 item 1) | - | 2 jobs per push | -2 per docs push | 0 |
| 9 | Cache the venv (actions/cache on `.venv`, key = python version + requirements + constraints) | ~30 s per job that builds it (gates, 4 vitest, worker): ~30 s on the critical path | - | 0 | 0 |
| 10 | When re-enabling: Dependabot security PRs grouped (a `.github/dependabot.yml` with `groups`, `applies-to: security-updates`; there is no dependabot.yml today); CodeQL limited to actions, javascript-typescript, python (advanced setup, on push to main + weekly, not every PR) | - | - | avoids a 30+ job burst | 0 |
| 11 | Team plan (60 jobs at once instead of 20) | only if slot waits return | | | $4 (github.com/pricing, read 2026-11-26) |
| 12 | Larger runners (more cores for the pipeline tier) | similar to #1 | | | billed even on public repos (GitHub billing docs, read 2026-11-26); price not checked |

Not recommended:
- **Queue batching (min group > 1 with a wait)**: docs builds already take ~1.3 min; batching adds the wait to every
  lone PR and a failing batch ejects both. Docs PRs lose time to the code entry ahead, which #1 and #2 shrink.
- **A docs fast lane that bypasses the queue** (the admin bypass, `gh pr merge --admin`): it skips the required
  checks too, and a direct change to main restarts every queued group (each code group's 20 minutes again).
- **The owner's Mac as a self-hosted runner**: GitHub: "self-hosted runners should almost never be used for public
  repositories on GitHub, because any user can open pull requests against the repository and compromise the
  environment" (docs.github.com/en/actions/reference/security/secure-use, read 2026-11-26). This Mac holds the release
  data, signing keys, store and Cloudflare credentials, and the owner's accounts; the fork-approval gate only covers
  first-time contributors. Availability is also poor: it sleeps, it runs heavy release jobs one at a time (it rebooted
  from memory pressure on 10-06), and a required check waiting on an offline runner blocks every merge (a job waits
  up to 24 h). Minutes there are free (a $0.002/min self-hosted platform fee was announced for March 2026 and then
  postponed; whether it applies now is **not confirmed**: github.blog/changelog/2025-12-16, theregister.com 2025-12-17).
- cancel-in-progress: already on for all four CI workflows and mutation (`concurrency:` blocks); merge-group refs are
  unique, so nothing more to gain.
- pnpm store cache: already on (`.github/actions/app-setup/action.yml:18`); pip download cache already on. Turbo /
  vitest result caches: the app tier (~8-10 min path) is not the bottleneck; skip.

Expected result of #1 + #2 + #3 (guess): a code PR from ~40 min to ~15-20 min (PR CI ~10 min, queue ~6 min or ~1
min when the area is unchanged); a docs PR ~2-4 min unless a code entry is ahead (then up to ~6-7 instead of ~15-21).

## 5. T1144: what to add

T1144 (`handoff/PLAN/app-integration/tickets/T1144-ci-on-the-new-org-and-workflow-clean-up.md`) already has: mutation
paths filter, one gate workflow, the `edited` trigger, the clean-up list, the docs-PR rule, Dependabot/CodeQL back on.
Add:
- **Facts correction**: the runner shortage was the first hour after the move (2-10 jobs at once, 35 waiting); since
  00:00 UTC 11-26 the org reaches the Free plan's 20. #217's 32 queue minutes were ~24 waiting + ~8 working on the app
  path, with a 20-min pipeline path beside it.
- **Item 2, design note**: the gate should report ONE required check (the ruleset then names one context, and
  `scripts/ci_paths.py` REQUIRED / `scripts/ci_status.py` WORKFLOWS follow). A single `ci.yml` with one `changes` job
  (four outputs) does the same with fewer moving parts than four `workflow_call` files; either is fine.
- **Item 5 (docs PRs at once)**: with 20 slots, no docs-PR limit is needed; if a rule is wanted, limit code PRs in
  CI at once (proposal: two) and keep build concurrency at 5. Settle after the fixes below land.
- **Item 6**: when CodeQL comes back, choose languages (actions, javascript-typescript, python; c-cpp/ruby/swift/
  java-kotlin failed or are not used), no macOS job; group the Dependabot security PRs.
- **New item**: drop `main` from the four workflows' `on: push` (keep `release/**`), plus a cache-warm job on main;
  prove `ci_status.py` reads the merge_group run at the merge sha (tests with a merge_group event).
- **New item**: the merge-queue skip of an area unchanged since the PR's green run (#2 above).
- **New item**: move the APP-STORE-SUBMISSION.md check to docs-ci (#7) and note runbooks/** runs the pipeline tier.
- **Acceptance add**: a code PR's last push to merge measured before and after, with this note's commands.

NEW TICKET: The pipeline no-data tier runs in parallel (pytest-xdist on the 4-core runner, or shards), measured on CI before and after; fix tests that are not parallel-safe.
NEW TICKET: A PR title is checked for the merge-commit length (100 minus " (#N)") and a conflicted PR is named, before or right after `gh pr create` (before_push / the PR helper).

## Commands used (all read-only, re-runnable)

```sh
# rulesets and merge queue settings
gh api repos/canifishthis/canifishthis/rulesets
gh api repos/canifishthis/canifishthis/rulesets/14082789
# org plan, runners, billing, caches, fork approval, CodeQL
gh api orgs/canifishthis --jq '{plan, type, public_repos, created_at}'
gh api orgs/canifishthis/actions/runners
gh api orgs/canifishthis/actions/runner-groups
gh api repos/canifishthis/canifishthis --jq '{visibility, merge_commit_title}'
gh api organizations/canifishthis/settings/billing/usage
gh api repos/canifishthis/canifishthis/actions/cache/usage
gh api repos/canifishthis/canifishthis/actions/caches --jq '.actions_caches[]|[.key,.size_in_bytes,.ref]|@tsv'
gh api repos/canifishthis/canifishthis/actions/permissions/fork-pr-contributor-approval
gh api repos/canifishthis/canifishthis/code-scanning/default-setup
# runs, PRs
gh run list -R canifishthis/canifishthis --limit 1000 --json event,createdAt
gh pr list -R canifishthis/canifishthis --state all --limit 80 --json number,title,state,createdAt,mergedAt
# bulk collection (GET only; runs/<id>/jobs, pulls/<n>, pulls/<n>/files, issues/<n>/timeline), then the analysis
D=<scratchpad>/night/ci-merge-queue
GH_TOKEN=$(gh auth token) nice -n 15 python3 -I $D/collect.py $D/raw 2026-11-24T00:00:00Z 185 268
GH_TOKEN=$(gh auth token) nice -n 15 python3 -I $D/refetch.py $D/raw $D     # re-tries jobs that failed on the network
nice -n 15 python3 -I $D/analyze.py $D/raw <repo worktree> > $D/timing.txt
nice -n 15 python3 -I $D/concurrency.py $D/raw 2026-11-25T22:14 2026-11-25T23:10
# step times of one job, failed logs
gh api repos/canifishthis/canifishthis/actions/jobs/<job id> --jq '.steps[]|[.name,.started_at,.completed_at]'
gh run view -R canifishthis/canifishthis --job <job id> --log-failed
# PR details
gh pr view 265 -R canifishthis/canifishthis --json mergeable,mergeStateStatus,statusCheckRollup
gh api "repos/canifishthis/canifishthis/issues/262/timeline?per_page=100"
```
Note: `actions/runs` returns at most 1,000 runs for one query; tonight that reached back to 11-25 06:19 UTC. PR #262
(5,494 files) is left out of table C (the files API refused it, HTTP 422); its queue events were read separately.

## Picks for the owner

1. Speed up the pipeline tier first? (a) **pytest-xdist on the same runner (no extra slots)**, (b) 4 shards like the
   app suite (+3 jobs per run), (c) a larger runner (billed).
2. The duplicate run in the merge queue: (a) **skip an area whose files did not change since the PR's green run**,
   (b) keep re-running everything (today, safest, ~20 min per code PR), (c) turn the queue off and merge directly
   (fastest; loses the catch that stopped #262 + #263 tonight).
3. The push-to-main re-run (same commit the queue tested): (a) **drop main from `on: push`, keep release/** and a
   cache-warm job**, (b) keep it.
4. Required checks: (a) **one workflow / one required check (docs PR = ~4 jobs)**, (b) keep four workflows and four
   checks, only add the mutation paths filter.
5. Docs PRs open at once in AGENTS.md: (a) **no limit; at most two code PRs in CI at once instead**, (b) one docs PR
   at a time (T1144's proposal), (c) no rule at all.
6. More runner slots: (a) **not now (Free, 20 is enough after the fixes)**, (b) Team plan, $4/month, 60 slots.
7. Self-hosted runner on the Mac: (a) **no**, (b) only for release builds on a private mirror (separate design).

## Not verified

- Why the new org ran only 2-10 jobs at once in its first hour (no GitHub doc on new-org limits found); whether it
  can recur.
- Whether merge-group runs can restore main's caches (so whether the cache-warm job on main is really needed); whether
  min group size > 1 builds one group for several entries or one build per entry.
- The speed-up of pytest-xdist or sharding (not run: the rules forbid test suites tonight); which pipeline tests are
  not parallel-safe.
- The self-hosted runner platform fee's current status; larger-runner prices.
- A conflicted PR in this window (none found); the conflict behaviour is from GitHub's docs only.
- Runs before 2026-11-25 06:19 UTC (the 1,000-run cap); the old account's concurrency beyond 19:00-22:14.
- `pipeline/release.py` or other scripts that may read push runs on main (only `scripts/ci_status.py` was read).
