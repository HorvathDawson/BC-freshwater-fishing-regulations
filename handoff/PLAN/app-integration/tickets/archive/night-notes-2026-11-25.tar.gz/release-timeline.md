# How long the last two releases took, and what would make the next one faster

Night agent, 2026-11-25, read-only. All times are Mountain time (MST, -07:00).

**Short answer.** Very little of a release is the computer working. The data build takes about 30 minutes, the
checks after it 25 to 40 minutes on a quiet machine, and a phone build a few minutes. Most of the rest goes to five
things:
- work added after the cut;
- the release stopping, one at a time, on test pins that read the live release;
- the Mac sleeping, or busy with other chats' jobs;
- production commands spread over a whole day;
- other chats changing things in the middle of the release.

The machine work in 0.9.0 was about 4 hours of its 17. A one-day patch release (freeze in the evening, production
before noon, about 1.5 hours of your time) looks possible. Most of it needs rules, not code.

## Where the numbers come from

| Source | What it gave |
|---|---|
| `git log --first-parent` on `origin/release/0.9.0` and `origin/release/0.10.0`, compared with `origin/main` | The cut point and every commit on each branch, with its time |
| `git for-each-ref refs/tags` | `v0.9.0` made 2026-11-24 14:22:34 on 65f84020c; `data/r-0aec88ed3edb` 04:40:28 |
| `gh pr list --state all` (268 PRs; saved in `release-timeline/prs.json`) | Open and merge times. Script: `release-timeline/pr_windows.py` |
| `gh run list --created >=2026-11-21` (it stops at 1000 runs, so it covers 2026-11-24 23:19 to 2026-11-25 20:27 only; `release-timeline/runs.json`) | CI durations. Script: `release-timeline/ci_share.py` |
| The main checkout's `data/generated/release/ledger.json` (read only) | Each release's built, accepted, re-cut, tested, promoted, uploaded, smoked and production times |
| The main checkout's `data/generated/build-manifest.json` and `build-logs/*/` | How long each build stage took, and how much memory it used |
| `handoff/PLAN/views/OWNER-TODO.md` (the generated view), STATUS.md, RESTART-091-chat.md, the 0.9.0 restart page (`git show 65e4ddbb2:handoff/PLAN/NEXT-SESSION-2026-11-24-after-090.md`) | Your answers and when you gave them, and what the chats wrote at the time |
| Tickets T1058, T1059, T1062, T1063, T1133, T1135, T1140, T1144, T1146 | Waits and stops the chats measured themselves |

Where a time is my own inference rather than a recorded stamp, the row says "inferred" or "guess".

---

## 1. 0.9.0: the timeline

The batch ran 2026-11-22 18:00 to 2026-11-23 22:23. The cut was 2026-11-23 22:25. The merge-back was
2026-11-24 15:28.

| Phase | Start | End | Hours | Evidence |
|---|---|---|---|---|
| Batch: 14 parallel lanes, PRs #31–#84 | 11-22 18:11 | 11-23 22:23 | 28.2 | PR times. 53 PRs merged: 38 code, 15 docs. A code PR waited a median 3.5 h from opened to merged (longest 18.1 h) |
| Paused for credits | 11-22 20:15 | 11-22 23:02 | 2.8 | STATUS 11-22 20:15; PR #46 at 20:12; PR #52 at 23:02 |
| Your question rounds 1–5 | 11-22 23:20 | 11-23 00:05 | 0.75 | OWNER-TODO sections 650–691 |
| No scope freeze: the last feature PR (#84) was opened at 20:37 and merged at 22:23, which is the cut point | — | 11-23 22:23 | — | `git log`: release/0.9.0 forks at 15a257ca9 (#84) |
| Side atlas build, then the promote | about 21:45 (guess) | 11-23 22:16 | about 0.5 | `atlas/full.prev` file times run from 22:04 to 22:16 (COMPLETE.json). The start was not recorded. Your "yes promote if it fixes all the issues??" (OWNER-TODO 562) |
| Cut: the version, the What's-new draft, the app_reads row | 22:25:41 | 22:31:42 | 0.1 | 8d51c8913, 3f5de5d97, 6ea5b344a |
| Fix commits onto the branch (7, listed below) | 22:58 | 11-24 07:50 | — | release branch log |
| Data build: reach 11.3 min, alongside tiles 16.2 min, then deliver 12.5 min | 23:15:57 | 23:44:39 | 0.48 | build-manifest run of 2026-11-23T23:15:57, 1722 s |
| Release command: built → binding diff accepted → in-season → golden re-cut | 11-24 00:01:38 | 00:07:17 | 0.1 | ledger `built_at`, `binding_diff.accepted_at`, `inseason.at`, `follows.recut.at` |
| The checks after the build ("follows"): the app suite, 25 gates, the pipeline data tier | 00:07 | 02:18:34 | 2.2 | ledger `follows.tests.at`. A clean run on 0.8.5 took 25 min (r-741815c6090d: 16:31→16:56). One stop is known (the T991 pins, re-cut at 00:48), and the 0.9.1 chat's four lanes started at 01:10 on the same Mac |
| Promote, staging data upload | 02:18:36 | 02:21:52 | 0.05 | ledger `promoted_at`, `uploaded_at` |
| Staging site and smoke test | 02:22 | 04:40:26 | 2.3 | ledger `smoked_at` / `staged_at` 04:40, checks re-run 04:39. Inferred cause: the staging site build broke and was fixed on the branch at 03:11 (127bf433c, "the gauge chart's script builds from the repo root, as site-all.sh runs it") |
| Emulator device pass: three real bugs found and fixed | about 05:00 | 07:50 | 2.8 | T1027 picked 05:26, T1049 07:24, T1034 07:50; 0.9.1 memory note at 05:00 |
| You were asleep (machine idle for production) | about 00:45 | about 08:13 | about 7.5 | 0.9.1 note "owner asleep from ~00:45"; your first answers 08:13 (PR #117) |
| Your answers: What's new cleared, T1049 shipped as a known issue, the CI skip, the tag | 08:13 | 08:14 | — | defb62b4c; OWNER-TODO 559–567 |
| First production Android build attempt: the fast-fail took 30 min behind another chat's test runs, then the build hung for over an hour after BUILD SUCCESSFUL | about 09:40 (guess) | after 11:15 | 1.5 or more | T1063 source line; T1058 ("10:14 ... hung for over an hour") |
| **Production data (yours)** | — | 12:00:46 | — | ledger `prod_at` |
| Production Android build 44 (yours) | 12:19:06 | not recorded | — | 65f84020c versionCode commit |
| iPhone build 45 (yours): waited 70 min for the build lock, then built | not recorded | before 15:14 (inferred) | 70 min wait or more | T1063 "the 0.9.0 iOS build, 70 minutes" |
| `v0.9.0` tag moved onto the production build commit | — | 14:22:34 | — | tag date; T1062: the tag was moved after production ran |
| Merge-back PR #140 | 15:14 | 15:28 | 0.24 | PR |
| TestFlight external submit: refused by Claude's permission check, so it went to you | about 15:00 | about 22:58 | about 8 (calendar only) | RESTART-091 owner to-do; PR #157 "TestFlight ext submitted" |
| Play Closed review and Beta App Review | 11-24 | still pending | — | releases.md row 0.9.0 |

**Totals for 0.9.0:**
- cut → staging: 6.25 h;
- staging → production data: 7.3 h;
- cut → production data: 13.6 h;
- cut → merge-back: 17.1 h;
- batch start → production data: 41.8 h.

**Fix commits after the cut (7).** Each line gives the time it went onto the branch and, where there was one, its PR
on main.

| Ticket | On the branch | PR on main | Opened → merged | Order |
|---|---|---|---|---|
| T796 (your size gate answer) | 22:58 | #89 | 23:08 → 00:41 (1.6 h) | branch first |
| T1012 (Kootenay pin) | 23:48 | #90 | 00:03 → 00:41 (0.6 h) | branch first |
| T991 (pins re-cut) | 00:48 | none (came back in the merge-back) | — | branch only |
| T1039 (staging site script) | 03:11 | #102 | 03:43 → 05:10 (1.5 h) | branch first |
| T1027 (WorkManager under R8) | 05:26 | #109 | 05:03 → 05:25 (0.4 h) | main first |
| T1049 (cold-start tab) | 07:24 | #107 | 04:49 → 05:05 (0.3 h) | main first, picked 2.3 h later |
| T1034 (frame crash) | 07:50 | #115 | 07:44 → 08:02 (0.3 h) | branch first |

So 4 of the 6 fixes that had a PR were on the release branch before their PR merged. The runbook says the other way
round ("A fix lands on main first", `release-by-hand.md:418-428`). In practice the release did not wait for the merge.

## 2. 0.10.0: the timeline (not on staging tonight)

It was called 0.9.1 until your pick at 03:00 on 11-25. It was cut at 07:20 on 11-25, and is held for T1146, T1140
and T1145.

| Phase | Start | End | Hours | Evidence |
|---|---|---|---|---|
| Batch: the 0.9.1 chat, which started beside the 0.9.0 release | 11-24 00:48 | 11-25 03:42 | 26.9 | memory note; the cut's base is #114 at 03:42. 61 PRs merged between the merge-back and the cut: 18 code, 43 docs |
| Network outage: every lane stopped | 11-24 16:15 | 11-24 22:15 | 6.0 | RESTART-091 header |
| Side atlas build (Anderson Lake added), then the promote | 11-25 02:50:12 | 03:22 | 0.53 | `atlas-next.log` "ok in 31m40s, peak 20.0 GB"; `a27-promote.log` |
| **Mac asleep, lid closed** | about 03:50 | 12:06 | 8.3 | OWNER-TODO 157–160: "the night release stopped right after the cut". The cut commit (07:20:36) and PR #199 (07:23) show the Mac woke briefly around 07:20 |
| Cut | 07:20:36 | 07:20:36 | — | 22ffed7ee |
| CI red on the release branch (a test that cut "0.10.0" to 10 characters) | 07:20 | 13:32 | 6.2 (mostly asleep) | pipeline push runs 07:20 and 12:16 failed (22.9 and 22.6 min); green at 13:32 |
| What's-new draft | 12:12 | — | — | bcd03931b (still "a draft for the owner to clear") |
| Data build: clim 0.5 min, reach 12.8 min alongside tiles 18.2 min, then deliver 15.1 min | 12:30:49 | 13:04:42 | 0.57 | build-manifest run of 12:30:49, 2033 s |
| Two test fixes picked from main | 13:30 | 13:30 | — | #212 (merged 13:29), #218 (picked 13:30, merged 13:59: branch first) |
| Release command: binding diff accepted → in-season → golden re-cut | 13:46 | 13:54 | 0.13 | ledger |
| Follows stops: six test pins that read the live release, about 45 min each | 13:54 | about 15:29 | about 4 (T1135's figure, counting the stops before 13:54) | T1135; 2cc614bb2, d7370c772, 5c5a0b60a at 14:41; ledger `checks.at` 14:55:47 |
| Your Squamish report → T1140 (HIGH) | 14:58 | — | — | OWNER-TODO 212 |
| Chat's estimate at 14:50 if nothing more stopped: staging 15:35, production commands 16:30, Android 17:30, iPhone 18:30 | — | — | — | OWNER-TODO 201–206 |
| Your choice: move the repo now and re-cut 0.10.0 afterwards; repo transferred | 15:14 | 15:15 | — | OWNER-TODO 221, 125 |
| Staging run stopped cleanly before it tagged, to take the rc build first | — | 15:29 | — | OWNER-TODO 229–233 |
| Slug pick; T1062 release-candidate picks | 15:53 | 17:02 | — | 5b7d1acf6, d0b56415f, e2b789bb6 |
| Held for real part names: T1146, T1140, T1145 | 17:09 | still held | — | OWNER-TODO 13–18 |
| T1145 merged; T1146 merged (it changes the data, so another build is needed); T1140 #265 still open | 18:07 / 19:42 / open | — | — | PRs |

**Totals for 0.10.0:** cut → now (20:30) is 13.2 h, and nothing is on staging. Ten commits on the branch, six CI
pushes to it (pipeline runs of 22.9, 22.6, 21.7, 13.9, 21.7 and 23.2 min; two red). One data build so far; a second
is needed for T1146 and T1140. Your look at the binding diff and the naming pictures is still owed.

## 3. Where the hours went

The figures for 0.9.0 cover cut → merge-back, 17.1 h. Phases overlap, so the columns do not add up to the total.

| Bin | 0.9.0 | 0.10.0 (cut → now) | How measured |
|---|---|---|---|
| **Machine** (builds, follows, CI, phone builds) | about 4 h: build 0.5, atlas 0.5, follows 2.2 (of which clean is about 0.4), Android build a few minutes (T1058: 2–2.5 min unloaded), iPhone not recorded, release-branch CI about 0.4 per push | about 2.5 h: atlas 0.5, build 0.6, follows over 1, CI 2 h of runner time spread over 6 pushes | manifest, ledger, `gh run list` |
| **Queue** (one heavy job at a time, CI runners) | 1.7 h or more: the fast-fail took 30 min behind another chat's runs, the iPhone build waited 70 min; the restart page says release builds "waited hours" | small so far; the merge queue (from 15:24) held docs PRs 3–77 min each, and #217 waited 32 min for runners | T1063, T1144, PR times |
| **Waiting on you** | about 3.5 h with staging ready and nothing for production to do while you slept (04:40 → 08:13; the device pass filled most of it). Your production steps spread over about 7 h (08:14 → about 15:10) | the binding diff, pictures and production commands are still owed; the What's-new words were not cleared | ledger, OWNER-TODO |
| **Rework** (redone because something changed after the cut, or broke) | about 3.5 h: staging site fix about 2.3, Gradle hang 1 or more, T991 pin re-cut | about 4 h of follows stops (T1135); the stopped staging run (about 0.5–1 h of follows thrown away); a second build and follows owed for T1146 / T1140 | T1135, ledger |
| **Machine unavailable** (asleep, no network) | none during the release | 8.3 h asleep (4.7 h of it after the cut) | OWNER-TODO 157 |
| **Coordination between chats** | the 0.9.1 chat ran 4 or more Opus lanes on the same Mac from 01:10 (load average up to 136); 26 of its code PRs merged into main during the release | six chats live on release day (release, planning, iOS, store, repo-move, clean-up). 51 docs PRs merged after the cut, against 10 code PRs. The repo move went through in the middle of the release | memory notes, PR list, roadmap rows |

The work itself was not the slow part: a code fix PR after the cut took a median of 1.1 h from opened to merged in
both releases.

## 4. The ten biggest savings, ranked

"Hours" means hours saved per release, at the low and high ends of what the evidence supports.

| # | Change | Hours saved | Effort | Risk | Evidence |
|---|---|---|---|---|---|
| 1 | **No new scope after the cut.** A find after the cut, even a HIGH one, ships as the next patch the next day, unless the release makes it worse | 0 to 24 (0.10.0: production was estimated for 16:30 the same day; now it is "tomorrow") | none (a rule) | low: T1140 is already on production since 0.9.0, so shipping 0.10.0 without the fix adds no harm | OWNER-TODO 201–233, 13–18; T1146 forces a second build and follows run |
| 2 | **Keep the Mac awake for a release run.** `caffeinate -i` around the release command and heavy.sh jobs; refuse to start an unattended run on battery | 0 to 8.3 (8.3 on 0.10.0) | tiny | none | OWNER-TODO 157–160. No `caffeinate` or `pmset` anywhere in `scripts/heavy.sh`, `pipeline/release.py` or the build scripts (searched) |
| 3 | **Test pins that read the live release, checked before merge (T1135), and a rehearsal that lists every stop at once** | 2 to 4 | M | low | T1135: 6 stops × about 45 min on 0.10.0. 0.9.0's follows took 2.2 h against 25 min clean |
| 4 | **Every owner look and answer before the cut.** The cut refuses while a ticket in the release has an open owner question, pictures to see or What's-new words to clear | 1 to 3, and no idle night | S | none | 0.9.0 had 7 release questions during the release (OWNER-TODO 559–567). What's new was drafted at 22:26 and cleared at 08:14. 0.10.0's draft is still uncleared |
| 5 | **One production sitting for you.** Claude finishes every dry run first, then hands you one ordered list: final tag, data, site, feeds, Android, iPhone | 2 to 4 | S | low | 0.9.0: your steps ran from 08:14 to about 15:10. Production data at 12:00, Android at 12:19, iPhone after a 70-min wait |
| 6 | **A quiet Mac on release day.** No other chat runs heavy jobs, emulators or test runs from hooks while the release holds the machine (or T1063's priority lane) | 1 to 3 | S (rule) / S (T1063) | other chats wait a day | T1063: the fast-fail took 30 min, the iPhone build waited 70 min, load average up to 136. 0.9.0's follows overlapped with the 0.9.1 lanes |
| 7 | **Phone bundles built from the release candidate overnight, uploaded in the morning.** `deploy/prod/build-apk.sh --no-upload` exists (`deploy/prod/build-apk.sh:6`) and `--publish-only` uploads later (`release-by-hand.md:274-275`). The precheck already wants HEAD to be the newest rc (`release-by-hand.md:251-253`). Later this moves to CI runners (T1133, as a line item) | 1.5 to 3 | S now, L on CI | low: a replaced rc only uses up build numbers | 0.9.0's phone builds started after you woke and after production data |
| 8 | **Fewer chats on release day, and no repo or infrastructure change in the middle of a release** | 1 to 2, and fewer runner jams | none (a rule) | other work moves a day | 0.10.0: six chats, 51 docs PRs after the cut. The repo move stopped the staging run at 15:29 and added two picks with about 23 min of CI each |
| 9 | **Fewer pushes to the release branch.** Batch the picks into one push per round, so CI and the phone builds' CI gate run once per rc. A trunk-based release (tag main) would remove the picks, but only if main freezes on release day: 26 code PRs from the next release's chat merged into main during 0.9.0 | 0.5 to 1.5 | S (batching); M (trunk-based plus a main freeze) | trunk-based blocks the parallel chat | 0.10.0: 6 pushes at about 23 min each, 2 red. 0.9.0: 4 of 6 fixes went to the branch before main anyway |
| 10 | **CI that runs only what changed, and docs PRs batched** (T1144, another agent's area: line item only) | 0.5 to 1 on the critical path | M | medium (required checks are easy to break) | docs PRs took about 2 min before the merge queue and 3–77 min after it; #217 waited 32 min for runners. 453 of 1000 runs were on docs branches (12 runner-hours of 71) |

**Smaller items, below the top ten:**
- **A faster data build.** 0.10.0's 33.9 min went as follows. Tiles (18.2 min) and reach (12.8 min) run side by side,
  then deliver (15.1 min) has to wait for the tiles (`pipeline/build.py:101-102,117`). Inside deliver, the bundle
  step is 518 s of about 908 s (`build-logs/2026-11-25T123049/deliver.log:149`). Every stage is already cached by
  its inputs, and a no-op rerun takes 2 s (the manifest's runs). A rules-only patch skips tiles when the atlas and
  tile code have not changed, which saves about 6 min. The atlas (31.7 min) runs only when its inputs change, and both
  releases built it before the cut. A faster bundle step would save 5–8 min per build at M–L effort. The build is
  under 5% of the cycle.
- **Running the follows in parallel.** The follows run "every check:fast gate one by one"
  (`pipeline/release_follows.py:16-19`). Running them at the same time might save 10–15 min on a quiet Mac. It is low
  priority while the stops (item 3) cost hours.
- **Release candidates (T1062), now built.** They save little time directly. They remove the "move the tag?" question
  (0.9.0 moved `v0.9.0` after production) and they make item 7 safe.
- **Fixed already:** the Gradle hang (T1058, 1 h or more on 0.9.0) and the CI lookback (T1059, which forced
  `CI_CHECK_SKIP`).

## 5. A proposed target: a patch release in one day

From freeze to production in about 14 hours on the clock, with about 1.5 hours of your time.

| When | Who | What |
|---|---|---|
| Evening, day 0, before the cut (about 30 min of yours) | Planning chat and you | Close the scope. You answer every look: pictures, the binding-diff expectation, the What's-new words. Every fix PR is merged; anything that changes answers has passed T1135's side-release check. Other chats stop heavy jobs and code PRs until the merge-back |
| Night, unattended (Mac on power, kept awake) | Release chat | Cut. Atlas only if its inputs changed (32 min). Build (30–35 min). Follows (25–40 min with no stops). Staging ship as `v<x.y.z>-rc.1`. Staging site and feeds worker (about 40 min; time not measured). Smoke test. Emulator device pass. Staging sideload APK emailed |
| Night, optional (your pick 4) | You before bed, or later CI (T1133) | `CONFIRM_PROD=… deploy/prod/build-apk.sh --no-upload`, and the iPhone build without submit, on rc.1 |
| Morning (about 1 h of yours) | You | Look at staging and the sideload (20 min). Then one sitting from the prepared list: `release --final`, production data, site, feeds worker, Android upload, iPhone upload |
| Late morning | Claude | Production smoke, promote to Play Closed, TestFlight distribute, merge-back PR, the releases.md row and the feedback-log "Fixed in" column |
| Any time after | Google and Apple | Reviews. Outside our control, not counted |
| A find after the cut | Planning chat | The next patch, the next night (rule 1) |

The same with today's measured parts, and no stops: build 0.6 + follows 0.6 + staging 0.7 + device pass 1–2 +
your look and production 1.5 + phones 0.5–1 = 5–7 h of work. That fits one night and one morning. 0.9.0 took
17.1 h from cut to merge-back, plus a 28 h batch before the cut.

---

## Picks for the owner

1. **New finds after the cut:** (A) they go to the next patch, the next day, unless the release makes them worse
   (recommended); (B) you may hold the release for any HIGH find, as with 0.10.0; (C) hold for any find.
2. **Release-day chats:** (A) only the release chat and the planning chat run; the rest pause until the merge-back
   (recommended); (B) the other chats may do docs only, batched into one PR per hour; (C) as today.
3. **Production commands:** (A) one sitting from one prepared list, with every dry run green first (recommended);
   (B) one at a time as each is ready, as today.
4. **Phone builds:** (A) you start the production builds with `--no-upload` on the rc before bed, and upload in the
   morning (recommended until T1133 can do it); (B) wait for T1133's CI builds; (C) as today, after production data.
5. **Release branch or tag main:** (A) keep `release/x.y.z` and picks, but batch the picks into one push per round
   (recommended while two release chats overlap); (B) trunk-based: tag main and freeze main on release day; (C) as
   today.
6. **Night runs:** (A) the release runs overnight with the Mac kept awake on power (recommended); (B) only while you
   are awake.

## NEW TICKET lines

- NEW TICKET: The release command and heavy.sh keep the Mac awake for the length of a run (`caffeinate -i`), and an
  unattended run refuses to start on battery.
- NEW TICKET: A pre-cut owner gate: `release --cut` lists every ticket in the release with an open owner question,
  pictures to see or What's-new words to clear, and refuses until the list is empty (an escape flag with a reason).
- NEW TICKET: One prepared production list for the owner: every dry run done, then the ordered commands (final tag,
  data, site, feeds, Android, iPhone) on one page, each still gated by `CONFIRM_PROD`.
- NEW TICKET: The release ledger records the start and end of every stage (preflight, build, checks, follows,
  promote, upload, staging site, smoke), and the phone build scripts record theirs, so the next timeline is measured,
  not inferred. Today the follows start, the staging-site time and both phone builds are not recorded.
- NEW TICKET: A release-day lane rule in AGENTS.md: while a release holds the main checkout, other chats run no heavy
  jobs, emulators or hook test runs on the Mac, and make no repo or infrastructure changes. It goes with T1063's
  priority lane.
- Line items for other agents' tickets, not new: T1133 (phone builds on CI runners, built at the rc tag), T1144
  (path-filtered CI, docs PR batching), T1135 (test pins checked before merge), T1063 (a fair, prioritised heavy
  queue).

## Not verified

- **Start times not recorded:** the 0.9.0 atlas side build (only its file times, 22:04–22:16) and the first 0.9.0
  production Android attempt (only T1058's "10:14 ... hung for over an hour").
- **Phone build times:** the iPhone 45 build time and the Android 44 build length are not recorded anywhere I could
  read. No phone build log was found.
- **The 02:22–04:40 gap on 0.9.0:** blaming the staging-site fix (127bf433c at 03:11) is an inference from the
  commit message and the ledger. I did not read that chat's transcript.
- **The 0.10.0 cut time:** the Mac-asleep window (03:50–12:06) comes from the chat's note. The 07:20 cut commit
  shows a short wake that the note does not mention.
- **The follows on 0.10.0:** after 13:54 I have T1135's "about 45 minutes each" and the ledger's last `checks.at`
  (14:55). The follows-test end time was never written, because the run was stopped at 15:29.
- **CI data:** `gh run list` stops at 1000 runs, so its numbers cover only 2026-11-24 23:19 to 2026-11-25 20:27.
  Earlier CI (the whole 0.9.0 release) was not measured. The merge-queue start delays read as 0 at the run level;
  waits for a runner per job were not measured.
- **Tonight:** the release being built now from the main checkout. The hour savings in section 4 are estimates from
  the two releases above, not measured trials.
