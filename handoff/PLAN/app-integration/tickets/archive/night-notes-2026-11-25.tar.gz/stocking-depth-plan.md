# Stocked lakes and depth maps: what is shipped, what is next (2026-11-25)

Read-only research. Repo read at main worktree (head 8d2637f94, tag v0.9.0 is the last production release). Nothing in the app was run: every "what a user sees" line below is read from code, not seen on a screen.

## 1. What is shipped today

Short answer: **the plumbing is shipped, the data is not.** Both modes are built and switched off because no release carries values.

### In the app (all in `app/packages/core/src` unless noted)
- `layers.ts:38` colour choices "regulations | stocked | depth". Entries: `water.stocked` (`layers.ts:150-151`, note "When a lake was last stocked", needs release values "stocked"), `water.depth` (`layers.ts:152-154`, "Which lakes were surveyed", needs "surveyed"), `overlay.contours` (`layers.ts:159-160`, "Depth contours: Traced lines on surveyed lakes").
- Availability is derived: a release with no lake values makes the entry "no-data" (`layers.ts:25`, `:96-101`, `:200`). Wording on screen: "Coming soon" with the long text "No data yet: the release carries no values for it. It turns on by itself when one does."
- `lakeFacts.ts:1-13`, `:64-101`: reader for the `lakes/1` file (per lake section: survey 0 none / 1 sheet / 2 digitised, and last-stocked day). The file's own header says "PREPARED, NOT FED". Recency bands (`lakeFacts.ts:23-29`): this season 120 d, this year 365, 1-3 yr, 3-10 yr, older.
- Legends: `layers.ts:112-121`, `:412-418` and `mapKey.ts:25-27`, `:50-51` (stocked ramp, depth "Contours traced / Sheet only / Not surveyed").
- `app/packages/ui/src/mapModes.ts:126` colours lakes by the measure and paints every stream and wetland neutral.
- `near.ts:39-125` and `search.ts:18`: a "stocked" weight in nearby ranking reads `stock_water`, which is empty.
- Credits claim it already: `menu/sources.ts:121` ("Stocking: Province of British Columbia, Fisheries Inventory Data Queries") and `menu/licences.ts:144-146` ("Fish stocking and lake surveys ... Stocked lakes and lake depth", licence `oglBc`). See pick 6: this text runs ahead of the data and of the licence.
- There is no Lake tab and no stocking card or depth card in `app/packages/ui/src` (grep found stocking/depth words only in the files above). T634 plans the fourth "Lake" tab.
- Tiles carry no contour layer: T201 says so ("T158: tiles carry no contour layer"); `lake_facts.py` says lake features carry only `section_id, name, water, area_m2`. Not checked in the style file. So the "Depth contours" switch has no data behind it. Not verified whether it is visible or greyed (it has no `needs`, `layers.ts:159`).

### In the pipeline
- `pipeline/deliver/lake_facts.py:1-40`: format, the binding rule (code first, name only confirms), "NOTHING produces a lakes file today"; the release ships none unless `--lake-facts FILE` is passed.
- `pipeline/deliver/bundle/schema.sql:1176-1191`: tables `stock_water`, `stock_code`, `chart` exist and are empty; `release` is marked RETIRED (keyed by name).
- `pipeline/stocking/` (`fetch_fidq.py`, `propose.py`) and `pipeline/bathymetry/` (`propose.py`, `accept.py`, `compress.py`, `contours.py`, `e00.py`, `place*.py`): research tools. No curated match file exists yet (`data/curated/stocking`, `data/curated/bathymetry` absent in the owner's checkout). Proposals exist in `data/generated/{stocking,bathymetry}/proposals.json` (Nov 10).
- Measured by earlier passes (ticket T634 and the two feasibility notes, not re-run by me): stocking proposals clean 1,751 of 2,318 FIDQ lakes (FISS-point version: 2,164 auto, 154 review); chart proposals clean 1,995, 343 to review; 2,599 PDFs compressed 748 -> 201 MB at `~/data-offgit/bc-bathymetry-pdf-200dpi/`; 25 of 28 placed contour lakes clean; 298 strict + 117 loose placed vector files.

### What a user sees today
| | Phone (Android) | Web | Online | Offline |
|---|---|---|---|---|
| Stocked lake | Nothing special. The Layers sheet lists "Stocked" greyed, "Coming soon". Lake looks like any lake, coloured by regulations. | Same (one shared `core`) | Same | Same |
| Lake with a depth map | Nothing. "Depth" greyed. No chart link. | Same | Same | Same |
The old production site (the pre-rebuild app on `main` branch history) did show a "Stocking" tab and a "Bathy map" PDF tab per lake. This app shows neither yet. That is a regression people may notice (BetterFish and River Atlas both show stocking).

### Tickets
- T200 (stocking, first) and T201 (depth, second): both OPEN, "next after closed testing" (`tickets/README.md:77-87`). T634 (Lake tab) POSTPONED but supplies the shared "Path to ship". T218/T219 (digitising and tracing scans) postponed behind T201. T234 (push notifications, phone-only, local notifications, no server push) is the home for "followed lake stocked" alerts.
- T608 D (closed, audit): found production matched by name first, nearest same-named lake, no distance cap; no review; licence "Access Only" on stocking and sheet layer. T412 (closed): the slow-feed pattern: one button/worker-started workflow publishes, content-hashed files, `index.json` written last, publish only on real change with a diff, staging automatic, never a GitHub schedule. It names bathymetry as a follower.
- The 2026-11-13 owner words are in T200/T201. Defaults already recorded there: ask for licence link, FISS-only first, class B sample-tick, lakes only, 5 years history, lag accepted (stocking); PDF-only, no NONNA, no emails, no modelled depth (depth).

## 2. Sources and licences (web, fetched 2026-11-25)

### Stocking
- **BC Data Catalogue "Provincial Fish Stocking Reports"**: https://catalogue.data.gov.bc.ca/api/3/action/package_show?id=provincial-fish-stocking-reports (read 2026-11-25). Licence: **"Access Only"** (not OGL). Metadata modified 2026-11-25. Update cycle: daily (but the data we fetched ends 2026-06-29, see below). One resource, "BC Geographic Warehouse Custom Download", no direct URL; access is through the Geographic Warehouse download service. Covers lakes and rivers, 1900 to present. So there is **no open file or API**. Fields (from earlier passes, `stocking-feasibility.md` section 2): date, species, strain, brood year, hatchery, origin, life stage, mark, genotype, count, average weight, FIDQ id, WBID code. FIDQ web pages (https://www2.gov.bc.ca/gov/content/environment/plants-animals-ecosystems/fish/fish-and-fish-habitat-data-information/search-fish-fish-habitat-data-information/fisheries-inventory-data-queries) are an HTML front end; our fetcher scrapes it.
- **Open alternative, no counts**: layer "Known BC Fish Observations" (FISS), OGL-BC, public WFS, 74,879 release points, release rows have date, species, life stage, agency but no count/strain/weight. Facts from `stocking-feasibility.md` (2026-11-13, not re-fetched by me today).
- **GoFishBC stocking report** (Freshwater Fisheries Society of BC): https://www.gofishbc.com/news/education/how-to-create-custom-reports-using-the-stocking-report-tool (2026-11-25). Fields shown: release date, waterbody, nearest town, species; expanded row adds strain, genotype, life stage, average size. Filters: region, town, lake/river, species. No alert or subscribe; "Pin this report" saves filters in the browser only. Footer: "Copyright 2003-2026 Freshwater Fisheries Society of BC. All Rights Reserved." So it is the freshest and richest but needs the Society's written consent. An earlier search snippet said it updates every couple of days in season (not confirmed on the page; the page gave no cadence). Scripted requests met a Cloudflare challenge on 2026-11-13.
- Scale from the Society's 2025 review https://www.gofishbc.com/news/about-us/2025-bc-freshwater-fish-stocking-review/ (2026-11-25): about 673 lakes (regional counts sum to 661) and 4.94 million fish in spring and fall 2025; 3.13 M rainbow, 1.45 M kokanee, 281 k eastern brook, 72 k westslope cutthroat, 15 k coastal cutthroat; steelhead into six Lower Mainland rivers plus the Somass. Stocking is seasonal (spring and fall): a weekly check is plenty, even monthly in winter.
- Attribution for OGL-BC: "Contains information licensed under the Open Government Licence - British Columbia" (terms https://www2.gov.bc.ca/gov/content?id=A519A56BC2BF44E4A008B33FCF527F61, cited in the earlier note).
- Could not confirm: HectaresBC (not found by search, no page read). Anglers Atlas is a competitor, not a source.

### Depth
- **"Bathymetric Maps - Open"**: https://catalogue.data.gov.bc.ca/dataset/1427d389-cd21-4fe2-8ed9-282d9bdcb7e2 (API read 2026-11-25). Licence **Open Government Licence - British Columbia**. Last modified 2023-08-23; update "asNeeded". Two CSV resources (reference table and maps; data definitions). The PDFs are the scanned sheets: 2,741 CSV rows, 2,599 usable PDFs in our set (earlier passes), about 2,000 lakes matched cleanly, surveys mostly 1950s-1990s, not georeferenced, in feet or metres. So: **we can publish charts, with attribution, now.**
- **"Bathymetric Maps of Surveyed Lakes"** (digitised contours, 28 lakes): https://catalogue.data.gov.bc.ca/dataset/bathymetric-maps-of-surveyed-lakes (2026-11-25). Licence **Access Only**. Formats: custom download, WMS, KML. Contour polygons per depth including 0 m; "not intended for navigation". Max/mean depth fields come from it (earlier pass).
- Other sources (CHS NONNA for Harrison/Pitt only, CHS paper charts not digitisable, Hakai multibeam for Seton/Anderson/Horne, OBWB Okanagan lidar near-shore only, modelled GLOBathy/HydroLAKES) are in `bathymetry-feasibility.md` section 3b, dated 2026-11-13; I did not re-read them. No open full-depth vector data exists for Okanagan Lake.
- The 510 old E00 vector files are reached only through the Access Only sheet layer (earlier passes).

Net licence picture today: charts (PDF) = OGL, free to ship. Stocking full detail, placed contours, vector zips = Access Only, the owner's OGL link is still owed (T634). Open stocking from FISS = OGL.

## 3. Competitors (checked 2026-11-25)

| App | Stocking | Depth | Evidence |
|---|---|---|---|
| River Atlas (iPhone, Lower Mainland and Fraser Valley) | "Browse stocking reports for supported lakes, follow the waters you care about, check new reports". Page mentions no push alert, so "follow" may only list reports (unconfirmed). | Not mentioned. Flow, level, temperature. | https://apps.apple.com/us/app/river-atlas-bc-fishing-map/id6822164700 (v1.3.2, free, Member $24.99) |
| BetterFish | A third-party listing says a stocked-lakes map layer, boat launches, campgrounds, parks, private land. No depth mentioned. Its own page timed out; not confirmed first-hand. | Not seen | https://mwm.ai/apps/betterfish/6794007475 (via search, 2026-11-25) |
| Fishbrain | Not BC stocking. A "stocking-lake" water page exists on its site; contents not read. | Depth contours layer needs Pro and an internet connection; Navionics SonarChart or C-Map Genesis Social; about 0.5 m accuracy claimed; Navionics 18,000+ 1 ft HD lakes in US and Canada | https://fishbrain.helpshift.com (search result text; one help page 404'd) |
| Navionics | No | Strong depth contours, paid subscription, proprietary; BC lakes added (forum post) | search results 2026-11-25; offline use not confirmed |
| Anglers Atlas / MyCatch | Not checked (sites not reached; Anglers Atlas guides carry BC stocking information per search snippet) | Not checked | unconfirmed |
| FFSBC GoFishBC itself | The reference: report per lake, filter by species, no alerts | Links to depth maps (earlier note) | page above |
| Fishr (also listed in COMPETITORS.md) | Search did not find the app at all; unconfirmed | | |

Reading: stocking with "follow" is where a close competitor is moving right now; depth contours on BC lakes are a paid, proprietary thing, so our free, open provincial PDFs plus max/mean depth are a real offer even though they are old scans. Nobody I found gives push alerts for stocking with confidence.

## 4. Options

Weekly feed pattern: the T412 pattern fits both. One publisher (a button-started workflow or the feeds worker `app/workers/feeds/src`, which already has `inseason.ts`, `runtiming.ts`, `push.ts`, `health.ts`), content-named files, an `index.json` written last, publish only on a real change with a diff, stale-age words in the app, no GitHub cron. For stocking the province source itself lags (data to 2026-06-29 when read on 11-13); I did not re-measure the lag today.

### Stocking
| Option | What the angler gets | Effort | Phone data | Offline | Feed fit / blocker |
|---|---|---|---|---|---|
| S1 Stocking card on lake page (last stocked, species, history) | Date, species, stage, count, size, years of history | M card + M matching + M feed (Lake tab is L, shared) | 5 yr 35 KB gzip; last-stocked index 12 KB; full history 354 KB (measured earlier) | Works after the feed is cached; with the release if bundled | Needs the FIDQ licence for counts/strain. FISS-only version has no counts |
| S2 "Stocked in last N days" filter + map colour | Turn the Stocked layer on, lakes coloured by recency; filter chip | S once S1 data exists (colour engine, legend and toggle already built) | the 12 KB index | Yes | T158 colour-blind ramp clash to fix; "no record" must never read "not stocked" |
| S3 Species filter | Rainbow / kokanee / brook / cutthroat | S-M | species dictionary, a few KB | Yes | Needs per-lake species in the index (about +20 KB, guess) |
| S4 Alert when a followed lake is stocked | Local notification | M-L; depends on T234 follow + notification settings | tiny | Phone checks the feed when online; no server push (owner rule) | Fires only on a feed publish, so only as fresh as the source; seasonal bursts |
| S5 Streams (stocked rivers) | Places on a river | M extra | | | Defer; lakes only |

### Depth
| Option | What the angler gets | Effort | Phone data | Offline | Fit / blocker |
|---|---|---|---|---|---|
| D1 "Depth chart" card: official PDF in the Lake tab | The government chart, survey year, units, "not for navigation" | S storage + M card + owner review hours (1,995 clean ticked in bulk, 343 one by one) | Table 40-60 KB; PDFs 201 MB on R2, median 60-80 KB each (estimate), never bundled | After first open; "save this lake offline" later | OGL, no blocker. Matching and the review are the work |
| D2 Max / mean depth on the lake page | Two numbers | S for 25-28 lakes; more would need reading the PDF text layer (T219 says readable) | under 10 KB | Yes | Source of the 28 is Access Only |
| D3 Depth layer tint ("has a chart") | Lakes tinted sheet / digitised | S (built, switches on with `lakes/1`) | under 10 KB | Yes | Needs the reviewed match file |
| D4 Contour vector tiles | Real contours and shading on the map | L for about 400 lakes; XL for scans | 25 lakes under 1 MB; about 415 lakes 10-30 MB (estimate) | Separate optional pack | Access Only licence, unit ticks (110 unstated), owner tick per placing, T158 drawing rules |
| D5 Link to the Province's own PDF | Link out | S | 0 | No | Breaks self-host rule; not recommended |

## 5. Looks (text mock-ups)

### Stocking
- **A. Card first.** Lake page, new "Stocking" card under the regulations: `Last stocked 14 May 2026 · 1,500 Rainbow Trout (yearling, 34 g)` / `2025: 3 releases ... 2024: 2 releases` / `Records to 29 Jun 2026, Province of B.C.` A lake with none: `No stocking record`.
- **B. Map colour.** Layers sheet: Stocked switch on. Lakes in the navy-to-yellow ramp; legend `This season / This year / 1-3 years / 3-10 / Over 10 / No record`; tap a lake, sheet opens with one line `Stocked 14 May 2026` and a "More" link to the card. Rivers draw plain.
- **C. Recent list.** A "Recently stocked" list near you: `Trout Lake, 12 km, Rainbow, 9 days ago`, with chips `7 d | 30 d | 90 d` and a species chip row.
- **D. Follow.** A bell on the lake page: `Tell me when this lake is stocked`. Card gets `Following`. Notification: `Trout Lake was stocked (Rainbow Trout), data as of 3 Dec`.

### Depth
- **A. Chart card.** Lake page "Depth" card: a small preview of the chart, `Surveyed 1974 · depths in feet · Province of B.C.`, `Open chart`, `Save for offline (82 KB)`, footnote `Not for navigation`.
- **B. Facts strip.** One line `Max depth 31 m · Mean 12 m · Surveyed 1989` above a chart button; only on lakes with digitised data.
- **C. Tint.** Layers sheet "Depth" on: lakes tinted `Contours traced / Sheet only / Not surveyed`; tap goes to card A.
- **D. Contours.** Lake zoomed in, bands of blue by depth, 5 m lines labelled, legend in metres, `Offline pack: Skaha Lake 0.4 MB`.

## 6. Recommended first slice

**Stocking (one small release): S1 + S2 on the open FISS data, lakes only, 5 years.** Steps: add FISS points to `pipeline.stocking.propose`, owner ticks 154 review rows (+ sample of class B), frozen file `data/curated/stocking/matches.json`, feed `feeds/stocking/index.json` through the T412 pattern, switch on the Stocked colour (fix the T158 ramp), a Stocking card with date, species, stage and "count not published". Needs no licence answer because FISS is OGL. Shows "records to <date>" so the lag is honest. Alerts (S4) follow with T234.
**Why:** the colour engine, legend, toggle and file format are already built; River Atlas and BetterFish show stocking; the card plus colour is where the demand is.

**Depth (one small release): D1 + D3 + D2 for the 25 clean contour lakes only if the licence link arrives, otherwise D1 + D3.** Steps: bulk-tick the 1,995 clean chart matches after a 50-row spot check, review the 343, PDFs to staging R2, `chart` table, `lakes/1` survey state, "Depth chart" card with survey year, units and the not-for-navigation line. All OGL. Contours (D4) after.
**Order:** stocking release first (as the owner said), depth second; both need the Lake tab (T634 item 6), so build the tab once in the stocking release with a Depth card slot.

## Picks for the owner
1. Stocking first version: (a) open FISS only, no counts or strain, ship now [recommended]; (b) wait for the FIDQ licence link; (c) ask the Society for permission to use its report (freshest, richest).
2. Depth first version: (a) official PDF chart card + tint, no contours [recommended]; (b) PDF card plus max/mean depth for the 28 contour lakes (needs the licence link); (c) contours for the strict placed lakes.
3. Stocking alerts: (a) later, with T234 notifications [recommended]; (b) in the first release; (c) never.
4. Which look for stocking: A card, B map colour, C recent list, D follow. Default: A + B together.
5. Which look for depth: A chart card, B facts strip, C tint, D contours. Default: A + C.
6. The credits page already says "Stocked lakes and lake depth, Open Government Licence" (`menu/licences.ts:144-146`). Until the data ships and the licence is settled: (a) reword to what is true today [recommended]; (b) leave.
7. Is a lagging stocking date (source ends months behind) acceptable if the card says "Records to <date>"? (a) yes [recommended]; (b) no, wait for the Society.

## NEW TICKET lines
- NEW TICKET: Credits text claims stocking and depth data not yet shipped (`menu/licences.ts:144`, `menu/sources.ts:121`)
- NEW TICKET: Stocking first version from the open FISS layer (matches file, feed, card, Stocked colour on, T158 ramp)
- NEW TICKET: Depth chart card and tint from the OGL provincial PDFs (review of 1,995 + 343, R2 upload, `chart` table, `lakes/1`)
- NEW TICKET: Follow a lake and get told when it is stocked (under T234)
- NEW TICKET: Check whether the "Depth contours" switch is offered with no data behind it (`layers.ts:159`)

## Not verified
- Nothing was run or seen on a screen; user-visible behaviour is read from code. Not checked: whether the contours switch shows, how the Layers sheet looks.
- Current lag of the stocking sources (not re-measured; 2026-06-29 is from 11-13). Whether FIDQ licence changed: it still reads Access Only today.
- BetterFish first-hand (its page timed out; third-party listing only). Anglers Atlas, MyCatch, Fishr, Fishbrain stocking, Navionics offline: not confirmed. HectaresBC not found.
- GoFishBC cadence (page gave none). Fishbrain help page 404.
- Counts and sizes quoted from earlier passes (T634, two feasibility notes) were not re-run; sizes marked "estimate" are estimates.
- Old production site behaviour (from the earlier note, not opened).
