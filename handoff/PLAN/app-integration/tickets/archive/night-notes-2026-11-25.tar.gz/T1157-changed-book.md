# T1157 step 1: what changed in the book on gov.bc.ca (read-only)

Written 2026-11-25 night. Read-only: no curated row changed, no mark written, the parser not run.

The two copies:
- **Repo copy**: `data/source/fishing_synopsis.pdf` (sha 08f58537…). In the PDF metadata it was made on 2025-11-18
  (InDesign).
- **gov.bc.ca copy**: fetched 2026-11-25 (sha a83fc599…). Its metadata says it was made 2026-07-29 and edited
  2026-08-25 (in Acrobat).

**The gov.bc.ca copy is newer.** Both the metadata and the content show it: it prints, in red, the 2026 in-season
changes that took effect on July 30, 2026 and August 27, 2026. Both copies still say "2025-2027" and are valid from
April 1, 2025 to March 31, 2027.

Pictures of every changed row (repo copy on top, gov.bc.ca below) are in `night/T1157-changed-book/`:
`01_cowichan_river_p17.png` … `08_similkameen_river_p77.png`.

## How this was read

- **Pixels.** Each of the 37 pages was rendered for both copies (pypdfium2, scale 2) and compared pixel by pixel.
  The bands where the pixels differ are in `T1157-changed-book/bands.txt`, and the crops are in `img/`. Every band
  was then looked at, plus full pages 2-4, 8-12, 17-20, 34, 75-77 and 83.
  Script: `T1157-changed-book/pixdiff.py`.
- **Red text.** The red (in-season) lines of each copy were listed from the character colours:
  `red_repo.txt` and `red_gov.txt` (`meta_red.py`).
- **The raw text diff misled in four places.** It comes from the hidden text layer, so trust the rendered pages over it:
  1. It put the PUNTLEDGE RIVER rows on p.17. They are not visible there: they are hidden text.
  2. It gave "No Fishing July 30-Sept 15" to JEWEL CREEK and to SATURDAY LAKE. On the page, those lines belong to
     OKANAGAN RIVER and SIMILKAMEEN RIVER.
  3. It missed the Similkameen change completely.
  4. It showed the phone number "++1-778-372-0729" as gone from p.10. It is still printed there.
- **Page numbers.** These follow the brief: printed = PDF−2 up to printed 40, then PDF−6. PDF p.2 has no printed
  number.

## 1. Every page, classified

| PDF p. (printed) | class | what a reader sees |
|---|---|---|
| 2 (none) | LAYOUT | The minister's letter is re-wrapped narrower. Same words. |
| 3 (1) | WORDING | "Regional"→"regional". The in-season paragraph is shortened (ministry name and "RSS feed no longer used" dropped). New engagement web address. |
| 4 (2) | **LICENSING** + layout | New "PROVINCE WIDE" box: from April 1, 2026 an angler may state their FWID instead of showing the licence (see §3). |
| 5 (3) | WORDING | "Licencing"→"Licensing", a web address, "Wildlife and Ecosystems Branch". |
| 7 (5) | WORDING | "license"→"licence" once; a link style. **The fee table is unchanged** (no pixel change on it). |
| 8 (6) | **LICENSING** + layout | New WILD and FWID sections; proof-of-licence and carrying rules rewritten; where to buy is now WILD; lost-licence text rewritten. Conservation Surcharges moves to p.9. |
| 9 (7) | LAYOUT + **LICENSING** (minor) + wording | Text reflowed. New: "a valid angling guide number must be entered to purchase a guided licence". The Classified Waters sentence is reworded with the same meaning; the white sturgeon link is new. |
| 10 (8) | LAYOUT | Reflowed only (Family Fishing Weekend and the guide-check text moved in from p.9). |
| 11 (9) | LAYOUT + WORDING | Reflow; web addresses without "https://". |
| 12 (10) | LAYOUT + **LICENSING** + wording | "Keep your angling licence handy while travelling - FWID and ID are acceptable if a Conservation Surcharge Stamp and catch retention record were not required for your catch". The angling guide link changed. |
| 14, 22, 29, 35, 47, 54, 69, 73 (12, 20, 27, 33, 41, 48, 63, 67) | WORDING | "gov.bc.ca/WildlifeManagementUnits." → "www.gov.bc.ca/WildlifeManagementUnits" |
| 17 (15) | **RULE** + layout | COWICHAN RIVER: the red "No Fishing July 4-July 14" is gone. FORBUSH LAKE moves in from p.16. |
| 18 (16) | **RULE** + layout | HEBER RIVER dates (below). FORBUSH LAKE moves out. |
| 19 (17) | **ROWS LOST** + layout | LITTLE QUALICUM RIVER and LIZARD LAKE are missing from the whole gov.bc.ca copy (checked in the text layer and on the rendered pp.18-20). PUNTLEDGE RIVER is now printed twice: at the bottom of p.19 and again, unchanged, at the top of p.20. |
| 23 (21) | WORDING | A web address (plus a 1-pixel speck). |
| 26 (24) | LAYOUT | A trailing space in the text layer; no pixel changes. |
| 34 (32) | **RULE** | SALMON RIVER 3-26: new red line. |
| 36, 48, 55, 63, 70, 80-83, 85 (34, 42, 49, 57, 64, 74-77, 79) | WORDING | Web addresses shortened or re-wrapped; "Wildlife and Ecosystems Branch" (p.85). |
| 75 (69) | **RULE** ×3 + layout | New red row BESSETTE CREEK; red lines on GRANBY RIVER and GRANBY RIVER'S TRIBUTARIES. JEWEL CREEK moves to p.70. |
| 76 (70) | **RULE** ×2 + layout | Red lines on OKANAGAN RIVER and OKANAGAN RIVER OXBOWS. SATURDAY LAKE moves to p.71. |
| 77 (71) | **RULE** + layout | Red line on SIMILKAMEEN RIVER. The NOTE at the bottom is re-wrapped. |

**Counts by page** (the main class; 37 in all):

| class | pages |
|---|---|
| RULE | 6 |
| rows lost | 1 |
| LICENSING | 4 |
| WORDING only | 23 |
| LAYOUT only | 3 |

**Counts by change:** 9 rule changes (one of them a new row), 2 rows lost, 1 row printed twice, and about 7 licensing
items.

## 2. Rule changes and what the app holds

How the app's answer was checked:
- Curated rows: `data/curated/regulations/synopsis/region-*.json` (main checkout).
- The answer: `data/generated/bundle/bundle.sqlite` (12:57 today), the bundle release `r-71d09ad82e81` was cut
  from. The labels are confirmed in `data/generated/regs/ui-rules-export.json` (13:00).
- The release's own regs files are binary and were not decoded.
- In-season notices: `data/generated/inseason/feed/index.json` (captured 2026-11-08) and
  `data/curated/inseason/notice_waters.json`.

**In-season notices only add a banner.** They never change the answer (`data/curated/inseason/README.md`). By the
owner's 2026-11-11 rule, a banner with no end date shows until gov.bc.ca's page drops the notice
(`app/packages/core/src/inseason-span.parity.json:24-28`).

| # | Region · water · MU | old words (repo copy) | new words (gov.bc.ca) | the app today | verdict |
|---|---|---|---|---|---|
| R1 | 1 · COWICHAN RIVER · 1-4 | red "No Fishing July 4-July 14" | line removed | Curated rule `cowichan_river.r1` (`r1:cowichan_river_see_map_below@1-4`) says "No fishing, Jul 4-Jul 14" **every year**. The in-season notice `is-689cae172c40` reads "July 4, 2025 to August 31, 2025: No fishing", so the red line was a **2025-only** closure that was baked in as a standing rule. | **MISSING (stale closure).** The app wrongly says the river is closed July 4-14. That already happened in July 2026; next it would be July 2027, after this book expires, if this book's data is still served. |
| R2 | 1 · HEBER RIVER · 1-9 | "No Fishing upstream of top of lower canyon … Nov 1-Sept 14"; "No Fishing downstream of top of lower canyon …" | "… Nov 1-Aug 31"; "… downstream … Jan 1-Dec 31" | Curated `heber_river.r1` says Nov 1-Sep 14. `r2` has no dates, which means year-round, so it matches "Jan 1-Dec 31". There are two banners: `is-74fcb31b2d0b` (Aug 27, 2026) prints the new dates, and `is-03e14f544b83` (Apr 1, 2026) just says "No fishing". | **MISSING for r1.** Above the lower canyon the app says closed **Sept 1-14**, but the book now says open from Sept 1. The banner shows the right words, but the answer is wrong. Next bites Sept 2027. The r2 change is wording only. |
| R3 | 3 · SALMON RIVER · 3-26 | (none) | red "No Fishing July 30-Sept 15 including tributaries" | Curated `r3:salmon_river@3-26` has only catch-and-release and a bait ban. Banner `is-06e7bf41d7fc` (effective July 30, 2026, no end) is bound to the river and its tributaries. | **IN THE DATA as a banner only.** The answer says open. |
| R4 | 8 · BESSETTE CREEK (incl. tributaries) · 8-22 | row not in book | **new row**, red "No Fishing July 30-Sept 15" | No curated row (no Bessette entry in the bundle). Banner `is-f528732e7d5b`. | Banner only. |
| R5 | 8 · GRANBY RIVER · 8-15 | (none) | red "No Fishing July 30-Sept 15 from 12 pm to midnight" | Curated `r8:granby_river@8-15` has no closure. Banner `is-e03c3754d0af`. | Banner only. |
| R6 | 8 · GRANBY RIVER'S TRIBUTARIES · 8-15 | "Bait ban" | + red "No Fishing July 30-Sept 15 from 12 pm to midnight" | Banner `is-79fcd6f4a6bc`. | Banner only. |
| R7 | 8 · OKANAGAN RIVER · 8-1 | (none) | red "No Fishing July 30-Sept 15" | Banner `is-2fa458fef3c3`. | Banner only. |
| R8 | 8 · OKANAGAN RIVER OXBOWS · 8-1 | (none) | red "No Fishing July 30-Sept 15" | Banner `is-bb5426c61ff3`. | Banner only. |
| R9 | 8 · SIMILKAMEEN RIVER (incl. tributaries) · 8-2 | (none) | red "No Fishing July 30-Sept 15" | Curated `r8:similkameen_river@8-2` has no closure. Banner `is-6a32433916ac`. | Banner only. |

**About R3-R9, the seven July 30-Sept 15 closures:**
- They are the province's 2026 in-season closures, the notices dated July 30, 2026. The PDF was made the day before.
- Between July 30 and Sept 15, 2026 the app's answer said these waters were open. That **could have let an angler
  break the law**, but it is over now. The feed was first captured 2026-10-29 (`firstSeen`), so there was no banner
  during the closure either.
- Today they bite no one. The banners still print "No fishing July 30 to September 15" with no end date.
- **Whether they come back in July 2027: CANNOT TELL.** The book prints no year. My guess is they are one-season
  (drought) closures, because the Cowichan red line followed the same pattern: printed red with no year, later
  dropped. Making them every-year rules would close seven waters every summer on a guess.

**Rows lost (R10, R11): LITTLE QUALICUM RIVER (1-6) and LIZARD LAKE (1-3).** The app is right here:
- The data and the bundle keep both rows (`r1:little_qualicum_river@1-6`, 5 rules; `r1:lizard_lake@1-3`, electric
  motor only).
- No in-season notice and no line on the "Regulation Changes" page explains removing them. Puntledge appearing
  twice in the same place suggests a page-assembly error by the publisher (a guess).
- **The risk is the runbook:** a re-extraction of the gov.bc.ca copy would list both as "gone". If they were
  confirmed gone, the app would drop:
  - the Dec 1-May 31 closure from the falls to the hatchery fence;
  - the 35 m hatchery closure;
  - fly-only Sept 1-Nov 30;
  - the tributary closure and Lizard Lake's motor limit.

**PUNTLEDGE RIVER (1-6) is not changed.** It is pixel-identical on p.20 in both copies; the extra copy on p.19 is the
same words. The ticket's lead ("moved or changed?") is settled: neither. The p.17 text in the diff is the hidden layer.

**Nothing else changed in the water tables.** Every other water-table page is pixel-identical, apart from the bands
listed above.

## 3. Licensing: the app against the new book

| book now (gov.bc.ca) | the app today | out of date? |
|---|---|---|
| From April 1, 2026: for the basic, classified waters and white sturgeon licences you may **state your FWID or produce your licence** (PDF p.4, printed 2; p.8, printed 6). | "Anglers 16 and over: produce your angling licence and photo ID when an officer asks". Curated `zp:licence_administration#produce_licence` with the old 2025 words; label text at `pipeline/regs/parsing/catalogue_parts/gear.py:373`. | Yes. It is stricter than the law, so no one breaks the law by following it. It is wording, but wrong since April 1, 2026. |
| The paper licence is required when retaining hatchery steelhead, chinook, Shuswap char or rainbow trout and Kootenay Lake rainbow trout; carry the paper licence when a stamp retention record is required. | `carry_paper_licence` with the same four fish (`app/packages/core/src/regs/words.ts:548`). | No change in meaning. |
| Travelling with fish: "FWID and ID are acceptable if a Conservation Surcharge Stamp and catch retention record were not required" (p.12, printed 10). | "Have your angling licence at hand when you travel with fish" (`zp:transporting_catch` r1). | Yes. Stricter; wording. |
| Licences are sold through **WILD** (www.gov.bc.ca/wild); an FWID is needed to buy one; in person at Service BC, FrontCounter BC or a vendor. | The app names no seller. The price note links "gov.bc.ca/fish-licence" (`words.ts:543`). That address is still printed on PDF p.48 of the new book. | It is only missing. `reference/licensing.md:240-254` already carries the WILD text from a Feb 2026 news release, but nothing in the app shows it (0 hits for "FWID" in the UI exports). |
| Lost licence: "If you already have a valid licence do not buy a new licence"; reprint through WILD with your FWID. | `basic_one_per_year`: "one annual angling licence per year". | Wording. |
| A guided non-resident needs the guide's number to buy a Classified Waters licence (p.9, printed 7). | Not said. | Minor. |
| Fees (PDF p.7, printed 5) | The fee table "as printed for 2025-2027". | **Unchanged.** |

**Side finding.** `reference/licensing.md:17` already states "you may either state your FWID …" inside the section
headed "Transcribed verbatim from the synopsis". The repo copy does not print that sentence; only the gov.bc.ca copy
does. If the repo keeps the old PDF as its source, that line is mislabelled. Not checked: whether
`test_catalogue_entries` notices it.

## 4. Older, or just different?

- **The repo copy is older.** Its metadata says 2025-11-18; gov.bc.ca's says created 2026-07-29 and edited
  2026-08-25. The gov.bc.ca copy carries the 2026 notices (Heber River, Aug 27, 2026; the seven closures, July 30,
  2026).
- **The gov.bc.ca copy also lacks three things the repo copy has:**
  1. the red Cowichan 2025 line (removed on purpose: the 2025 closure is over);
  2. the LITTLE QUALICUM RIVER row (very likely an error);
  3. the LIZARD LAKE row (very likely an error).

  Every other red correction in the repo copy is still in the gov.bc.ca copy (`red_repo.txt` against `red_gov.txt`).

## 5. Summary for the owner

| # | change | where | severity | in the app |
|---|---|---|---|---|
| R1 | Cowichan River's 2025-only "No Fishing July 4-14" dropped | R1, 1-4, PDF p.17 (15) | wrongly told not to fish (July 4-14; next July 2027) | stale standing rule |
| R2 | Heber River above the canyon: closure ends Aug 31, not Sept 14 | R1, 1-9, PDF p.18 (16) | wrongly told not to fish (Sept 1-14; next Sept 2027) | old dates; the banner is right |
| R3-R9 | July 30-Sept 15, 2026 closures: Salmon River 3-26, Bessette Creek 8-22 (new row), Granby River and its tributaries 8-15 (noon to midnight), Okanagan River and Oxbows 8-1, Similkameen River 8-2 | PDF pp.34, 75-77 | could break the law, but only during Jul 30-Sep 15, 2026 (over) | banners only, still showing |
| R10-11 | Little Qualicum River, Lizard Lake rows missing from the gov.bc.ca copy | R1, PDF p.19 (17) | none in the app today; a re-parse risk | kept (correct) |
| L1 | FWID can stand in for showing the licence (from April 1, 2026) | PDF pp.4, 8, 12 | wording (the app is stricter) | old words |
| L2 | WILD is where to buy; lost-licence reprint through WILD | PDF p.8 | wording / missing | not shown |
| L3 | guided licence needs the guide's number | PDF p.9 | wording | not shown |

**What the annual runbook (`handoff/PLAN/runbooks/annual-synopsis.md`) would redo** if the gov.bc.ca copy is adopted:
1. Step 1: keep the old copy, record the new checksum. The validity dates are the same.
2. Step 2: check the extractor on the new copy. The new copy was edited in Acrobat, so its hidden text layer differs
   from the repo copy's. Then run the 2c gate and the extraction (heavy jobs).
3. Step 4 carry should list:
   - **changed**: Cowichan, Heber, Salmon (3-26), Granby, Granby tributaries, Okanagan River, Okanagan Oxbows,
     Similkameen;
   - **new**: Bessette Creek;
   - **gone**: Little Qualicum and Lizard Lake. These must be kept, not confirmed gone.

   Also check that Puntledge printed twice does not mint a second entry.
4. Steps 5-6: a parse of about 9 rows (owner only, credits). This is small enough to curate by hand instead.
5. Step 8: re-transcribe the licensing reference and edit the `zp:` licence entries (`licence_administration`,
   `transporting_catch`).
6. Source pages move for FORBUSH LAKE (16→15), JEWEL CREEK (69→70) and SATURDAY LAKE (70→71); these are cosmetic.
   The fee table test should pass unchanged.
7. Step 9: cut a new extractor baseline. Steps 10-11: build and staging.

## Picks for the owner

1. **How should the changed book come in?**
   - (a) **Default:** adopt the gov.bc.ca copy through the runbook, and keep Little Qualicum River and Lizard Lake by
     your decision, citing the old copy.
   - (b) Keep the repo copy as the source; hand-fix only Cowichan r1 (remove it) and Heber r1 (Nov 1-Aug 31), each
     citing its in-season notice.
   - (c) Change nothing until the 2027-29 book.
2. **The seven July 30-Sept 15 closures (R3-R9):**
   - (a) **Default:** leave them as in-season banners and add no standing rule.
   - (b) Add them as rules dated 2026 only.
   - (c) Add them as every-year rules.
3. **Licence-proof words (FWID, WILD):**
   - (a) **Default:** update the `zp:` licensing entries and app words now (state your FWID or show the licence; WILD
     as where to buy).
   - (b) Wait for the next book.
4. **The missing rows on gov.bc.ca:**
   - (a) **Default:** you tell the synopsis inbox printed on p.5 that Little Qualicum River and Lizard Lake are missing
     and Puntledge is printed twice.
   - (b) Do nothing.

## NEW TICKET lines

- NEW TICKET: Cowichan River's 2025-only "No Fishing July 4-July 14" is a standing rule in the data; the current book
  dropped it.
- NEW TICKET: Heber River above the lower canyon is closed Nov 1-Aug 31 (book and in-season notice of 2026-08-27), not
  Nov 1-Sept 14.
- NEW TICKET: Licence-proof wording: from April 1, 2026 an FWID may be stated instead of showing the licence; licences
  are sold in WILD. Includes fixing the "transcribed verbatim" label on `reference/licensing.md:17`.
- NEW TICKET (input to T1157 step 3, the standing check): compare the **ink-checked, visible** text per water row, or
  the rendered pixels, not the raw text layer. Tonight the raw diff put rules on the wrong waters and missed
  Similkameen. Pixel bands (`pixdiff.py`) found every change in about 1 minute for 37 pages.

## Not verified

- The release's own regs files (`data/release/r-71d09ad82e81/regs-*.sqlite.gz`) are binary-encoded. I read the
  bundle and UI export it was cut from instead, and did not prove they are identical.
- What the app actually shows on a phone for the two Heber banners. In particular, whether the April 1, 2026 notice,
  which just says "No fishing", is shown with no end date; it may mislead.
- Whether the seven 2026 closures recur in 2027 (no web check was made).
- Whether gov.bc.ca/fish-licence and gov.bc.ca/wild resolve today.
- How the runbook's carry step treats one row id printed twice.
- I did not run `test_catalogue_entries` or `test_base_rules_in_print`.
- The four unnumbered centre pages and every page outside the 37 were not looked at; they had no text difference.
