# T1149 scoping: an area's rule reaches outside the area (read-only, 2026-11-25 night)

Data: the main checkout's generated files of the 0.10.0 candidate (bundle, tiles and atlas all on section handles
`4ae7b62955bc9990`, registry `2231d68636b8e9ee`). Code: the planning worktree at main.
Scripts and outputs: `night/T1149-scoping/` (`measure.py`, `analyze.py`, `lakes.py`; `straddlers.csv` holds all
646 straddling stream sections with lengths and coordinates; `summary.json`, `options.json`, `lakes.csv`).

**How lengths were measured.** For every stream section a rule binds, I took the section's line from the tile
layer `stream.geojsonl` (keyed by section id), projected it to BC Albers, and cut it against the area polygon the
atlas used (`atlas/full/area_catalog.gpkg`). "Outside" = section length minus the part inside the polygon. A
section counts as straddling when more than 5 m lies outside. All bound sections were measured, nothing was
sampled. The three scripts together ran under 25 s and 1.7 GB.

## Short answer to the owner's question

"If they straddle, can they get the rule?" They do get it today, on their WHOLE length. That is the problem. The
book says "within Strathcona Park", so the rule applies to the water inside the park. A section that dips 31 m
into the park (Rees Creek) shows the rule on 9.6 km of creek outside the park. The question is not whether a
straddler gets the rule. It is how far past the edge the rule may reach.

For Strathcona this matters little. Its only rule is "No powered boats" (book p.18), a stricter rule that never
changes open or closed or what you may keep. **The serious case is a different one, found tonight: the Creston
Valley WMA.** Its rule lets you fish for bass and yellow perch with no limit. In the rest of Region 4 it is illegal
to fish for bass and perch. That rule now reaches 190 km of creeks outside the WMA (Goat River, Corn Creek, Summit
Creek and more). The app tells anglers there that they may keep any number of bass, when fishing for bass there is
illegal. I checked this with the app's own reader (`effective_rules`) on Goat River section 448018: bass "no limit"
is in force, and the Region 4 bass closure is lifted.

## 1. How area membership is decided and bound (code)

- Each area says how it is cut, in `data/curated/waters/area_closures.json`: national parks, ecological reserves
  and the Chilkoot Trail use `cut: "clean"`, `rejoin_m: 1000` (lines 5-63). Provincial parks (line 105), WMAs
  (117) and watersheds (128) use `cut: false`, which means membership only, never cut (`_cut_policy`, line 223).
  Regions, management-unit groups and sign zones use `first_last` with both-sides membership.
- The atlas cuts areas in `pipeline/atlas/build.py:1120-1200` (`cut_areas`). For a `false` area it only loads
  the polygons (build.py:1197, "membership-only (no cut)").
- Membership is decided in `pipeline/atlas/splits/border.py:327` `mark_inside_areas`, called at build.py:1476.
  For a clean-cut area the cutter's inside stretches decide (border.py:397-406). For every other area a section is
  a member when its polygon `covers` it, OR when more than **`_AREA_MIN_OVERLAP_M = 1.0` m** of it lies inside
  (border.py:275, test at 429-438 through `registry/regions.py:247` `holds`; a region needs more than 5 m).
- **The only minimum-overlap rule is that 1 m (5 m for regions).** There is no share test and no length cap for
  streams. Lakes and wetlands use the outline test: at least 0.1 ha or a tenth of the lake inside
  (border.py:277-292). The owner's Z10 ruling (T796) also lets a lake that lies mostly outside be taken out by name,
  with a page note (`pipeline/deliver/bundle/outside_note.py`).
- The registry turns `in_areas` into one `area:` item per area (`pipeline/atlas/registry/build.py:501-514`). A
  rule's `within` extent is a plain set operation on that item's sections (`pipeline/atlas/reach/extent.py`
  around line 1285). Nothing downstream looks at geometry again, so the 1 m overlap is final.

## 2. Strathcona: what the rule says and what it does outside

- Book p.18, Region 1 row "STRATHCONA PARK WATERS": *"No powered boats on any water within Strathcona Park except
  Gold, Upper Campbell and Buttle lakes."* That is the park's only rule (`strathcona_park_waters.r1`, a vessel
  rule).
- It binds 6,431 stream sections (5,995 km). **384 straddle: 478.4 km outside the park**, and only 377.5 km of
  those same sections is inside. 217 of the 384 lie mostly outside (379 km), 44 lie 90% or more outside. 35 have
  less than 50 m inside, 205 less than 500 m.
- Spread of the share outside (number of sections per tenth): 0-10% 37, 10-20% 24, 20-30% 31, 30-40% 33,
  40-50% 42, 50-60% 42, 60-70% 41, 70-80% 49, 80-90% 41, 90-100% 44. The full list, sorted by share outside, is
  in `straddlers.csv` (group `strathcona`).
- Stricter or looser? **Stricter.** On Rees Creek, Cruickshank River and Ucona River the park rule is the ONLY
  boat rule bound (checked in the bundle), so without it nothing restricts boats there. Outside the park the angler is told "no powered boats" where nothing
  forbids them. It changes no open/closed colour, no quota and no gear rule. Harm: small; nobody is told to fish
  where fishing is closed.
- Lakes: only 10 bound lakes and wetlands reach past the boundary, 6.3 ha in all (Duncan Lake has 3 ha of 12 ha
  outside). Not an issue.

## 3. Every other area whose rule binds by overlap

These are all the `within` extents in the bundle on an area that is not clean-cut (basins are left out: they
are bound by watershed code, not by polygon overlap).

| area (cut mode) | rule(s), book | direction outside | stream sections bound | straddlers | km outside | worst sections |
|---|---|---|---|---|---|---|
| Strathcona Park (none) | no powered boats, p.18 | stricter, harmless | 6,431 | 384 | 478.4 | Cruickshank R. 20.2 km out of 20.8; Piggott Cr. 13.0 km; Comox Cr. 12.5 km; Ucona R. 10.0 km out with 6 m in; Rees Cr. 9.5 km out with 31 m in |
| **Creston Valley WMA (none)** | bass and yellow perch "no limit", lifting Region 4's bass/perch closure; WMA permit required, p.34/36 | **LOOSER: told open when closed**; also a permit asked for where none is needed | 111 | 57 (all 57 also carry the permit) | **190.3** (68% of all the length the rule is on) | Goat R. 23.8 km out with 145 m in; Corn Cr. 23.2 km; Summit Cr. 21.8 km; Boulder Cr. 10.2 km; Newington Cr. 6.9 km |
| Bowron Lake Park (none) | trout/char 1 a day (30-50 cm), bait ban, single barbless hook, no powered boats, p.43 | stricter: told restricted when not (the Region 5/7A base is 2 a day from streams, any size, bait allowed) | 2,023 | 31 | 135.4 | Antler Cr. 23.3 km out with 274 m in; North Star Cr. 20.3 km out with 56 m in (its outside part is in Region 7A); Cariboo R. 16.9 km and 11.0 km |
| Liard River watershed (none) | bull trout catch and release Aug 15-Oct 15, else 1, p.65 | looser than Region 7B's bull trout 0, BUT 27 of 28 outside parts lie north of 60° or east of 120° W, i.e. outside B.C. | 137,893 | 28 | 15.6 (0.1 km inside B.C.) | Petitot R. 4.7 km along the 60th parallel |
| MUs 1-1 to 1-6 (first_last) | summer stream closure Jul 15-Aug 31, p.13 | stricter | 16,688 | 10 | 5.6 | Campbell River, all 10 (the river is the MU line) |
| Hamber Park (none) | Wood River no fishing Sep 1-Nov 30, p.40 | — | 7 | 0 | 0 | — |
| Haida Gwaii MUs (first_last) | Haida Gwaii quotas and bait ban | — | 16,700 | 0 | 0 | — |
| Kikomun Creek Park, Malcolm Knapp forest | lakes only | — | lakes | 0 / 1 lake | 0 / 0.2 ha | Peaceful Lake, kept in by an earlier owner ruling |
| Regions (first_last, both sides) | every zone rule | both regions' rules, the stricter wins (T183 policy) | — | 69 | 130 km on the smaller side | Fraser R3/R5 and R5/R7A, West Road R5/R6, Ahbau R5/R7A: these rivers ARE the region line |

**Is Strathcona the worst or only the first found?** It is the largest by km (478) but nearly harmless. The worst
is Creston: 190 km, and the only one where the reach makes the app say MORE is allowed than the law allows. Bowron
is second (135 km of wrong quotas and gear rules, on the strict side). The rest are small or outside B.C.

Region straddlers have grown from the 55 stream cases in the memory note (2026-09-08) to 69. That is the owner's
accepted both-regions policy, a separate item. I did not check why the count grew.

## 4. Options, with cost and binding change

The "binding change" columns come from `options.json`, computed from the measured lengths.

**(a) A minimum overlap (metres or share inside).** This fixes the 31 m and 6 m cases and very little else,
because most straddlers have real water inside.

| test | Strathcona: drop / km outside removed / km inside lost / km outside left | Creston | Bowron |
|---|---|---|---|
| inside > 100 m | 58 / 64.7 / 2.7 / **413.7** | 14 / 34.9 / 0.6 / **155.4** | 6 / 27.5 / 0.4 / 107.9 |
| inside > 1,000 m | 287 / 265.8 / 100.0 / 212.5 | 47 / 153.7 / 14.9 / 36.7 | 19 / 68.4 / 4.9 / 67.0 |
| inside share ≥ 25% | 105 / 255.7 / 31.4 / 222.6 | 32 / 171.7 / 11.1 / 18.6 | 15 / 107.2 / 9.5 / 28.2 |

Cost: small code (border.py:437 threshold), but membership is decided in the atlas, so it needs an atlas run
plus reach, deliver and tiles of one vintage. No new sections, so section handles stay. Verdict: it does not meet
the ticket's acceptance ("no section shows an area's rule on more than an agreed length outside"). The worst
section left still shows the rule 20 km outside.

**(d) Bind by the section's majority (inside share ≥ 50%).** Strathcona: 217 sections drop the rule, 379 km
outside removed, but **102 km inside the park lose it**, and 99 km outside keep it. Creston: 42 drop, 9.5 km
outside left, 16.3 km inside lost. Bowron: 24 drop, 3.4 km left, 26.4 km inside lost. It moves the error to the
other side of the line. For Creston, the inside water that loses the rule would show the bass closure (safe side).
For Bowron, park water that loses the rule would show the looser regional quota inside the park (unsafe side).
Same cost as (a). It matches the spirit of Z10 for lakes ("mostly outside is taken out"), but a stream can be cut
and a lake cannot.

**(b) Cut stream sections at the boundary: the clean cut that already exists.** National parks and reserves use
it today (`pipeline/atlas/splits/clean_cut.py:179` `decide_rejoin`, `:319` `resolve_clean_cuts`). The owner ruled
on 2026-10-06 that closure areas get this cut. Applying it to the areas whose rules reach outside is a curated
change in `area_closures.json`: one new entry for the rule-bearing parks (as `ecological_reserves` already picks
from the same `parks_bc` layer by a `where`), and one for the Creston WMA, both `cut: "clean"` and
`rejoin_m: 1000`. No new cutter code. Measured effect with a 1,000 m rejoin:

| area | straddlers | boundary crossings | sections after | new sections | km outside left |
|---|---|---|---|---|---|
| Strathcona | 384 | 485 | 763 | 379 | 5.5 |
| Bowron | 31 | 45 | 66 | 35 | 0.5 |
| Creston WMA | 57 | 70 | 123 | 66 | 0.2 |
| (Liard, if wanted) | 28 | 65 | 63 | 35 | 1.7 |

The binding change: the outside pieces (about 473 km Strathcona, 135 km Bowron, 190 km Creston) lose the area
rule and its permit. On Creston's outside pieces the Region 4 bass/perch closure comes back. Cost: an atlas
rebuild (a heavy job), then reach, deliver and tiles; about 480 new sections, so section handles change. That
needs the registry/entry resync and the full binding diff that T1149's step 4 already asks for. It is the only
option that meets the acceptance check, and the check is simple to add: no stream piece carries a `within` area
rule with more than `rejoin_m` of it outside.

**(c) A side mark, as the owner chose for the 55 region streams.** That decision marks each side of an EXISTING
cut in or out. A provincial park has no cut, so there is no side to mark. The nearest version is an "in part" note:
on a straddler the area rule is shown as "only inside Strathcona Park" and never decides. The Kootenay Lake WMA
permit (`undrawn_part`) and the T796 lake note already work this way, but only for a whole rule. Doing it per
section needs a new bundle field and an app change on every platform. The atlas would keep its sections. It
fixes Creston's direction (the lift no longer decides, so the closure stands). The inside part of each straddler
(377 km for Strathcona) gets only a note, and the app still says something on 478 km of outside water. Cost:
medium-large (bundle, app, guide words). I do not recommend it for areas.

**What each does to the side channels (T1146 cause D; T1140's nameless parts).** Burman, Bedwell, Rees, Comox and
Thelwood: the side channel lies wholly outside the park and correctly lacks the rule. Its main-stem neighbour
straddles (Burman 42% outside, Bedwell 32%, Thelwood 35%, Comox 88%, Rees 99.7%).
- (b) cut: every outside main-stem piece loses the rule, matches its side channel, and the nameless part merges
  away. All five are solved.
- (d) majority: Rees and Comox lose the rule and merge. Burman, Bedwell and Thelwood keep it and stay separate
  parts.
- (a) threshold: only Rees (31 m) at any threshold over 31 m. Comox needs more than 1,773 m.
- (c) note: the main stem's rule set still differs (rule versus note). Whether the parts merge depends on whether
  a note counts in the part key. I did not check this; probably they stay separate.

## 5. Ten worst cases, for pictures (Rees Creek first)

Coordinates are lat, lon (WGS84): the middle of the longest inside piece, then the middle of the longest outside
piece. "blk" is the FWA blue line key, measures in metres from its mouth.

| # | area | water | section | blk, measures | length | inside | outside | share out | inside point | outside point |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Strathcona | Rees Creek | 53166 | 354150445, 0-9563 | 9,564 m | 31 m | 9,533 m | 99.7% | 49.59132, -125.36164 | 49.60318, -125.30667 |
| 2 | Creston WMA | Goat River | 448018 | 356569573, 0-23980 | 23,980 m | 145 m | 23,835 m | 99.4% | 49.08400, -116.53462 | 49.11027, -116.44586 |
| 3 | Creston WMA | Corn Creek | 442963 | 356564225, 0-23965 | 23,966 m | 766 m | 23,200 m | 96.8% | 49.09305, -116.61069 | 49.06324, -116.73997 |
| 4 | Creston WMA | Summit Creek | 448871 | 356570324, 0-24360 | 24,361 m | 2,597 m | 21,764 m | 89.3% | 49.14026, -116.63214 | 49.13953, -116.77915 |
| 5 | Bowron | Antler Creek | 315807 | 356364159, 3762-27328 | 23,566 m | 274 m | 23,292 m | 98.8% | 53.24223, -121.43272 | 53.17130, -121.39742 |
| 6 | Bowron | North Star Creek | 308598 | 356360866, 0-20309 | 20,309 m | 56 m | 20,254 m | 99.7% | 53.26265, -120.73123 | 53.32135, -120.79664 |
| 7 | Strathcona | Cruickshank River | 57431 | 354153859, 2499-23283 | 20,784 m | 562 m | 20,222 m | 97.3% | 49.68425, -125.37224 | 49.63643, -125.27629 |
| 8 | Strathcona | Ucona River | 56894 | 354153463, 0-10005 | 10,005 m | 6 m | 9,999 m | 99.9% | 49.73480, -125.98878 | 49.71628, -126.03868 |
| 9 | Strathcona | Piggott Creek | 56288 | 354152983, 0-15690 | 15,691 m | 2,660 m | 13,032 m | 83.1% | 49.73265, -125.33473 | 49.78888, -125.37679 |
| 10 | Strathcona | Comox Creek | 57453 | 354153873, 0-14231 | 14,232 m | 1,773 m | 12,459 m | 87.5% | 49.54735, -125.32011 | 49.53617, -125.25061 |

A picture of each: the area polygon (`area_catalog.gpkg`, layer `areas`, by `area_id`), the section line
(`stream.geojsonl` by `section_id`), inside part in one colour and outside part in another, with the two points
labelled. Corn Creek and Summit Creek run west toward the Kootenay flats; Goat River runs east through Creston.

## Picks for the owner

1. How to fix it (hardening release)?
   - **(b) Cut streams at the edge of every area whose rule reaches outside (Strathcona, Bowron, Creston WMA),
     using the clean cut the national parks already have; plus a build check (recommended)**
   - (d) Majority binding, no new sections
   - (a) A minimum overlap only
   - (c) An "in part" note on straddlers
2. Creston WMA tells anglers they may keep any number of bass on 190 km where fishing for bass is illegal. When?
   - **Fix it in the next patch, ahead of the hardening release: the Creston WMA's clean cut alone, one
     atlas rebuild (recommended)**
   - With the rest in the hardening release
   - Now, in 0.10.0
3. The length outside an area that the build check allows:
   - **Up to the rejoin distance, 1,000 m, as for national parks (recommended)**
   - 250 m
   - 0 m (cut every crossing; Strathcona would need 869 pieces instead of 763)
4. Liard watershed (15.6 km, all but 0.1 km outside B.C.):
   - **Leave it (recommended)**
   - Cut it too

## NEW TICKET lines

- NEW TICKET: Creston Valley WMA bass/perch "no limit" and the WMA permit reach 190 km of creeks outside the WMA
  (Goat River, Corn Creek, Summit Creek ...), lifting Region 4's bass/perch closure there. HIGH, unsafe direction.
  (Or fold it into T1149 as its first part, if the owner prefers.)
- NEW TICKET: the build check for T1149's acceptance: no stream piece carries an area's `within` rule with more
  than N m outside the area polygon, run at build time and refusing a regression; region straddlers counted
  by kind (69 streams today, against 55 in the 09-08 note).

## Not verified

- Lengths come from the tile layer's drawn lines, not the atlas's own geometry pickle (2 GB, too heavy tonight).
  Tile and bundle share one vintage. Small differences are possible: 2 region straddlers measure under 5 m on the
  smaller side, where the atlas found more than 5 m.
- "Stricter / looser" for Strathcona and Bowron rests on the bundle's zone rules on a few sampled sections
  (Bowron: three sections, rainbow and kokanee on Aug 15) and on the book text. I did not read every straddler's
  full answer. The Creston lift was confirmed with the reader on two sections (Goat River, Corn Creek).
- Whether Goat, Corn and Summit Creeks hold bass or perch at all (a guess: few or none upstream of the flats).
  Even so, the app states a false legal permission.
- The clean-cut numbers are my own simulation of `decide_rejoin` (joining outside runs of 1,000 m or less between
  inside runs). The real cutter also ignores dips under 5 m, snaps to boundaries already on the line, and runs the
  sliver gate, so the true counts will differ a little.
- Whether option (c)'s note would count in the part key (T1140 merging). Why the region stream straddlers rose
  from 55 to 69.
- Park polygons with no rule were not measured. They bind nothing, so they cause no wrong rule.
- Files were read while a release was being built on the machine. All inputs carried one vintage when read
  (21:12-21:17).
