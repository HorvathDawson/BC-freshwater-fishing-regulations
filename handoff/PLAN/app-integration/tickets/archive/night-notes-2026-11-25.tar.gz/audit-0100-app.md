# 0.10.0 app-side review (independent), 2026-11-25 night

What I read: `v0.9.0` (the only 0.9/0.10 tag) to `origin/release/0.10.0` (head e2b789bb6), app/ only, plus PR #260
(T1145, merged on main as 5b0d4709d), and the open PR #265 (T1140, head da141d1cf, read with `gh pr diff 265` and `git show
da141d1cf:<path>`). PR #264 (T1146) touches no app file. I ran no tests and no builds. I read the 0.10.0 candidate's
data (data/release/r-71d09ad82e81) read-only, with one small script (`audit-0100-app/tidal_parts.py`).

## 1. What is in the release, by ticket (app/ only)

How I counted: `git log --no-merges v0.9.0..origin/release/0.10.0 -- app`, then lines added/removed per ticket with
mini-release, fixtures, pictures and snapshots left out. A squash-merged PR shows up as its branch commits AND its
squash commit, so these sizes can be up to about twice the real size. 100 non-merge commits in all. Without data,
fixtures, tests and app/tools, the release changes 96 app source files, +2,894 / -324 lines.

| ticket | commits | +lines | -lines | what it is |
|---|---|---|---|---|
| T1016 | 6 | 1748 | 169 | a web tab older than the served release refreshes itself (web only) |
| T1041 | 5 | 1516 | 233 | the ticket ledger tool (app/tools, no app code) |
| T1049 | 6 | 1233 | 146 | a start link lands on a slow cold start |
| T1029 | 12 | 1071 | 249 | one-bank closures on the map |
| T1036 | 4 | 952 | 274 | "All sources" sheet lists what the page's sheets cite |
| T1072 | 4 | 654 | 225 | store pictures (tools only) |
| T1027 | 11 | 629 | 50 | R8 keep rules (WorkManager), Android build |
| T1116 | 2 | 551 | 57 | push token only with the phone's permission; worker drops 30-day tokens |
| T1107 | 4 | 536 | 30 | search on the web /gauges page |
| T1052 | 3 | 386 | 36 | a water closed to all fishing says it once, salmon included |
| T905 | 3 | 340 | 43 | DFO publisher's bookkeeping out of the public feed (worker) |
| T1031 | 4 | 307 | 35 | trout row sheet cites every rule behind the row |
| T1083 | 3 | 248 | 21 | links read every item id kind (wsc:) |
| T1051 | 5 | 158 | 19 | Hooks row says which hooks are allowed |
| T1030 | 6 | 154 | 19 | "N waters changed" in the inbox |
| T1076, T1024, T1058, T1099, T1034, T1101, T1098, T1039, T1053, T1012, T666, T1050, release | 1-3 each | under 151 each | | small fixes, pins, docs |

Still to be picked tonight: #260 (T1145, 5 app source lines: the game-fish bar's "open" colour), #264 (pipeline only),
#265 (T1140: about 230 app source lines plus a mini-release re-cut).

## 2. Findings

### HIGH 1 — PR #265: opening the tidal lower piece of a river crashes the app

- Where: `app/packages/core/src/regs/header.ts:113-116` at the PR head (`partsOthersOf`), called on every page by
  `headerOf` (`header.ts:153`), so by `useRegsPage` (`WaterScreen.tsx:121`) and by the Conditions view's
  `useWaterPlace` (`app/packages/ui/src/regs.ts:487`).
- What goes wrong: a tap on the tidal stretch of a river that also has two or more listed parts opens that river on
  its tidal piece. `targetFor` resolves the tapped section through `part_section` to the tidal part
  (`app/packages/data/src/regs/inputs.ts:189`), and the page is the "Tidal water" page (T672). The map's list of parts
  never holds a tidal piece (`waterGroup` drops it). So `places` has entries but none for this part, and
  `partsOthersOf` throws "regs header: the map lists no part 0 of …". The throw happens inside a `useMemo` during
  render, and the app has no error boundary (I searched app/ and found no `componentDidCatch` or
  `getDerivedStateFromError`). The screen goes blank or the app closes, on the phone and on the web. It happens once the
  water's parts are read, which is about a second after the tap.
- How many waters: in the 0.10.0 candidate, 95 parts are tidal. 29 of them sit on a water with 2 or more listed parts,
  and all 29 have sections in `part_section` that the core file maps to the river (`item_section`). That includes the
  Fraser (20 tidal sections), Chemainus (16), Campbell, Nanaimo, Capilano, Squamish, Coquitlam, Somass, Sooke,
  Qualicum, Stave, Skeena and Nass. Measured with `audit-0100-app/tidal_parts.py` against
  `r-71d09ad82e81/water-09dd6a71d30f.sqlite.gz` and its `core-63bcc575830e.sqlite.gz`.
- Why I am fairly sure (about 85%): the code already treats a page on a tidal piece of a listed water as a real way in.
  `app/packages/ui/src/inseason.ts:131` says the page covers "a part no entry holds (a tidal piece: never listed on the
  map)". `WaterMapView.tidal.test.tsx` opens "a named tidal piece (a tap, an address)". The header's own name code
  guards this case (`header.ts:40`, `p === null` returns early). The new function does not.
- Tests: none cover it. `partLabel.test.tsx` walks the Coquitlam but only over listed parts (`partsOf` keeps
  `!p.tidal`). `header.test.ts:224` pins the throw as intended. No test passes places to a tidal page.
- Smallest fix: in `partsOthersOf`, return null when the page has no key (`inp.key == null`: a tidal piece, or outside
  B.C. with no listed entry) before the lookup. Or return null when `!p && inp.tidalPart`, and throw otherwise. Add one
  test: the Coquitlam's (gnis:19986) Regulations and Conditions views opened on its tidal section draw the tidal card
  and do not throw.
- Not affected: v0.9.0 and the current release branch. This is new in #265.

### MED 2 — the privacy page names a version that does not exist

- Where: `app/tools/seo/html.ts:300` says "From version 0.9.1, the app sends the token only while this phone lets it
  show notifications …".
- What goes wrong: that behaviour (T1116) ships in 0.10.0. There is no v0.9.1 tag, and `app.json` says 0.10.0. An iPhone
  on 0.9.0 still registers its token after "Don't Allow", so the sentence is wrong for anyone reading the page with 0.9.0.
- How sure: certain about the text and the tags. Whether 0.9.1 will ever ship is the owner's call.
- Smallest fix: "From version 0.10.0". `app/tools/seo/site.test.ts` pins the page words, so the pin changes with it.

### LOW 3 — the privacy page's list of website scripts leaves out the new /gauges search

- Where: `app/tools/seo/html.ts:302` lists the scripts the site runs (visit counter, a gauge page's script, the Join card,
  a region page's water search). T1107 added a script on the /gauges page (`app/tools/seo/gaugeFind.ts:92`). It reads the
  live gauge index and the search file, and reports its failures to our server.
- Nothing personal is sent; it is only a gap in the list. Fix: add "on the gauges page, a script for its gauge search,
  which reads the gauge list and which gauges report today". Note: T1148 (satellite cache, "not stored" at
  `html.ts:255`) is a known open ticket and is not repeated here.

### Process note (not a defect): picking order and the data re-cut for #265

- #265 was re-pinned after it merged main with T1145 (commit 367cfaa4b: "the open colour moved"). Pick #260 before #265,
  or the single-part pin test fails.
- #265 says a data re-cut is needed for the "inside <area>" names. Its release-backed test (`tools/seo/t1140.release.test.ts`)
  fails on a release cut before its deliver change. Picking #265 therefore means the candidate r-71d09ad82e81 is cut
  again, and the pins that name it (T1053 `5c5a0b60a`, T666 `0ae4d07be`) follow the new id. On the old candidate, the
  app still works: such a part is named by the data's own label ("2 side channels, joining …").
- I checked the app suite on PR #265's own CI: it is green (`gh pr checks 265`). CI has no live release, so the
  release-backed tests were skipped there.

### Looked at and found sound (no finding)

- T1052 `closedWithSalmon` (core/regs/withSalmon.ts). It joins the two statements only when every salmon closure is
  one the banner cites and all of them stand all year. Its two throws need a rule the part's own index lacks, which cannot
  happen with real inputs.
- T1051 `hooksAllowed` (core/regs/gear.ts:226-235) matches the pipeline's hook answers (`pipeline/deliver/answers/gear.py:619-624`).
  "any" (points limited but not to 1) correctly never says treble. A hook rule held only in part says nothing.
- T1083 item ids (data/src/itemId.ts): one list read by every link reader. Ids are capped at 100 characters. A refused
  start link is now reported, not only logged.
- T1016 (ui/src/replaced.ts, web only): one automatic refresh per kind and release, at most 3 reloads per session, every
  wait bounded at 10 s. Nothing runs on a phone (`replaced.native.ts` is a no-op).
- T1116 (ui/src/notify.ts, apps/mobile notify.native.ts): the token is sent only with the permission. It is re-read on each
  return to the front, and every NotifyPlatform has `onResume` (the web exports no controls).
- T1049 startFollow: pure and bounded. 30 s when nothing is coming, 180 s while a part is still coming.
- PR #265's accessibility: screen-reader labels keep the full part name (`aria` on the place row, `current.name` on the
  map bar). The "Other parts …" line is a 44 px button with its words as its label.
- PR #260: colour only (`palette.salmon.open` on the game-fish bar, word and dot). It is typed, so every palette has it.

## 3. Compatibility

- 0.9.0 app on 0.10.0 data: no file format moves. The candidate's file formats equal production r-0aec88ed3edb's
  (compared from both manifests). The new top-level `water_digests` key is ignored by 0.9.0's `parseManifest`. The
  new salmon `bk` field (T1029) is ignored by 0.9.0: its decoder makes no unknown-key check. The feed index loses
  `sha256/changed/failures/header/unresolved/texts` (T905), and none of them is read by the 0.9.0 app (`SalmonFeedRegion`
  at v0.9.0 has no such field). With #265's re-cut, the `near:inside:<area>` end token is named by 0.9.0's `spanName`
  through its existing `near:` branch (`ends.ts` at v0.9.0). The PR states this and the code agrees. Not run.
- 0.10.0 app on 0.9.0 data (a phone offline on its old set): `bk` absent means no bank cue. `changed_waters` absent means
  the inbox says nothing. `facts.runs` exists in old data, so #265's "data's own label" works. I found nothing that breaks.
- The candidate manifest has no `minAppVersion` or `published` yet. Production had 0.8.4. These are publish stamps
  derived by `pipeline/deliver/release/app_gate.py`. The pipeline reviewer should confirm it does not stamp 0.10.0,
  which would leave 0.9.0 phones on the old data.

## 4. Verdict

Ship the release branch with #260 as it is. Ship #265 only after fixing HIGH 1: it is a one-line guard and one test.
Without the fix, #265 must not go in, because a tap on the Fraser below Mission (or 28 other tidal river mouths) would
crash the app. Fix MED 2 (one word) in the same pass.

## Picks for the owner

1. PR #265 (no "Part n of m") and the tidal crash:
   a) Fix the guard plus one test, then pick it (recommended).
   b) Leave #265 out of 0.10.0.
   c) Pick it as is (not advised: a crash on 29 waters).
2. The privacy page's "From version 0.9.1":
   a) Change it to 0.10.0 now (recommended).
   b) Keep it if a 0.9.1 will ship first.
3. The /gauges search script missing from the page's script list:
   a) Add one sentence in this release (recommended).
   b) Leave it for the hardening release with T1148.

## NEW TICKET lines

- NEW TICKET: T1140 follow-up — a tidal piece's page (the Fraser below Mission, the Coquitlam's mouth) throws in
  `partsOthersOf`; guard it and pin it with a tidal-section open on Regulations and Conditions (only if #265 lands
  before the fix).
- NEW TICKET: privacy page names version 0.9.1 for the T1116 token rule; and lists no /gauges search script.
- NEW TICKET (optional, hardening): a top-level error boundary, so one render throw shows an error page with Try again
  instead of a blank app.

## Not verified

- I did not open the app or tap a tidal section on a device or in the web build. The crash is from reading the code and
  the release data (about 85% sure). The one doubt is whether tidal sections are drawn as tappable features in the tiles.
  The core file maps them to the river, and the tidal-piece test says "a tap", so I believe they are.
- I ran no tests (rules: no full suites). Only #265's CI status was read.
- I did not review T1027 (R8 keep rules), T1058 (Gradle), T1072/T1076 (store pictures), T1041 (ledger tool) or the
  T1029 map paint expressions line by line. They are build or tooling, or visual only.
- I did not review the feeds worker's T905 state move beyond confirming that the 0.9.0 app reads none of the moved keys.
- Pipeline changes (#264, the deliver half of #265, the `minAppVersion` stamp) are the other reviewer's.
