# T1151 scoping: braids, side channels and parts (read-only, 2026-11-25 night)

Data: the candidate release r-71d09ad82e81 as it sits in the main checkout (`data/generated/bundle/bundle.sqlite`,
12:57; atlas `data/generated/atlas/full`, 03:21; tiles `data/generated/tiles`, 12:49). That is BEFORE T1146's walk
fix (#264); where T1146 changes a number I say so, from T1146's own measured diff. Code read at origin/main 4f5109144
and, for tonight's join rule, the local branch `fix/T1140-part-label` (cf449ed75, not pushed; PR #265 is older).
Scripts and raw output: `night/T1151-scoping/` (`count.py`, `count2.py`, `count3.py`, `cases.py`, `counts*.txt`).

## The short answer

- **Braids are not why waters have extra parts.** 15,782 side-channel groups sit on named rivers. 14,997 of them
  (95%) are already in the same part as the river beside them. Only 29 parts in multi-part waters are made of side
  channels alone (26 of them are T1140's nameless parts), and about 22 will remain after T1146.
- **Those parts exist because a rule reaches the river but not the channel, never because the channel is small.**
  The causes are: a park or WMA judged by overlap (T1149), a river that is a region or MU line, a canal piece the
  walk will not enter, a licensing or salmon stretch cut at a different place on the braid, and real closures
  (reserves, a national park). If small braids were deleted by size, the real closures would go too. The Gordon's
  closed channel inside Pacific Rim National Park Reserve is 46 m long.
- **The map clutter is real, but it is a look problem, not a parts problem.** The Halfway River has 299 side-channel
  sections against 16 on its main line (235 km of channel beside 291 km of river). Side channels are only 1.2% of
  the stream tile layer's bytes, so tile size is no reason to act either way.
- **Recommendation:** one rule for where every channel joins, computed once in the atlas. Then a side channel takes
  its river's rules at that point, unless an area closure covers it or a rule names it. Do this after T1149. The
  look is improved in the app, not by deleting lines.

## 1. How side channels exist today

**In FWA.** Every stream line has an edge type. "Main flow" is 1000/1050/1200/1250. "Side channel" is 1100/1350.
1150 is in neither group, and 2300 is a man-made connector, treated as a canal and a barrier
(`pipeline/common/fwa_edge_types.py:8-39`). A braid is the main blue line plus one blue line per channel, and the
channels carry the river's watershed code.

**In the atlas (`pipeline/atlas/build.py`).**
- Braids are already simplified before any cut (`build.py:736` `prune_graph`; `--no-simplify-braids` off by
  default, `:364-370`). The prune drops an unnamed channel that leaves the river and comes back to it with nothing
  else of its own (`graph/prune.py:1-45`, `prune_mainstem_loops` `:448`). A creek flowing into a dropped channel is
  moved onto the channel's exit. "Nests" (loops inside loops) keep only the channels some water needs to get
  somewhere (`graph/nests.py:1-25`).
- Last build (`data/generated/atlas-next.log:59-77`): 46,772 loop pieces were removed. 2,550 creek mouths were moved,
  by a median of 228 m (p99 2.2 km, max 5.0 km). 34,523 nests went from 54,722 channels to 6,747. 515,781 unnamed
  headwater leaves were also pruned.
- The prune **never** removes a named channel or a dead-end channel, meaning one that leaves and never returns: a
  distributary, a delta channel, or a channel into a pond (`build.py:364-365`). That is why braids survive "at the
  mouth".
- Cuts. A curated, gauge or length cut is carried across every braid of the river that rejoins on both sides
  (the braid sweep, `splits/braid_sweep.py:1-40`). Last build: 66 braid cuts; 21 refused "one side", 9 refused
  "another water" (`atlas-next.log:94`). An area (reserve, park) is cut where each line crosses its polygon, or, for
  parks and WMAs (`cut: false`), not cut at all. Membership there goes by overlap (`splits/border.py:327`
  `mark_inside_areas`).

**In the reach step (rules to sections).**
- A stretch rule ("from A up to B") is placed by route measure on the cut's own blue line. Braids are then placed by
  where both their ends attach, as connected groups (`atlas/reach/extent.py:316` `_by_measure`). Pieces that touch
  nothing are placed by their own blue line (`:477`), then by their flow path (`:503`). Unplaceable pieces are
  reported, never guessed.
- A whole-water or tributary rule walks the graph (`atlas/graph/tributaries.py`, `expand` `:1401`). Since T1146
  (`A_SIDE_CHANNEL_GOES_WITH_ITS_WATER`, `:1097`; `_side_channel_seeds` `:1129`), a walked water's no-main-flow
  pieces go with it, when every piece of the same water they touch was walked. A canal (2300) is still a barrier
  (`may_enter` `:847`).
- A DFO place that names a river also holds that river's own named side-channel items (`atlas/reach/channels.py:1-25`).
- Unnamed lakes on the main flow count as the river (`extent.py:850` `river_widenings`). A pond on a side channel
  does not.

**In the bundle (parts).**
- Each section of a named water has `section_span` (`pipeline/deliver/bundle/schema.sql:108-126`): metres along the
  main stem, its end tokens, and `off_stem` = 1 for a side channel or braid. A side channel carries the stem measure
  where it flows back in, or NULL where it never does.
- A part is a connected run of one water's sections that share every one of: the rule set, the licensing set, the
  province exceptions, steelhead water and presence, "mostly no-access land", and the DFO salmon chain
  (`deliver/bundle/derived.py:247` `part_rows`, runs at `:201` `_runs_of`). **Any one difference makes a side
  channel its own part.** Parts are put in river order, with a side channel listed right after the main-stem part
  it runs beside (`topology.py:112` `order_parts`).
- Names come from end tokens. For a part with no main stem, tonight's local branch adds the join distance
  (`deliver/bundle/side_channels.py`, below in section 4).

**In the app.**
- `mergeNav` joins two neighbouring parts only when they share item, rule-set group, run and the live salmon
  reading (`app/packages/core/src/waterNav.ts:251-305`). It never joins parts whose rules differ, so a channel with
  different rules always shows as its own part.
- The step buttons walk one line through every part, side channels included (`waterNav.ts:16-24`).
- Drawing. A side-channel line carries `sc: 1` in the tiles and is drawn thinner (`deliver/tiles/export.py:747`,
  `app/packages/map/src/paint.ts:657`, T891). A connected side-channel run appears at one zoom, the zoom of its
  biggest piece (`export.py:755`).

## 2. Counts

How measured: `count.py` / `count2.py` / `count3.py` on the bundle. A "side-channel section" is a section of a named
stream water with `off_stem` = 1. A "channel group" is a connected set of them in one water (`section_touch`).
Lengths come from `section_length`. Unnamed waters are not counted (the bundle groups nothing for them). FWA edge
types are not in the bundle, so these are "off the main stem" counts, not edge-type counts.

**Size.**
- Named stream water: 73,784 sections. 20,885 are off the main stem: 14,343 km, against about 185,000 km of main-stem
  line.
- Side-channel sections by their own length: <100 m 1,271; 100-250 m 4,090; 250-500 m 5,873; 0.5-1 km 5,716;
  1-2 km 2,887; 2-5 km 943; 5 km or more 105.
- 15,782 channel groups. By total length: <100 m 970; 100-250 m 3,177; 250-500 m 4,123; 0.5-1 km 3,833;
  1-2 km 2,193; 2-5 km 1,152; 5 km or more 334.
- 17,438 side-channel sections flow back into the main stem; 9,867 of those are under 500 m. 3,447 never flow back
  (dead ends and distributaries); 1,306 of those are under 500 m.

**Where they sit (channel groups; a group can be in more than one).** "At the mouth" means it rejoins within the
larger of 2 km or 5% of the main-stem length, or it never rejoins but touches a stem piece that low, or it touches
tidal water. The end tokens cannot be used for this: on a side channel, "mouth/source" only means no cut there.
- At the mouth: 1,656 (924 rejoin, 732 never rejoin).
- Into a lake: 1,429.
- Touching or being the river's own polygon: 312.
- Never rejoin at all: 1,668.

**Parts.**
- 20,679 listed parts (with rules, not tidal) over 19,766 waters. 478 waters have 2 or more, holding 1,391 parts. With
  T1140's 56 parts outside B.C. and 29 tidal pieces that makes 1,476, so it matches T1140.
- 35 listed parts have no main-stem section. 6 of them are whole slough or canal waters drawn as polygons (Bowman,
  Caribou Creek slough, Hansen, Lewis and Taylor Sloughs, Seton Canal), not side channels. **29 sit in multi-part
  waters:** T1140's 26 nameless parts plus Klinaklini p1 and Old Kootenay River Channel p1 and p2.
- 16 waters are multi-part only because of such parts. That is before T1146, and was not recounted after.
- What makes those 29 differ from the part they touch: the rule set 25, licensing 6, salmon chain 5, steelhead 1,
  province exception 1. 9 touch no other part of their water.
- After T1146 (its measured diff; the part merges are T1146's prediction): Forsyth p1, Koksilah p1, MacMillan p2,
  Shelagyote p0, Omineca p0 and Manson p0 join their neighbours. Old Kootenay p1 gains the rule its other pieces
  carry. Halfway p2 shrinks from 12 sections to 3. **About 22 stay**, by cause:

| cause | parts | what fixes it |
|---|---|---|
| Real area closure (inside a reserve or national park) | Squamish p1 1.4 km, Gordon p0 46 m, Okanagan River Oxbows p1 4.5 km | nothing: correct, named by T1140 |
| A rule only on the channel / it flows into another water | Theodosia p1 0.4 km, Snehumption p1 2.9 km | nothing (correct) |
| Park by overlap (Strathcona) | Burman 5.0 km, Bedwell 3.3 km, Rees 0.8 km, Comox 0.2 km, Thelwood 0.9 km | T1149 (cut the park); Thelwood also needs the Westmin answer |
| River is an MU or region line | Campbell p6 0.3 km, Cottonwood p1 0.6 km, West Road p3 0.2 km | an owner pick (below) |
| Canal (2300) barrier or ditch grid | Mahood p1 2.9 km, Stirling p1 1.9 km, Halfway p2 (now about 2.5 km) | an owner pick (below) |
| Head-lake policy | Robertson p1 0.2 km | T1053 policy |
| Added city streams filed under the wrong river | Noons p4 2.2 km, Seymour p3 0.2 km | T1150 |
| Licensing stretch cut at a different place on the braid | Skeena p4 1.5 km | a cleaner cut (option d) |
| Salmon chain only | Klinaklini p1 1.6 km | option c, or the DFO cut |
| Leftover piece | Old Kootenay River Channel (one part, about 4 km) | probably merges; not recounted |

**Side channels placed in a different part from the river beside them** (count2/count3). Of the 15,782 groups:
- 14,997 are in the same part as the stem they touch.
- 661 touch no stem section of their water (they connect through lakes or ponds).
- 73 are in a different part from every stem section they touch.
- 51 touch the stem of their own part and of another part (they run past a boundary).
- These 124 groups are spread over 58 waters.
- What differs across those pairs: the rule set 73, salmon chain 30, licensing 16, steelhead 2.
- The rules that differ most:

| rule | pairs | what it is |
|---|---|---|
| Strathcona Park waters | 18 | park by overlap |
| Region 7A base rules | 15 | river on a region line (Fraser, West Road, Cottonwood) |
| Region 5 base rules | 9 | same |
| Peace River, Hwy 29 to Site C | 8 | the Halfway's channels; T1146 fixes most |
| Creston Valley WMA | 6 | WMA by overlap |
| Steelhead | 6 | |
| Reserve closures | 5 | real area cuts |

- Worked case, **Goat River (Creston, gnis:11220)**. Part 0 is one main-stem section of 24 km carrying the Creston
  Valley WMA rules (`r4:creston_valley_wildlife_management_area_cvwma_waters` r1, r2). Its three channels at km
  7.7, 9.3 and 9.9 (346 m, 412 m, 373 m) do not carry those rules, so they are listed in part 1, the upper river,
  although they lie beside part 0. This is the "sections should split more cleanly" picture. The cause is the WMA
  being judged by overlap (the T1149 family), not the braid.

**The map's load.**
- The waters with the most side-channel sections: Stikine 386, Muskwa 308, Halfway 299, Kechika 287, Liard 255,
  Prophet 179, Skeena 178, Iskut 174, McGregor 161, Akie 159.
- Halfway River: 274 sections flow back (205 km; 109 of them under 500 m), and 32 never do (32 km).
- Tiles: 40,760 of 1,253,106 stream features carry `sc` (3.3%). They hold 33.2 MB of the layer's 2,701 MB of source
  GeoJSON (1.2%). Measured with grep and wc on `tiles/layers/stream.geojsonl`.
- So removing every side channel would save roughly 1% of the stream tiles: about 2 MB of the 198 MB
  `atlas.pmtiles`. That is an estimate that assumes tiles shrink in proportion; it was not built.

## 3. Options

Each option: what it does to rule bindings, to the map, to tile size, and its cost and risk.

**(a) Merge braids under a length or width into the main stem in the atlas** (an extra prune by size).
- Bindings:
  - Every rule on a dropped channel is gone, and creek mouths move onto the channel's exit (today's move: median
    228 m, up to 5 km).
  - Of the ~22 remaining parts, a 500 m limit removes 7 (Gordon 46 m, Comox, West Road, Robertson, Seymour,
    Campbell, Theodosia).
  - **Gordon is a national park reserve closure, and Theodosia is a real rule.** Size-only pruning hides closed water.
  - The other 15 are longer and stay.
- Width: FWA lines have no width. Only polygons do, so width means option (b).
- Map: simpler on the north-east braided rivers (up to 9,867 named rejoining channels under 500 m, plus unnamed
  ones). But the map would draw one line where an angler standing there sees several channels.
- Tiles: about 1% at most (above).
- Cost: L (atlas rebuild about 31 min, reach, tiles, deliver; diff every binding, per
  `split-fix-changes-trib-walk`).
- Risk: high. A dropped channel can never be named by a later rule. Survivors survive the existing prune for a
  reason (named, dead end, a creek's only route); why each one survived was not measured (heavy, see
  `T1151-scoping/why_survived.NOT_RUN.md`).
- Verdict: wrong tool for parts. Only a trial for the look, unnamed rejoining loops only, never a channel whose part
  differs.

**(b) A channel lying on its river's own polygon is the river.**
- Bindings: such channels take the river's rules. About 312 groups touch or are the river polygon (2%). Among the
  stemless parts only Halfway p2's canal piece and Okanagan River Oxbows p1 qualify. The Oxbows is a named water
  inside an ecological reserve, so it would be exempt.
- Map: the lines inside a wide reach could be hidden, because the polygon already draws the water.
- Tiles: tiny.
- Cost: S-M (reach rule plus a reach-only rerun, tiles, deliver).
- Risk: low. It is a subset of (c).

**(c) A side channel takes its river's rules where it joins, and forms no part unless a rule names it or an area
covers it.**
- Bindings:
  - Merges the canal, MU, region, licensing and salmon-chain cases, and most of the 124 misplaced groups. Halfway,
    Goat (once the WMA is fixed), Skeena p4, Klinaklini and Campbell come out as one clean part.
  - Keeps Squamish, Gordon and Oxbows (area closures) and Theodosia and Snehumption (their own rule).
  - **Order matters:** done before T1149, the Strathcona channels would pick up the park rule that the straddling
    river wrongly carries. That spreads an error instead of removing a part.
  - Region-line rivers: a channel physically on the other region's side would take the river's region. That needs
    the owner's word.
- Map: no lines change, and there are fewer separate highlights.
- Tiles: none.
- Cost: M-L (a reach rule, a reach-only rerun, tiles plus deliver, the full binding diff). It needs one join point
  per channel (section 4).
- Risk: medium. It is policy (it overrides "a rule's extents are its own" for unnamed channels), and needs a build
  check that names every part left with no main stem and its reason.

**(d) Cleaner section splits.**
- Where splits are unclean today:
  1. Parks and WMAs judged by overlap (Strathcona 18 pairs, Creston 6): T1149's cut-or-mark.
  2. Licensing and DFO stretch ends crossing a braid at a different place from the main stem (Skeena p4). Whether the
     braid sweep covers those cuts was not verified.
  3. The sweep's refusals (21 "one side", 9 "another water" on the last build).
  4. Region-line rivers.
- Rule: every part boundary that is a point on the river (curated, gauge, DFO, licensing) is one perpendicular line
  across the whole braid. A boundary that is a polygon (a reserve) stays on the polygon's edge, because that edge is
  real.
- Bindings: only those cases. Map: the part edges line up across the floodplain.
- Cost: M (atlas). Risk: medium (a split change changes the walk).

**(e) Display only. The data keeps the lines; the app thins or groups them.**
- Already done: side channels drawn thinner, and a side-channel run appears whole at one zoom.
- More is possible:
  - The parts list puts a side-channel part under the part it lies beside, as one indented row ("side channel:
    closed, inside Baynes Island Ecological Reserve"), not a sibling row.
  - The map highlights a selected part together with the side channels in it.
  - Lines inside the river polygon can be hidden.
- Never hide a line whose part or paint differs from its neighbour's (paint and parts never diverge).
- Bindings: none. Tiles: none. Cost: S-M (app). Risk: low.

**(f) Nothing more after T1146 + T1140** (with T1149 and T1150 as planned).
- About 10 artefact parts remain (Campbell, Cottonwood, West Road, Mahood, Stirling, Halfway, Robertson, Skeena p4,
  Klinaklini, Old Kootenay), each named by T1140's label.
- The map look is unchanged. Free, but the owner's "consistent way" is not met.

## 4. The join rule (tonight's proposal), tested

What is built, on the local branch `fix/T1140-part-label` (`deliver/bundle/side_channels.py`):
- It applies only to the ONE part of a water that has no main stem, and only to sections whose flow never reaches
  the stem.
- It finds the downstream end (from the flow pointer, else both ends).
- If that end touches, within 1 m (`TOUCH_M` `:55`), a named lake on the main line, the part is "into <Lake>".
- If it touches the river's own polygon or an unnamed lake on the main line, it is measured at the main line's
  nearest point, at any distance.
- Otherwise the snap limit is 50 m (`MAX_SNAP_M` `:51`). Beyond it, the part is measured at the nearest point but
  said without "joining" (`how = "nearest"`, `:297`). A channel with no main line to measure gives no distance.
- Names only; the walk binds by its own graph rules.

Worked cases:
- **Halfway p2 (after T1146: the 2.4 km canal piece plus two short stubs).** The canal piece's lower end is on the
  river polygon, so it is measured. The stubs end at pond outlets; whether those ponds lie on the main line was not
  verified. **The names hold, but the part should not exist:** it is a canal-barrier artefact, so the rule names a
  defect.
- **Squamish p1, Gordon p0.** Named by the reserve or park they lie inside; the join rule is not needed. Holds.
- **Okanagan River Oxbows p1.** Polygon pieces touching two water bodies; a later commit (37b7bc906) picks between
  them by id. **Breaks mildly:** the pick is arbitrary, and could name the less useful of the two.
- **Stirling p1.** Into Acme Lake, a named lake on its main line, so "into Acme Lake". Holds. The part itself is a
  canal artefact.
- **Robertson p1.** Drains Boot Lagoon into Great Central Lake, which touches Robertson Creek's main line at its head.
  So the rule says "side channel into Great Central Lake". True on the ground, but it is a feeder of the lake above
  the river's top, not a side channel of the creek. **Breaks on meaning.**
- **MacMillan p2 (merges after T1146) and Theodosia p1.** They are distributaries: they leave the river and end in
  ANOTHER water (Diana Lake in another basin; Powell Lake). The downstream end touches nothing of the river, so the
  rule falls to "nearest", measured from the far end. **Breaks:** for a channel that leaves and never returns, the
  join is where it LEAVES (its upstream end).
- **Noons p4, Seymour p3.** Added city streams on the wrong river; the "own name" rule names them first. The join rule
  would have given a distance on the wrong river. It holds only because a rule ahead of it catches them.
- **Cottonwood, West Road, Campbell, Burman, Bedwell, Rees, Comox.** Their flow reaches the stem, so the flow join
  is used. Holds.
- **Skeena p4.** Has real end tokens; not a join case. Its problem is the cut (option d).

Where it breaks in general:
1. Distributaries: it measures the downstream end, where the leaving end is the honest join.
2. It is a naming rule in deliver, while binding uses a different notion in the walk. A channel can be named
   "joining 12 km" by one rule and bound by another.
3. It applies only to a water's single stemless part. A water with several uses "near <feature>" names, so there are
   two rules for one question.
4. The 50 m limit now changes only the word: a channel 49 m away reads "joining", one at 51 m does not.
5. The 1 m touch needs FWA lines that end exactly on polygon edges. Added streams do not.

Replacement proposed (one rule, computed once in the atlas and read by the walk, the deliver names and the build
check). For every side-channel group, in order:
1. Where its flow re-enters its own water's main stem.
2. Else, where its flow LEAVES the main stem (a distributary).
3. Else, where an end touches its own river's polygon, an unnamed lake on the main line, or a named lake on the main
   line (the lake names it).
4. Else, the nearest point within 50 m.
5. Else, no join, listed by the build check (never guessed).
On a tie between two water bodies: the one on the main stem nearer the mouth, not the lower id.

## 5. Recommendation and staged plan

1. **Now (0.10.0):** ship T1140's names as built. Optional small fix: measure a distributary at its leaving end
   (affects MacMillan and Theodosia only). No atlas change.
2. **Hardening release, with T1149 first:**
   - NEW TICKET (one join point per channel, in the atlas).
   - Then option (c), gated: a reach-only rerun, a diff of every rule binding, the owner's picks on canals and
     region lines.
   - A build check: "a part with no main stem exists only where an area closure covers it or a rule names it".
     That is T1151's acceptance.
   - Expected result: about 5 named side-channel parts province-wide (Squamish, Gordon, Oxbows, Theodosia,
     Snehumption) and no artefact parts.
3. **Same release or next, the look:**
   - (e) in the app: side-channel rows folded under their neighbour, and the part highlight taking its channels.
   - (b) hiding lines inside the river polygon.
   - Only if the pictures say the map is still too busy: a side-atlas trial of (a) on unnamed rejoining loops under
     a length the owner picks, with a binding diff. A channel whose part differs is never pruned.
4. **(d)** after T1149: check whether the braid sweep covers DFO and licensing cuts (Skeena p4). Extend it if not.

**Pictures the owner should see.** None were made tonight: no builds, and no screenshots were taken. Each needs the
web app on a side release, or the current one for "before".
1. **Halfway River where it meets the Peace** (his example). Before: the braided river with p2's three channels
   lit as their own part. After (c): one part. After (a) at 500 m: the same view with fewer lines, to judge the look.
2. **Gordon River mouth, Pacific Rim National Park Reserve.** Before: the 46 m closed channel. After (a): it is gone
   and the closure vanishes from the map. This is the case against pruning by size.
3. **Squamish River at Baynes Island Ecological Reserve.** Stays its own part, now named "inside Baynes Island
   Ecological Reserve". This is what a legitimate side-channel part looks like.
4. **Rees Creek and Burman River by Strathcona Park.** Before: the river carries the park rule 9.6 km outside the park
   while its channels do not. After T1149 plus (c): one part each. With (c) alone the channels turn park-ruled,
   which is wrong.
5. **Goat River near Creston (WMA).** Before: three channels at km 7.7 to 9.9 listed in the upper part, beside the
   lower one. After T1149-style marking plus (c): with the part they lie beside.
6. **Skeena at the Exchamsiks** (p4). Before: the Classified Waters edge sits 1 km apart on the braid and the main
   stem. After (d): one line across.
7. **Stikine or Muskwa at z10, z12 and z14.** Today's density, then with (e) (lines inside the polygon hidden).
8. **MacMillan Creek into Diana Lake.** Where the join rule breaks: the label measured from the Diana Lake end,
   against the leaving end.

## Picks for the owner

1. How should side channels stop making their own parts?
   - **(A, recommended)** A channel takes its river's rules where it joins, unless an area closure covers it or a
     rule names it. Done after the park fix (T1149).
   - (B) Delete small braids under a size in the atlas.
   - (C) Leave them as parts and name them (today's T1140).
2. A canal piece (FWA "man-made") inside a river's own channel network (Halfway, Mahood, Stirling):
   - **(A, recommended)** Goes with its river; the walk still never climbs past it into other water.
   - (B) Stays its own part.
3. A river that is a region or MU line, with its channel wholly on the other side (Cottonwood, West Road, Campbell):
   - **(A, recommended)** The channel follows the river beside it (one answer per stretch, as "mark, don't cut").
   - (B) The channel keeps its own side's rules.
4. The map's busy braids:
   - **(A, recommended)** App-only: side channels folded under their part in the list, and lines inside the river's
     polygon hidden.
   - (B) Also a side-atlas trial of pruning unnamed short braid loops, shown as pictures first.
   - (C) Nothing.
5. The "where a channel joins" rule:
   - **(A, recommended)** Tonight's proposal plus "a channel that leaves and never returns joins where it leaves",
     computed once in the atlas and used for both rules and names.
   - (B) The proposal as shipped in 0.10.0.
   - (C) Drop the distance; say only "side channel".

## NEW TICKET

- NEW TICKET: One join point per side channel, computed in the atlas (flow back in; else where it leaves; else
  touching its river's water body; else 50 m; else listed), read by the reach walk, the deliver names and a build
  check.
- NEW TICKET: A side channel takes its river's rules at its join point unless an area closure covers it or a rule
  names it (after T1149; reach-only rerun, full binding diff); build check "no part with no main stem without an
  area or a naming rule".
- NEW TICKET: Parts list and map highlight: a side-channel part is shown under the part it lies beside; lines inside
  the river's polygon hidden (app only).
- NEW TICKET: Audit why about 10,000 short side channels survive the braid prune (graph-side, heavy; spec in
  `night/T1151-scoping/why_survived.NOT_RUN.md`).
- NEW TICKET (check first): Does the braid sweep carry DFO and licensing stretch cuts across braids (Skeena p4 at the
  Exchamsiks)?

## Not verified

- Every count is from the candidate before T1146. The post-T1146 part counts are T1146's prediction, not a recount.
- FWA edge types per section were not read: the bundle does not hold them, and the graph is too big to load
  tonight. "Side channel" here means off the main stem.
- Why each short channel survived the prune (named, dead end, a creek's route, other code): not measured.
- Geometry was not used. "Into a lake" and "river polygon" come from end tokens and section touches. "At the mouth"
  comes from stem measures, with a threshold I chose (2 km or 5%).
- The Goat River reading (channels outside the WMA polygon) is inferred from the rule diff, not checked against the
  polygon.
- Which two Halfway stubs remain after T1146, and whether their ponds lie on the main line.
- Whether the braid sweep covers DFO and licensing cuts.
- The tile-size estimate assumes the tiles shrink in proportion to the source GeoJSON.
- Theodosia's channel being a diversion into Powell Lake is my memory of the place (a guess). The data says only
  that it carries the Powell Lake rule.
- No pictures were made.
